"""SciPy cobyqa constrained NLP adapter."""

import numpy as np
from scipy.optimize import NonlinearConstraint


def build_options(problem, cfg, constraints, gradient, options):
    kwargs = dict(
        constraints=[NonlinearConstraint(constraints, 0.0, np.inf)],
        options={
            **dict(
                maxiter=cfg.get("maxiter", 300),
                maxfev=cfg.get("max_function_evaluations", 5000),
                initial_tr_radius=0.12,
                final_tr_radius=1e-7,
                feasibility_tol=1e-10,
            ),
            **options,
        },
    )
    return kwargs
