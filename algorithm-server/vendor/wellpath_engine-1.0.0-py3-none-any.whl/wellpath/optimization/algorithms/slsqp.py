"""SciPy slsqp constrained NLP adapter."""


def build_options(problem, cfg, constraints, gradient, options):
    kwargs = dict(
        jac=lambda z: gradient,
        constraints=[dict(type="ineq", fun=constraints)],
        options={**dict(maxiter=cfg.get("maxiter", 300), ftol=1e-9), **options},
    )
    if callable(getattr(problem, "equality_constraints", None)):
        kwargs["constraints"].append(dict(type="eq", fun=problem.equality_constraints))
    return kwargs
