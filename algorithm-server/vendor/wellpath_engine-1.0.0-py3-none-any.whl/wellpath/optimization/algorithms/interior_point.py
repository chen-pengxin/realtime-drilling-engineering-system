"""SciPy interior_point constrained NLP adapter."""

import numpy as np
from scipy.optimize import BFGS, NonlinearConstraint


def build_options(problem, cfg, constraints, gradient, options):
    kwargs = dict(
        jac=lambda z: gradient,
        hess=lambda z: np.zeros((len(z), len(z))),
        constraints=[NonlinearConstraint(constraints, 0.0, np.inf, jac="2-point", hess=BFGS())],
        options={
            **dict(
                maxiter=cfg.get("maxiter", 300), gtol=1e-7, xtol=1e-9, barrier_tol=1e-8, verbose=0
            ),
            **options,
        },
    )
    return kwargs
