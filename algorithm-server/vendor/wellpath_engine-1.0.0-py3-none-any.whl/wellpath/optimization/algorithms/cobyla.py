"""SciPy cobyla constrained NLP adapter."""


def build_options(problem, cfg, constraints, gradient, options):
    kwargs = dict(
        constraints=[dict(type="ineq", fun=constraints)],
        options={
            **dict(
                maxiter=cfg.get("max_function_evaluations", 5000),
                rhobeg=0.12,
                tol=1e-7,
                catol=1e-10,
            ),
            **options,
        },
    )
    return kwargs
