"""Shared feasible-start construction."""

import time

import numpy as np
from scipy.optimize import least_squares


def feasible_starts(problem):
    cfg = problem.cfg.get("solver", {})
    clock = time.perf_counter()
    rng = np.random.default_rng(cfg.get("random_seed", 7))
    starts = []
    log = []
    for i in range(cfg.get("initial_search_attempts", 8)):
        start = time.perf_counter()
        result = least_squares(
            lambda z: np.minimum(problem.evaluate(z)["g"] - 2e-7, 0),
            problem.seed(rng, i),
            bounds=(0.0, 1.0),
            max_nfev=cfg.get("feasibility_max_nfev", 400),
            ftol=1e-10,
            xtol=1e-10,
            gtol=1e-10,
        )
        check = problem.check(result.x)
        fine = problem.check(result.x, dense=True) if check["feasible"] else check
        log.append(
            dict(
                attempt=i + 1,
                elapsed_seconds=time.perf_counter() - start,
                nfev=int(result.nfev),
                check=check,
                fine_check=fine,
            )
        )
        print(f"Initial {i + 1}: feasible={fine['feasible']}, SF={fine['minimum_sf']}", flush=True)
        if fine["feasible"]:
            starts.append(result.x.copy())
            if len(starts) >= cfg.get("optimization_starts", 1):
                break
    return starts, dict(
        elapsed_seconds=time.perf_counter() - clock,
        attempts=log,
        status="feasible" if starts else "search_failed_not_proof_of_infeasibility",
    )
