"""Construct exact endpoint/tangent splices using a two-angle intermediate state.

For prescribed start/middle/end attitudes and azimuth winding, constant-toolface
arc displacements are linear in their lengths. Solve the 3x3 position system,
then independently check the exact existing integration and collision kernels.
"""

import argparse
import time
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree

from wellpath.anticollision.uncertainty import path_at
from wellpath.geometry.arc import tangent
from wellpath.geometry.segments import segment_state
from wellpath.planning.geometry_problem import WellControlProblem
from wellpath.workflows.local_replanning import LocalReplanningProblem, configuration, load_data
from wellpath.workflows.scenario_replanning import save_json

gx, gw = np.polynomial.legendre.leggauss(96)
gx = (gx + 1) / 2
gw = gw / 2


def arc_units(i0, a0, i1, da):
    i0, a0, i1, da = np.broadcast_arrays(i0, a0, i1, da)
    logratio = np.log(np.tan(i1 / 2) / np.tan(i0 / 2))
    w = np.arctan2(da, logratio)
    theta = (i1 - i0) / np.cos(w)
    ii = i0[..., None] + (i1 - i0)[..., None] * gx
    aa = a0[..., None] + (da / logratio)[..., None] * np.log(
        np.tan(ii / 2) / np.tan(i0[..., None] / 2)
    )
    v = np.stack([np.sin(ii) * np.cos(aa), np.sin(ii) * np.sin(aa), np.cos(ii)], axis=-1)
    unit = np.einsum("...ij,i->...j", v, gw)
    return unit, theta, w


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", type=float, default=707.0)
    ap.add_argument("--end", type=float, default=1300.0)
    ap.add_argument("--output", type=Path, required=True)
    a = ap.parse_args()
    a.output.mkdir(parents=True, exist_ok=True)
    begin = time.perf_counter()
    source = a.output / "backup_before_replan.xlsx"
    data = load_data(a.start, a.end, source if source.exists() else None)
    cfg, settings = configuration(data, a.end)
    g = WellControlProblem(cfg)
    tree = cKDTree(np.vstack([n["scan"]["positions"] for n in data["neighbors"]]))
    i0, a0 = np.deg2rad([cfg["start"]["inclination_deg"], cfg["start"]["azimuth_deg"]])
    it, at = np.deg2rad([cfg["target"]["inclination_deg"], cfg["target"]["azimuth_deg"]])
    # Dense inclinations near the initial direction retain small steering loops.
    im = np.unique(np.r_[np.linspace(0.05, 8, 50), np.linspace(8.5, 119.5, 120)])
    da = np.arange(-540.0, 541.0, 3.0)
    IM, DA = np.meshgrid(np.deg2rad(im), np.deg2rad(da), indexing="ij")
    keep = (abs(IM - i0) > 1e-7) & (abs(IM - it) > 1e-7)
    IM = IM[keep]
    DA = DA[keep]
    AM = a0 + DA
    u1, theta1, w1 = arc_units(i0, a0, IM, DA)
    firstvalid = (theta1 > 0) & (theta1 < np.deg2rad(150.0))
    IM, DA, AM, u1, theta1, w1 = [v[firstvalid] for v in [IM, DA, AM, u1, theta1, w1]]
    tm = np.column_stack([np.sin(IM) * np.cos(AM), np.sin(IM) * np.sin(AM), np.cos(IM)])
    _logs = []
    candidates = []
    systems = 0
    for winding in range(-2, 3):
        u3, theta3, w3 = arc_units(IM, AM, it, at + 2 * np.pi * winding - AM)
        matrices = np.stack([u1, tm, u3], axis=-1)
        valid = (theta3 > 0) & (theta3 < np.deg2rad(150.0)) & (abs(np.linalg.det(matrices)) > 1e-10)
        ids = np.flatnonzero(valid)
        systems += len(ids)
        lengths = np.linalg.solve(
            matrices[ids], np.broadcast_to(g.pt - g.p0, (len(ids), 3))[..., None]
        )[..., 0]
        good = (lengths >= g.lower[:, 2]).all(axis=1) & (lengths <= g.upper[:, 2]).all(axis=1)
        d1 = np.rad2deg(theta1[ids]) * 30 / lengths[:, 0]
        d3 = np.rad2deg(theta3[ids]) * 30 / lengths[:, 2]
        good &= (d1 >= 0.01) & (d1 <= 5.999) & (d3 >= 0.01) & (d3 <= 5.999)
        for j, L, k1, k3 in zip(ids[good], lengths[good], d1[good], d3[good]):
            controls = np.array(
                [[k1, np.rad2deg(w1[j]), L[0]], [0.0, 0.0, L[1]], [k3, np.rad2deg(w3[j]), L[2]]]
            )
            # Exact original segment integrator: positions remain linear in L.
            tmid = tangent(np.rad2deg(IM[j]), np.rad2deg(AM[j]) % 360)
            exact1 = segment_state(
                np.zeros(3),
                g.t0,
                np.rad2deg(theta1[j]) * 30,
                controls[0, 1],
                1.0,
                "constant_toolface",
            )[0]
            exact3 = segment_state(
                np.zeros(3),
                tmid,
                np.rad2deg(theta3[j]) * 30,
                controls[2, 1],
                1.0,
                "constant_toolface",
            )[0]
            exactL = np.linalg.solve(np.column_stack([exact1, tm[j], exact3]), g.pt - g.p0)
            if np.any(exactL < g.lower[:, 2]) or np.any(exactL > g.upper[:, 2]):
                continue
            controls[:, 2] = exactL
            controls[[0, 2], 0] = np.rad2deg([theta1[j], theta3[j]]) * 30 / exactL[[0, 2]]
            if np.any(controls[:, 0] > 5.999) or np.any(controls[[0, 2], 0] < 0.01):
                continue
            z = g.pack(controls)
            e = g.evaluate(z)
            query = np.unique(np.r_[np.linspace(0, exactL.sum(), 180), np.cumsum(exactL)])
            p, _, _ = path_at(g, e, query)
            distance = float(tree.query(p)[0].min())
            candidates.append(
                dict(
                    minimum_center_m=distance,
                    controls=controls,
                    maximum_exact_position_error_m=float(np.linalg.norm(e["position_error"])),
                    middle_inclination_deg=float(np.rad2deg(IM[j])),
                    middle_unwrapped_azimuth_deg=float(np.rad2deg(AM[j])),
                    end_winding=winding,
                )
            )
        print(
            "winding",
            winding,
            "bounded candidates",
            int(good.sum()),
            "exact total",
            len(candidates),
            flush=True,
        )
    candidates.sort(key=lambda c: -c["minimum_center_m"])
    save_json(a.output / "splice_grid_top_candidates.json", candidates[:50])
    info = dict(
        start_MD_m=a.start,
        end_MD_m=a.end,
        linear_systems_solved=systems,
        valid_exact_candidates=len(candidates),
        wall_seconds=time.perf_counter() - begin,
        best_sampled_center_m=None if not candidates else candidates[0]["minimum_center_m"],
        construction="Intermediate inclination/azimuth + azimuth winding; solve exact length-linear 3x3 system; enforce positive lengths, curvature<6 and bend<150; 180-point center prescreen",
    )
    save_json(a.output / "splice_grid_summary.json", info)
    print(info, flush=True)
    problem = LocalReplanningProblem(cfg, data, settings)
    for index, c in enumerate(candidates[:30]):
        if c["minimum_center_m"] < 5.2:
            break
        z = problem.pack(c["controls"])
        check = problem.final_verify(z)
        print(
            "exact final candidate",
            index,
            check["check"]["feasible"],
            check["check"]["minimum_sf"],
            check["check"]["minimum_centerline_distance_m"],
            flush=True,
        )
        if check["check"]["feasible"]:
            save_json(a.output / "initial_controls.json", c["controls"])
            save_json(
                a.output / "initialization.json",
                dict(
                    status="feasible",
                    elapsed_seconds=time.perf_counter() - begin,
                    method=info["construction"]
                    + " -> Rev0 full history + all-neighbor 1m verification",
                    grid=info,
                    final_check=check["check"],
                ),
            )
            break


if __name__ == "__main__":
    main()
