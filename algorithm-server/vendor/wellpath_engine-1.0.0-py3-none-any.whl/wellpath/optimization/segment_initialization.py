"""Certified necessary-condition checks and shared starts for 1..5 segments."""

import time

import numpy as np
from scipy.optimize import least_squares

from wellpath.planning.geometry_problem import WellControlProblem


def necessary_conditions(problem):
    """Only report infeasibility when a conservative analytical bound proves it."""
    displacement = problem.pt - problem.p0
    distance = float(np.linalg.norm(displacement))
    rho = float(problem.position_tol)
    max_length = float(problem.upper[:, 2].sum())
    checks = [
        dict(
            name="arc_length_at_least_chord",
            passed=max_length >= distance - rho,
            maximum_total_length_m=max_length,
            straight_distance_m=distance,
            target_radius_m=rho,
            required_length_lower_bound_m=max(0.0, distance - rho),
            expression="sum(L_upper) >= ||target-start|| - target_radius",
        )
    ]
    # A single spatial circle plus an optional tangent straight lies in one
    # plane containing the initial tangent. If the endpoint misses the desired
    # point by <=rho, the plane can rotate by at most asin(rho/||d_perp||).
    if problem.arc_segment_model == "minimum_curvature" and problem.segment_types.count("arc") == 1:
        cross = np.cross(problem.t0, displacement)
        perp = float(np.linalg.norm(cross))
        if perp > rho:
            normal = cross / perp
            outplane = float(np.rad2deg(np.arcsin(np.clip(abs(problem.tt @ normal), 0, 1))))
            tolerance = problem.cfg["target"]
            # Triangle inequality on the sphere: angular change from varying I
            # and A is no greater than |delta I|+|delta A| (conservative).
            cone = float(
                tolerance["inclination_tolerance_deg"] + tolerance["azimuth_tolerance_deg"]
            )
            rotation = float(np.rad2deg(np.arcsin(rho / perp)))
            checks.append(
                dict(
                    name="single_arc_planarity",
                    passed=outplane <= cone + rotation + 1e-10,
                    target_tangent_out_of_position_plane_deg=outplane,
                    allowed_attitude_cone_upper_bound_deg=cone,
                    allowed_position_plane_rotation_upper_bound_deg=rotation,
                    displacement_perpendicular_to_start_tangent_m=perp,
                    expression="angle(target tangent, start/displacement plane) <= I_tol + A_tol + asin(rho/||d_perp||)",
                    proof="A circle and its tangent straight are coplanar. Endpoint error rotates this plane by at most asin(rho/||d_perp||); allowed terminal attitude changes direction by at most I_tol+A_tol.",
                )
            )
    return dict(proven_infeasible=any(not c["passed"] for c in checks), checks=checks)


def make_segment_initial(problem):
    """Geometry -> optional geometry restoration -> full constraints -> 1m check.

    Geometry-only rejection avoids expensive uncertainty restoration for a point
    which does not even satisfy position/attitude. All accepted starts are still
    independently checked by the full Rev0 engine.
    """
    begin = time.perf_counter()
    cfg = problem.cfg
    gprob = WellControlProblem(cfg)
    certificate = necessary_conditions(gprob)
    attempts = []
    starts = []
    best = None
    timing = dict(
        geometric_fit_seconds=0.0,
        geometric_feasibility_restoration_seconds=0.0,
        feasibility_restoration_seconds=0.0,
        final_1m_verification_seconds=0.0,
    )
    rng = np.random.default_rng(cfg["solver"]["random_seed"])
    deadline = begin + problem.settings.get("initialization_max_seconds", 90.0)

    class InitialBudget(Exception):
        pass

    def budget():
        if time.perf_counter() > deadline:
            raise InitialBudget()

    def record_best(z):
        nonlocal best
        e = gprob.evaluate(z)
        score = float(
            np.linalg.norm(e["position_error"]) / 0.5
            + np.sum(np.abs(e["angle_errors"])) / 0.5
            + 100 * np.linalg.norm(np.minimum(e["g"][: 4 * gprob.n], 0))
        )
        if best is None or score < best["score"]:
            best = dict(
                score=score,
                normalized_controls=np.asarray(z).tolist(),
                physical_controls=gprob.unpack(z).tolist(),
                geometry_check=gprob.check(z),
            )

    if not certificate["proven_infeasible"]:
        for attempt in range(cfg["solver"]["initial_search_attempts"]):
            entry = dict(attempt=attempt + 1, restoration_seconds=0.0, nfev=0)
            try:
                seed = gprob.seed(rng, attempt)
                record_best(seed)
                fit_begin = time.perf_counter()

                def residual(z):
                    budget()
                    e = gprob.evaluate(z)
                    return np.r_[
                        e["position_error"] / 100.0,
                        e["angle_errors"] / 10.0,
                        np.minimum(e["g"][: 4 * gprob.n], 0.0) * 10.0,
                    ]

                try:
                    fitted = least_squares(
                        residual,
                        seed,
                        bounds=(0.0, 1.0),
                        max_nfev=cfg["solver"]["feasibility_max_nfev"],
                        ftol=1e-11,
                        xtol=1e-11,
                        gtol=1e-11,
                    )
                finally:
                    timing["geometric_fit_seconds"] += time.perf_counter() - fit_begin
                entry["nfev"] = int(fitted.nfev)
                record_best(fitted.x)
                if not gprob.check(fitted.x)["feasible"]:
                    t = time.perf_counter()

                    def feasible_geometry(z):
                        budget()
                        e = gprob.evaluate(z)
                        position = (
                            problem.settings["optimization_target_radius_m"]
                            - np.linalg.norm(e["position_error"])
                        ) / 0.5
                        angles = (gprob.angle_tol - np.abs(e["angle_errors"])) / 0.5
                        return np.r_[
                            min(position, 0.0),
                            np.minimum(angles, 0.0),
                            10 * np.minimum(e["g"][: 4 * gprob.n], 0.0),
                        ]

                    try:
                        fitted = least_squares(
                            feasible_geometry,
                            fitted.x,
                            bounds=(0.0, 1.0),
                            max_nfev=cfg["solver"]["feasibility_max_nfev"],
                            ftol=1e-11,
                            xtol=1e-11,
                            gtol=1e-11,
                        )
                    finally:
                        timing["geometric_feasibility_restoration_seconds"] += (
                            time.perf_counter() - t
                        )
                    record_best(fitted.x)
                entry["geometry_check"] = gprob.check(fitted.x)
                if not entry["geometry_check"]["feasible"]:
                    entry["accepted"] = False
                    entry["stage"] = "geometry_search_failed"
                    attempts.append(entry)
                    continue
                budget()
                check = problem.check(fitted.x)
                if not check["feasible"]:
                    t = time.perf_counter()

                    def full_residual(z):
                        budget()
                        return np.minimum(problem.evaluate(z)["g"] - 1e-6, 0.0)

                    try:
                        fitted = least_squares(
                            full_residual,
                            fitted.x,
                            bounds=(0.0, 1.0),
                            max_nfev=cfg["solver"]["feasibility_max_nfev"],
                            gtol=1e-10,
                            ftol=1e-10,
                            xtol=1e-10,
                        )
                    finally:
                        entry["restoration_seconds"] = time.perf_counter() - t
                        timing["feasibility_restoration_seconds"] += entry["restoration_seconds"]
                    check = problem.check(fitted.x)
                dense = problem.final_verify(fitted.x) if check["feasible"] else None
                if dense is not None:
                    timing["final_1m_verification_seconds"] += dense["check"][
                        "final_verification_seconds"
                    ]
                entry.update(
                    coarse_check=check,
                    final_check=None if dense is None else dense["check"],
                    accepted=dense is not None and dense["check"]["feasible"],
                )
                attempts.append(entry)
                if entry["accepted"]:
                    starts.append(fitted.x.copy())
                    break
            except InitialBudget:
                entry.update(accepted=False, stage="initialization_wall_budget_reached")
                attempts.append(entry)
                break
    elapsed = time.perf_counter() - begin
    timing["coarse_constraint_validation_and_control_seconds"] = max(
        0.0, elapsed - sum(timing.values())
    )
    return starts, dict(
        status="feasible"
        if starts
        else (
            "proven_infeasible_under_configured_constraints"
            if certificate["proven_infeasible"]
            else "initial_search_failed_not_proof_of_infeasibility"
        ),
        elapsed_seconds=elapsed,
        attempts=attempts,
        timing_breakdown=timing,
        necessary_condition_certificate=certificate,
        best_geometry_candidate=best,
        method=f"MC geometric seed -> {problem.arc_segment_model} bounded geometric least_squares -> optional geometric feasibility restoration -> full Rev0 constraints/restoration -> independent 1m verification",
        shared_across_algorithms=True,
    )
