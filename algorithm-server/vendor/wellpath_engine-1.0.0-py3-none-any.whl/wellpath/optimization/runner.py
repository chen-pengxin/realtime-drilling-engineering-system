"""Four actual constrained NLP solvers, timing, common starts and honest status."""

import time

import numpy as np
from scipy.optimize import Bounds, minimize

from wellpath.optimization.algorithms.cobyla import build_options as cobyla
from wellpath.optimization.algorithms.cobyqa import build_options as cobyqa
from wellpath.optimization.algorithms.interior_point import build_options as interior_point
from wellpath.optimization.algorithms.slsqp import build_options as slsqp
from wellpath.optimization.initialization import feasible_starts

ALGORITHM_BUILDERS = {
    "SLSQP": slsqp,
    "trust-constr": interior_point,
    "COBYLA": cobyla,
    "COBYQA": cobyqa,
}
ALGORITHMS = tuple(ALGORITHM_BUILDERS)


class BudgetExceeded(Exception):
    pass


def solve_algorithm(problem, starts, method):
    if method not in ALGORITHMS:
        raise ValueError(f"Choose one of {ALGORITHMS}")
    cfg = problem.cfg.get("solver", {})
    overall = time.perf_counter()
    runs = []
    if not starts:
        return None, dict(
            algorithm=method,
            status="no_feasible_initial_point",
            solver_success=False,
            optimization_seconds=0.0,
            validation_seconds=0.0,
            global_optimum_proven=False,
        )
    length = lambda z: float(problem.unpack(z)[:, 2].sum())
    best = min(starts, key=length).copy()
    origin = "verified_initial_point"
    validation_seconds = 0.0
    initial_length = length(best)
    gradient = np.zeros_like(problem.width)
    gradient[:, 2] = problem.width[:, 2] / problem.scale
    gradient = gradient.ravel()[problem.active]
    for index, z0 in enumerate(starts):
        begin = time.perf_counter()
        last = z0.copy()
        history = []
        evaluations = 0
        incumbent = z0.copy()
        incumbent_length = length(z0)
        maximum = float(cfg.get("max_seconds_per_run", 45.0))
        maxeval = int(cfg.get("max_function_evaluations", 5000))

        def tick(z):
            nonlocal last, evaluations
            last = np.asarray(z).copy()
            evaluations += 1
            if time.perf_counter() - begin > maximum or evaluations > maxeval:
                raise BudgetExceeded()

        def objective(z):
            tick(z)
            return length(z) / problem.scale

        def constraints(z):
            if time.perf_counter() - begin > maximum:
                raise BudgetExceeded()
            return problem.evaluate(z)["g"]

        def callback(z, *args):
            nonlocal incumbent, incumbent_length
            e = problem.evaluate(z)
            if (
                cfg.get("retain_feasible_iterates", False)
                and length(z) < incumbent_length
                and e["g"].min() >= -1e-10
            ):
                if problem.check(z)["feasible"]:
                    incumbent = np.asarray(z).copy()
                    incumbent_length = length(z)
            history.append(
                dict(
                    iteration=len(history),
                    elapsed_seconds=time.perf_counter() - begin,
                    length_m=length(z),
                    maximum_scaled_constraint_violation=float(max(0.0, -e["g"].min())),
                    minimum_sf=e["separation"]["minimum_sf"],
                    position_error_m=float(np.linalg.norm(e["position_error"])),
                    minimum_centerline_distance_m=e["separation"].get(
                        "minimum_centerline_distance_m"
                    ),
                    normalized_controls=np.asarray(z).tolist(),
                )
            )

        options = cfg.get("algorithm_options", {}).get(method, {})
        kwargs = ALGORITHM_BUILDERS[method](problem, cfg, constraints, gradient, options)
        interrupted = False
        try:
            # trust-constr may otherwise evaluate negative curvature/length at
            # intermediate bound-violating trials. Opt in without altering the
            # legacy default; other methods already respect their box bounds.
            keep_bounds = method == "trust-constr" and cfg.get(
                "keep_variable_bounds_feasible", False
            )
            result = minimize(
                objective,
                z0,
                method=method,
                bounds=Bounds(np.zeros_like(z0), np.ones_like(z0), keep_feasible=keep_bounds),
                callback=callback,
                **kwargs,
            )
            candidate = result.x
            success = bool(result.success)
            message = str(result.message)
            nit = int(getattr(result, "nit", len(history)))
        except BudgetExceeded:
            candidate = last
            success = False
            interrupted = True
            message = "Configured time/function-evaluation budget reached; no convergence claim."
            nit = len(history)
        solver_time = time.perf_counter() - begin
        verify_start = time.perf_counter()
        coarse = problem.check(candidate)
        fine = problem.check(candidate, dense=True) if coarse["feasible"] else coarse
        verification_time = time.perf_counter() - verify_start
        validation_seconds += verification_time
        accepted = fine["feasible"]
        raw_candidate = np.asarray(candidate).copy()
        if cfg.get("retain_feasible_iterates", False) and (
            not accepted or incumbent_length < length(candidate)
        ):
            candidate = incumbent.copy()
            coarse = problem.check(candidate)
            fine = problem.check(candidate, dense=True)
            accepted = fine["feasible"]
        if accepted and length(candidate) < length(best):
            best = candidate.copy()
            origin = f"{method} run {index + 1}"
        runs.append(
            dict(
                run=index + 1,
                solver_success=success,
                message=message,
                interrupted=interrupted,
                iterations=nit,
                objective_calls=evaluations,
                elapsed_seconds=solver_time,
                validation_seconds=verification_time,
                candidate_length_m=length(candidate),
                coarse_check=coarse,
                fine_check=fine,
                history=history,
                raw_candidate_controls_normalized=raw_candidate.tolist(),
                retained_candidate_controls_normalized=np.asarray(candidate).tolist(),
            )
        )
        print(
            f"{method}: success={success} accepted={accepted} length={length(candidate):.6f} "
            f"time={solver_time:.3f}s",
            flush=True,
        )
    check_start = time.perf_counter()
    check = problem.check(best, dense=True)
    validation_seconds += time.perf_counter() - check_start
    report = dict(
        algorithm=method,
        status="feasible_design",
        selected_candidate=origin,
        solver_success=any(r["solver_success"] for r in runs),
        runs=runs,
        selected_candidate_solver_success=next(
            (r["solver_success"] for r in runs if origin == f"{method} run {r['run']}"), False
        ),
        initial_total_length_m=initial_length,
        final_total_length_m=length(best),
        optimization_seconds=sum(r["elapsed_seconds"] for r in runs),
        validation_seconds=validation_seconds,
        algorithm_wall_seconds=time.perf_counter() - overall,
        final_check=check,
        global_optimum_proven=False,
    )
    return best, report


__all__ = ["ALGORITHMS", "feasible_starts", "solve_algorithm"]
