"""Merge artifact-authored cell values into original packages, validate, install.

Only requested coordinate cells and directly dependent SF/annotation content
change. Unrelated workbook parts and all original formatting are preserved.
Existing SF risk row highlighting is refreshed using the existing styles.
"""

import argparse
import hashlib
import json
import re
import shutil
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
from lxml import etree
from openpyxl import load_workbook

from wellpath.workflows.uncertainty_comparison import save_json

NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
N = {"s": NS}
Q = lambda name: f"{{{NS}}}{name}"


def value(cell, strings):
    if cell is None:
        return None
    t = cell.get("t")
    v = cell.find(Q("v"))
    if t == "inlineStr":
        return "".join(cell.itertext())
    if v is None:
        return None
    if t == "s":
        return strings[int(v.text)]
    if t in ["str", "e"]:
        return v.text or ""
    if t == "b":
        return v.text == "1"
    return float(v.text)


def set_value(cell, v):
    for child in list(cell):
        cell.remove(child)
    if v is None:
        cell.attrib.pop("t", None)
        return
    if isinstance(v, str):
        cell.set("t", "str")
        etree.SubElement(cell, Q("v")).text = v
    else:
        cell.set("t", "n")
        etree.SubElement(cell, Q("v")).text = format(float(v), ".17g")


def assemble(folder):
    patch = json.loads((folder / "workbook_patch.json").read_text())
    backup = Path(patch["source_file"])
    dest = folder.parent / "updated_files" / patch["filename"]
    dest.parent.mkdir(exist_ok=True)
    authored = folder / "authored_cells.xlsx"
    assert authored.exists()
    checks = []
    with (
        ZipFile(backup) as old,
        ZipFile(authored) as edits,
        ZipFile(dest, "w", ZIP_DEFLATED) as out,
    ):
        strings = []
        if "xl/sharedStrings.xml" in edits.namelist():
            sr = etree.fromstring(edits.read("xl/sharedStrings.xml"))
            strings = ["".join(si.itertext()) for si in sr]
        sheet_patches = {
            f"xl/worksheets/sheet{i + 1}.xml": p for i, p in enumerate(patch["patches"])
        }
        for item in old.infolist():
            data = old.read(item.filename)
            if item.filename not in sheet_patches:
                out.writestr(item, data)
                continue
            p = sheet_patches[item.filename]
            r = etree.fromstring(data)
            er = etree.fromstring(edits.read(item.filename))
            cells = {c.get("r"): c for c in r.findall(".//s:sheetData/s:row/s:c", N)}
            ecells = {c.get("r"): c for c in er.findall(".//s:sheetData/s:row/s:c", N)}
            rows = {int(row.get("r")): row for row in r.findall("s:sheetData/s:row", N)}
            allowed = set(["P1", "Q2", "U2", "L7", "L8"])
            for k in range(p["first_row"], p["last_row"] + 1):
                for col in ["E", "F", "P", "Q", "R", "S", "T", "U"]:
                    allowed.add(f"{col}{k}")
            for ref in allowed:
                v = value(ecells.get(ref), strings)
                if ref not in cells:
                    row_number = int(re.search(r"\d+", ref).group())
                    cell = etree.SubElement(rows[row_number], Q("c"), r=ref)
                    # Q can be absent when the original well has no unsafe neighbor.
                    if ref.startswith("Q"):
                        cell.set("s", "34")
                    cells[ref] = cell
                set_value(cells[ref], v)
            # Reuse existing normal/unsafe styles. Keep endpoint marking.
            normal = {35: 13, 36: 14, 37: 18, 38: 19, 39: 33, 40: 34, 41: 33, 42: 34}
            risky = {13: 35, 14: 36, 18: 37, 19: 38, 33: 39, 34: 40}
            for i, annotation in enumerate(p["annotations"]):
                k = p["first_row"] + i
                unsafe = annotation[5].startswith(("红", "橙"))
                for c in rows[k]:
                    ref = c.get("r")
                    col = re.sub(r"\d+", "", ref)
                    if col not in [
                        "A",
                        "B",
                        "C",
                        "D",
                        "E",
                        "F",
                        "G",
                        "H",
                        "I",
                        "J",
                        "P",
                        "Q",
                        "R",
                        "S",
                        "T",
                        "U",
                    ]:
                        continue
                    style = int(c.get("s", "0"))
                    base = normal.get(style, style)
                    new = risky.get(base, base) if unsafe else base
                    if new != style:
                        c.set("s", str(new))

                # Re-sort any formerly missing annotation cell into column order.
                def order(c):
                    col = re.sub(r"\d+", "", c.get("r"))
                    n = 0
                    for ch in col:
                        n = n * 26 + ord(ch) - 64
                    return n

                children = sorted(list(rows[k]), key=order)
                rows[k][:] = children
            out.writestr(item, etree.tostring(r, encoding="UTF-8", xml_declaration=True))
            checks.append(
                dict(
                    sheet=p["sheet"],
                    edited_value_cells=len(allowed),
                    trajectory_points=len(p["coordinates_EN"]),
                )
            )
    return dest, patch, checks


def validate(dest, patch):
    before = load_workbook(patch["source_file"], read_only=True, data_only=True)
    after = load_workbook(dest, read_only=True, data_only=True)
    assert before.sheetnames == after.sheetnames
    heads = []
    max_translation_error = 0.0
    checked = 0
    changed_metadata = {"P1", "Q2", "U2", "L7", "L8"}
    for sb, sa, p in zip(before, after, patch["patches"]):
        shift = np.asarray(p["coordinates_EN"][0]) - np.asarray(
            next(sb.iter_rows(min_row=3, max_row=3, values_only=True))[4:6]
        )
        for rn, (rb, ra) in enumerate(
            zip(sb.iter_rows(values_only=True), sa.iter_rows(values_only=True)), 1
        ):
            # Preserve every unrelated cell value, including the complete MD/I/A/D
            # and closure/dogleg/section metadata in A:D, G:O.
            assert len(rb) == len(ra)
            for ci, (vb, va) in enumerate(zip(rb, ra), 1):
                col = ""
                x = ci
                while x:
                    col = chr(65 + (x - 1) % 26) + col
                    x = (x - 1) // 26
                ref = f"{col}{rn}"
                if ref in changed_metadata:
                    continue
                if rn >= 3 and ci in [5, 6]:
                    err = abs(float(va) - (float(vb) + shift[ci - 5]))
                    max_translation_error = max(max_translation_error, err)
                    assert err < 1e-8
                    assert isinstance(va, (int, float))
                elif rn >= 3 and 16 <= ci <= 21:
                    continue
                else:
                    assert vb == va, (p["sheet"], ref, vb, va)
                checked += 1
            if rn == 3:
                heads.append([float(ra[5]), float(ra[4]), float(ra[3])])
        assert len(p["coordinates_EN"]) == p["last_row"] - p["first_row"] + 1
    before.close()
    after.close()
    heads = np.array(heads)
    distance = np.linalg.norm(heads[:, None, :2] - heads[None, :, :2], axis=2)
    np.fill_diagonal(distance, np.inf)
    assert distance.min() >= 8 - 1e-9
    assert len(np.unique(heads[:, 0])) == 2
    row_dist = float(np.diff(np.unique(heads[:, 0]))[0])
    assert abs(row_dist - 8) < 1e-9
    for north in np.unique(heads[:, 0]):
        np.testing.assert_allclose(
            np.diff(np.sort(heads[heads[:, 0] == north, 1])), 8, rtol=0, atol=1e-9
        )
    # Preserve every non-worksheet OOXML part byte-for-byte (styles, merges,
    # dimensions, frozen panes and print settings inside sheets also remain).
    with ZipFile(patch["source_file"]) as a, ZipFile(dest) as b:
        assert a.namelist() == b.namelist()
        unchanged = []
        for name in a.namelist():
            if not name.startswith("xl/worksheets/sheet"):
                assert a.read(name) == b.read(name)
                unchanged.append(name)
        for i in range(len(heads)):
            name = f"xl/worksheets/sheet{i + 1}.xml"
            x = etree.fromstring(a.read(name))
            y = etree.fromstring(b.read(name))
            for tag in [
                "cols",
                "sheetViews",
                "mergeCells",
                "sheetFormatPr",
                "sheetPr",
                "pageMargins",
                "pageSetup",
                "printOptions",
            ]:
                xx = x.find(Q(tag))
                yy = y.find(Q(tag))
                assert (etree.tostring(xx) if xx is not None else None) == (
                    etree.tostring(yy) if yy is not None else None
                )
    return dict(
        passed=True,
        unrelated_values_compared=checked,
        maximum_translation_error_m=max_translation_error,
        minimum_horizontal_wellhead_distance_m=float(distance.min()),
        row_spacing_m=row_dist,
        row_counts=[int((heads[:, 0] == v).sum()) for v in np.unique(heads[:, 0])],
        all_wellhead_NE_m=heads[:, :2].tolist(),
        unchanged_package_parts=unchanged,
        source_file=str(dest),
    )


def run(output, install):
    output = Path(output)
    reports = []
    prepared = []
    for folder in sorted(output.glob("group_*")):
        dest, patch, cells = assemble(folder)
        report = validate(dest, patch)
        report["authored_changes"] = cells
        save_json(folder / "coordinate_verification.json", report)
        reports.append(report)
        prepared.append((folder, dest, patch))
        print(folder.name, "coordinate content/format preservation verified", flush=True)
    if install:
        # Only install after every group candidate has passed full validation.
        for folder, dest, patch in prepared:
            target = Path(patch["target_file"])
            backup = Path(patch["source_file"])
            assert (
                hashlib.sha256(target.read_bytes()).digest()
                == hashlib.sha256(backup.read_bytes()).digest()
            ), "Input changed since backup; refuse to overwrite"
        for folder, dest, patch in prepared:
            target = Path(patch["target_file"])
            temporary = target.with_name(target.name + ".relocation_tmp")
            shutil.copyfile(dest, temporary)
            temporary.replace(target)
            shutil.copyfile(target, folder / "source.xlsx")
            digest = hashlib.sha256(target.read_bytes()).hexdigest()
            for file in ["input_audit.json", "workbook_data.json", "visualization_data.json"]:
                doc = json.loads((folder / file).read_text())
                audit = (
                    doc
                    if file == "input_audit.json"
                    else doc["input_audit"]
                    if file == "workbook_data.json"
                    else doc["source_audit"]
                )
                audit["sha256_before"] = digest
                audit["sha256_after"] = digest
                audit["coordinate_modification_applied"] = True
                audit["backup_preserved"] = True
                save_json(folder / file, doc)
            print("Updated original file:", target, flush=True)
        batch = json.loads((output / "batch_audit.json").read_text())
        batch["groups"] = [
            json.loads((folder / "input_audit.json").read_text()) for folder, _, _ in prepared
        ]
        save_json(output / "batch_audit.json", batch)
    save_json(
        output / "coordinate_verification.json",
        dict(passed=True, installed=install, groups=reports),
    )


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--install", action="store_true")
    a = p.parse_args()
    run(a.output, a.install)
