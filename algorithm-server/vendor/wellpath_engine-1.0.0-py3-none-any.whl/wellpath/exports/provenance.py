"""Copy a runnable source tree, including packaged model parameter files."""

import shutil
from pathlib import Path


def snapshot_sources(project_root, destination):
    root, destination = Path(project_root), Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    for directory in ("src/wellpath", "configs/experiments", "tools", "docs"):
        source = root / directory
        if source.is_dir():
            shutil.copytree(
                source,
                destination / directory,
                dirs_exist_ok=True,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
            )
    for name in ("pyproject.toml", "README.md", "requirements.txt", "package.json"):
        if (root / name).is_file():
            shutil.copy2(root / name, destination / name)
