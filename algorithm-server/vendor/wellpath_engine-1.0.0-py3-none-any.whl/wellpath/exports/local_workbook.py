"""Merge artifact-authored values/styles into the original well workbook."""

import argparse
import copy
import hashlib
import json
import re
import shutil
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
from lxml import etree
from openpyxl import load_workbook

from wellpath.exports.cluster_workbook import N, Q, set_value, value
from wellpath.workflows.scenario_replanning import save_json

NORMAL = {35: 13, 36: 14, 37: 18, 38: 19, 39: 33, 40: 34, 41: 33, 42: 34}
RISKY = {13: 35, 14: 36, 18: 37, 19: 38, 33: 39, 34: 40}


def colnum(ref):
    n = 0
    for c in re.sub(r"\d+", "", ref):
        n = 26 * n + ord(c) - 64
    return n


def strings(z):
    if "xl/sharedStrings.xml" not in z.namelist():
        return []
    return ["".join(s.itertext()) for s in etree.fromstring(z.read("xl/sharedStrings.xml"))]


def install(out):
    p = json.loads((out / "workbook_patch.json").read_text())
    before = Path(p["source_file"])
    target = Path(p["target_file"])
    assert hashlib.sha256(before.read_bytes()).hexdigest() == p["source_sha256"]
    permitted = {p["source_sha256"]}
    prior_check = out / "workbook_verification.json"
    if prior_check.exists():
        permitted.add(json.loads(prior_check.read_text())["updated_sha256"])
    assert hashlib.sha256(target.read_bytes()).hexdigest() in permitted, (
        "Input changed before install"
    )
    final = out / "cluster_20_well_14_replanned.xlsx"
    with (
        ZipFile(before) as src,
        ZipFile(out / "authored_cells.xlsx") as edits,
        ZipFile(final, "w", ZIP_DEFLATED) as dst,
    ):
        ss = strings(edits)
        _source_ss = strings(src)
        parts = {f"xl/worksheets/sheet{i + 1}.xml": s for i, s in enumerate(p["patches"])}
        for item in src.infolist():
            raw = src.read(item.filename)
            if item.filename not in parts:
                dst.writestr(item, raw)
                continue
            sp = parts[item.filename]
            if not sp["annotation_changes"] and "trajectory_rows" not in sp:
                dst.writestr(item, raw)
                continue
            root = etree.fromstring(raw)
            edit = etree.fromstring(edits.read(item.filename))
            sd = root.find(Q("sheetData"))
            rows = {int(r.get("r")): r for r in sd}
            ec = {c.get("r"): c for c in edit.findall(".//s:sheetData/s:row/s:c", N)}

            def cell(ref):
                rn = int(re.search(r"\d+", ref)[0])
                if rn not in rows:
                    rows[rn] = etree.SubElement(sd, Q("row"), r=str(rn))
                found = next((c for c in rows[rn] if c.get("r") == ref), None)
                if found is None:
                    found = etree.SubElement(rows[rn], Q("c"), r=ref)
                return found

            def authored(ref, style=None):
                c = cell(ref)
                set_value(c, value(ec.get(ref), ss))
                if style is not None:
                    c.set("s", str(style))
                return c

            if "trajectory_rows" in sp:
                old_rows = {k: copy.deepcopy(r) for k, r in rows.items()}
                last = sp["new_point_count"] + 2
                for rn in list(rows):
                    if rn > last:
                        sd.remove(rows.pop(rn))
                for i, vals in enumerate(sp["trajectory_rows"]):
                    rn = i + 3
                    source_row = sp["source_old_row_for_new_row"][i]
                    template = old_rows.get(source_row or 4, old_rows[4])
                    tc = {re.sub(r"\d+", "", c.get("r")): c for c in template}
                    for ci, col in enumerate("ABCDEFGHIJ"):
                        style = int(tc[col].get("s", "13"))
                        style = NORMAL.get(style, style)
                        # New adjustment interior starts from ordinary numeric styles.
                        if source_row is None:
                            style = 14 if col in ["C", "H"] else 13
                        if rn in sp["endpoint_rows"]:
                            style = 19 if col in ["C", "H"] else 18
                        authored(f"{col}{rn}", style)
                    authored(f"O{rn}", 34)
                    # Existing arbitrary top-right metadata remains tied to row
                    # addresses, independently of the moving trajectory rows.
                for ref in ["O2", "M4", "L7", "L8", "P1"]:
                    authored(ref, 29 if ref == "O2" else None)
                for rn in range(11, 11 + len(sp["segment_metadata"])):
                    for col in ["L", "M", "N"]:
                        authored(f"{col}{rn}")
                for rn in range(
                    11 + len(sp["segment_metadata"]),
                    sp["footnotes_first_row"] + len(sp["footnotes"]),
                ):
                    for col in ["L", "M", "N"]:
                        authored(f"{col}{rn}")
                dimension = root.find(Q("dimension"))
                if dimension is None:
                    dimension = etree.Element(Q("dimension"))
                    root.insert(1 if root.find(Q("sheetPr")) is not None else 0, dimension)
                dimension.set("ref", f"A1:U{last}")
                # Make the explicitly requested new adjustment marker legible.
                columns = root.find(Q("cols"))
                marker = etree.Element(Q("col"), min="15", max="15", width="18", customWidth="1")
                columns.append(marker)
                columns[:] = sorted(columns, key=lambda c: int(c.get("min")))
            for c in sp["annotation_changes"]:
                rn = c["row"]
                unsafe = c["values"][5].startswith(("红", "橙"))
                for col in ["P", "Q", "R", "S", "T", "U"]:
                    authored(f"{col}{rn}", 33 if col == "P" else 34)
                # Refresh existing risk paint only on directly affected rows.
                for cc in rows[rn]:
                    col = re.sub(r"\d+", "", cc.get("r"))
                    if col not in list("ABCDEFGHIJ") + ["P", "Q", "R", "S", "T", "U"]:
                        continue
                    st = NORMAL.get(int(cc.get("s", "0")), int(cc.get("s", "0")))
                    cc.set("s", str(RISKY.get(st, st) if unsafe else st))
            for row in rows.values():
                row[:] = sorted(row, key=lambda c: colnum(c.get("r")))
            sd[:] = sorted(sd, key=lambda r: int(r.get("r")))
            dst.writestr(item, etree.tostring(root, encoding="UTF-8", xml_declaration=True))
    # Validate all trajectory values, affected annotations and unrelated cells.
    b = load_workbook(before, read_only=True, data_only=True)
    a = load_workbook(final, read_only=True, data_only=True)
    assert b.sheetnames == a.sheetnames
    unrelated = 0
    updated_annotations = 0
    for sb, sa, sp in zip(b, a, p["patches"]):
        old = list(sb.values)
        new = list(sa.values)
        changes = {c["row"]: c["values"] for c in sp["annotation_changes"]}
        for rn, row in enumerate(new, 1):
            if rn in changes:
                for v, w in zip(row[15:21], changes[rn]):
                    if isinstance(w, (int, float)):
                        assert v == w
                    else:
                        assert v == w
                updated_annotations += 1
            if "trajectory_rows" not in sp:
                assert len(old) == len(new)
                for ci, (v, w) in enumerate(zip(old[rn - 1], row)):
                    if rn in changes and 15 <= ci < 21:
                        continue
                    assert v == w, (sp["sheet"], rn, ci, v, w)
                    unrelated += 1
            elif rn >= 3:
                np.testing.assert_allclose(row[:10], sp["trajectory_rows"][rn - 3], rtol=0, atol=0)
                assert row[14] == sp["marks"][rn - 3][0]
        if "trajectory_rows" in sp:
            assert sa.max_row == sp["new_point_count"] + 2
            for rn in sp["endpoint_rows"]:
                assert str(new[rn - 1][14]).startswith("调整段端点")
    b.close()
    a.close()
    with ZipFile(before) as x, ZipFile(final) as y:
        assert x.namelist() == y.namelist()
        for name in x.namelist():
            if not name.startswith("xl/worksheets/sheet"):
                assert x.read(name) == y.read(name)
        for i, sp in enumerate(p["patches"]):
            old = etree.fromstring(x.read(f"xl/worksheets/sheet{i + 1}.xml"))
            new = etree.fromstring(y.read(f"xl/worksheets/sheet{i + 1}.xml"))
            for tag in [
                "cols",
                "sheetViews",
                "mergeCells",
                "sheetFormatPr",
                "pageMargins",
                "pageSetup",
                "printOptions",
            ]:
                oo = old.find(Q(tag))
                nn = new.find(Q(tag))
                if tag == "cols" and "trajectory_rows" in sp:
                    nn = copy.deepcopy(nn)
                    for col in list(nn):
                        if col.get("min") == "15" and col.get("max") == "15":
                            nn.remove(col)
                assert (None if oo is None else etree.tostring(oo)) == (
                    None if nn is None else etree.tostring(nn)
                )
    # Candidate is installed only after the complete workbook verification.
    temp = target.with_name(target.name + ".local_replan_tmp")
    shutil.copyfile(final, temp)
    temp.replace(target)
    save_json(
        out / "workbook_verification.json",
        dict(
            passed=True,
            installed=True,
            output_file=str(final),
            target_file=str(target),
            source_sha256=p["source_sha256"],
            updated_sha256=hashlib.sha256(final.read_bytes()).hexdigest(),
            unrelated_neighbor_cells_compared=unrelated,
            updated_annotation_rows=updated_annotations,
            original_styles_and_nonworksheet_parts_preserved=True,
            original_layout_preserved_except_new_O_marker_width=True,
        ),
    )
    print("Installed and verified", target, flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--output", type=Path, required=True)
    install(p.parse_args().output)
