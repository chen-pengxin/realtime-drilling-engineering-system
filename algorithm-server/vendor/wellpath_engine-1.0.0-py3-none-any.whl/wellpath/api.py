"""Library interfaces for trajectory optimization and collision evaluation.

Coordinates are N/E/D in metres; inclination/azimuth are degrees; covariance
is 1-sigma N/E/D m². No plotting or workbook writes occur in these functions.
"""

import time
from copy import deepcopy
from pathlib import Path

import numpy as np

from .anticollision.error_models.registry import load_model_settings
from .anticollision.error_models.schema import _model_type
from .anticollision.methods.center_distance import centerline_minimum_distance
from .anticollision.methods.separation_factor import pointwise_separation_minimum
from .anticollision.policy import classify_separation
from .anticollision.uncertainty import (
    empirical_covariance,
    make_survey,
    propagated_uncertainty,
    scalar_radius,
    simplified_mwd_uncertainty,
)
from .optimization.runner import feasible_starts, solve_algorithm
from .planning.problem import PlanningProblem
from .planning.toolface import has_discrete_toolface


def calculate_uncertainty(
    md_m, inclination_deg, azimuth_deg, positions_m, settings=None, *, config_dir=None
):
    """Calculate covariance/radius for one well using a selected model.

    With settings=None, use the current Rev.0 profile. An explicitly supplied
    settings object is validated as supplied, without filling mandatory fields.
    Propagated models require real/synthetic survey stations, not independent
    1m plotting samples. They must include the fixed MD=0 reference.
    """
    settings = load_model_settings() if settings is None else deepcopy(settings)
    md = np.asarray(md_m, dtype=np.float64)
    inc = np.asarray(inclination_deg, dtype=np.float64)
    azi = np.asarray(azimuth_deg, dtype=np.float64)
    positions = np.asarray(positions_m, dtype=np.float64)
    if (
        md.ndim != 1
        or len(md) < 1
        or inc.shape != md.shape
        or azi.shape != md.shape
        or positions.shape != (len(md), 3)
        or np.any(np.diff(md) <= 0)
        or not all(np.isfinite(x).all() for x in (md, inc, azi, positions))
        or np.any(md < 0)
        or np.any((inc < 0) | (inc > 180))
    ):
        raise ValueError("Require matching finite MD/I/A/NED arrays and increasing nonnegative MD.")
    kind = _model_type(settings)
    if kind == "md_scalar_radius":
        return {"model": kind, "covariance_nev_m2": None, "radius_m": scalar_radius(md, settings)}
    if kind in ("iscwsa_rev0", "wdw"):
        detail = propagated_uncertainty(md, inc, azi, positions, settings)
        covariance = detail["cov"]
    elif kind == "iscwsa":
        detail = {}
        covariance = make_survey(md, inc, azi, positions, settings).cov_nev
    elif kind == "simplified_mwd":
        detail = simplified_mwd_uncertainty(md, inc, settings)
        covariance = detail["cov"]
    else:
        detail = {}
        covariance = empirical_covariance(md, settings, config_dir)
    radius = np.sqrt(np.maximum(np.linalg.eigvalsh(covariance)[:, -1], 0.0))
    return {"model": kind, "covariance_nev_m2": covariance, "radius_m": radius, "details": detail}


def evaluate_collision(
    positions_a_m,
    positions_b_m,
    uncertainty_a,
    uncertainty_b,
    *,
    k_sigma=1.0,
    sf_method="major_axis_sum",
    screening=True,
    sf_levels=(1.0, 1.5, 2.5),
    centerline_red_distance_m=5.0,
    radii_margin_m=0.0,
    sigma_pa_m=0.0,
):
    """Evaluate sampled SF and continuous *polyline* center distance separately.

    The SF minimum and the center-distance minimum can involve different points.
    Input paths should first be sampled using the selected trajectory geometry.
    A curved trajectory's polyline distance is not a certified curved-path bound.
    """
    if not np.isfinite(k_sigma) or k_sigma <= 0:
        raise ValueError("k_sigma must be finite and positive.")
    start = time.perf_counter()
    ca, cb = uncertainty_a["covariance_nev_m2"], uncertainty_b["covariance_nev_m2"]
    kwargs = dict(
        k=k_sigma,
        sf_method=sf_method,
        screening=screening,
        margin=radii_margin_m,
        sigma_pa=sigma_pa_m,
    )
    if ca is None or cb is None:
        # Scalar envelopes also support the directional/RSS convention retained
        # by the existing scalar evaluation kernel.
        kwargs.update(ra=uncertainty_a["radius_m"], rb=uncertainty_b["radius_m"])
    else:
        kwargs.update(c=ca, d=cb)
    sf = pointwise_separation_minimum(positions_a_m, positions_b_m, **kwargs)
    center = centerline_minimum_distance(positions_a_m, positions_b_m, screening=screening)
    center_distance = center["distance_m"]
    risk = classify_separation(
        sf["minimum_sf"],
        center_distance,
        sf_levels=sf_levels,
        center_distance_red_m=centerline_red_distance_m,
    )
    return {
        "separation": sf,
        "center_distance": center,
        "risk": risk,
        "k_sigma": float(k_sigma),
        "sf_method": sf_method,
        "elapsed_seconds": time.perf_counter() - start,
    }


def optimize_trajectory(configuration, *, algorithm="SLSQP", config_dir=None, starts=None):
    """Solve from verified starts and return controls plus complete diagnostics.

    No initial solution is treated as proof of infeasibility. Caller-provided
    starts are normalized active-variable vectors and must pass dense checks.
    """
    if has_discrete_toolface(configuration):
        raise ValueError("Discrete toolface choices require the enumerating planning workflow.")
    problem = PlanningProblem(deepcopy(configuration), config_dir=Path(config_dir or "."))
    if starts is None:
        starts, initialization = feasible_starts(problem)
    else:
        starts = [np.asarray(z, dtype=float) for z in starts]
        if any(not problem.check(z, dense=True)["feasible"] for z in starts):
            raise ValueError("Every supplied start must pass dense feasibility verification.")
        initialization = {"status": "caller_supplied_verified", "elapsed_seconds": 0.0}
    selected, report = solve_algorithm(problem, starts, algorithm)
    return {
        "controls": None if selected is None else problem.unpack(selected),
        "normalized_controls": selected,
        "initialization": initialization,
        "report": report,
    }
