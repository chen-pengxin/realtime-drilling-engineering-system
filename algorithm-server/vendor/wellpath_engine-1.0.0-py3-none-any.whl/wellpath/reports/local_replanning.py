"""Interactive accepted local splice, timing, incremental scans and MC comparison."""

import argparse
import html
import json
import time
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from plotly.offline import get_plotlyjs

from wellpath.exports.provenance import snapshot_sources
from wellpath.workflows.local_replanning import BASE, ROOT
from wellpath.workflows.scenario_replanning import save_json

matplotlib.use("Agg")


plt.rcParams.update(
    {"font.family": "Arial Unicode MS", "axes.unicode_minus": False, "font.size": 11}
)


def table(rows):
    return (
        "<table>"
        + "".join(
            "<tr>"
            + "".join(
                f"<{'th' if i == 0 else 'td'}>{html.escape(str(v))}</{'th' if i == 0 else 'td'}>"
                for v in row
            )
            + "</tr>"
            for i, row in enumerate(rows)
        )
        + "</table>"
    )


TEMPLATE = r"""<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>20口井组 · 井14局部调整</title>
<style>body{font-family:Arial,"PingFang SC",sans-serif;background:#eef2f7;color:#172033;margin:0}main{max-width:1550px;margin:auto;padding:26px}section{background:white;border-radius:10px;padding:24px;margin:20px 0}p,li{line-height:1.8}h1{font-size:28px}h2{font-size:21px}h3{font-size:17px}table{border-collapse:collapse;font-size:13px;width:100%}td,th{text-align:right;padding:9px;border-bottom:1px solid #e2e8f0;white-space:nowrap}th{background:#243c55;color:white}td:first-child,th:first-child{text-align:left}.scroll{overflow:auto;max-height:500px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}.plot{height:570px}.controls{position:sticky;top:0;background:#f8fafc;padding:12px;z-index:5}label{margin-right:18px}select{padding:8px;font-size:15px}img{width:100%}a{color:#1d4ed8}summary{cursor:pointer;padding:10px}.note{color:#475569}.key{font-size:18px;line-height:1.9}pre{white-space:pre-wrap;line-height:1.6;font-size:13px}@media(max-width:950px){.grid{display:block}}</style>
<script>__PLOTLY__</script><body><main>
<h1>20口井组 · 井14危险段局部调整</h1>
<p><a href="../../cluster_wellheads_spacing8m_20261113/index.html">三个井组历史总览</a>　<a href="cluster_20_well_14_replanned.xlsx">下载已覆盖数据的工作簿</a>　<a href="updated_well14_1m.csv">井14完整1m轨迹与防碰结果</a>　<a href="updated_Rev0_K1_pairs.csv">190井对更新汇总</a>　<a href="notes.md">详细方法与公式</a></p>
<section><h2>最终结果与覆盖范围</h2>__RESULT__
<p>原危险区间为MD763–868m，判据为中心距≤5m或SF≤1.5。采用现有SLSQP、圆弧–直线–圆弧、段内恒工具面恒曲率；Rev.0沿用当前全部默认参数，K=1，SF=D/[K(r₁+r₂)]，r=√λmax(C)。没有扣井径、裕量，也没有附加位置标准差。</p>
<p>只改变井14的接入点与接回点之间的几何。为保持测深与实际新段长一致，接回点之后原坐标、井斜、方位保留，测深统一顺延；井口与最终靶点坐标保留。原MD1300m接回点的坐标与方向是优化等式约束。备份保存在同目录backup_before_replan.xlsx。</p>
<p class="note">此页为当前局部调整后的Rev.0评价。此前十模型报告保留为再规划前历史结果，其他误差模型没有被标记为本次已更新。</p></section>
<div class="controls"><label>显示K <select id="k"><option>1</option><option>2</option><option>2.5</option><option>3</option></select></label><label>风险着色 <select id="method"><option value="combined">SF与中心距联合</option><option value="sf">仅SF</option><option value="center">仅中心距</option></select></label><span>蓝/橙为原设计/调整轨迹线；点击图例可分别隐藏。</span></div>
<section><h2>三维与二维轨迹对比</h2><p><button id="view-all">全井组视图</button>　<button id="view-local">调整段局部视图</button></p><div id="three" style="height:760px"></div><div class="grid"><div id="plan" class="plot"></div><div id="vertical" class="plot"></div></div><p class="note">可旋转、缩放。邻井使用完整原采样点；原井14、调整后井14、调整段按1m测斜点进行MC复算的轨迹分别显示。垂直剖面是沿原井口至原井底水平投影方向的投影，不把空间曲线强制放入一个平面。</p></section>
<section><h2>调整前后的防碰曲线</h2><p id="current-stats"></p><div class="grid"><div id="sf" class="plot"></div><div id="center" class="plot"></div></div><div class="grid"><div id="radius" class="plot"></div><div id="toolface" class="plot"></div></div><p class="note">本次方案按K=1求解。切换K仅作新轨迹的精确SF与有效半径敏感性展示，不代表已按其他K重新优化。局部工具面角在每个曲线段内恒定，直线段工具面不定义；方位可跨越0°/360°，方位转动量不等于狗腿角。</p></section>
<section><h2>三段控制参数与端点直接值</h2><div class="scroll">__CONTROLS__</div><div class="scroll">__NODES__</div><p>工作簿A:J保留原字段；O列新增“调整段”或“调整段端点0–3”。四个端点直接由控制参数计算，保留完整数值，不用表格显示值重新反算；A:J复用原浅黄色端点样式。1m网格外的分数测深端点额外保留，共用端点仅列一次。</p></section>
<section><h2>与最小曲率法复算的差别</h2>__MC__<div class="grid"><div id="mc-delta" class="plot"></div><div id="mc-coarse" class="plot"></div></div><p><a href="minimum_curvature_comparison_1m.csv">下载逐点两种MC复算对照</a>　<a href="minimum_curvature_comparison.json">差值统计</a></p><p>第一种对照按最终1m表格的相同MD/I/A，从同一起点逐段累计MC位移，不强行把复算终点改回目标。第二种仅用四个控制节点作MC积分，独立展示稀疏节点造成的近似差别。写回工作簿的是恒工具面恒曲率名义轨迹。</p></section>
<section><h2>初值构造、约束和SLSQP收敛</h2><p>初值通过中间姿态与方位绕转分支搜索构造：固定两端姿态，计算两条单位长度恒工具面曲线位移u₁、u₃，再解[u₁,tₘ,u₃][L₁,L₂,L₃]ᵀ=p目标−p起点。筛除负段长、超曲率和超转角解，按中心距筛选后做完整Rev.0及1m验收。SLSQP从通过验收的初值继续缩短进尺。</p>
<p>优化等式约束为接回点N/E/D与井斜/方位五项连续；不等式包括曲率、段长、井斜、弯曲角、SF和中心距。SF在每次约束调用中使用水平AABB初筛、候选区间细化。优化阶段保留SF和中心距缓冲，最终另以完整1m点和段端点复评；约束参与整个优化过程。</p>
<div class="grid"><div id="convergence" class="plot"></div><div id="convergence-time" class="plot"></div></div><div class="scroll">__CONSTRAINTS__</div><p>初值构造过程和各次搜索窗口见JSON记录；报告的初值时间是最终采用的确定性构造一次耗时，之前的接点和分支探索单独保留，不混入SLSQP耗时。</p></section>
<section><h2>增量评价与执行时间</h2>__TIMING__<p>复用171个无关井对、19口邻井的误差与几何缓存以及井14接入前结果。新几何会改变Rev.0在井14下游的累计误差，因此只对该井下游误差依赖项更新；相关邻井逐点最小值若原匹配点被删除，单独修复缓存失效项。不只比较新增候选而保留已删除旧点的最小值。增量扫描始终为水平AABB初筛+候选区间细化，没有全井组重算。</p>
<p><a href="incremental_timing.json">详细阶段计时</a>　<a href="incremental_verification.json">增量数值核查</a>　<a href="workbook_verification.json">覆盖与保留范围核查</a>　<a href="updated_Rev0_K1_all_points.csv.gz">全部当前逐点结果CSV.gz</a></p></section>
<section><h2>静态对比图</h2><img src="figures/local_replan_comparison.png"><details><summary>最终工作簿端点样式与调整段标注</summary>__PREVIEWS__</details></section>
<section><details><summary>Rev.0全部生效参数及单位字段</summary><pre>__PARAMETERS__</pre></details></section>
</main><script>
const D=__DATA__,k=document.getElementById('k'),method=document.getElementById('method');
const C=['#dc2626','#f97316','#eab308','#2563eb'],L=['红：危险','橙：警告','黄：关注','蓝：安全'];
const base={font:{family:'Arial, PingFang SC'},margin:{l:80,r:35,t:70,b:100},legend:{orientation:'h',y:-.2},uirevision:'fixed'};
const opts={responsive:true,displaylogo:false,toImageButtonOptions:{format:'png',scale:2}};
const position=w=>w.p, E=w=>w.p.map(p=>p[1]),N=w=>w.p.map(p=>p[0]),Z=w=>w.p.map(p=>p[2]);
const phi=D.section_azimuth_deg*Math.PI/180,vs=w=>w.p.map(p=>(p[0]-D.original.p[0][0])*Math.cos(phi)+(p[1]-D.original.p[0][1])*Math.sin(phi));
function update(){const kval=+k.value,w=D.updated;let col=w.sf.map((v,i)=>{let s=v/kval,g=s<=1?0:s<=1.5?1:s<=2.5?2:3;return C[method.value==='center'?(w.center[i]<=5?0:3):method.value==='combined'&&w.center[i]<=5?0:g];});
const tracks=[...D.neighbors.map(n=>({...n,color:'#aeb8c5',dash:'solid',width:1})),{...D.original,name:'井14 · 原设计',color:'#2563eb',dash:'dash',width:4},{...w,name:'井14 · 调整后',color:'#f97316',dash:'solid',width:4},{...D.mc,name:'调整段 · 1m最小曲率复算',color:'#059669',dash:'dot',width:3}];
const tt=tracks.map(t=>({type:'scatter3d',mode:'lines',name:t.name,x:E(t),y:N(t),z:Z(t),line:{color:t.color,width:t.width,dash:t.dash},customdata:t.md,hovertemplate:t.name+'<br>MD=%{customdata:.6f}m<br>E=%{x:.6f}<br>N=%{y:.6f}<br>D=%{z:.6f}<extra></extra>'}));
tt.push({type:'scatter3d',mode:'markers',name:'井14 · 当前风险着色',x:E(w),y:N(w),z:Z(w),marker:{size:2.5,color:col},customdata:w.md.map((m,i)=>[m,w.sf[i]/kval,w.center[i],w.r[i]*kval]),hovertemplate:'MD=%{customdata[0]:.6f}m<br>SF=%{customdata[1]:.6f}<br>中心距=%{customdata[2]:.6f}m<br>K×r=%{customdata[3]:.6f}m<extra></extra>'});
L.forEach((name,i)=>tt.push({type:'scatter3d',mode:'markers',name,x:[null],y:[null],z:[null],marker:{color:C[i],size:7}}));
Plotly.react('three',tt,{...base,title:{text:'原设计、局部调整与MC复算（全轨迹，可独立隐藏）'},margin:{l:0,r:260,t:55,b:0},scene:{xaxis:{title:{text:'E（m）'}},yaxis:{title:{text:'N（m）'}},zaxis:{title:{text:'D（m）'},autorange:'reversed'},aspectmode:'data'},legend:{x:1,y:1}},opts);
for(const [id,x,y,title] of [['plan',E,N,'水平投影 E–N'],['vertical',vs,Z,'垂直剖面 · 方位'+D.section_azimuth_deg.toFixed(3)+'°']]){
 Plotly.react(id,tracks.map(t=>({type:'scattergl',mode:'lines',name:t.name,x:x(t),y:y(t),line:{color:t.color,width:t.width,dash:t.dash},customdata:t.md})),{...base,title:{text:title},showlegend:false,xaxis:{title:{text:id==='plan'?'E（m）':'垂直剖面水平投影（m）'}},yaxis:{title:{text:id==='plan'?'N（m）':'D（m）'},...(id==='plan'?{scaleanchor:'x',scaleratio:1}:{autorange:'reversed'})}},opts);}
const source=[{w:D.original,name:'调整前',color:'#2563eb'},{w,name:'调整后',color:'#f97316'}];
for(const [id,key,title,threshold] of [['sf','sf','井14逐点最小SF',1.5],['center','center','井14逐点最小中心距',5],['radius','r','井14有效误差半径 K×r',null]]){
 const traces=source.map(t=>({type:'scattergl',mode:'lines',name:t.name,x:t.w.md,y:t.w[key].map(v=>key==='sf'?v/kval:key==='r'?v*kval:v),line:{color:t.color}}));
 Plotly.react(id,traces,{...base,title:{text:title},xaxis:{title:{text:'MD（m）'},...(key==='r'?{}:{range:[680,1350]})},yaxis:{title:{text:key==='sf'?'SF':'m'},...(key==='sf'?{type:'log'}:key==='center'?{range:[0,20]}:{})},shapes:threshold?[{type:'line',xref:'paper',x0:0,x1:1,y0:threshold,y1:threshold,line:{color:'#dc2626',dash:'dash'}}]:[]},opts);}
document.getElementById('current-stats').textContent=`K=${kval}，井14全井最小SF=${(Math.min(...w.sf)/kval).toFixed(6)}；最小采样中心距=${Math.min(...w.center).toFixed(6)}m。K=1安全结论见最终验收表。`;
}
Plotly.newPlot('toolface',D.segments.filter(s=>s.type!=='straight').map(s=>({type:'scatter',mode:'lines+markers',name:'调整曲线段'+s.segment,x:[s.start,s.end],y:[s.w,s.w]})),{...base,title:{text:'段内工具面角恒定（直线段不定义）'},xaxis:{title:{text:'MD（m）'}},yaxis:{title:{text:'局部工具面角（°）'}}},opts);
Plotly.newPlot('mc-delta',[['dN','ΔN'],['dE','ΔE'],['dD','ΔD'],['distance','三维差值']].map(([key,name])=>({type:'scattergl',mode:'lines',name,x:D.diff.md,y:D.diff[key]})),{...base,title:{text:'完整1m测斜表：顺序MC复算 − 恒工具面轨迹'},xaxis:{title:{text:'MD（m）'}},yaxis:{title:{text:'坐标差（m）'}}},opts);
Plotly.newPlot('mc-coarse',[{type:'scattergl',mode:'lines',name:'仅四控制节点MC',x:D.diff.md,y:D.diff.coarse}],{...base,title:{text:'仅四控制节点MC与名义轨迹的差别'},xaxis:{title:{text:'MD（m）'}},yaxis:{title:{text:'三维坐标差（m）'}}},opts);
for(const [id,key,label] of [['convergence','iteration','SLSQP迭代'],['convergence-time','elapsed_seconds','SLSQP墙钟时间（s）']])Plotly.newPlot(id,[{type:'scatter',mode:'lines+markers',name:'调整段长度（m）',x:D.history.map(v=>v[key]),y:D.history.map(v=>v.length_m)},
{type:'scatter',mode:'lines+markers',name:'最大缩放不等式违反量',x:D.history.map(v=>v[key]),y:D.history.map(v=>Math.max(v.maximum_scaled_constraint_violation,1e-14)),yaxis:'y2'}],{...base,title:{text:'进尺与约束违反量'},xaxis:{title:{text:label}},yaxis:{title:{text:'段长（m）'}},yaxis2:{title:{text:'违反量'},type:'log',overlaying:'y',side:'right'},margin:{l:75,r:85,t:65,b:100}},opts);
document.getElementById('view-local').onclick=()=>{
 const indices=D.updated.md.map((m,i)=>m>=707&&m<=D.segments.at(-1).end+1e-8?i:-1).filter(i=>i>=0);
 const local={p:indices.map(i=>D.updated.p[i])};
 const range=v=>[Math.min(...v)-25,Math.max(...v)+25];
 Plotly.relayout('three',{'scene.xaxis.range':range(E(local)),'scene.yaxis.range':range(N(local)),'scene.zaxis.range':range(Z(local)).reverse()});
 Plotly.relayout('plan',{'xaxis.range':range(E(local)),'yaxis.range':range(N(local))});
 Plotly.relayout('vertical',{'xaxis.range':range(vs(local)),'yaxis.range':range(Z(local)).reverse()});
};
document.getElementById('view-all').onclick=()=>{
 Plotly.relayout('three',{'scene.xaxis.autorange':true,'scene.yaxis.autorange':true,'scene.zaxis.autorange':'reversed'});
 Plotly.relayout('plan',{'xaxis.autorange':true,'yaxis.autorange':true});
 Plotly.relayout('vertical',{'xaxis.autorange':true,'yaxis.autorange':'reversed'});
};
k.onchange=update;method.onchange=update;update();
</script></body></html>"""


def run(out):
    begin = time.perf_counter()
    out = Path(out)
    fig = out / "figures"
    fig.mkdir(exist_ok=True)
    report = json.loads((out / "result.json").read_text())
    timing = json.loads((out / "incremental_timing.json").read_text())
    config = json.loads((out / "problem.json").read_text())
    initial = json.loads((out / "initialization.json").read_text())
    track = pd.read_csv(out / "updated_well14_1m.csv")
    old = pd.read_csv(BASE / "K_1/iscwsa_rev0/point_scan.csv.gz", low_memory=False)
    old = old[old.well == "井14"]
    allpoints = pd.read_csv(out / "updated_Rev0_K1_all_points.csv.gz")
    comparison = pd.read_csv(out / "minimum_curvature_comparison_1m.csv")
    controls = np.asarray(json.loads((out / "selected_controls.json").read_text()))
    ends = config["start"].get("md", 707.0) + np.cumsum(controls[:, 2])
    starts = np.r_[707.0, ends[:-1]]

    def track_data(frame):
        return dict(
            name="井14",
            md=frame.MD_m.tolist(),
            p=frame[["N_m", "E_m", "D_m"]].values.tolist(),
            sf=frame.minimum_SF.tolist(),
            center=frame.minimum_center_m.tolist(),
            r=frame.own_radius_m.tolist(),
        )

    neighbors = []
    for n in range(1, 21):
        if n == 14:
            continue
        q = allpoints[allpoints.well == f"井{n}"]
        neighbors.append(
            dict(name=f"井{n}", md=q.MD_m.tolist(), p=q[["N_m", "E_m", "D_m"]].values.tolist())
        )
    history = report["runs"][0]["history"]
    oldp = old[["N_m", "E_m", "D_m"]].values
    d = oldp[-1] - oldp[0]
    data = dict(
        original=track_data(old),
        updated=track_data(track),
        neighbors=neighbors,
        mc=dict(
            name="MC复算",
            md=comparison.MD_m.tolist(),
            p=comparison[["N_MC_1m_m", "E_MC_1m_m", "D_MC_1m_m"]].values.tolist(),
        ),
        diff=dict(
            md=comparison.MD_m.tolist(),
            dN=comparison.delta_N_MC1m_m.tolist(),
            dE=comparison.delta_E_MC1m_m.tolist(),
            dD=comparison.delta_D_MC1m_m.tolist(),
            distance=comparison.distance_difference_MC1m_m.tolist(),
            coarse=comparison.distance_difference_MC_nodes_m.tolist(),
        ),
        section_azimuth_deg=float(np.rad2deg(np.arctan2(d[1], d[0])) % 360),
        history=history,
        segments=[
            dict(
                segment=i + 1,
                type="straight" if row[0] == 0 else "arc",
                start=float(starts[i]),
                end=float(ends[i]),
                w=float(row[1]),
                dls=float(row[0]),
                length=float(row[2]),
            )
            for i, row in enumerate(controls)
        ],
    )
    result_table = table(
        [
            ["指标", "调整前", "调整后"],
            [
                "危险段采样点数（井14全井）",
                int(((old.minimum_SF <= 1.5) | (old.minimum_center_m <= 5)).sum()),
                int(((track.minimum_SF <= 1.5) | (track.minimum_center_m <= 5)).sum()),
            ],
            ["井14全井最小SF", f"{old.minimum_SF.min():.6f}", f"{track.minimum_SF.min():.6f}"],
            [
                "井14最小采样中心距（m）",
                f"{old.minimum_center_m.min():.6f}",
                f"{track.minimum_center_m.min():.6f}",
            ],
            ["调整区间长度（m）", "593.000000", f"{controls[:, 2].sum():.6f}"],
            ["接回点测深（m）", "1300.000000", f"{ends[-1]:.6f}"],
            ["井底测深（m）", f"{old.MD_m.max():.6f}", f"{track.MD_m.max():.6f}"],
            ["位置连续误差（m）", "—", f"{report['final_check']['position_error_m']:.3e}"],
            [
                "方向连续误差（°）",
                "—",
                f"{report['final_check']['tangent_direction_error_deg']:.3e}",
            ],
            [
                "调整段中心线下界（m）",
                "—",
                f"{report['final_check']['minimum_centerline_distance_m']:.6f}",
            ],
            ["最大控制曲率（°/30m）", "—", f"{controls[:, 0].max():.6f}"],
        ]
    )
    control_table = table(
        [
            [
                "段",
                "类型",
                "长度（m）",
                "曲率（1/m）",
                "造斜率（°/30m）",
                "恒定工具面（°）",
                "起点MD（m）",
                "终点MD（m）",
            ]
        ]
        + [
            [
                i + 1,
                "直线" if r[0] == 0 else "恒工具面曲线",
                f"{r[2]:.9f}",
                f"{np.deg2rad(r[0]) / 30:.12f}",
                f"{r[0]:.9f}",
                "不定义" if r[0] == 0 else f"{r[1]:.9f}",
                f"{starts[i]:.9f}",
                f"{ends[i]:.9f}",
            ]
            for i, r in enumerate(controls)
        ]
    )
    node_rows = []
    for i, md in enumerate(np.r_[707.0, ends]):
        row = track.iloc[(track.MD_m - md).abs().argmin()]
        node_rows.append(
            [
                i,
                f"{row.MD_m:.12f}",
                *[
                    f"{row[k]:.12f}"
                    for k in ["N_m", "E_m", "D_m", "inclination_deg", "azimuth_grid_deg"]
                ],
                f"{row.minimum_SF:.9f}",
                f"{row.minimum_center_m:.9f}",
            ]
        )
    node_table = table(
        [["端点", "MD（m）", "N（m）", "E（m）", "D（m）", "I（°）", "A（°）", "SF", "中心距（m）"]]
        + node_rows
    )
    pd.DataFrame(
        node_rows, columns=["node", "MD_m", "N_m", "E_m", "D_m", "I_deg", "A_deg", "SF", "center_m"]
    ).to_csv(out / "adjustment_control_nodes.csv", index=False, encoding="utf-8-sig")
    mc = timing["minimum_curvature_comparison"]
    mc_table = table(
        [
            ["MC复算方式", "最大三维坐标差（m）", "终点三维坐标差（m）"],
            [
                "最终1m测斜表顺序MC",
                f"{mc['one_m_MC']['maximum_position_difference_m']:.9f}",
                f"{mc['one_m_MC']['endpoint_position_difference_m']:.9f}",
            ],
            [
                "仅四控制节点MC",
                f"{mc['control_node_only_MC']['maximum_position_difference_m']:.9f}",
                f"{mc['control_node_only_MC']['endpoint_position_difference_m']:.9f}",
            ],
        ]
    )
    constraints = table(
        [
            ["约束", "配置", "参与优化方式"],
            ["接回N/E/D", "原MD1300m位置，验收≤0.0001m", "三项等式"],
            ["接回井斜/方位", "原姿态，验收各≤0.00001°", "两项等式"],
            ["圆弧曲率", "0.01–5.999°/30m", "变量界+不等式"],
            ["直线曲率", "0", "固定，剔除变量"],
            ["各段长度", "1–533.7m", "变量界"],
            ["工具面", "−180°至180°，每弧段恒定", "变量界"],
            ["井斜", "0.01°–120°", "全段极值不等式"],
            ["单弧弯曲角", "≤150°", "不等式"],
            ["分离系数", "最终>1.5；优化缓冲0.05", "逐点/邻井不等式"],
            ["中心距", "最终>5m；优化缓冲0.15m", "中心线下界不等式"],
        ]
    )
    times = table(
        [
            ["阶段", "秒", "范围"],
            [
                "最终采用初值构造与验收",
                f"{initial['elapsed_seconds']:.6f}",
                "中间姿态/绕转网格、精确几何与1m验收",
            ],
            [
                "SLSQP优化",
                f"{report['optimization_seconds']:.6f}",
                f"{report['runs'][0]['iterations']}次迭代；求解成功={report['solver_success']}",
            ],
            ["求解器内结果验证", f"{report['validation_seconds']:.6f}", "不重复计入SLSQP优化"],
            ["最终调整段1m验收", f"{report['final_dense_seconds']:.6f}", "独立最终验收"],
            [
                "增量流程总时间",
                f"{timing['evaluation_wall_seconds']:.6f}",
                "含误差依赖更新、19井对扫描、修复、导出与抽查；不含NLP/工作簿",
            ],
            [
                "其中误差传播",
                f"{timing['uncertainty_seconds']:.6f}",
                "仅井14，保留从井口开始的累计历史",
            ],
            ["其中水平初筛", f"{timing['screening_seconds']:.6f}", "扫描与失效项修复的AABB初筛"],
            [
                "其中区间细化",
                f"{timing['interval_refinement_seconds']:.6f}",
                "保留候选的三维/SF细化",
            ],
            ["无关井对复用", "171/190", "没有调用扫描内核"],
            ["更新井对", "19/190", "全部涉及井14"],
        ]
    )
    params = json.loads((BASE / "models/iscwsa_rev0/parameters.json").read_text())[
        "effective_parameters"
    ]
    previews = "".join(
        f'<p>{html.escape(f.stem)}</p><img src="workbook_QA/{f.name}">'
        for f in sorted((out / "workbook_QA").glob("after_endpoint_*.png"))
    )
    replacements = {
        "__PLOTLY__": get_plotlyjs(),
        "__RESULT__": result_table,
        "__CONTROLS__": control_table,
        "__NODES__": node_table,
        "__MC__": mc_table,
        "__CONSTRAINTS__": constraints,
        "__TIMING__": times,
        "__PARAMETERS__": html.escape(json.dumps(params, ensure_ascii=False, indent=2)),
        "__PREVIEWS__": previews,
        "__DATA__": json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace(
            "</", "<\\/"
        ),
    }
    text = TEMPLATE
    for key, value in replacements.items():
        text = text.replace(key, value)
    (out / "index.html").write_text(text)
    # Scientific static export, with the same complete comparison data.
    f, axes = plt.subplots(2, 2, figsize=(17, 12), layout="constrained")
    axes[0, 0].plot(old.E_m, old.N_m, label="原井14", color="#2563eb")
    axes[0, 0].plot(track.E_m, track.N_m, label="调整后井14", color="#f97316")
    axes[0, 0].set(title="水平投影", xlabel="E（m）", ylabel="N（m）")
    axes[0, 0].axis("equal")
    axes[0, 0].legend()
    axes[0, 1].plot(old.MD_m, old.minimum_SF, label="调整前")
    axes[0, 1].plot(track.MD_m, track.minimum_SF, label="调整后")
    axes[0, 1].axhline(1.5, color="red", ls="--", label="SF=1.5")
    axes[0, 1].set(title="最小SF", xlabel="MD（m）", ylabel="SF", yscale="log")
    axes[0, 1].legend()
    axes[1, 0].plot(old.MD_m, old.minimum_center_m, label="调整前")
    axes[1, 0].plot(track.MD_m, track.minimum_center_m, label="调整后")
    axes[1, 0].axhline(5, color="red", ls="--", label="5m")
    axes[1, 0].set(
        title="最小中心距（浅部局部）",
        xlabel="MD（m）",
        ylabel="中心距（m）",
        xlim=(680, 1350),
        ylim=(0, 20),
    )
    axes[1, 0].legend()
    axes[1, 1].plot(comparison.MD_m, comparison.distance_difference_MC1m_m, label="完整1m表MC复算")
    axes[1, 1].set(
        title="1m最小曲率复算与恒工具面轨迹差别", xlabel="MD（m）", ylabel="三维坐标差（m）"
    )
    axes[1, 1].legend()
    for ax in axes.flat:
        ax.grid(alpha=0.2)
    f.savefig(fig / "local_replan_comparison.png", dpi=150, bbox_inches="tight")
    plt.close(f)
    narrative = f"""# 20口井组井14局部调整说明

## 1. 数据、危险区间与覆盖范围

原危险区间为MD763–868m，按Rev.0、K=1、SF≤1.5或中心距≤5m识别，原最小SF{old.minimum_SF.min():.9f}，最小中心距{old.minimum_center_m.min():.9f}m。接入原MD707m，接回原MD1300m，位置和方向固定并连续。

新三段总长{controls[:, 2].sum():.12f}m，替换原593m；新接回MD{ends[-1]:.12f}m。后续原坐标/井斜/方位保留，MD顺延{report["downstream_MD_shift_m"]:.12f}m；原井底坐标不变，新井底MD{track.MD_m.max():.12f}m。逐点1m表保留分数端点，段首/段尾直接计算而不按显示位数反算。

最终井14全井最小SF{track.minimum_SF.min():.9f}，最小采样中心距{track.minimum_center_m.min():.9f}m；调整段连续中心线的保守距离下界{report["final_check"]["minimum_centerline_distance_m"]:.9f}m。全部井14点符合SF>1.5且中心距>5m，控制曲率最大{controls[:, 0].max():.9f}°/30m<6。SLSQP成功={report["solver_success"]}，只表示此初值分支下的局部求解，没有全局最优证明。

## 2. 恒工具面恒曲率计算

每个曲线段κ=πDLS/(180×30)，I'(s)=κcosω，A'(s)=κsinω/sinI，p'(s)=(sinIcosA,sinIsinA,cosI)。角度积分内用弧度；I(s)=I0+κcosωs；当cosω非零时A(s)=A0+tanω ln[tan(I(s)/2)/tan(I0/2)]。位置用现有src/wellpath/geometry/segments.py的DOP853积分及特殊情况解析式。直线段κ=0、方向固定。ω在每个曲线段内恒定，不等同于最小曲率平面圆弧的初始工具面。

方位是周期角，构造初值必须考虑绕转分支；仅用两端方位差的最短角进行初值搜索可能漏掉可行空间曲线。端点姿态相同也不能推断两条曲线形状相同。

## 3. 可行初值的构造与时间

固定两端姿态，遍历中间I、未取模的中间A和末段A绕转分支。对弧段，ΔA=tanω×Δln(tan(I/2))；由两端姿态和绕转分支确定恒工具面ω及总曲率转角θ。确定姿态演化后，位置增量随段长线性缩放。用现有精确积分计算单位长度位移u1、u3，解三维线性系统[u1,t_mid,u3](L1,L2,L3)^T=p_target−p_start。

筛除负长度、曲率≥6、超井斜或弯曲角、超段长的结果；按邻井中心距进行候选筛选后，执行完整Rev.0、全部邻井1m评价。最终采用的初值构造及验收耗时{initial["elapsed_seconds"]:.6f}s，详细网格记录见splice_grid_summary.json、splice_grid_top_candidates.json、initialization.json。之前未通过的窗口和SQP分支搜索保留在上级各window目录，不计入这次最终构造时间。

## 4. SLSQP及约束

决策变量共7个：两曲线段各κ/ω/L，以及直线L。变量归一化到[0,1]，目标为三段总进尺最小。接回N/E/D和I/A为五项等式；曲率、长度、井斜极值、弯曲角、SF和中心距为优化过程中的不等式，求解器逐次调用，不是只做末次检验。为避免极窄位置容差不等式造成病态，局部接回精确采用等式替代重复窄带；其他任务的默认行为不变。

曲率界0.01–5.999°/30m，直线0；每段长1–533.7m；ω∈[−180°,180°]；I∈[0.01°,120°]；每弧总弯曲角≤150°。优化阶段SF缓冲0.05、中心距缓冲0.15m；最终以完整1m点/端点重新评价，要求SF>1.5、中心距>5m。接回验收位置≤0.0001m，I/A各≤0.00001°。全配置见problem.json/settings.json。

SLSQP优化{report["optimization_seconds"]:.6f}s、{report["runs"][0]["iterations"]}次迭代；最终位置误差{report["final_check"]["position_error_m"]:.12g}m、方向误差{report["final_check"]["tangent_direction_error_deg"]:.12g}°。收敛历史、逐次进尺和违反量见result.json，不把回退初值标为求解成功。

## 5. 默认Rev.0及增量依赖

Rev.0保留当前全部默认参数，误差从井口MD0连续传播，不在707m清零。测站保持原30m合成站逻辑，调整段加入分段边界；保留段测深顺延时，原测站身份同步映射，不能把所有变成分数MD的1m插值点误当成新测量站。

SF=D/[K(r1+r2)]，D为不同井采样点三维中心距，r_i=√λmax(C_i)，K=k_sigma=1；不扣井径/裕量，不额外加位置标准差。中心距独立评价。风险分级SF≤1红、≤1.5橙、≤2.5黄、其余蓝，中心距≤5直接红。页面其他K是精确缩放敏感性展示，未按该K重新求解。

复用171个不含井14的井对，19口邻井的模型/坐标不重建。井14接入前结果原样保留；只扫井14调整及其下游误差变化区与邻井。初筛用水平AABB距离下界及半径上界，随后精确三维/SF细化。对邻井逐点旧最小值若匹配已删除/改变的井14点，必须删除该旧最小值，并对保留前缀修复；保留171井对与前缀缓存不是简单全局再算。

井14下游几何未变但累计协方差和MD发生依赖变化，因此仍更新这些误差和井14相关扫描，这是局部更改引起的必要依赖更新，不是全井组模型重算。增量相关19井对的双向匹配和最小值都保存，其他井对复用。核查见incremental_verification.json，包括独立无筛选探针和所有输出匹配公式。

## 6. 1m插值与MC复算

写回的是恒工具面恒曲率轨迹的直接1m计算结果，额外保留四个控制端点。工作簿O列标“调整段/调整段端点0–3”；端点复用原浅黄色A:J样式，原有防碰高亮随新评价刷新。源文件先备份，候选工作簿全量验证后覆盖。

同一套1m MD/I/A从同一起点做顺序MC复算：Δp=(ΔMD/2)(t_i+t_(i+1))RF，RF=2tan(β/2)/β，β=atan2(||t_i×t_(i+1)||,t_i·t_(i+1))；不把每一步或最终终点重新锚回名义坐标。最大三维差{mc["one_m_MC"]["maximum_position_difference_m"]:.12f}m，终点差{mc["one_m_MC"]["endpoint_position_difference_m"]:.12f}m。

另用仅四个控制节点做MC积分，最大三维差{mc["control_node_only_MC"]["maximum_position_difference_m"]:.12f}m，终点差{mc["control_node_only_MC"]["endpoint_position_difference_m"]:.12f}m。此项用于展示粗离散误差，不能与完整1m复算混称。MC只能在离散测斜站间按平面圆弧逼近，恒局部工具面的真实空间曲线通常不与之严格重合，精细1m离散的差异小但不人为置零。

## 7. 计时、文件和复算

增量评价流程{timing["evaluation_wall_seconds"]:.6f}s，其中水平初筛{timing["screening_seconds"]:.6f}s、区间细化{timing["interval_refinement_seconds"]:.6f}s、误差传播{timing["uncertainty_seconds"]:.6f}s。总流程包含读取/构造/19井对扫描/失效修复/导出/独立探针；不含NLP与工作簿编辑。独占内部阶段不重复叠加到总墙钟时间。完整阶段/每井对见incremental_timing.json，工作簿及可视化另计。

主要结果：cluster_20_well_14_replanned.xlsx、updated_well14_1m.csv、updated_Rev0_K1_all_points.csv.gz、updated_Rev0_K1_pairs.csv、minimum_curvature_comparison_1m.csv、adjustment_control_nodes.csv、逐井Rev0_incremental_neighbors.npz和updated_well14_covariance.npz。171个复用井对有显式status，不伪造独立扫描耗时。

详细生效模型参数沿用上级历史报告及reproduction/中的系统说明，当前参数原样列在HTML中。本组共有19口邻井，其他模型仍保留在再规划前历史目录；本次只更新Rev.0。
"""
    (out / "notes.md").write_text(narrative)
    repro = out / "reproduction"
    repro.mkdir(exist_ok=True)
    snapshot_sources(ROOT, repro)
    save_json(
        out / "report_timing.json",
        dict(wall_seconds=time.perf_counter() - begin, included_in_optimization_or_scan=False),
    )
    parent = out.parent
    (parent / "index.html").write_text(
        '<html lang="zh-CN"><meta charset="utf-8"><meta http-equiv="refresh" content="0;url='
        + out.name
        + '/index.html"><a href="'
        + out.name
        + '/index.html">打开20口井组井14最终局部调整报告</a></html>'
    )
    print("Report saved", out / "index.html")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--output", type=Path, required=True)
    run(p.parse_args().output)
