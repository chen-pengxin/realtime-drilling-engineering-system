"""Offline single-file dashboards and scientific figures for cluster K scans."""

import argparse
import csv
import json
import time
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import BoundaryNorm, ListedColormap
from plotly.offline import get_plotlyjs

from wellpath.workflows.uncertainty_comparison import save_json

matplotlib.use("Agg")


COLORS = ["#dc2626", "#f97316", "#eab308", "#2563eb"]
LEVELS = ["红：危险", "橙：警告", "黄：关注", "蓝：安全"]
plt.rcParams.update(
    {"font.family": "Arial Unicode MS", "axes.unicode_minus": False, "font.size": 10}
)


def figure_save(fig, folder, name):
    fig.savefig(folder / name, dpi=150, bbox_inches="tight")
    plt.close(fig)


def static_figures(folder, data, pairs):
    out = folder / "figures"
    out.mkdir(exist_ok=True)
    names = data["models"]
    wells = data["wells"]
    n = len(wells)
    labels = data["labels"]
    ks = data["k_values"]
    cmap = ListedColormap(COLORS)
    norm = BoundaryNorm([-0.5, 0.5, 1.5, 2.5, 3.5], 4)
    matrix_center = np.full((n, n), np.nan)
    for r in pairs:
        if r["model"] != names[0] or r["K"] != 1:
            continue
        i = int(r["well_a"][1:]) - 1
        j = int(r["well_b"][1:]) - 1
        matrix_center[i, j] = matrix_center[j, i] = r["minimum_center_m"]
    for kval in ks:
        fig, axes = plt.subplots(2, 5, figsize=(25, 10), layout="constrained")
        for ax, name in zip(axes.flat, names):
            values = np.full((n, n), np.nan)
            codes = values.copy()
            for r in pairs:
                if r["model"] != name or r["K"] != kval:
                    continue
                i = int(r["well_a"][1:]) - 1
                j = int(r["well_b"][1:]) - 1
                values[i, j] = values[j, i] = r["minimum_SF"]
                codes[i, j] = codes[j, i] = r["risk_code"]
            ax.imshow(np.ma.masked_invalid(codes), cmap=cmap, norm=norm)
            ax.set_title(labels[name])
            ax.set_xticks(range(n), range(1, n + 1), fontsize=7)
            ax.set_yticks(range(n), range(1, n + 1), fontsize=7)
            for i in range(n):
                for j in range(n):
                    if i != j:
                        ax.text(
                            j,
                            i,
                            f"{values[i, j]:.2f}",
                            ha="center",
                            va="center",
                            fontsize=4.5 if n == 20 else 5.5,
                            color="white" if codes[i, j] in [0, 3] else "#111827",
                        )
        fig.suptitle(
            f"{n}口井最小SF矩阵，K={kval:g}；数字为SF，颜色为联合等级（含中心距≤5m判红）",
            fontsize=16,
        )
        figure_save(fig, out, f"SF_matrices_K{kval:g}.png")
    fig, ax = plt.subplots(figsize=(10, 9), layout="constrained")
    im = ax.imshow(matrix_center, cmap="viridis_r")
    ax.set_xticks(range(n), range(1, n + 1))
    ax.set_yticks(range(n), range(1, n + 1))
    ax.set_title(f"{n}口井最小中心距矩阵（m，不随K或误差模型变化）")
    for i in range(n):
        for j in range(n):
            if i != j:
                ax.text(j, i, f"{matrix_center[i, j]:.1f}", ha="center", va="center", fontsize=5.5)
    fig.colorbar(im, ax=ax, shrink=0.8, label="中心距（m）")
    figure_save(fig, out, "center_distance_matrix.png")
    for key, title, filename in [
        ("sf1", "K=1逐点最小SF（全部误差模型）", "SF_profiles_all_wells.png"),
        ("radius", "误差半径：协方差最大半轴或标量边界（m）", "uncertainty_profiles_all_wells.png"),
    ]:
        rows = int(np.ceil(n / 3))
        fig, axes = plt.subplots(rows, 3, figsize=(18, 3.1 * rows), layout="constrained")
        for ax, w in zip(axes.flat, wells):
            for name in names:
                ax.plot(w["md"], w["models"][name][key], lw=0.8, label=labels[name])
            if key == "sf1":
                for threshold in [1, 1.5, 2.5]:
                    ax.axhline(threshold, lw=0.5, color="#64748b", ls="--")
            ax.set(title=w["name"], xlabel="MD（m）")
            ax.set_yscale("log")
            ax.grid(alpha=0.2)
        for ax in axes.flat[n:]:
            ax.set_visible(False)
        handles, texts = axes.flat[0].get_legend_handles_labels()
        fig.legend(handles, texts, loc="outside lower center", ncol=5)
        fig.suptitle(title)
        figure_save(fig, out, filename)
    fig, axes = plt.subplots(1, 4, figsize=(23, 6), layout="constrained")
    for ax, kval in zip(axes, ks):
        summaries = [r for r in data["summaries"] if r["K"] == kval]
        left = np.zeros(len(names))
        for level, c in zip(["red", "orange", "yellow", "blue"], COLORS):
            v = np.array([r[f"{level}_points"] for r in summaries])
            ax.barh([labels[name] for name in names], v, left=left, color=c, label=level)
            left += v
        ax.invert_yaxis()
        ax.set(title=f"K={kval:g}", xlabel="轨迹点数")
        if ax != axes[0]:
            ax.set_yticklabels([])
    handles, texts = axes[0].get_legend_handles_labels()
    fig.legend(handles, LEVELS, loc="outside lower center", ncol=4)
    fig.suptitle("各K值与误差模型的联合风险分级（中心距≤5m直接判红）")
    figure_save(fig, out, "risk_K_comparison.png")
    fig, axes = plt.subplots(1, 3, figsize=(18, 6), layout="constrained")
    for w in wells:
        x = np.array(w["positions"])
        axes[0].plot(x[:, 1], x[:, 0], label=w["name"])
        axes[1].plot(x[:, 1], x[:, 2])
        axes[2].plot(x[:, 0], x[:, 2])
    axes[0].set(title="水平面 E–N", xlabel="E（m）", ylabel="N（m）")
    axes[0].axis("equal")
    for ax, label in zip(axes[1:], ["E", "N"]):
        ax.set(title=f"{label}–D垂直投影", xlabel=f"{label}（m）", ylabel="D（m）")
        ax.invert_yaxis()
    handles, texts = axes[0].get_legend_handles_labels()
    fig.legend(handles, texts, loc="outside lower center", ncol=10)
    figure_save(fig, out, "trajectory_projections.png")
    timing = data["scan_timing"]
    fig, ax = plt.subplots(figsize=(12, 3), layout="constrained")
    left = 0.0
    for key, label, c in [
        ("uncertainty_construction_seconds", "误差模型构造", "#a78bfa"),
        ("center_distance_seconds", "中心距搜索", "#0d9488"),
        ("screening_seconds", "水平包围盒初筛", "#f59e0b"),
        ("interval_refinement_seconds", "候选区间细化", "#2563eb"),
        ("aggregation_and_control_seconds", "匹配分级及控制", "#94a3b8"),
    ]:
        v = timing[key]
        ax.barh(["共享评价"], [v], left=left, label=f"{label} {v:.3f}s", color=c)
        left += v
    ax.set(
        xlabel="墙钟时间（s）",
        title=f"10模型共享扫描 {timing['evaluation_total_seconds']:.3f}s；四个K精确换算，不重复扫描",
    )
    fig.legend(loc="outside lower center", ncol=3)
    figure_save(fig, out, "timing_breakdown.png")


TEMPLATE = r"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>__TITLE__</title>
<style>body{margin:0;background:#eef2f7;color:#172033;font-family:Arial,"PingFang SC",sans-serif}main{max-width:1500px;margin:auto;padding:28px}section{padding:22px;background:white;border-radius:10px;margin:20px 0}h1{font-size:28px}h2{font-size:21px}p,li{line-height:1.8}select{font-size:15px;padding:9px;margin-right:16px}label{display:inline-block;margin:6px 0}.controls{position:sticky;top:0;background:#f8fafc;z-index:4;padding:12px;border-bottom:1px solid #cbd5e1}.plot{height:650px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.smallplot{height:530px}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:8px;border-bottom:1px solid #e2e8f0;text-align:right;white-space:nowrap}th{background:#183653;color:white;cursor:pointer}th:first-child,td:first-child{text-align:left}img{width:100%;height:auto}.scroll{overflow:auto;max-height:550px}a{color:#1d4ed8}.legend span{margin-right:20px}.note{color:#475569}details{margin:14px 0}summary{cursor:pointer;font-size:18px}.stats{font-size:16px;line-height:1.9}@media(max-width:900px){.grid{display:block}}</style>
<script>__PLOTLY__</script></head><body><main><h1>__TITLE__</h1>
<p>__DESCRIPTION__</p><p><a href="../index.html">返回三个井组总览</a>　<a href="collision_assessment_summary.xlsx">Excel汇总</a>　<a href="model_K_summary.csv">全部模型×K汇总CSV</a>　<a href="all_model_K_pairs.csv">全部井对CSV</a>　<a href="report.md">方法、参数与数据说明</a></p>
<section><h2>评价方法与边界</h2><p>中心距：全部异井采样点组合中的三维欧氏距离最小值。分离系数：SF=D/[K(r₁+r₂)]；协方差模型 r=√λmax(C)，标量模型 r 为当前经验边界半径。未扣井径、未扣裕量，未额外加入位置标准差。SF与中心距的最小值可能来自不同点对。</p><p>SF≤1红色；1&lt;SF≤1.5橙色；1.5&lt;SF≤2.5黄色；SF&gt;2.5蓝色。联合分级另将中心距≤5m直接判红。规划安全要求SF&gt;1.5且中心距&gt;5m。本次未剔除井口或浅部。</p><p class="note">输入文件均以“设计方案”命名，未附独立实钻身份或仪器校准元数据。本次按文件实际轨迹评价，不将其宣称为现场实钻。地磁、测量误差和经验参数沿用项目配置，结果用于参数敏感性比较。</p></section>
<div class="controls"><label>误差模型 <select id="model"></select></label><label>K <select id="k"></select></label><label>着色方法 <select id="method"><option value="combined">联合分级（SF+中心距）</option><option value="sf">仅SF分级</option><option value="center">仅中心距（≤5m判红）</option></select></label></div>
<section><h2>当前选择结果</h2><div id="stats" class="stats"></div><div class="legend"><span style="color:#dc2626">● 红：危险</span><span style="color:#f97316">● 橙：警告</span><span style="color:#ca8a04">● 黄：关注</span><span style="color:#2563eb">● 蓝：安全</span></div></section>
<section><h2>交互三维轨迹</h2><p>可旋转、缩放；点击图例隐藏井，双击单独显示。悬停可查看MD、SF、中心距及误差半径。所有源轨迹点保留。</p><div id="three" class="plot"></div></section>
<section><h2>水平面与垂直投影</h2><div class="grid"><div id="plan" class="smallplot"></div><div id="east" class="smallplot"></div><div id="north" class="smallplot"></div><div id="profile" class="smallplot"></div></div></section>
<section><h2>井对矩阵与沿程评价</h2><div class="grid"><div id="sfmatrix" class="smallplot"></div><div id="centermatrix" class="smallplot"></div><div id="centerprofile" class="smallplot"></div><div id="radiusprofile" class="smallplot"></div></div><p class="note">SF矩阵颜色随所选着色方法变化；数字始终是SF。中心距矩阵与中心距曲线不随模型或K改变。误差半径为未经K放大的基础半径。</p></section>
<section><h2>全部井对（点击列名排序）</h2><div id="pairs" class="scroll"></div></section>
<section><h2>十种模型与四个K对比</h2><div id="risks" style="height:650px"></div><div class="scroll"><table id="summary"></table></div></section>
<section><h2>评价耗时</h2>__TIMING__<img src="figures/timing_breakdown.png"></section>
__STATIC__
<section><h2>完整数据如何查阅</h2><p>每个 K_数值/模型名/ 目录保存井对、逐井、连续风险区间CSV和逐点 point_scan.csv.gz。models/ 保存各误差模型参数、逐点误差半径/协方差及适用模型的测站误差项。shared/ 保存中心距、原轨迹、逐点对每口邻井的最小SF及匹配索引NPZ。NPZ的minimum_sf_K1轴序为[模型,本井点,邻井]，其他K精确除以K；邻井点索引从0开始。完整笛卡尔点对矩阵未保存。</p></section>
</main><script>
const DATA=__DATA__, PAIRS=__PAIRS__, C=['#dc2626','#f97316','#eab308','#2563eb'], levels=['红：危险','橙：警告','黄：关注','蓝：安全'];
const model=document.getElementById('model'),ks=document.getElementById('k'),method=document.getElementById('method');
DATA.models.forEach(m=>model.add(new Option(DATA.labels[m],m)));model.value='iscwsa_rev0';DATA.k_values.forEach(k=>ks.add(new Option(k,k)));
const base={font:{family:'Arial, PingFang SC'},margin:{l:70,r:35,t:55,b:65},legend:{orientation:'h',y:-.18},uirevision:'preserve'};
function grade(sf,d){let g=sf<=1?0:sf<=1.5?1:sf<=2.5?2:3;return method.value==='center'?(d<=5?0:3):method.value==='combined'&&d<=5?0:g;}
const buttons={responsive:true,displaylogo:false,toImageButtonOptions:{format:'png',scale:2}};
let sorting='minimum_SF',ascending=true;
function pairTable(rows){rows=[...rows].sort((a,b)=>typeof a[sorting]==='string'?(ascending?1:-1)*a[sorting].localeCompare(b[sorting]):(ascending?1:-1)*(a[sorting]-b[sorting]));
const cols=[['well_a','井A'],['well_b','井B'],['minimum_SF','最小SF'],['minimum_center_m','最小中心距(m)'],['SF_MD_a_m','SF点MD-A(m)'],['SF_MD_b_m','SF点MD-B(m)'],['distance_at_SF_min_m','SF点对距离(m)'],['center_MD_a_m','中心距MD-A(m)'],['center_MD_b_m','中心距MD-B(m)']];
document.getElementById('pairs').innerHTML='<table><thead><tr>'+cols.map(([key,label])=>`<th data-key="${key}">${label}</th>`).join('')+'<th>当前等级</th></tr></thead><tbody>'+rows.map(r=>'<tr>'+cols.map(([key])=>`<td>${typeof r[key]==='number'?r[key].toFixed(5):r[key]}</td>`).join('')+`<td style="color:${C[grade(r.minimum_SF,r.minimum_center_m)]}">${levels[grade(r.minimum_SF,r.minimum_center_m)]}</td></tr>`).join('')+'</tbody></table>';
document.querySelectorAll('#pairs th[data-key]').forEach(th=>th.onclick=()=>{if(sorting===th.dataset.key)ascending=!ascending;else{sorting=th.dataset.key;ascending=true;}pairTable(rows);});}
function update(){const m=model.value,k=+ks.value,n=DATA.wells.length;const rows=PAIRS.filter(r=>r.model===m&&r.K===k);const s=DATA.summaries.find(r=>r.model===m&&r.K===k);
document.getElementById('stats').textContent=`${DATA.labels[m]}，K=${k}；最小SF=${s.minimum_SF.toFixed(6)}；最小中心距=${s.minimum_center_m.toFixed(6)}m；SF≤1.5井对=${s.sf_le_1_5_pairs}/${s.well_pairs}；中心距≤5m井对=${s.center_le_5m_pairs}；联合不满足规划安全井对=${s.combined_unsafe_pairs}。`;
let three=[],plan=[],east=[],north=[],sf=[],center=[],radius=[];
DATA.wells.forEach(w=>{const d=w.models[m],v=d.sf1.map(x=>x/k),codes=v.map((x,i)=>grade(x,w.center[i])),color=codes.map(g=>C[g]);const e=w.positions.map(p=>p[1]),nn=w.positions.map(p=>p[0]),z=w.positions.map(p=>p[2]);const custom=w.md.map((md,i)=>[md,v[i],w.center[i],d.radius[i],levels[codes[i]]]);
const hover=w.name+'<br>MD=%{customdata[0]:.3f}m<br>SF=%{customdata[1]:.6f}<br>中心距=%{customdata[2]:.4f}m<br>基础半径=%{customdata[3]:.4f}m<br>%{customdata[4]}<extra></extra>';
three.push({type:'scatter3d',mode:'lines+markers',name:w.name,x:e,y:nn,z:z,line:{width:2,color:'#a8b3c2'},marker:{size:2,color:color},customdata:custom,hovertemplate:hover});
for(const [dest,x,y] of [[plan,e,nn],[east,e,z],[north,nn,z]])dest.push({type:'scattergl',mode:'lines+markers',name:w.name,x,y,line:{width:1,color:'#a8b3c2'},marker:{size:2,color:color},customdata:custom,hovertemplate:hover});
sf.push({type:'scattergl',mode:'lines',name:w.name,x:w.md,y:v});center.push({type:'scattergl',mode:'lines',name:w.name,x:w.md,y:w.center});radius.push({type:'scattergl',mode:'lines',name:w.name,x:w.md,y:d.radius});});
levels.forEach((name,i)=>three.push({type:'scatter3d',mode:'markers',name,x:[null],y:[null],z:[null],marker:{size:6,color:C[i]},hoverinfo:'skip'}));
Plotly.react('three',three,{...base,height:650,title:{text:DATA.labels[m]+', K='+k},scene:{xaxis:{title:{text:'东坐标E(m)'}},yaxis:{title:{text:'北坐标N(m)'}},zaxis:{title:{text:'垂深D(m)'},autorange:'reversed'},aspectmode:'data',uirevision:'same-camera'},legend:{x:1,y:1},margin:{l:0,r:170,t:45,b:0}},buttons);
for(const [id,traces,xlabel,ylabel,rev] of [['plan',plan,'E(m)','N(m)',false],['east',east,'E(m)','D(m)',true],['north',north,'N(m)','D(m)',true]])Plotly.react(id,traces,{...base,title:{text:xlabel+'–'+ylabel},xaxis:{title:{text:xlabel}},yaxis:{title:{text:ylabel},autorange:rev?'reversed':true,...(id==='plan'?{scaleanchor:'x',scaleratio:1}:{})}},buttons);
Plotly.react('profile',sf,{...base,title:{text:'逐点最小SF'},xaxis:{title:{text:'MD(m)'}},yaxis:{title:{text:'SF'},type:'log'},shapes:[1,1.5,2.5].map(t=>({type:'line',xref:'paper',x0:0,x1:1,y0:t,y1:t,line:{color:'#64748b',dash:'dash',width:1}}))},buttons);
Plotly.react('centerprofile',center,{...base,title:{text:'逐点最小中心距'},xaxis:{title:{text:'MD(m)'}},yaxis:{title:{text:'中心距(m)'}},shapes:[{type:'line',xref:'paper',x0:0,x1:1,y0:5,y1:5,line:{color:C[0],dash:'dash'}}]},buttons);
Plotly.react('radiusprofile',radius,{...base,title:{text:'基础误差半径（未乘K）'},xaxis:{title:{text:'MD(m)'}},yaxis:{title:{text:'半径(m)'}}},buttons);
let a=Array.from({length:n},()=>Array(n).fill(null)),d=a.map(r=>[...r]),g=a.map(r=>[...r]);
rows.forEach(r=>{let i=+r.well_a.slice(1)-1,j=+r.well_b.slice(1)-1;a[i][j]=a[j][i]=r.minimum_SF;d[i][j]=d[j][i]=r.minimum_center_m;g[i][j]=g[j][i]=grade(r.minimum_SF,r.minimum_center_m);});
const wn=DATA.wells.map(w=>w.name),colorscale=[[0,C[0]],[.1666,C[0]],[.1667,C[1]],[.5,C[1]],[.5001,C[2]],[.8333,C[2]],[.8334,C[3]],[1,C[3]]];
Plotly.react('sfmatrix',[{type:'heatmap',x:wn,y:wn,z:g,zmin:0,zmax:3,customdata:a,text:a.map(row=>row.map(v=>v===null?'':v.toFixed(2))),texttemplate:'%{text}',textfont:{size:n>16?8:10},colorscale,showscale:false,hovertemplate:'%{y} / %{x}<br>SF=%{customdata:.6f}<extra></extra>'}],{...base,title:{text:'井对最小SF（数字）与所选方法等级（颜色）'},yaxis:{autorange:'reversed'}},buttons);
Plotly.react('centermatrix',[{type:'heatmap',x:wn,y:wn,z:d,colorscale:'Viridis',reversescale:true,hovertemplate:'%{y} / %{x}<br>中心距=%{z:.6f}m<extra></extra>'}],{...base,title:{text:'井对最小中心距(m)'},yaxis:{autorange:'reversed'}},buttons);
pairTable(rows);
const summary=DATA.summaries.filter(r=>r.K===k);
Plotly.react('risks',['red','orange','yellow','blue'].map((l,i)=>({type:'bar',orientation:'h',name:levels[i],y:summary.map(r=>r.label),x:summary.map(r=>r[l+'_points']),marker:{color:C[i]}})),{...base,title:{text:'当前K的各模型联合分级点数'},barmode:'stack',margin:{l:220,r:20,t:50,b:90},yaxis:{autorange:'reversed'}},buttons);
document.getElementById('summary').innerHTML='<tr><th>模型</th><th>K</th><th>最小SF</th><th>SF≤1.5井对</th><th>联合不安全井对</th><th>红点</th><th>橙点</th><th>黄点</th><th>蓝点</th></tr>'+DATA.summaries.map(r=>'<tr>'+[r.label,r.K,r.minimum_SF.toFixed(6),r.sf_le_1_5_pairs,r.combined_unsafe_pairs,r.red_points,r.orange_points,r.yellow_points,r.blue_points].map(v=>'<td>'+v+'</td>').join('')+'</tr>').join('');}
model.onchange=update;ks.onchange=update;method.onchange=update;update();
</script></body></html>"""


def run(output, skip_figures=False):
    output = Path(output)
    all_summaries = []
    batch_start = time.perf_counter()
    for folder in sorted(output.glob("group_*")):
        start = time.perf_counter()
        data = json.loads((folder / "visualization_data.json").read_text())
        rows = list(csv.DictReader((folder / "all_model_K_pairs.csv").open(encoding="utf-8-sig")))
        pairs = [
            {
                k: (v if k in ["group", "model", "well_a", "well_b", "risk"] else float(v))
                for k, v in row.items()
            }
            for row in rows
        ]
        if not skip_figures:
            static_figures(folder, data, pairs)
        n = len(data["wells"])
        point_count = sum(len(w["md"]) for w in data["wells"])
        timing = data["scan_timing"]
        timing_text = (
            f"<p>共享10模型完整评价 {timing['evaluation_total_seconds']:.3f}s；水平初筛 {timing['screening_seconds']:.3f}s；候选区间细化 {timing['interval_refinement_seconds']:.3f}s；中心距搜索 {timing['center_distance_seconds']:.3f}s；误差构造 {timing['uncertainty_construction_seconds']:.3f}s。此处不含读取、导出、绘图与独立验证。不是各模型独立端到端计时。</p><table><tr><th>K</th><th>精确换算、匹配分级及汇总(s)</th><th>该K完整导出(s)</th></tr>"
            + "".join(
                f"<tr><td>{r['K']:g}</td><td>{r['derivation_and_grading_seconds']:.4f}</td><td>{r['export_seconds']:.4f}</td></tr>"
                for r in data["K_timing"]
            )
            + "</table>"
        )
        static = ""
        for filename, title in [
            ("risk_K_comparison.png", "四个K风险分级对比"),
            ("center_distance_matrix.png", "中心距矩阵"),
            ("trajectory_projections.png", "轨迹二维投影"),
            ("SF_profiles_all_wells.png", "所有井与模型的SF曲线"),
            ("uncertainty_profiles_all_wells.png", "所有井与模型的误差半径曲线"),
            *[(f"SF_matrices_K{k:g}.png", f"K={k:g}十模型井对矩阵") for k in data["k_values"]],
        ]:
            static += f'<section><details><summary>{title}</summary><img loading="lazy" src="figures/{filename}"></details></section>'
        replacements = dict(
            __TITLE__=f"{n}口井丛式井组防碰评价",
            __DESCRIPTION__=f"{point_count:,}个完整轨迹点，{n * (n - 1) // 2}个井对；10种误差模型 × K=1、2、2.5、3。默认显示ISCWSA Rev.0、K=1。此HTML包含数据与交互图运行库，可离线使用；静态图和下载表需保留相邻目录。",
            __PLOTLY__=get_plotlyjs(),
            __TIMING__=timing_text,
            __STATIC__=static,
            __DATA__=json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace(
                "</", "<\\/"
            ),
            __PAIRS__=json.dumps(pairs, ensure_ascii=False, separators=(",", ":")).replace(
                "</", "<\\/"
            ),
        )
        document = TEMPLATE
        # Replace script data after library injection; no regex or template evaluation.
        for key, value in replacements.items():
            document = document.replace(key, value)
        (folder / "index.html").write_text(document)
        report(folder, data, timing)
        all_summaries.extend(data["summaries"])
        save_json(
            folder / "visualization_timing.json",
            dict(
                wall_seconds=time.perf_counter() - start,
                scope="HTML/report regeneration only; existing static figures reused"
                if skip_figures
                else "Static figures plus HTML/report generation",
                included_in_numerical_evaluation=False,
            ),
        )
        print(folder.name, "visualization complete", flush=True)
    index = '<html lang="zh-CN"><meta charset="utf-8"><title>三个丛式井组防碰评价总览</title><style>body{font-family:Arial,"PingFang SC",sans-serif;background:#f1f5f9;color:#172033;max-width:1400px;margin:auto;padding:35px}section{background:white;padding:22px;margin:20px 0}table{border-collapse:collapse}td,th{padding:10px;border-bottom:1px solid #ddd;text-align:right}a{color:#1d4ed8}</style><h1>三个丛式井组防碰评价总览</h1><p>井筒中心距法与最小分离系数法。10种当前误差模型，K=1、2、2.5、3，共120个井组—模型—K组合。点击井组打开交互3D、水平/垂直投影、SF/中心距曲线、矩阵、模型与K对比及数据下载。</p>'
    for n in [15, 16, 20]:
        index += f'<section><h2><a href="group_{n}/index.html">{n}口井可视化总览</a></h2><p><a href="group_{n}/collision_assessment_summary.xlsx">Excel汇总</a>　<a href="group_{n}/report.md">报告与配置说明</a></p><table><tr><th>默认Rev.0的K值</th><th>最小SF</th><th>最小中心距(m)</th><th>SF≤1.5井对</th><th>中心距≤5m井对</th><th>联合不满足规划安全井对</th></tr>'
        for r in all_summaries:
            if r["group"] != f"group_{n}" or r["model"] != "iscwsa_rev0":
                continue
            index += (
                "<tr>"
                + "".join(
                    f"<td>{v}</td>"
                    for v in [
                        r["K"],
                        f"{r['minimum_SF']:.6f}",
                        f"{r['minimum_center_m']:.6f}",
                        r["sf_le_1_5_pairs"],
                        r["center_le_5m_pairs"],
                        r["combined_unsafe_pairs"],
                    ]
                )
                + "</tr>"
            )
        index += "</table></section>"
    index += '<p>中心距不受K或误差模型影响；SF_K=SF_1/K。未剔除井口和浅部，因此井口间距≤5m会直接判红。参数沿用当前系统，未针对这三个井组现场校准。详见各组报告。</p><p><a href="all_groups_model_K_summary.csv">三组120组合汇总CSV</a>　<a href="verification.json">独立数值核查记录</a></p></html>'
    (output / "index.html").write_text(index)
    save_json(
        output / "visualization_timing.json",
        dict(
            wall_seconds=time.perf_counter() - batch_start,
            scope="HTML/report regeneration only; existing static figures reused"
            if skip_figures
            else "Static figures plus HTML/report generation",
        ),
    )


def report(folder, data, timing):
    _cfg = json.loads((folder / "config.json").read_text())
    audit = json.loads((folder / "input_audit.json").read_text())
    text = f"""# {len(data["wells"])}口井组防碰评价

## 1. 输入与评价范围

输入为 `{Path(audit["source_file"]).name}`，共 {audit["total_points"]:,} 个轨迹点，{audit["pairs"]} 个井对。读取源表完整数值，N/E/D坐标原样保留，未将显示精度当作数值精度。原文件哈希前后相同。源文件均以设计方案命名，未提供单独标识的实钻轨迹文件，不推断现场实钻身份。

轨迹扫描使用源文件的1m网格及全部非整数测深端点。不是同测深点比较，而是每对井全部采样点的组合；未排除井口或浅部。中心距是采样点法结果，不是连续曲线最短距离的严格认证。

## 2. 井筒中心距法

点对距离为 D=||x_p-x_q||₂，坐标轴顺序为北/东/垂深。逐点中心距取所有邻井点中的最小值，井对中心距取两井全部点对中的最小值。采用精确KD树搜索，eps=0，保留匹配点。中心距≤5m直接判红；中心距不随误差模型或K改变。

## 3. 最小分离系数法

所有模型使用 SF=D/[K(r₁+r₂)]，K分别为1、2、2.5、3。协方差模型半径为1σ协方差最大特征值的平方根；MD标量模型使用当前系统scalar_radius实现的经验边界，非统计1σ的声明。简化MWD沿用项目球形包络代理。误差模型和参数不因K改变。

SF公式不扣除井径/附加裕量，也不添加额外位置标准差。各误差模型自身已配置的起点协方差仍按其参数生效。例如Rev5.11演示配置含起点协方差diag(0.25,0.25,0.25)m²；Rev.0本次未另加起点位置标准差。

逐点SF与井对SF分别取全邻井/全点组合最小值。最大半轴而非连心线投影是本次统一半径口径。最小SF点对与最小中心距点对可不同，导出中分开保存。

## 4. 风险分级

SF≤1红色；1<SF≤1.5橙色；1.5<SF≤2.5黄色；SF>2.5蓝色。联合等级再将中心距≤5m置为红色。SF单独等级与联合等级分别导出。规划安全要求SF>1.5且中心距>5m。

## 5. 初筛、细化与K共享

SF扫描先将井段点集分块，在水平E–N平面计算轴对齐包围盒间距下界，结合块内最大误差半径上界构造SF下界。仅当不能改善双方任一逐点最小SF时才剪除。剩余块计算完整三维距离和SF并更新双方匹配；此处细化指候选区间的点对计算，不是新增插值网格。中心距独立使用精确KD树。

K是全井一致的正数，故min(D/[K(r₁+r₂)])=min(D/(r₁+r₂))/K，匹配点也保持不变。因此共享一次10模型K=1扫描，四个K分别精确换算并重新分级和汇总，避免重复相同几何计算。共享扫描时间不得重复计入四次。原始零误差点的无穷SF在内核采用极小正分母保护，最终保存的最小SF点对均另行以原始半径核查。

## 6. 误差模型与有效参数

本次沿用当前系统十种模型。Rev.0为交互页面默认选择。地磁参数、仪器误差与经验系数没有针对本井组校准，比较结果反映模型敏感性，不是预测准确率排名。ISCWSA、Rev.0及WdW使用30m合成测站，并额外保留非整数端点；测站姿态采用最小曲率插值，协方差插值到扫描点。源坐标不重算、不覆盖。

网格方位按零子午线收敛角等同真方位处理。源数据未提供仪器型号、磁场实测值、坐标参考系或误差校准资料；这些是使用现场标定参数前需补齐的信息。

"""
    for name in data["models"]:
        p = json.loads((folder / "models" / name / "parameters.json").read_text())
        text += f"### {data['labels'][name]}（{name}）\n\n"
        text += (
            "半径定义："
            + p["radius_definition"]
            + "。参数与单位沿用当前模型API；全部生效参数如下。\n\n```json\n"
            + json.dumps(p, ensure_ascii=False, indent=2)
            + "\n```\n\n"
        )
    text += "## 7. 评价计时\n\n共享十模型评价的墙钟时间分解如下（不含读取、导出、可视化和独立验证）。各模型内核时间不等于各模型独立端到端耗时。\n\n"
    for key, label in [
        ("evaluation_total_seconds", "评价总时间"),
        ("uncertainty_construction_seconds", "模型构造"),
        ("center_distance_seconds", "中心距搜索"),
        ("screening_seconds", "水平初筛"),
        ("interval_refinement_seconds", "候选区间细化"),
        ("aggregation_and_control_seconds", "匹配分级及控制开销"),
    ]:
        text += f"- {label}：{timing[key]:.6f} s。\n"
    text += "\n各K的精确换算分级、导出及共享扫描定义见timing.json；输入读取与组内数值导出全流程见input_audit.json；绘图另见visualization_timing.json。\n\n## 8. 保存结构与复算\n\n"
    text += "- index.html：带内嵌数据及运行库的离线交互报告；静态PNG和下载项位于相邻目录。\n- K_*/模型/point_scan.csv.gz：完整逐点最小SF、匹配邻井点、两半径、中心距和分级。gzip压缩CSV可解压读取。\n- 同目录pair_scan.csv、well_summary.csv、risk_intervals.csv：井对、逐井及风险区间结果。\n- shared/*_all_neighbors_K1.npz：每个模型、每个本井点对每口邻井的最小SF及匹配索引，轴为[模型,本井点,邻井]；其他K除以K。\n- shared/center_distance_points.csv及center_distance_pairs.csv：完整中心距结果。\n- models/：全部模型参数、逐点协方差或标量半径、测站与分项协方差。\n- collision_assessment_summary.xlsx：模型×K汇总、全部井对、逐井汇总与配置和计时。完整逐点数据在CSV.gz/NPZ，不重复塞入超大Excel。\n- ../reproduction/：本次数值与图表脚本及现有内核快照。\n\n当前系统各模型原理与技术来源见项目的《docs/error_models_manual.md》及《rev0_wdw_parameter_audit.md》。本次没有新增或校准误差模型。\n"
    (folder / "report.md").write_text(text)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--html-only", action="store_true")
    args = p.parse_args()
    run(args.output, args.html_only)
