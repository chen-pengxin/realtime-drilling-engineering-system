"""HTML and Markdown explanations tied to the actual four-solver implementation."""

import html
import json


def algorithm_explanations_html(settings):
    options = settings["solver"].get("algorithm_options", {})
    content = (
        r"""<section id="algorithm-principles"><h2>四算法原理、约束参与方式与执行流程</h2>
<p><strong>共同数学问题。</strong> 七个决策变量为两圆弧的DLS、初始工具面和段长，以及中间直线段长。变量按上下界归一化为z∈[0,1]⁷，目标是最小化新钻进尺，内部使用 f(z)=(L₁+L₂+L₃)/S，S为起点至靶点的距离尺度。每一次试探z都会按最小曲率递推轨迹、从固定实钻历史继续传播Rev.0协方差、计算SF与中心距，再返回整组不等式g(z)≥0；防碰、中靶和工程约束参与优化过程。</p>
<pre>minimize    f(z) = [L₁(z)+L₂(z)+L₃(z)] / S
subject to  0 ≤ z ≤ 1
            ||x_end(z)−x_target|| ≤ 0.49 m          [优化保护半径]
            |I_end−89°| ≤ 0.5°
            |wrap(A_end−145.9°)| ≤ 0.5°
            SF_p(z) ≥ 1.53   [每个新段扫描点，对各邻井点取最小]
            d_center,lower(z) ≥ 5.1 m               [每口邻井]
            0.1° ≤ I(s,z) ≤ 95°                    [段内解析极值]
            每弧累计转角 ≤ 150°；分段长度/工具面/DLS在配置范围
final check ||x_end−x_target|| ≤ 0.5 m，DLS &lt; 6，SF &gt; 1.5，中心距下界 &gt; 5 m</pre>
<p><strong>约束缩放。</strong> SF约束除以1.5，中心距约束除以5 m，姿态误差除以30°，位置球约束用(ρ²−||e||²)/(2Sρ)表示。另加入0.49 m球必然满足的各坐标分量界，改善精确中靶初值处球约束零梯度的线性化；并未将欧氏球替换为盒子。归一化违反量用于曲线诊断，最终仍逐项按米、度、SF进行物理量验收。</p>
<p><strong>导数与非光滑点。</strong> 长度目标对归一化段长变量的梯度解析给出，其分量为段长范围/S，其余为0。SF含邻井点最小值和协方差最大特征值，最近点切换或特征值重合时不完全光滑；算法可能因此停止或达到预算。最终复评与求解器success分别报告。</p>
<details open><summary>SLSQP：序列二次规划原理与流程</summary>
<p><strong>原理。</strong> 在当前zₖ附近，用目标的二次近似和约束的一阶线性化构造QP子问题。记Jg为约束雅可比，Bₖ近似拉格朗日函数Hessian，则求步长方向d：</p>
<pre>min_d  ∇f(zₖ)ᵀd + ½ dᵀBₖd
s.t.   g(zₖ) + Jg(zₖ)d ≥ 0
       −zₖ ≤ d ≤ 1−zₖ
zₖ₊₁ = zₖ + αₖd，α由内部线搜索和约束/目标评价确定</pre>
<p><strong>本次流程。</strong> 公共可行初值 → 计算目标/整组约束 → 解析长度梯度、有限差分约束雅可比 → 求内部QP方向 → 线搜索并重新计算轨迹与约束 → 记录迭代/保留可行改进 → 满足ftol或达到预算/失败停止 → 检查候选，必要时保留该算法已找到的较短可行迭代 → 独立1 m验收。</p>
<p><strong>接口与停止。</strong> scipy.optimize.minimize(method='SLSQP')；Bounds与type='ineq'传入约束。ftol=1e-9，maxiter读取实验配置。局部二次近似能利用导数，常有较快局部收敛；有限差分、近邻切换和缩放会影响线搜索。success只表示该实现的停止标准满足，不证明全局最优。</p></details>
<details><summary>trust-constr：信赖域内点法原理与流程</summary>
<p><strong>原理。</strong> 对不等式g(z)≥0引入松弛量s&gt;0，并使用对数障碍，形成一系列有约束子问题；通过信赖域限制局部模型的步长，并逐步降低障碍参数μ。</p>
<pre>min_{z,s&gt;0} f(z) − μ Σ_j log(s_j)
s.t.        g(z) − s = 0，0 ≤ z ≤ 1
局部步长受 ||d|| ≤ Δ 限制；比较实际/预测改善以调整Δ
逐步降低μ，并检查拉格朗日梯度、约束违反量、步长与障碍停止条件</pre>
<p><strong>本次流程。</strong> 公共可行初值 → 初始化内部松弛量、信赖域和障碍状态 → 调用非线性约束及有限差分雅可比 → 用目标解析梯度/零Hessian、约束BFGS更新构造局部模型 → 求信赖域步并评价实际目标/约束 → 接受或拒绝并调整信赖域/障碍 → 记录迭代并保留较短可行结果 → 按gtol/xtol/barrier_tol或预算停止 → 独立1 m验收。</p>
<p><strong>接口与停止。</strong> minimize(method='trust-constr')，NonlinearConstraint(g,0,+∞)，jac='2-point'，约束Hessian使用BFGS。gtol=1e-7、xtol=1e-9、barrier_tol=1e-8；实际覆盖项以配置为准。它同时平衡目标、可行性和障碍，可能暂时增加进尺；本次若未取得比初值更短的可行解，明确采用公共初值，不能称为已收敛优化解。</p></details>
<details><summary>COBYLA：线性近似无导数约束优化原理与流程</summary>
<p><strong>原理。</strong> 用插值点上的函数值建立目标和约束的局部线性近似，不需要用户提供梯度。每轮在信赖域半径ρ内寻找兼顾目标下降与约束满足的步：</p>
<pre>min_d  m_f(d)                      [目标的线性插值模型]
s.t.   m_gj(d) ≥ 0，||d|| ≤ ρ       [约束的线性近似]
评价真实f和g，更新插值几何/局部模型并逐步调整或收缩ρ
</pre>
<p><strong>本次流程。</strong> 公共可行初值 → 建立归一化变量附近插值点集 → 在每个试探点重新计算真实轨迹、误差、SF和中心距 → 建立线性近似 → 求信赖域步 → 更新插值点集及半径 → 记录迭代/保留可行改进 → 半径/可行性准则或预算停止 → 独立1 m验收。</p>
<p><strong>接口与停止。</strong> minimize(method='COBYLA')，type='ineq'及Bounds。rhobeg=0.04为归一化变量尺度的初始半径，tol=1e-7、catol=1e-10；maxiter在COBYLA中限制函数评价数量，不能与SLSQP的迭代数直接等同。不同SciPy版本的callback调用次数也不代表相同计算量，故同时给运行时间曲线与objective_calls。</p></details>
<details><summary>COBYQA：二次近似无导数约束优化原理与流程</summary>
<p><strong>原理。</strong> 与线性模型相比，COBYQA利用插值点建立目标和非线性约束的局部二次近似，再通过信赖域SQP思想计算步长；不调用用户梯度。</p>
<pre>m_f(d) = c_f + a_fᵀd + ½dᵀH_f d
m_gj(d)= c_j + a_jᵀd + ½dᵀH_j d
在变量范围及信赖域内，根据局部模型求改善目标/可行性的试探步
用真实f、g评价步长质量，更新二次模型、插值点集与信赖域半径
</pre>
<p><strong>本次流程。</strong> 公共可行初值 → 构建有界插值点集 → 评价真实目标/非线性约束 → 构建二次模型并求内部约束信赖域步 → 按真实改善接受/拒绝 → 更新插值几何与半径、保留可行改进 → 最终半径/可行性或预算停止 → 独立1 m验收。</p>
<p><strong>接口与停止。</strong> minimize(method='COBYQA')，NonlinearConstraint(g,0,+∞)。初始信赖域半径0.12、最终半径1e-7、feasibility_tol=1e-10；maxiter/maxfev及墙钟预算公开于配置。二次插值可能减少对导数的依赖，但每次真实约束评价仍需计算轨迹和误差。达到75 s预算时不宣称收敛，采用结果与末次候选分别展示。</p></details>
<p><strong>共同验收链。</strong> 算法试探并处理约束 → 内部停止/预算 → 检查候选与已保留可行迭代 → 用1 m点和原始邻井全部点复评SF、连续中心距下界与目标/工程限制 → 不通过时明确回退公共可行初值。记录求解器停止原因、采用来源和最终可行性，三者互不替代。全部算法均为局部非线性规划，没有证明全局最优。</p>
<p><strong>实现与公开依据。</strong> <code>src/wellpath/optimization/runner.py:solve_algorithm</code>、<code>src/wellpath/planning/replanning_problem.py:ReplanningProblem.evaluate/final_verify</code>、<code>src/wellpath/workflows/scenario_replanning.py:make_initial/run_scene</code>；
<a href="https://docs.scipy.org/doc/scipy/reference/optimize.minimize-slsqp.html">SciPy SLSQP</a> ·
<a href="https://docs.scipy.org/doc/scipy/reference/optimize.minimize-trustconstr.html">SciPy trust-constr</a> ·
<a href="https://docs.scipy.org/doc/scipy/reference/optimize.minimize-cobyla.html">SciPy COBYLA</a> ·
<a href="https://docs.scipy.org/doc/scipy/reference/optimize.minimize-cobyqa.html">SciPy COBYQA</a>。
当前COBYLA实现来源另见<a href="https://www.libprima.net">PRIMA</a>（Zhang, 2023）；COBYQA依据<a href="https://www.cobyqa.com/stable/">官方方法与引用说明</a>及<a href="https://theses.lib.polyu.edu.hk/handle/200/12294">Ragonneau(2022)博士论文</a>。算法来源包括Kraft(1988) SQP技术报告、Byrd–Hribar–Nocedal(1999)内点法论文、Powell(1994) COBYLA，以及Ragonneau(2022)的COBYQA博士论文与官方软件文档；具体运行以本项目安装SciPy实现及参数快照为准。</p>
<details><summary>本次四算法的实际选项与预算</summary><pre>"""
        + html.escape(
            json.dumps(
                dict(common=settings["solver"], algorithm_options=options),
                ensure_ascii=False,
                indent=2,
            )
        )
        + """</pre></details></section>"""
    )

    n = int(settings.get("n_segments", 3))
    a = n if settings.get("trajectory_mode", "arc-straight") == "arc" else (n + 1) // 2
    b = n - a
    dim = settings.get("free_control_variables", 3 * a + b)
    lengths = "+".join(f"L{j + 1}" for j in range(n))
    content = (
        content.replace(
            "七个决策变量为两圆弧的DLS、初始工具面和段长，以及中间直线段长",
            f"{dim}个决策变量为{a}个圆弧的DLS、初始工具面和段长，以及{b}个直线段长",
        )
        .replace("z∈[0,1]⁷", f"z∈[0,1]^{dim}")
        .replace("L₁+L₂+L₃", lengths)
    )
    if settings.get("arc_segment_model", "minimum_curvature") == "constant_toolface":
        content = content.replace(
            "按最小曲率递推轨迹", "按恒曲率—恒工具面方程计算名义轨迹"
        ).replace("初始工具面", "段内恒定工具面")
    if "discrete_toolface_selection" in settings:
        content = content.replace(
            f"{dim}个决策变量为{a}个圆弧的DLS、段内恒定工具面和段长，以及{b}个直线段长",
            f"当前固定角组合只有{dim}个自由变量；离散工具面固定且不进入NLP向量，其他自由曲率、段长及连续工具面按实际配置优化",
        )
    return content
