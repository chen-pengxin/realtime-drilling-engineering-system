"""Explain saved horizontal wellhead layouts and rigid trajectory translations."""

import html
import json

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from plotly.offline import get_plotlyjs

from wellpath.paths import PROJECT_ROOT

matplotlib.use("Agg")


ROOT = PROJECT_ROOT
OUT = ROOT / "results/cluster_wellheads_spacing8m_20261113"


def run():
    groups = []
    plt.rcParams.update({"font.family": "Arial Unicode MS", "axes.unicode_minus": False})
    for n in [15, 16, 20]:
        folder = OUT / f"group_{n}"
        data = json.loads((folder / "wellhead_changes.json").read_text())
        rows = data["changes"]
        groups.append(dict(n=n, **data))
        fig, axes = plt.subplots(1, 2, figsize=(14, 6), layout="constrained")
        for ax, prefix, title in zip(
            axes, ["old", "new"], ["修改前", "修改后：双排，排距和排内间距均8m"]
        ):
            e = np.array([r[f"{prefix}_E_m"] for r in rows])
            north = np.array([r[f"{prefix}_N_m"] for r in rows])
            ax.scatter(e, north, s=55, c=[r["row"] for r in rows], cmap="Set1", edgecolors="white")
            for r in rows:
                ax.annotate(
                    r["well"],
                    (r[f"{prefix}_E_m"], r[f"{prefix}_N_m"]),
                    xytext=(4, 5),
                    textcoords="offset points",
                    fontsize=9,
                )
            ax.scatter(
                data["center_NE_m"][1],
                data["center_NE_m"][0],
                marker="+",
                s=150,
                c="black",
                label="原井口平均中心",
            )
            ax.set(title=f"{n}口井：{title}", xlabel="E（m）", ylabel="N（m）")
            ax.axis("equal")
            ax.grid(alpha=0.2)
            ax.legend()
        (folder / "figures").mkdir(exist_ok=True)
        fig.savefig(folder / "figures/wellhead_before_after.png", dpi=170, bbox_inches="tight")
        plt.close(fig)
    content = ""
    for g in groups:
        n = g["n"]
        s = "".join(
            "<tr>"
            + "".join(
                "<td>"
                + html.escape(str(round(r[k], 6) if isinstance(r[k], float) else r[k]))
                + "</td>"
                for k in [
                    "well",
                    "row",
                    "old_N_m",
                    "old_E_m",
                    "new_N_m",
                    "new_E_m",
                    "delta_N_m",
                    "delta_E_m",
                    "unchanged_wellhead_D_m",
                ]
            )
            + "</tr>"
            for r in g["changes"]
        )
        content += f"""<section><h2>{n}口井组</h2><p>修改前井口平均中心 N={g["center_NE_m"][0]:.6f}m，E={g["center_NE_m"][1]:.6f}m；修改后保持此平均中心不变。</p><p><a href="updated_files/{ {15: "cluster_15_design.xlsx", 16: "cluster_16_design.xlsx", 20: "cluster_20_design.xlsx"}[n] }">修改后的设计工作簿</a>　<a href="group_{n}/index.html">独立防碰评价报告</a>　<a href="group_{n}/wellhead_changes.csv">坐标平移明细CSV</a></p><div id="plot{n}" style="height:650px"></div><img src="group_{n}/figures/wellhead_before_after.png" style="width:100%;height:auto" alt="井口修改前后独立比例尺对比"><details><summary>全部井口坐标和平移量</summary><div class="scroll"><table><tr>{"".join("<th>" + x + "</th>" for x in ["井号", "排号", "旧N(m)", "旧E(m)", "新N(m)", "新E(m)", "ΔN(m)", "ΔE(m)", "原D(m)保留"])}</tr>{s}</table></div></details></section>"""
    document = """<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>三个井组井口8m布局与轨迹平移</title><style>body{font-family:Arial,"PingFang SC",sans-serif;background:#eef2f7;color:#172033;margin:0}main{max-width:1400px;margin:auto;padding:30px}section{background:white;margin:24px 0;padding:25px;border-radius:10px}p{line-height:1.9}.scroll{overflow:auto}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:right;white-space:nowrap}th{background:#183653;color:white}a{color:#1d4ed8}summary{cursor:pointer}</style><script>__LIB__</script><main><h1>三个井组井口8m布局与轨迹平移</h1><p>三个井组分别处理。每口井全部N/E点加同一平移量；MD、井斜、方位、垂深和井眼相对形状不变，终点及靶点的绝对坐标随整井同步平移。井口按水平距离评价，均不小于8m。原始文件备份在backups，修改后的原名文件也保存在updated_files。</p><p>15口井组为8+7双排，16口为8+8双排，20口为10+10双排。所有排间距、同排相邻间距均为8m。15口两排人数不同，按人数加权布置N偏移，保持原平均中心；7口一排沿E相对8口一排错开4m并各自居中。16口原井口有分散位置，本次按原全部井口平均中心重新组成双排。20口保留原排距8m，仅将E方向相对原平均中心放大2倍。</p><p><strong>井口8m间距仅约束井口，不能保证地下全部井段防碰安全。</strong>修改后已按现有十模型、K=1/2/2.5/3分别重评。工作簿P:U标注改为默认Rev.0、K=1、最大半轴半径和公式，并结合中心距≤5m判红；详细结果请进入各组独立报告。</p>__CONTENT__<section><h2>修改公式与保留内容</h2><p>对每口井i：ΔNᵢ=Nᵢ,new−Nᵢ,old，ΔEᵢ=Eᵢ,new−Eᵢ,old；所有轨迹点N′ᵢ(s)=Nᵢ(s)+ΔNᵢ，E′ᵢ(s)=Eᵢ(s)+ΔEᵢ，D′ᵢ(s)=Dᵢ(s)。每口井原来的D起点原样保留，包括16口井组井5的−50m。闭合距和闭合方位相对井口，刚性平移后不变。</p><p><a href="wellhead_relocation_guide.md">详细修改说明</a>　<a href="wellhead_changes_all_groups.csv">51口井坐标修改总表</a>　<a href="coordinate_verification.json">坐标、间距与内容保留核查</a>　<a href="index.html">三个井组独立防碰结果入口</a></p></section></main><script>const groups=__DATA__;for(const g of groups){let t=[];for(const [prefix,label,color] of [['old','原井口','#94a3b8'],['new','新井口','#2563eb']])t.push({type:'scatter',mode:'markers+text',name:label,x:g.changes.map(r=>r[prefix+'_E_m']),y:g.changes.map(r=>r[prefix+'_N_m']),text:g.changes.map(r=>r.well),textposition:'top center',marker:{size:11,color},hovertemplate:'%{text}<br>E=%{x:.6f}m<br>N=%{y:.6f}m<extra>'+label+'</extra>'});for(const r of g.changes)t.push({type:'scatter',mode:'lines',x:[r.old_E_m,r.new_E_m],y:[r.old_N_m,r.new_N_m],line:{width:1,color:'#cbd5e1',dash:'dot'},showlegend:false,hoverinfo:'skip'});t.push({type:'scatter',mode:'markers',name:'原井口平均中心',x:[g.center_NE_m[1]],y:[g.center_NE_m[0]],marker:{symbol:'cross',color:'#172033',size:12}});Plotly.newPlot('plot'+g.n,t,{title:{text:g.n+'口井：井口原位置与新位置'},xaxis:{title:{text:'E(m)'}},yaxis:{title:{text:'N(m)'},scaleanchor:'x',scaleratio:1},margin:{l:80,r:30,t:60,b:60},legend:{orientation:'h'},updatemenus:[{buttons:[{label:'显示修改前后',method:'relayout',args:[{'xaxis.autorange':true,'yaxis.autorange':true}]},{label:'放大修改后井口',method:'relayout',args:[{'xaxis.range':[Math.min(...g.changes.map(r=>r.new_E_m))-8,Math.max(...g.changes.map(r=>r.new_E_m))+8],'yaxis.range':[Math.min(...g.changes.map(r=>r.new_N_m))-8,Math.max(...g.changes.map(r=>r.new_N_m))+8]}]}],x:0,y:1.15}]},{responsive:true,displaylogo:false});}</script></html>"""
    document = (
        document.replace("__LIB__", get_plotlyjs())
        .replace("__CONTENT__", content)
        .replace("__DATA__", json.dumps(groups, ensure_ascii=False))
    )
    (OUT / "wellhead_layout_and_relocation.html").write_text(document)
    (OUT / "wellhead_relocation_guide.md").write_text("""# 三个井组井口与轨迹坐标修改

## 修改范围

更新原目录中的15、16、20口井设计方案。共51口井，每井全部轨迹点进行刚性水平平移。旧工作簿逐文件备份在backups；updated_files为同名修改后副本。历史防碰报告保留，新的防碰结果在本目录各group_*内。

## 中心与布局

中心定义为每个原井组全部井口N/E的算术平均，修改后严格保留。排沿E方向展开，排间方向为N。

15口井：奇数井一排8口，偶数井一排7口，两排分别沿E居中；两排N为N中心−8×7/15、N中心+8×8/15。故N排距8m，且加权平均中心保持原值。8口排E偏移为28、20、12、4、−4、−12、−20、−28m；7口排为24、16、8、0、−8、−16、−24m。同排间距8m，最近跨排距离sqrt(8²+4²)大于8m。

16口井：奇数井一排8口，偶数井一排8口，两排N为N中心±4m，各排E为E中心加28、20、12、4、−4、−12、−20、−28m。

20口井：保留N坐标原双排布局；E新=E中心+2(E旧−E中心)。原排距已为8m，排内4m扩大为8m。

## 轨迹修改公式

ΔN=N新井口−N旧井口，ΔE=E新井口−E旧井口。每个轨迹点N新=N旧+ΔN、E新=E旧+ΔE，垂深D不变。终点绝对N/E随整井同步平移。MD、井斜、网格方位、垂深、闭合距、闭合方位、狗腿度、视平移和井段端点测深不变。16口井组井5的−50m起点垂深保留，不擅自统一高程。

## 防碰标注与重新评价

井口满足8m不代表地下井段安全。重新执行三个井组独立、十种误差模型、K=1/2/2.5/3的中心距及SF扫描。每个源工作簿P:U更新为当前默认Rev.0、K=1；SF=D/(K(r1+r2))，半径取各协方差最大半轴。联合等级含中心距≤5m直接判红。旧风险高亮同时刷新。全部其他模型与K在各组报告和导出数据中。

## 工作簿内容与格式保留

使用artifact-tool编写修改的坐标、SF及说明单元格，再将这些单元格内容合入原工作簿包。只更新E/F轨迹坐标、P:U直接相关防碰内容及相应风险高亮、P1/Q2/U2/L7/L8说明。样式表和其他OOXML部件逐字节保留，工作表顺序、列宽、行高、冻结窗格、合并单元格、打印配置保留。安装前逐单元格核对未改内容，并校验全轨迹平移、双排和8m间距。

## 可复核文件

wellhead_changes_all_groups.csv保存51口井全部旧坐标、新坐标、平移量及原D。coordinate_verification.json保存间距、行数和坐标/格式核查。各组coordinate_QA保存原表与修改表的预览。原始备份永久保留，旧结果目录不覆盖。
""")
    print("Wellhead layout report saved", flush=True)


if __name__ == "__main__":
    run()
