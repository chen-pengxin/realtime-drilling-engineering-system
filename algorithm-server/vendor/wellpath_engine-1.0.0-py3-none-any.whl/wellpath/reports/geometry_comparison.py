"""Offline reports for the geometry/layout/segment/algorithm comparison matrix."""

import html
import json
import time
from pathlib import Path

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from wellpath.reports.algorithm_explanations import algorithm_explanations_html
from wellpath.reports.scenario_replanning import COLORS, div, table
from wellpath.reports.segment_comparison import (
    csv_dicts,
    metric_rows,
    page,
    read_track,
    status_label,
)
from wellpath.workflows.scenario_replanning import save_json

MODEL = {
    "minimum_curvature": "最小曲率（平面圆弧）",
    "constant_toolface": "恒曲率恒工具面（空间曲线）",
}
MODE = {"arc": "全部弯曲段", "arc-straight": "弯曲—直线交替"}
DASH = {
    ("minimum_curvature", "arc"): "solid",
    ("minimum_curvature", "arc-straight"): "dash",
    ("constant_toolface", "arc"): "dot",
    ("constant_toolface", "arc-straight"): "dashdot",
}


def fmt(value, digits=4):
    return "—" if value is None else f"{value:.{digits}f}"


def root_of(out, r):
    return (
        out
        / r["arc_segment_model"]
        / r["trajectory_mode"]
        / f"segments_{r['n_segments']:02d}"
        / f"scene_{r['scenario']}"
    )


def identity(r):
    return dict(
        model=r["arc_segment_model"],
        layout=r["trajectory_mode"],
        n=r["n_segments"],
        algorithm=r["algorithm"],
    )


def scene_report(out, scene, config, reports, rows):
    folder = out / f"scene_{scene}"
    folder.mkdir(exist_ok=True)
    reference = root_of(out, reports[0])
    audit = json.loads((reference / "input_audit.json").read_text())
    start = np.array(audit["tie_in"]["position_m"])
    target = np.array(audit["common_target"]["position_m"])
    direction = target[:2] - start[:2]
    direction /= np.linalg.norm(direction)
    f3 = go.Figure()
    xy = go.Figure()
    vertical = go.Figure()
    sf = go.Figure()
    tf = go.Figure()

    # Graphs retain only display samples. Full 1m data remain in CSV/NPZ.
    def add_track(track, name, color, dash, meta, width=2):
        p = track["positions"]
        md = track["md"]
        ids = np.unique(np.r_[np.arange(0, len(md), 4), len(md) - 1])
        p = p[ids]
        md = md[ids]
        meta = dict(
            meta,
            bounds=dict(
                x=[float(p[:, 1].min()), float(p[:, 1].max())],
                y=[float(p[:, 0].min()), float(p[:, 0].max())],
                z=[float(p[:, 2].min()), float(p[:, 2].max())],
            ),
        )
        visible = bool(meta.get("base")) or (
            meta.get("model") == "minimum_curvature"
            and meta.get("layout") == "arc-straight"
            and meta.get("n") == 3
        )
        if meta.get("raw"):
            visible = False
        common = dict(
            name=name,
            meta=meta,
            legendgroup=name,
            mode="lines",
            visible=True if visible else "legendonly",
            line=dict(color=color, dash=dash, width=width),
            customdata=np.column_stack([md, p]),
            hovertemplate="MD=%{customdata[0]:.3f} m<br>N=%{customdata[1]:.3f}<br>E=%{customdata[2]:.3f}<br>D=%{customdata[3]:.3f}<extra>%{fullData.name}</extra>",
        )
        f3.add_trace(go.Scatter3d(x=p[:, 1], y=p[:, 0], z=p[:, 2], **common))
        xy.add_trace(go.Scatter(x=p[:, 1], y=p[:, 0], **common))
        vertical.add_trace(go.Scatter(x=(p[:, :2] - start[:2]) @ direction, y=p[:, 2], **common))
        if "base" not in meta and not meta.get("raw"):
            sf.add_trace(
                go.Scatter(
                    x=md,
                    y=track["sf"][ids],
                    **{k: v for k, v in common.items() if k not in ("customdata", "hovertemplate")},
                )
            )

    for sub, label, color, dash, base in [
        ("design_input", "井1 原设计", "#2563eb", "dash", "design"),
        ("actual_input", "井1 已钻历史", "#111827", "solid", "history"),
    ]:
        add_track(
            read_track(reference / sub / "well_1.csv"), label, color, dash, dict(base=base), 3
        )
    for j in range(2, 11):
        add_track(
            read_track(reference / "actual_input" / f"井{j}.csv"),
            f"井{j} 实钻",
            "#a8b2c1",
            "solid",
            dict(base="neighbors"),
            1,
        )
    table_rows = []
    initial_rows = []
    convergence = []
    stopping = []
    seen = set()
    constraint_rows = []
    control_rows = []
    initial_details = []
    neighbor_rows = []
    history_audit = None
    curves = {
        key: make_subplots(rows=2, cols=2, subplot_titles=config["algorithms"])
        for key in ("iteration", "elapsed", "violation", "sf")
    }
    for r in reports:
        cell = root_of(out, r)
        meta = identity(r)
        name = f"{MODEL[meta['model']]} / {MODE[meta['layout']]} / {meta['n']}段 / {r['algorithm']}"
        c = r.get("final_check") or {}
        relative = "../" + str(cell.relative_to(out))
        if history_audit is None and (cell / "fixed_history_evaluation.json").exists():
            history_audit = json.loads((cell / "fixed_history_evaluation.json").read_text())
        for detail in c.get("separation_details", []):
            neighbor_rows.append(
                [
                    MODEL[meta["model"]],
                    MODE[meta["layout"]],
                    meta["n"],
                    r["algorithm"],
                    detail["neighbor"],
                    fmt(detail["minimum_sf"], 6),
                    fmt(detail["reference_md_m"], 3),
                    fmt(detail["offset_md_m"], 3),
                    fmt(detail["reference_radius_m"], 4),
                    fmt(detail["offset_radius_m"], 4),
                    fmt(detail["centerline"]["distance_lower_bound_m"], 6),
                ]
            )
        link = f'<a href="{html.escape(relative)}/场景{scene}_再规划对比.html">详细报告</a> · <a href="{html.escape(relative)}/{r["algorithm"]}/result.json">JSON</a>'
        values = [
            MODEL[meta["model"]],
            MODE[meta["layout"]],
            meta["n"],
            r["algorithm"],
            status_label(r),
            "通过" if c.get("feasible") else "无认证结果",
            fmt(r.get("final_total_length_m")),
            fmt(r.get("complete_flow_seconds"), 3),
            fmt(c.get("position_error_m"), 6),
            fmt(c.get("minimum_sf")),
            fmt(c.get("minimum_centerline_distance_m")),
            link,
        ]
        table_rows.append(values)
        constraint_rows.append(
            [
                MODEL[meta["model"]],
                MODE[meta["layout"]],
                meta["n"],
                r["algorithm"],
                fmt(c.get("position_error_m"), 6),
                fmt(c.get("inclination_error_deg"), 6),
                fmt(c.get("azimuth_error_deg"), 6),
                fmt(c.get("maximum_dls_deg_per_30m"), 6),
                fmt(c.get("minimum_inclination_deg"), 4),
                fmt(c.get("maximum_inclination_deg"), 4),
                fmt(c.get("maximum_segment_bend_deg"), 4),
                fmt(c.get("minimum_sf"), 6),
                fmt(c.get("minimum_centerline_distance_m"), 6),
                c.get("segment_variable_bounds_satisfied", "—"),
            ]
        )
        cell_key = (meta["model"], meta["layout"], meta["n"])
        if cell_key not in seen:
            seen.add(cell_key)
            initial = json.loads((cell / "initialization.json").read_text())
            timing = initial["timing_breakdown"]
            initial_details.append(
                dict(
                    model=meta["model"],
                    layout=meta["layout"],
                    n_segments=meta["n"],
                    initialization=initial,
                )
            )
            initial_rows.append(
                [
                    MODEL[meta["model"]],
                    MODE[meta["layout"]],
                    meta["n"],
                    initial["status"],
                    len(initial["attempts"]),
                    *[
                        fmt(timing.get(k, 0), 4)
                        for k in (
                            "geometric_fit_seconds",
                            "geometric_feasibility_restoration_seconds",
                            "feasibility_restoration_seconds",
                            "final_1m_verification_seconds",
                        )
                    ],
                    fmt(initial["elapsed_seconds"], 4),
                ]
            )
        if not r.get("solver_executed"):
            continue
        result_cell = (
            cell / r["assignment_result_directory"]
            if "finite_choice_search" in r
            else cell / r["algorithm"]
        )
        geometry_cell = result_cell.parent
        if c.get("feasible"):
            add_track(
                read_track(result_cell / "selected_trajectory.csv"),
                name,
                COLORS[r["algorithm"]],
                DASH[meta["model"], meta["layout"]],
                meta,
                3,
            )
            raw = read_track(result_cell / "raw_solver_candidate_trajectory.csv")
            add_track(
                raw,
                name + " 末次候选（可能不可行）",
                COLORS[r["algorithm"]],
                "dot",
                dict(meta, raw=True),
                1,
            )
            # Recover the local toolface from the actual chosen geometry.
            from wellpath.planning.geometry_problem import WellControlProblem, samples

            geometry = WellControlProblem(json.loads((geometry_cell / "problem.json").read_text()))
            controls = json.loads((result_cell / "selected_segments.json").read_text())
            for segment in controls:
                control_rows.append(
                    [
                        MODEL[meta["model"]],
                        MODE[meta["layout"]],
                        meta["n"],
                        r["algorithm"],
                        segment["segment"],
                        "直线" if segment["type"] == "straight" else "弯曲段",
                        fmt(segment["length_m"], 6),
                        fmt(segment["dls_deg_per_30m"], 6),
                        fmt(segment["initial_toolface_deg"], 6),
                        fmt(segment["curvature_1_per_m"], 9),
                    ]
                )
            physical = np.array(
                [
                    [s["dls_deg_per_30m"], s["initial_toolface_deg"] or 0, s["length_m"]]
                    for s in controls
                ]
            )
            values = samples(geometry, geometry.pack(physical), step=5.0)
            tf.add_trace(
                go.Scatter(
                    x=values[:, 2] + r["tie_in_md_m"],
                    y=values[:, 8],
                    name=name,
                    meta=meta,
                    visible=True
                    if meta["model"] == "minimum_curvature"
                    and meta["layout"] == "arc-straight"
                    and meta["n"] == 3
                    else "legendonly",
                    line=dict(
                        color=COLORS[r["algorithm"]], dash=DASH[meta["model"], meta["layout"]]
                    ),
                    connectgaps=False,
                )
            )
        idx = config["algorithms"].index(r["algorithm"])
        rr = idx // 2 + 1
        cc = idx % 2 + 1
        run = r["runs"][0]
        h = run["history"]
        best = r["initial_total_length_m"]
        bests = []
        for index, v in enumerate(h):
            if v["maximum_scaled_constraint_violation"] <= 1e-8:
                best = min(best, v["length_m"])
            bests.append(best)
            convergence.append(
                dict(
                    scene=scene,
                    **meta,
                    callback_index=index + 1,
                    **{
                        k: v[k]
                        for k in (
                            "elapsed_seconds",
                            "length_m",
                            "maximum_scaled_constraint_violation",
                            "minimum_sf",
                            "position_error_m",
                        )
                    },
                )
            )
        visible = (
            True
            if meta["model"] == "minimum_curvature"
            and meta["layout"] == "arc-straight"
            and meta["n"] == 3
            else "legendonly"
        )
        common = dict(
            name=name,
            meta=meta,
            line=dict(color=COLORS[r["algorithm"]], dash=DASH[meta["model"], meta["layout"]]),
            visible=visible,
        )
        curves["iteration"].add_trace(
            go.Scatter(x=list(range(1, len(h) + 1)), y=[v["length_m"] for v in h], **common),
            row=rr,
            col=cc,
        )
        curves["elapsed"].add_trace(
            go.Scatter(
                x=[0] + [v["elapsed_seconds"] for v in h],
                y=[r["initial_total_length_m"]] + bests,
                **common,
            ),
            row=rr,
            col=cc,
        )
        curves["violation"].add_trace(
            go.Scatter(
                x=[v["elapsed_seconds"] for v in h],
                y=[max(v["maximum_scaled_constraint_violation"], 1e-13) for v in h],
                **common,
            ),
            row=rr,
            col=cc,
        )
        curves["sf"].add_trace(
            go.Scatter(
                x=[v["elapsed_seconds"] for v in h], y=[v["minimum_sf"] for v in h], **common
            ),
            row=rr,
            col=cc,
        )
        if c.get("feasible"):
            curves["elapsed"].add_trace(
                go.Scatter(
                    x=[
                        r.get("selected_assignment_optimization_seconds", r["optimization_seconds"])
                    ],
                    y=[r["final_total_length_m"]],
                    name=name + " 最终1m验收采用值",
                    meta=meta,
                    visible=visible,
                    mode="markers",
                    marker=dict(symbol="star", size=11, color=COLORS[r["algorithm"]]),
                ),
                row=rr,
                col=cc,
            )
        stopping.append(
            [
                MODEL[meta["model"]],
                MODE[meta["layout"]],
                meta["n"],
                r["algorithm"],
                r["solver_success"],
                run["interrupted"],
                run["iterations"],
                run["objective_calls"],
                fmt(run["elapsed_seconds"], 3),
                run["message"],
            ]
        )
    f3.update_layout(
        height=740,
        title="3D轨迹｜可旋转缩放，图例可隐藏/独显",
        scene=dict(
            xaxis_title="东 E / m",
            yaxis_title="北 N / m",
            zaxis=dict(title="垂深 D / m", autorange="reversed"),
            aspectmode="data",
        ),
    )
    xy.update_layout(
        height=540,
        title="水平投影",
        xaxis_title="东 E / m",
        yaxis=dict(title="北 N / m", scaleanchor="x"),
    )
    vertical.update_layout(
        height=540,
        title="沿纠偏点→共同靶点的垂直剖面",
        xaxis_title="剖面投影距离 / m",
        yaxis=dict(title="垂深 D / m", autorange="reversed"),
    )
    for p, label in [(start, "纠偏点"), (target, "共同靶点")]:
        f3.add_trace(
            go.Scatter3d(
                x=[p[1]],
                y=[p[0]],
                z=[p[2]],
                name=label,
                mode="markers",
                meta=dict(base="markers"),
                marker=dict(color="red", size=7),
            )
        )
        xy.add_trace(
            go.Scatter(x=[p[1]], y=[p[0]], name=label, mode="markers", meta=dict(base="markers"))
        )
        vertical.add_trace(
            go.Scatter(
                x=[(p[:2] - start[:2]) @ direction],
                y=[p[2]],
                name=label,
                mode="markers",
                meta=dict(base="markers"),
            )
        )
    sf.update_layout(
        height=430,
        title="采用轨迹逐点最小SF（显示采样；完整1m数据见CSV）",
        xaxis_title="全井MD / m",
        yaxis_title="SF",
    )
    sf.add_hline(y=config["sf_threshold"], line_dash="dash", line_color="red")
    tf.update_layout(
        height=440,
        title="当地高边工具面随测深变化｜直线段留空",
        xaxis_title="全井MD / m",
        yaxis_title="工具面 / °",
    )
    for key, title, xlabel in [
        ("iteration", "原始迭代进尺—回调序号", "回调序号"),
        ("elapsed", "累计最短网格可行进尺—时间；星号为最终1m验收采用值", "求解器秒数"),
        ("violation", "约束违反量—时间", "求解器秒数"),
        ("sf", "迭代最小SF—时间", "求解器秒数"),
    ]:
        curves[key].update_layout(height=700, title=title, showlegend=False)
        curves[key].update_xaxes(title_text=xlabel)
        if key == "violation":
            curves[key].update_yaxes(type="log")
    group_titles = [
        MODEL[m] + " / " + MODE[l]
        for m in config["arc_segment_models"]
        for l in config["trajectory_modes"]
    ]
    summary = []
    for key, title, unit in [
        ("new_length_m", "认证采用轨迹新段进尺", "m"),
        ("complete_flow_s", "完整流程耗时", "秒"),
        ("min_SF", "最终最小SF", "SF"),
        ("centerline_lower_bound_m", "连续中心距下界", "m"),
    ]:
        fig = make_subplots(rows=2, cols=2, subplot_titles=group_titles)
        for index, (model, layout) in enumerate(
            (m, l) for m in config["arc_segment_models"] for l in config["trajectory_modes"]
        ):
            for method in config["algorithms"]:
                selected = [
                    next(
                        (
                            r
                            for r in rows
                            if r["arc_segment_model"] == model
                            and r["trajectory_mode"] == layout
                            and r["n_segments"] == n
                            and r["algorithm"] == method
                        ),
                        {},
                    )
                    for n in config["segment_counts"]
                ]
                fig.add_trace(
                    go.Scatter(
                        x=config["segment_counts"],
                        y=[r.get(key) for r in selected],
                        name=method,
                        legendgroup=method,
                        showlegend=index == 0,
                        mode="lines+markers",
                        connectgaps=False,
                        line=dict(color=COLORS[method]),
                    ),
                    row=index // 2 + 1,
                    col=index % 2 + 1,
                )
        fig.update_layout(title=title, height=730)
        fig.update_xaxes(title_text="段数", dtick=1)
        fig.update_yaxes(title_text=unit)
        summary.append(div(fig, "summary_" + key))
    keys = [
        ("输入/误差准备", "shared_preprocessing_s"),
        ("初值构建", "initial_construction_s"),
        ("优化器", "solver_s"),
        ("内部验收", "solver_validation_s"),
        ("最终1m复评", "final_1m_scan_s"),
        ("导出", "export_s"),
    ]
    phases = go.Figure()
    labels = [
        f"{r['arc_segment_model']} / {r['trajectory_mode']} / {r['n_segments']}段 / {r['algorithm']}"
        for r in rows
    ]
    for label, key in keys:
        phases.add_trace(go.Bar(x=labels, y=[r[key] for r in rows], name=label))
    phases.add_trace(
        go.Bar(
            x=labels,
            y=[max(0.0, r["complete_flow_s"] - sum(r[k] for _, k in keys)) for r in rows],
            name="调度/其他",
        )
    )
    phases.update_layout(
        title="80组合耗时拆解｜可框选横轴局部查看",
        height=600,
        barmode="stack",
        xaxis_tickangle=-65,
        yaxis_title="秒",
    )
    module = make_subplots(
        rows=1, cols=2, subplot_titles=["优化阶段模块（含内部验收）", "最终1m复评模块"]
    )
    module_keys = [
        ("trajectory_and_target_constraints", "轨迹/几何约束"),
        ("trajectory_sampling", "1m采样/协方差插值"),
        ("rev0_propagation_and_radius", "误差传播"),
        ("sf_screening", "SF水平初筛"),
        ("sf_refinement", "SF区间细化"),
        ("sf_control", "SF调度"),
        ("centerline_screening", "中心距初筛"),
        ("centerline_refinement", "中心距细化"),
        ("constraint_assembly", "约束组装"),
    ]
    for col, prefix in [(1, "optimizer"), (2, "final_scan")]:
        for key, label in module_keys:
            module.add_trace(
                go.Bar(
                    x=labels,
                    y=[r.get(f"{prefix}_{key}_s", 0) for r in rows],
                    name=label,
                    legendgroup=key,
                    showlegend=col == 1,
                ),
                row=1,
                col=col,
            )
    module.update_layout(
        title="模块时间已经包含在相应阶段内，请勿重复相加",
        height=620,
        barmode="stack",
        xaxis_tickangle=-65,
    )
    cols = [
        (m, l, n)
        for m in config["arc_segment_models"]
        for l in config["trajectory_modes"]
        for n in config["segment_counts"]
    ]
    z = []
    texts = []
    for method in config["algorithms"]:
        line = []
        text = []
        for model, layout, n in cols:
            r = next(
                (
                    r
                    for r in reports
                    if r["arc_segment_model"] == model
                    and r["trajectory_mode"] == layout
                    and r["n_segments"] == n
                    and r["algorithm"] == method
                ),
                None,
            )
            code = (
                None
                if r is None
                else (
                    0
                    if r.get("status") == "proven_infeasible_under_configured_constraints"
                    else 1
                    if not r.get("solver_executed")
                    else 2
                    if r.get("selected_candidate") == "verified_initial_point"
                    or r.get("selected_after_dense_fallback_to_initial")
                    else 4
                    if r["solver_success"]
                    else 3
                )
            )
            line.append(code)
            text.append(
                {
                    0: "证明不可行",
                    1: "初值未找到",
                    2: "公共初值",
                    3: "可行/未收敛",
                    4: "可行/成功",
                }.get(code, "待计算")
            )
        z.append(line)
        texts.append(text)
    heat = go.Figure(
        go.Heatmap(
            z=z,
            x=[f"{m}<br>{l}<br>{n}段" for m, l, n in cols],
            y=config["algorithms"],
            text=texts,
            texttemplate="%{text}",
            zmin=0,
            zmax=4,
            colorscale=[
                [0, "#dc2626"],
                [0.1249, "#dc2626"],
                [0.125, "#f97316"],
                [0.3749, "#f97316"],
                [0.375, "#94a3b8"],
                [0.6249, "#94a3b8"],
                [0.625, "#eab308"],
                [0.8749, "#eab308"],
                [0.875, "#10b981"],
                [1, "#10b981"],
            ],
            colorbar=dict(
                tickvals=list(range(5)),
                ticktext=[
                    "证明不可行",
                    "初值未找到",
                    "采用公共初值",
                    "保留可行解/未收敛",
                    "成功并采用",
                ],
            ),
        )
    )
    heat.update_layout(height=490, title="完整状态矩阵：可行性、终止状态与采用来源分别记录")

    def select(name, label, options, default):
        return (
            f'<label>{label} <select id="{name}">'
            + "".join(
                f'<option value="{html.escape(str(k))}" {"selected" if str(k) == str(default) else ""}>{html.escape(str(v))}</option>'
                for k, v in options
            )
            + "</select></label>"
        )

    controls = (
        '<div class="controls">'
        + select("model", "几何", [("all", "两种对比"), *MODEL.items()], "minimum_curvature")
        + select("layout", "布局", [("all", "两种对比"), *MODE.items()], "arc-straight")
        + select("count", "段数", [("all", "全部段数"), *[(n, n) for n in range(1, 6)]], 3)
        + select(
            "method", "算法", [("all", "全部算法"), *[(a, a) for a in config["algorithms"]]], "all"
        )
    )
    controls += (
        "".join(
            f'<label><input id="{k}" type="checkbox" {"checked" if k != "raw" else ""}>{v}</label>'
            for k, v in [
                ("design", "原设计"),
                ("history", "井1历史"),
                ("neighbors", "实钻邻井"),
                ("raw", "末次候选（可能不可行）"),
            ]
        )
        + "</div>"
    )
    controls += '<p><button onclick="focusNew()">聚焦当前再规划轨迹</button> <button onclick="showAll()">显示全井范围</button></p>'
    # Escape table cells except the explicit, generated links.
    result_table = table(
        [
            "几何",
            "布局",
            "段数",
            "算法",
            "终止/采用状态",
            "最终可行",
            "新段长m",
            "完整流程s",
            "中靶误差m",
            "最小SF",
            "中心距下界m",
            "文件",
        ],
        [r[:-1] + ["LINK_" + str(i)] for i, r in enumerate(table_rows)],
    )
    for i, r in enumerate(table_rows):
        result_table = result_table.replace("LINK_" + str(i) + "</td>", r[-1] + "</td>")
    body = f"""<header><p>场景{scene} · 井1再规划 · 2种几何 × 2种布局 × 1–5段 × 四算法</p><h1>场景{scene}：完整80组合对比</h1><p>{sum(bool((r.get("final_check") or {}).get("feasible")) for r in reports)}/{len(reports)}条采用轨迹通过独立1m复评。求解器实际启动{sum(bool(r.get("solver_executed")) for r in reports)}次；成功终止{sum(r.get("solver_success") is True for r in reports)}次。</p><p>共同靶点N=-1333、E=1000、D=2200 m，末端I=89°±0.5°、A=145.9°±0.5°。从当前井1实钻末点续钻，其余9口实钻轨迹固定。</p><p>纠偏起点：MD={audit["tie_in"]["md_m"]:.6f}m，N={start[0]:.6f} / E={start[1]:.6f} / D={start[2]:.6f}m；I={audit["tie_in"]["inclination_deg"]:.6f}° / A={audit["tie_in"]["azimuth_deg"]:.6f}°。原设计末点距共同靶点{audit["original_design_endpoint_to_common_target_m"]:.6f}m，因此原设计仅作为轨迹参考，不作为同靶点进尺最优基准。</p><p class="note">恒曲率恒当地工具面一般为空间曲线；“圆弧”布局名称表示全部采用弯曲段，几何由单独选项决定。最小曲率段为精确平面圆弧，当地工具面通常随程变化。全部组合保留同一工程约束和误差参数；1段最大1800m不足以到靶点，记录证明与未启动状态。普通搜索失败仅表示本预算内未找到初值。</p><p><a href="../index.html">总览</a> · <a href="comparison.csv">本场景80组合完整指标CSV</a> · <a href="convergence.csv">全部真实回调CSV</a></p></header>
<section><h2>结果状态矩阵</h2>{div(heat, "feasibility")}{result_table}</section>
<section><h2>轨迹、分离系数与工具面交互对比</h2><p>选择器同步控制轨迹和收敛曲线；选择“两种对比”可同时查看两种几何。图例可进一步隐藏或独显。3D与2D显示每4点抽样，所有1m点、端点和完整精度数据仍保存在各算法目录中。直线段工具面无定义。勾选末次候选时，虚线不代表已通过验收。</p>{controls}{div(f3, "trajectory3d")}<div class="grid">{div(xy, "horizontal")}{div(vertical, "vertical")}</div>{div(sf, "sf_profile")}{div(tf, "toolface")}</section>
<section><h2>段数、几何、布局和算法的指标对比</h2>{"".join(summary)}</section>
<section><h2>每组合约束验收与采用控制</h2><p>顺序为位置≤0.5m、末端井斜/方位误差绝对值≤0.5°、DLS&lt;6°/30m、全过程I∈[0.1,95]°、κL≤150°、SF&gt;1.5、中心距&gt;5m，以及全部变量在配置范围内。无认证结果的组合留空。</p>{table(["几何", "布局", "段数", "算法", "位置误差m", "井斜差°", "方位差°", "最大DLS", "最小井斜°", "最大井斜°", "最大κL°", "最小SF", "中心距下界m", "变量边界通过"], constraint_rows)}<details><summary>全部采用轨迹逐段控制值（长度、曲率与工具面）</summary>{table(["几何", "布局", "总段数", "算法", "段号", "段类型", "段长m", "DLS °/30m", "命令工具面°", "曲率1/m"], control_rows)}</details></section>
<section><h2>各邻井验收明细与固定实钻历史</h2><p>下表的SF临界点与中心距临界点可能不同；两种评价均独立验收。井1已钻历史固定，不属于可改变的新段；其风险单独报告，不能用新段规划结果消除已有风险。</p><details><summary>全部采用结果 × 9口邻井的SF、临界测深和误差半径</summary>{table(["几何", "布局", "段数", "算法", "邻井", "最小SF", "井1临界MD m", "邻井临界MD m", "井1半轴m", "邻井半轴m", "连续中心距下界m"], neighbor_rows)}</details><details><summary>固定已钻历史完整SF审计（不参与新段可行性验收）</summary><pre>{html.escape(json.dumps(history_audit, ensure_ascii=False, indent=2))}</pre></details></section>
<section><h2>真实执行时间与模块拆解</h2><p>各单元及四算法顺序运行，BLAS线程数固定为1。每算法完整流程=该单元输入/误差准备+公共初值构建及核验+该算法运行、内部验收、最终复评和导出。共享成本在每算法对比中计一次，不能将80条完整流程时间相加充当批次墙钟时间。固定历史评价与报告绘图另计。模块为所属阶段的内层计时，不能再次叠加。</p>{div(phases, "timing")}{div(module, "modules")}</section>
<section><h2>初始值构建与实际耗时</h2><p>先检查总长度必要条件；最小曲率且仅一个圆弧时再检查共面必要条件。其余单元从MC几何猜测出发，以所选几何方程进行带界位置/姿态拟合、几何恢复、Rev.0全约束恢复和独立1m验收。每单元首个认证初值冻结后供四算法共用，各算法互不继承结果。最多12个种子、90秒构造预算，搜索失败不等于证明不可行。</p>{table(["几何", "布局", "段数", "初值状态", "尝试数", "几何拟合s", "几何恢复s", "全约束恢复s", "1m验收s", "初值总s"], initial_rows)}<details><summary>完整初值尝试记录、检查数值与不可行证书</summary><pre>{html.escape(json.dumps(initial_details, ensure_ascii=False, indent=2))}</pre></details></section>
<section><h2>收敛曲线与运行时间曲线</h2><p>以下曲线随上方选择器同步切换。回调序号与各算法内部迭代含义不同，不能据此等同函数评价量；时间为真实测量。累计最短曲线仅以优化网格约束判定，星号是独立最终1m验收采用结果。预算停止、采用初值与收敛分别记录，未启动组合没有虚构曲线。若另配置离散角枚举，本页曲线仅为获选角组合的连续NLP过程；全部角组合历史保存在各单元all_assignment_results.json，完整流程指标累计全部组合成本。</p>{"".join(div(curves[k], "convergence_" + k) for k in curves)}{table(["几何", "布局", "段数", "算法", "success", "预算中断", "内部迭代数", "目标调用数", "求解器秒", "停止原因"], stopping)}</section>
<section><h2>配置、原理与适用范围</h2><p>SF=D/[k(r₁+r₂)]，k=1，r为Rev.0协方差最大半轴。最终SF&gt;1.5、连续中心距下界&gt;5m、位置误差≤0.5m、DLS≤5.999°/30m。弯曲段长[10,1800]m，直线段长[10,2200]m，工具面[-180,180]°，全过程I∈[0.1,95]°，κL≤150°。优化采用0.49m、SF≥1.53、中心距≥5.1m保护量。</p><pre>曲率换算：κ = π·DLS/(180×30)，s为段内弧长，内部角度为弧度。
最小曲率：n₀=cosω₀·e_I(t₀)+sinω₀·e_A(t₀)
          t(s)=cos(κs)t₀+sin(κs)n₀
          x(s)=x₀+[sin(κs)/κ]t₀+[(1−cos(κs))/κ]n₀
恒工具面：I′=κcosω，A′=κsinω/sinI，x′=(sinIcosA,sinIsinA,cosI)
直线极限：κ=0，t(s)=t₀，x(s)=x₀+st₀。
最小曲率只指定ω₀；恒工具面指定整段固定的当地ω。</pre><p>每弯曲段3个自由变量（DLS、工具面、长度），直线段只有长度；全部弯曲1–5段为3/6/9/12/15变量，交替布局为3/4/7/8/11变量。恒工具面名义轨迹用恒控制方程积分；Rev.0按现有合成30m测站的MC雅可比传播，为新空间曲线上的离散近似。测站数量由各段长度上限固定，以保持优化时拓扑稳定、间距不超过30m；段数/布局变化时合成测站密度也会变化。实钻资料缺少真实工具/测站和磁场标定元数据，参数保留当前默认值；本结果是给定假设的数值比较。</p><details><summary>完整配置与参数</summary><pre>{html.escape(json.dumps(config, ensure_ascii=False, indent=2))}</pre></details></section>
<p>以下以三段最小曲率弯曲—直线—弯曲说明四算法的接口；其他布局按实际变量维度构造，恒工具面使用上面的空间曲线方程。各组合实际约束与控制值已逐项列出。</p>
{algorithm_explanations_html(dict(config, n_segments=3, trajectory_mode="arc-straight", arc_segment_model="minimum_curvature"))}"""
    script = r"""const controlled=['trajectory3d','horizontal','vertical','sf_profile','toolface','convergence_iteration','convergence_elapsed','convergence_violation','convergence_sf'];
function update(){const val=id=>document.getElementById(id).value;for(const id of controlled){const g=document.getElementById(id);if(!g?.data)continue;const visible=g.data.map(t=>{const m=t.meta||{};if(m.base)return m.base==='markers'||document.getElementById(m.base)?.checked;const ok=(val('model')==='all'||m.model===val('model'))&&(val('layout')==='all'||m.layout===val('layout'))&&(val('count')==='all'||String(m.n)===val('count'))&&(val('method')==='all'||m.algorithm===val('method'));return Boolean(ok&&(!m.raw||document.getElementById('raw').checked));});Plotly.restyle(g,{visible});}}
function focusNew(){const g=document.getElementById('trajectory3d');const selected=g.data.filter(t=>t.visible===true&&t.meta?.model&&!t.meta?.raw);if(!selected.length)return;const bound=k=>{let lo=Infinity,hi=-Infinity;for(const t of selected){lo=Math.min(lo,t.meta.bounds[k][0]);hi=Math.max(hi,t.meta.bounds[k][1]);}const pad=Math.max(20,(hi-lo)*.07);return[lo-pad,hi+pad];};Plotly.relayout(g,{'scene.xaxis.range':bound('x'),'scene.yaxis.range':bound('y'),'scene.zaxis.range':bound('z').reverse()});}
function showAll(){Plotly.relayout('trajectory3d',{'scene.xaxis.autorange':true,'scene.yaxis.autorange':true,'scene.zaxis.autorange':'reversed'});}
for(const id of ['model','layout','count','method','design','history','neighbors','raw'])document.getElementById(id).addEventListener('change',update);update();"""
    (folder / "index.html").write_text(
        page(f"场景{scene} 两种几何两种布局80组合", body, script), encoding="utf-8"
    )
    csv_dicts(folder / "comparison.csv", rows)
    csv_dicts(folder / "convergence.csv", convergence)
    save_json(folder / "algorithm_results.json", reports)
    static_matrix_figures(folder, scene, config, rows, reports, out, start, direction)


def static_matrix_figures(folder, scene, config, rows, reports, out, start, direction):
    """Standalone scientific PNG/PDF figures, separate from interactive views."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update(
        {
            "font.family": "Arial Unicode MS",
            "axes.unicode_minus": False,
            "figure.dpi": 150,
            "font.size": 9,
        }
    )
    figures = folder / "figures"
    figures.mkdir(exist_ok=True)
    combinations = [
        (m, l) for m in config["arc_segment_models"] for l in config["trajectory_modes"]
    ]
    for key, title, unit in [
        ("new_length_m", "认证采用轨迹新钻进尺", "m"),
        ("complete_flow_s", "算法完整流程耗时", "s"),
        ("min_SF", "最终最小分离系数", "SF"),
    ]:
        fig, axes = plt.subplots(2, 2, figsize=(14, 9), layout="constrained")
        for ax, (model, layout) in zip(axes.ravel(), combinations):
            for method in config["algorithms"]:
                values = [
                    next(
                        (
                            r.get(key)
                            for r in rows
                            if r["arc_segment_model"] == model
                            and r["trajectory_mode"] == layout
                            and r["n_segments"] == n
                            and r["algorithm"] == method
                        ),
                        None,
                    )
                    for n in config["segment_counts"]
                ]
                ax.plot(
                    config["segment_counts"],
                    [np.nan if v is None else v for v in values],
                    "-o",
                    color=COLORS[method],
                    label=method,
                    ms=4,
                )
            ax.set(
                title=MODEL[model] + " / " + MODE[layout],
                xlabel="段数",
                ylabel=unit,
                xticks=config["segment_counts"],
            )
            ax.grid(alpha=0.2)
        axes[0, 0].legend()
        fig.suptitle(f"场景{scene}：{title}（无认证结果留空）")
        fig.savefig(figures / f"{key}_矩阵对比.png")
        fig.savefig(figures / f"{key}_矩阵对比.pdf")
        plt.close(fig)
    fig, axes = plt.subplots(2, 2, figsize=(14, 10), layout="constrained")
    for ax, (model, layout) in zip(axes.ravel(), combinations):
        for r in reports:
            if (
                r["arc_segment_model"] != model
                or r["trajectory_mode"] != layout
                or not (r.get("final_check") or {}).get("feasible")
            ):
                continue
            if r["n_segments"] not in (2, 3, 5):
                continue
            cell = root_of(out, r)
            result_cell = (
                cell / r["assignment_result_directory"]
                if "finite_choice_search" in r
                else cell / r["algorithm"]
            )
            track = read_track(result_cell / "selected_trajectory.csv")
            p = track["positions"]
            ax.plot(
                p[:, 1],
                p[:, 0],
                color=COLORS[r["algorithm"]],
                ls={2: ":", 3: "-", 5: "--"}[r["n_segments"]],
                lw=1.3,
                label=f"{r['n_segments']}段 {r['algorithm']}",
            )
        ax.set(title=MODEL[model] + " / " + MODE[layout], xlabel="E / m", ylabel="N / m")
        ax.axis("equal")
        ax.grid(alpha=0.2)
    axes[0, 0].legend(fontsize=7, ncol=2)
    fig.suptitle(f"场景{scene}：2/3/5段认证采用轨迹水平投影（全部1–5段见HTML）")
    fig.savefig(figures / "legacy_e3ffe2dc11c4.png")
    fig.savefig(figures / "legacy_33e12630c2ea.pdf")
    plt.close(fig)


def render_matrix(out):
    out = Path(out)
    begin = time.perf_counter()
    config = json.loads((out / "experiment_config.json").read_text())
    from wellpath.workflows.geometry_comparison import collect

    reports = collect(out)
    rows = metric_rows(reports)
    # Correct the layout wording in early scene pages without rerunning a
    # numerical experiment merely to rebuild presentation.
    old = (
        "1段为圆弧，2段为圆弧—直线。一条圆弧及其末端切线直线共面，必须同时满足目标位置与末端姿态。"
    )
    for p in out.glob("minimum_curvature/arc/segments_*/scene_*/场景*_再规划对比.html"):
        text = p.read_text()
        if old in text:
            p.write_text(
                text.replace(
                    old,
                    "本次为全部圆弧布局；各弯曲段均为平面圆弧，不同段可处于不同平面。仅单圆弧检查共面必要条件；所有段数均检查总长度必要条件。",
                ),
                encoding="utf-8",
            )
    for row, r in zip(rows, reports):
        row["result_directory"] = r["result_directory"]
    csv_dicts(out / "comparison_240.csv", rows)
    save_json(out / "all_results.json", reports)
    summary = []
    cells = []
    scene_best = []
    group_best = []
    for model in config["arc_segment_models"]:
        for layout in config["trajectory_modes"]:
            for count in config["segment_counts"]:
                for scene in config["scenarios"]:
                    selected = [
                        r
                        for r in reports
                        if r["arc_segment_model"] == model
                        and r["trajectory_mode"] == layout
                        and r["n_segments"] == count
                        and r["scenario"] == scene
                    ]
                    if not selected:
                        continue
                    feasible = [r for r in selected if (r.get("final_check") or {}).get("feasible")]
                    best = (
                        min(feasible, key=lambda r: r["final_total_length_m"]) if feasible else None
                    )
                    summary.append(
                        [
                            scene,
                            MODEL[model],
                            MODE[layout],
                            count,
                            f"{len(feasible)}/{len(selected)}",
                            best["algorithm"] if best else "—",
                            fmt(best["final_total_length_m"]) if best else "—",
                            status_label(best or selected[0]),
                        ]
                    )
                    path = root_of(out, selected[0])
                    timing = json.loads((path / "scene_timing.json").read_text())
                    initial = json.loads((path / "initialization.json").read_text())
                    cells.append(
                        dict(
                            scene=scene,
                            model=model,
                            layout=layout,
                            n_segments=count,
                            path=str(path.relative_to(out)),
                            **timing,
                            initial_status=initial["status"],
                        )
                    )
    for scene in config["scenarios"]:
        selected = [r for r in reports if r["scenario"] == scene]
        if selected:
            scene_report(out, scene, config, selected, [r for r in rows if r["scenario"] == scene])
        feasible = [r for r in selected if (r.get("final_check") or {}).get("feasible")]
        if feasible:
            best = min(feasible, key=lambda r: r["final_total_length_m"])
            scene_best.append(
                [
                    scene,
                    MODEL[best["arc_segment_model"]],
                    MODE[best["trajectory_mode"]],
                    best["n_segments"],
                    best["algorithm"],
                    fmt(best["final_total_length_m"]),
                    fmt(best["complete_flow_seconds"], 3),
                    status_label(best),
                ]
            )
        for model in config["arc_segment_models"]:
            for layout in config["trajectory_modes"]:
                group = [
                    r
                    for r in selected
                    if r["arc_segment_model"] == model and r["trajectory_mode"] == layout
                ]
                safe = [r for r in group if (r.get("final_check") or {}).get("feasible")]
                best = min(safe, key=lambda r: r["final_total_length_m"]) if safe else None
                group_best.append(
                    dict(
                        scene=scene,
                        arc_segment_model=model,
                        trajectory_mode=layout,
                        combinations=len(group),
                        feasible=len(safe),
                        solver_executed=sum(bool(r.get("solver_executed")) for r in group),
                        solver_success=sum(r.get("solver_success") is True for r in group),
                        best_n_segments=None if best is None else best["n_segments"],
                        best_algorithm=None if best is None else best["algorithm"],
                        best_new_length_m=None if best is None else best["final_total_length_m"],
                        best_complete_flow_seconds=None
                        if best is None
                        else best["complete_flow_seconds"],
                        best_minimum_sf=None if best is None else best["final_check"]["minimum_sf"],
                        mean_executed_solver_seconds=float(
                            np.mean(
                                [
                                    r["optimization_seconds"]
                                    for r in group
                                    if r.get("solver_executed")
                                ]
                            )
                        )
                        if any(r.get("solver_executed") for r in group)
                        else None,
                    )
                )
    batch = dict(
        completed_combinations=len(reports),
        expected_combinations=240,
        completed_cells=len(cells),
        expected_cells=60,
        feasible=sum(bool((r.get("final_check") or {}).get("feasible")) for r in reports),
        solver_executed=sum(bool(r.get("solver_executed")) for r in reports),
        solver_success=sum(r.get("solver_success") is True for r in reports),
        actual_sequential_cells_wall_seconds=sum(r["scenario_wall_seconds"] for r in cells),
        combined_report_seconds=time.perf_counter() - begin,
        explanation="Sequential cells and algorithms. Cell wall includes preprocessing, one shared initial construction, method wall times, fixed-history audit and individual reports. Combined reporting and invocation overhead are separate; do not sum per-algorithm complete-flow costs as batch wall.",
    )
    batch["proven_infeasible_combinations"] = sum(
        r.get("status") == "proven_infeasible_under_configured_constraints" for r in reports
    )
    batch["initial_search_failed_combinations"] = sum(
        r.get("status") == "initial_search_failed_not_proof_of_infeasibility" for r in reports
    )
    batch["selected_common_initial"] = sum(
        r.get("solver_executed")
        and (
            r.get("selected_candidate") == "verified_initial_point"
            or r.get("selected_after_dense_fallback_to_initial")
        )
        for r in reports
    )
    save_json(out / "batch_timing.json", batch)
    save_json(out / "cell_timings.json", cells)
    save_json(out / "group_summary.json", group_best)
    csv_dicts(out / "group_summary.csv", group_best)
    body = f"""<header><h1>A/B/C：两种轨迹几何 × 两种布局 × 1–5段 × 四算法</h1><p>已完成{len(reports)}/240组合、{len(cells)}/60单元；采用轨迹通过复评{batch["feasible"]}条；求解器实际启动{batch["solver_executed"]}次、成功终止{batch["solver_success"]}次。</p><p>几何：最小曲率平面圆弧 / 恒曲率恒当地工具面空间曲线。布局：全部弯曲段 / 弯曲—直线交替。四算法：SLSQP、trust-constr（内点法）、COBYLA、COBYQA。</p><p>默认Rev.0全部参数、k=1；共同靶点(-1333,1000,2200)m；DLS&lt;6°/30m、中靶误差≤0.5m、SF&gt;1.5、中心距&gt;5m。原有资料与结果保留。</p><p class="note">单段上限1800m不足以到三场景共同靶点，单段组合按必要条件记录不可行，未运行优化器。恒工具面曲线不使用单平面圆弧共面判据。初值搜索失败、求解器未收敛、公共初值回退与通过复评的优化结果分别报告；没有将搜索失败宣称为数学不可行。</p></header>
<section><h2>每场景单文件完整报告</h2><ul>{"".join(f'<li><a href="scene_{s}/index.html">场景{s}：80组合、交互3D与2D、收敛曲线、工具面、初值及时间拆解</a></li>' for s in config["scenarios"])}</ul><h3>每场景本次最短认证采用结果</h3>{table(["场景", "几何", "布局", "段数", "算法", "新段长m", "该算法完整流程s", "采用状态"], scene_best)}</section>
<section><h2>每单元四算法中的最短认证采用结果</h2>{table(["场景", "几何", "布局", "段数", "可行算法数", "最短采用算法", "新段长m", "采用状态"], summary)}<p>最短仅指本次采用结果中最短，不证明全局最优；未收敛保留解或公共初值不会被标注为收敛最优解。</p></section>
<section><h2>数据和复算</h2><p><a href="comparison_240.csv">240组合完整指标CSV</a> · <a href="all_results.json">全部结果JSON</a> · <a href="experiment_config.json">完整配置</a> · <a href="cell_timings.json">60单元耗时</a> · <a href="experiment_guide.md">实验说明</a></p><pre>{html.escape(json.dumps(batch, ensure_ascii=False, indent=2))}</pre><p>单元目录：几何/布局/segments_01～05/scene_A～C。每算法保留1m轨迹、控制参数、全部邻井逐点SF/匹配点、完整协方差/误差项、原始候选、停止原因和回调。报告可单文件离线查看；详细文件链接依赖目录结构。</p></section>"""
    discrete = out / "discrete_validation" / "verification.json"
    if discrete.exists():
        validation = json.loads(discrete.read_text())
        demo_rows = [
            [
                r["algorithm"],
                r["selected_toolface_deg"],
                r["free_continuous_variables"],
                r["feasible"],
                r["solver_success"],
                fmt(r["length_m"]),
                fmt(r["complete_assignment_flow_seconds"], 3),
            ]
            for r in validation["records"]
        ]
        demo_links = "".join(
            f'<li><a href="discrete_validation/arc_1__tf0002__{method}__r1/trajectory_3d.html">合成验证 {method}：90°采用轨迹</a></li>'
            for method in config["algorithms"]
        )
        body += (
            "<section><h2>新增区间/离散工具面：独立合成验证</h2><p>上面的240组合使用原连续区间。新增可选配置支持逐段连续区间或有限角集合[0,90,180,270]；离散角先完整枚举并固定，再做连续NLP，不在优化结束后取整。以下是独立合成目标的16次组合验证，不代表A/B/C已按离散角集合重跑。</p>"
            + table(
                [
                    "算法",
                    "选定角°",
                    "NLP自由变量",
                    "最终可行",
                    "success",
                    "新段长m",
                    "全部4角组合累计流程s",
                ],
                demo_rows,
            )
            + '<p><a href="../../toolface_configuration.md">配置、公式与分段混用说明</a> · <a href="discrete_validation/finite_toolface_selection.json">全部离散选择记录</a> · <a href="discrete_validation/verification.json">独立ODE与导出核查</a></p><ul>'
            + demo_links
            + "</ul></section>"
        )
    (out / "index.html").write_text(page("A/B/C 240组合完整对比", body), encoding="utf-8")
    write_explanation(out, config, batch)


def write_explanation(out, config, batch):
    text = f"""# A/B/C 两种几何、两种布局、1–5段、四算法实验

**实验范围。** 2×2×5×3×4=240组合；同单元共享认证初值，不跨算法继承控制。已完成{batch["completed_combinations"]}组合，{batch["feasible"]}条采用轨迹通过1m复评。逐项状态以comparison_240.csv为准。

**几何含义。** minimum_curvature按精确平面圆弧递推，工具面控制为段起点当地高边角；constant_toolface按I′=κcosω、A′=κsinω/sinI、x′=t(I,A)计算，段内κ、ω恒定，一般不共面。直线κ=0。两种几何均保证段间位置和切向连续，未加曲率连续和跨段工具面旋转速率约束。

**布局与变量。** arc表示所有段均弯曲，1–5段为3/6/9/12/15变量；arc-straight为弯曲与直线交替，1–5段为3/4/7/8/11变量。每弯曲段变量[DLS,当地工具面,段长]，每直线只有段长。DLS换算κ=π·DLS/(180×30)。弯曲段统一[10,1800]m，直线[10,2200]m；全部弯曲的偶数段也严格用1800m上限。

**默认参数。** 当前iscwsa_rev0及25源参数预算不变，k_sigma=1，SF=D/[k(r₁+r₂)]，r=√λmax(Σ)。没有井径/额外裕量扣除，也没有任意0.5m附加位置先验；从井口实钻历史继续传播。邻井/历史30m合成测站，新段最大30m；1m插值点不当作独立测站。恒工具面名义轨迹使用新方程，Rev.0继续按MC测站雅可比离散传播，是该名义曲线的测站近似，并非恒控制参数的精确灵敏度。实钻标定与真实测站元数据缺失，沿用当前参数，不宣称已完成现场工具标定。

**约束。** 共同靶点N=-1333/E=1000/D=2200m；位置≤0.5m、末端I89°±0.5°/A145.9°±0.5°；DLS[0.02,5.999]°/30m，直线0；当地工具面[-180,180]°、全过程I[0.1,95]°、κL≤150°；最终SF>1.5、连续中心距下界>5m。优化保护半径0.49m、SF≥1.53、中心距≥5.1m。分离系数及中心距均参与每次试探点的约束评价，优化终止后再做独立精细验收。

**初值构建。** 先做保守必要条件检查，未排除者构造MC几何种子，再按所选几何方程做带界least_squares位置/姿态拟合、几何可行性恢复、全Rev.0约束恢复及独立1m验收。最多12种子、90秒；记录各阶段耗时。每单元首个认证初值冻结为四算法共同起点，保存哈希。普通搜索失败只标记未找到初值，不等于证明不可行。必要条件已证明不可行则不虚构优化迭代。

**算法设置。** SLSQP、trust-constr（信赖域内点法）、COBYLA、COBYQA均实际调用SciPy局部约束NLP。最大75秒/算法，函数/迭代预算见配置；未收敛可保留已找到的可行迭代，无改进时明确采用公共初值。为了避免内点法内部越过边界评价负曲率/负段长，本实验显式设置solver.keep_variable_bounds_feasible=true，trust-constr的Bounds启用keep_feasible，其余算法使用原有边界接口；旧默认不变。

**时间口径。** 60单元与每单元四算法顺序运行，固定BLAS单线程。完整流程包含输入/模型准备、公共初值和该算法优化/内部验收/最终扫描/导出，共享成本在每算法对比计一次，不能累加成真实批次墙钟。单元实际墙钟另含固定历史审计和报告绘图；总览的combined_report_seconds另列。优化及最终扫描分别记录SF初筛、SF细化、中心距初筛/细化、轨迹、误差传播和约束组装；这些是阶段内部时间，不与外层重复相加。

**不可行与失败。** 所有单段轨迹上限1800m，小于三个场景的必要弦长，因此全部单段组合均记录为已证明不可行；同一单段虽然两种布局等价，仍保留两个独立配置单元。最小曲率单弧加末端切线直线还受共面必要条件限制；该限制对恒工具面空间曲线不适用。不得将旧实验的共面结论套用新模式。

**可视化。** 每场景一个自包含HTML：80组合状态/约束指标、可选择几何/布局/段数/算法的交互3D与水平/垂直投影、原设计与实钻、逐点SF、实际当地工具面、初值阶段时间、算法/模块时间、进尺—回调、累计最短可行进尺—秒、约束违反量—秒及SF—秒。图形只做显示抽样，1m完整数值保存在CSV/NPZ。未启动组合没有虚构收敛曲线。

**文件结构。** index.html为总览；scene_A/B/C/index.html为每场景80组合报告；comparison_240.csv为扁平指标；all_results.json为原始报告；每单元在<几何>/<布局>/segments_XX/scene_X/中，含input_audit.json、problem.json、initialization.json、shared_initial_*、四算法result.json/selected_*和原始候选；source_before/after保存版本快照，historical_hashes_before.json用于验证原结果未改动。numerical_trials是最终设置确定前的试算，不纳入240组合。

**运行方式。** 在本目录使用安装requirements.txt的Python：

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python -B src/wellpath/workflows/geometry_comparison.py --config examples/replanning_geometry_matrix.json --output results/my_geometry_matrix --resume
python -B tests/test_geometry_matrix.py --output results/my_geometry_matrix
```

**恢复与重绘。** --resume仅跳过存在scene_timing.json的完整单元，且要求完整配置完全一致。可用--models、--modes、--counts、--scenarios运行子集；总览明确显示完成数。--render-only从数值记录重建报告，不重新优化。不覆盖历史目录。
"""
    groups = json.loads((out / "group_summary.json").read_text())
    text += "\n## 本次实际结果\n\n"
    text += f"**状态计数。** 实际启动{batch['solver_executed']}次NLP，成功终止{batch['solver_success']}次；{batch['proven_infeasible_combinations']}条记录有必要条件不可行证明，{batch['initial_search_failed_combinations']}条为初值搜索未成功。最终{batch['feasible']}条采用轨迹通过认证，其中{batch['selected_common_initial']}条采用公共可行初值。可行、收敛和采用来源分开记录。\n\n"
    text += "|场景|几何|布局|可行组合|本次最短段数|算法|新段长m|该算法完整流程s|\n|---|---|---|---:|---:|---|---:|---:|\n"
    for r in groups:
        text += f"|{r['scene']}|{MODEL[r['arc_segment_model']]}|{MODE[r['trajectory_mode']]}|{r['feasible']}/{r['combinations']}|{r['best_n_segments']}|{r['best_algorithm']}|{fmt(r['best_new_length_m'], 6)}|{fmt(r['best_complete_flow_seconds'], 3)}|\n"
    text += f"\n**实际墙钟。** 已完成单元顺序墙钟合计{batch['actual_sequential_cells_wall_seconds']:.3f}秒（含各单元输入准备、初值、四算法、固定历史审计和单元报告），本次组合报告绘制{batch['combined_report_seconds']:.3f}秒。模型切换时的专项验证、独立复核和桌面操作另列日志，不计作单元优化时间。该实验为单次本地顺序运行，早期测试/浏览核查造成的普通桌面负载已在experiment_notes.json说明；时间结果不应解释为多次统计基准。\n"
    text += "\n**结果解读。** 表中最短只是在当前初值、约束和预算下各算法采用结果中的最短，不代表该段数或几何的全局最优。四/五段未必优于三段；较多自由变量会增加局部搜索成本。最小曲率与恒工具面的有限段控制规律不同，即使进尺接近也不能互相重标模型。\n"
    (out / "experiment_guide.md").write_text(text, encoding="utf-8")
