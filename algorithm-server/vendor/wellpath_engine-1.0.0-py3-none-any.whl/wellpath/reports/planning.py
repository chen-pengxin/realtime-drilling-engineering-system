"""Offline interactive 3D paths/ISCWSA ellipsoids + static diagnostic panels."""

from pathlib import Path

import numpy as np

from wellpath.anticollision.uncertainty import interpolate_cov, path_at, scalar_radius
from wellpath.planning.geometry_problem import samples


def ellipsoid(center, cov, k):
    eig, vec = np.linalg.eigh((cov + cov.T) / 2)
    u = np.linspace(0, 2 * np.pi, 20)
    v = np.linspace(0, np.pi, 12)
    unit = np.array(
        [
            np.cos(u)[:, None] * np.sin(v),
            np.sin(u)[:, None] * np.sin(v),
            np.ones((len(u), 1)) * np.cos(v),
        ]
    )
    xyz = (vec @ np.diag(k * np.sqrt(np.maximum(eig, 0))) @ unit.reshape(3, -1)).reshape(unit.shape)
    return xyz + np.asarray(center)[:, None, None]


def add_legend_proxy(fig, name, color, group, marker="circle"):
    import plotly.graph_objects as go

    fig.add_trace(
        go.Scatter3d(
            x=[None],
            y=[None],
            z=[None],
            mode="markers",
            name=name,
            legendgroup=group,
            marker=dict(size=7, color=color, symbol=marker),
            showlegend=True,
            hoverinfo="skip",
        )
    )


def plot_run(problem, initial, final, report, out):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import plotly.graph_objects as go

    out = Path(out)
    e = problem.evaluate(final)
    data = samples(problem, final, problem.cfg.get("output_sample_step_m", 0.5))
    initial_data = samples(problem, initial, 0.5)
    sf = problem.engine.evaluate(
        e, factor=problem.cfg["iscwsa"].get("validation_scan_factor", 4), refine=False
    )
    fig = plt.figure(figsize=(15, 11), constrained_layout=True)
    grid = fig.add_gridspec(3, 3)
    ax = fig.add_subplot(grid[:2, :2], projection="3d")
    ax.plot(*initial_data[:, 3:6].T, "--", alpha=0.6, label="Feasible initial")
    palette = plt.get_cmap("tab10")
    interactive = go.Figure()
    interactive.add_trace(
        go.Scatter3d(
            x=initial_data[:, 3],
            y=initial_data[:, 4],
            z=initial_data[:, 5],
            name="Feasible initial",
            mode="lines",
            line=dict(color="gray", dash="dash", width=3),
        )
    )
    for i in range(1, problem.n + 1):
        part = data[data[:, 0] == i]
        kind = problem.segment_types[i - 1]
        ax.plot(*part[:, 3:6].T, label=f"{i}: {kind}", color=palette((i - 1) % 10))
        interactive.add_trace(
            go.Scatter3d(
                x=part[:, 3],
                y=part[:, 4],
                z=part[:, 5],
                mode="lines",
                name=f"Segment {i}: {kind}",
                line=dict(width=7),
                customdata=part[:, [2, 6, 7, 9]],
                hovertemplate="N %{x:.2f} E %{y:.2f} TVD %{z:.2f}<br>MD %{customdata[0]:.2f}"
                "<br>Inc %{customdata[1]:.2f} Azi %{customdata[2]:.2f}"
                "<br>DLS %{customdata[3]:.3f}<extra></extra>",
            )
        )
    for well in problem.engine.neighbors:
        md, q, c = problem.engine.offset(well, 4)
        ax.plot(*q.T, label=well["name"], color="black", alpha=0.7)
        interactive.add_trace(
            go.Scatter3d(
                x=q[:, 0],
                y=q[:, 1],
                z=q[:, 2],
                name=well["name"],
                mode="lines",
                line=dict(color="black", width=4),
                legendgroup="offset_path",
            )
        )
        for index in np.linspace(0, len(q) - 1, 5, dtype=int):
            if problem.engine.scalar_radius_mode:
                cov = (
                    np.eye(3)
                    * float(scalar_radius(np.array([md[index]]), well["settings"])[0]) ** 2
                )
                scale = 1.0
            else:
                cov = c[index]
                scale = problem.engine.k
            xyz = ellipsoid(q[index], cov, scale)
            interactive.add_trace(
                go.Surface(
                    x=xyz[0],
                    y=xyz[1],
                    z=xyz[2],
                    opacity=0.18,
                    colorscale=[[0, "red"], [1, "red"]],
                    showscale=False,
                    name=(
                        "Offset well scalar-radius sphere"
                        if problem.engine.scalar_radius_mode
                        else f"Offset well {problem.engine.k:g} sigma EOU"
                    ),
                    legendgroup="offset_eou",
                    showlegend=False,
                    hoverinfo="skip",
                )
            )
    covdata = sf["covariance"]
    start_md = float(problem.cfg["iscwsa"]["planned"].get("start_md_m", 0.0))
    query = np.linspace(0, float(e["physical"][:, 2].sum()), 7)
    pp, _, _ = path_at(problem, e, query)
    cc = interpolate_cov(covdata["md"], covdata["cov"], query + start_md)
    if covdata["model_type"] == "md_scalar_radius":
        radii = scalar_radius(query + start_md, problem.cfg["iscwsa"]["planned"])
        cc = np.eye(3)[None, :, :] * radii[:, None, None] ** 2
    uncertainty_scale = 1.0 if covdata["model_type"] == "md_scalar_radius" else problem.engine.k
    planned_uncertainty_label = (
        "Planned well scalar-radius sphere"
        if covdata["model_type"] == "md_scalar_radius"
        else f"Planned well {problem.engine.k:g} sigma EOU"
    )
    for point, cov in zip(pp, cc):
        xyz = ellipsoid(point, cov, uncertainty_scale)
        interactive.add_trace(
            go.Surface(
                x=xyz[0],
                y=xyz[1],
                z=xyz[2],
                opacity=0.2,
                colorscale=[[0, "royalblue"], [1, "royalblue"]],
                showscale=False,
                name=planned_uncertainty_label,
                legendgroup="planned_eou",
                showlegend=False,
                hoverinfo="skip",
            )
        )
    for name, point, color in [("Start", problem.p0, "green"), ("Target", problem.pt, "red")]:
        ax.scatter(*point, color=color, marker="*", s=80)
        interactive.add_trace(
            go.Scatter3d(
                x=[point[0]],
                y=[point[1]],
                z=[point[2]],
                mode="markers",
                name=name,
                marker=dict(size=6, color=color, symbol="diamond"),
                legendgroup=name.lower(),
            )
        )
    if problem.position_mode == "sphere":
        xyz = ellipsoid(problem.pt, np.eye(3) * float(problem.position_tol) ** 2, 1)
        interactive.add_trace(
            go.Surface(
                x=xyz[0],
                y=xyz[1],
                z=xyz[2],
                opacity=0.3,
                colorscale=[[0, "green"], [1, "green"]],
                showscale=False,
                name="Target position tolerance",
                legendgroup="target_tolerance",
                showlegend=False,
                hoverinfo="skip",
            )
        )
    for detail in report["final_check"]["separation_details"]:
        points = np.array([detail["reference_position_m"], detail["offset_position_m"]])
        interactive.add_trace(
            go.Scatter3d(
                x=points[:, 0],
                y=points[:, 1],
                z=points[:, 2],
                mode="lines+markers",
                name=f"Minimum SF pair ({detail['minimum_sf']:.3f})",
                line=dict(color="darkorange", width=6, dash="dash"),
                legendgroup="minimum_sf",
            )
        )
    # Surface traces are difficult to identify from a compact legend; proxies
    # provide clear labels and group toggles for all ellipsoids of each type.
    add_legend_proxy(
        interactive,
        "Planned well scalar-radius sphere"
        if covdata["model_type"] == "md_scalar_radius"
        else f"Planned well position uncertainty ({problem.engine.k:g} sigma)",
        "royalblue",
        "planned_eou",
    )
    add_legend_proxy(
        interactive,
        "Offset well scalar-radius sphere"
        if problem.engine.scalar_radius_mode
        else f"Offset well position uncertainty ({problem.engine.k:g} sigma)",
        "red",
        "offset_eou",
    )
    if problem.position_mode == "sphere":
        add_legend_proxy(interactive, "Target position tolerance", "green", "target_tolerance")
    ax.set(xlabel="North (m)", ylabel="East (m)", zlabel="TVD (m)")
    ax.invert_zaxis()
    ax.legend(fontsize=8)
    ax.set_box_aspect(np.maximum(np.ptp(data[:, 3:6], axis=0), 1))
    uncertainty_label = (
        "ISCWSA"
        if covdata["model_type"] == "iscwsa"
        else "MD scalar-radius"
        if covdata["model_type"] == "md_scalar_radius"
        else "Simplified MWD envelope"
        if covdata["model_type"] == "simplified_mwd"
        else "Empirical uncertainty"
    )
    uncertainty_title = (
        uncertainty_label
        if covdata["model_type"] == "md_scalar_radius"
        else f"{uncertainty_label} k={problem.engine.k}"
    )
    interactive.update_layout(
        title=f"{report['algorithm']} | mode={problem.trajectory_mode} | n={problem.n} | "
        f"geometry={problem.arc_segment_model} | L={report['final_total_length_m']:.4f} m | {uncertainty_title}",
        scene=dict(
            xaxis_title="North (m)",
            yaxis_title="East (m)",
            zaxis=dict(title="TVD (m)", autorange="reversed"),
            aspectmode="data",
        ),
        width=1450,
        height=850,
        legend=dict(
            orientation="v",
            x=1.02,
            y=1,
            yanchor="top",
            groupclick="togglegroup",
            bgcolor="rgba(255,255,255,0.88)",
            bordercolor="#999",
            borderwidth=1,
        ),
        margin=dict(l=0, r=300, b=0, t=90),
    )
    interactive.write_html(out / "trajectory_3d.html", include_plotlyjs=True, full_html=True)
    axsf = fig.add_subplot(grid[0, 2])
    for profile in sf["profiles"]:
        axsf.plot(profile["relative_md_m"], profile["minimum_sf"], label=profile["neighbor"])
    axsf.axhline(problem.engine.threshold, color="red", ls="--", label="SF threshold")
    axsf.set(xlabel="Relative MD (m)", ylabel="Separation factor SF")
    axsf.legend(fontsize=7)
    axsf.grid(alpha=0.3)
    axangles = fig.add_subplot(grid[1, 2])
    axangles.plot(data[:, 2], data[:, 6], label="Inclination")
    axangles.plot(data[:, 2], np.rad2deg(np.unwrap(np.deg2rad(data[:, 7]))), label="Azimuth")
    axangles.set(xlabel="Relative MD (m)", ylabel="Angle (deg)")
    axangles.legend()
    axangles.grid(alpha=0.3)
    axplan = fig.add_subplot(grid[2, 0])
    axplan.plot(data[:, 4], data[:, 3])
    axplan.set(xlabel="East (m)", ylabel="North (m)")
    for well in problem.engine.neighbors:
        q = well["positions"]
        axplan.plot(q[:, 1], q[:, 0], "k.-")
    axplan.set_aspect("equal", adjustable="datalim")
    axplan.grid(alpha=0.3)
    axcontrols = fig.add_subplot(grid[2, 1])
    axcontrols.plot(data[:, 2], data[:, 9], label="DLS (deg/30m)")
    axcontrols.plot(data[:, 2], data[:, 8], label="Actual toolface (deg)")
    axcontrols.set(xlabel="Relative MD (m)", ylabel="Control")
    axcontrols.legend()
    axcontrols.grid(alpha=0.3)
    axconv = fig.add_subplot(grid[2, 2])
    for run in report["runs"]:
        history = run["history"]
        if history:
            axconv.plot(
                [h["elapsed_seconds"] for h in history],
                [h["length_m"] for h in history],
                label=f"Run {run['run']}",
            )
    axconv.set(xlabel="Solver time (s)", ylabel="Iteration length (m)")
    axconv.grid(alpha=0.3)
    fig.suptitle(
        f"{report['algorithm']} | {problem.trajectory_mode} | n={problem.n} | length={report['final_total_length_m']:.4f} m | "
        f"min SF={report['final_check']['minimum_sf']} | solver {report['optimization_seconds']:.3f} s"
    )
    fig.savefig(out / "diagnostics.png", dpi=160)
    plt.close(fig)


def plot_comparison(rows, out):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    out = Path(out)
    labels = [f"{r['layout']}\n{r['algorithm']}" for r in rows]
    fig, axes = plt.subplots(3, 1, figsize=(max(10, len(rows) * 0.65), 12), constrained_layout=True)
    for ax, key, label in zip(
        axes,
        ["length_m", "solver_seconds", "minimum_sf"],
        ["Selected feasible length (m)", "Solver time (s)", "Minimum verified SF"],
    ):
        values = [float("nan") if r.get(key) is None else r[key] for r in rows]
        colors = [
            "tab:blue" if r.get("selected_candidate_solver_success") else "tab:orange" for r in rows
        ]
        ax.bar(np.arange(len(rows)), values, color=colors)
        ax.set_ylabel(label)
        ax.set_xticks(range(len(rows)), labels, rotation=45, ha="right", fontsize=8)
        ax.grid(axis="y", alpha=0.3)
        for i, r in enumerate(rows):
            if r["status"] != "feasible_design":
                ax.text(i, 0, "No feasible initial", rotation=90, fontsize=7)
    if rows:
        axes[2].axhline(rows[0]["sf_threshold"], color="red", ls="--")
    fig.suptitle(
        "Blue: selected solver candidate converged; orange: fallback or nonconverged candidate"
    )
    fig.savefig(out / "comparison.png", dpi=160)
    plt.close(fig)


def plot_plan_comparison(entries, out):
    """Plan-view overlay and local collision-risk detail for feasible layouts."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Ellipse

    from wellpath.anticollision.uncertainty import interpolate_cov, neighbor_at, planned_covariance

    out = Path(out)
    entries = [entry for entry in entries if entry.get("final") is not None]
    if not entries:
        return
    fig, (ax, detail_ax) = plt.subplots(
        1, 2, figsize=(14, 6.2), constrained_layout=True, gridspec_kw={"width_ratios": [1.15, 1]}
    )
    colors = plt.get_cmap("tab10")
    risk_points = []
    for idx, entry in enumerate(entries):
        problem = entry["problem"]
        z = entry["final"]
        label = entry["label"]
        color = colors(idx % 10)
        data = samples(problem, z, 0.2)
        ax.plot(data[:, 4], data[:, 3], lw=2.1, color=color, label=label)
        detail_ax.plot(data[:, 4], data[:, 3], lw=1.8, color=color, label=f"{label} path")
        e = problem.evaluate(z)
        details = entry["report"].get("final_check", {}).get("separation_details", [])
        for item in details:
            planned = np.asarray(item["reference_position_m"])
            offset = np.asarray(item["offset_position_m"])
            ax.plot(
                [planned[1], offset[1]],
                [planned[0], offset[0]],
                ls=":",
                lw=1.1,
                color=color,
                alpha=0.85,
            )
            ax.scatter(planned[1], planned[0], s=25, marker="x", color=color, zorder=5)
            ax.scatter(
                offset[1], offset[0], s=22, marker="o", facecolor="white", edgecolor=color, zorder=5
            )
            detail_ax.plot(
                [planned[1], offset[1]],
                [planned[0], offset[0]],
                ls="--",
                lw=1.5,
                color=color,
                label=f"{label}: min SF {item['minimum_sf']:.2f}",
            )
            detail_ax.scatter(planned[1], planned[0], s=38, marker="x", color=color, zorder=6)
            detail_ax.scatter(
                offset[1], offset[0], s=34, marker="o", facecolor="white", edgecolor=color, zorder=6
            )
            risk_points.extend([planned, offset])
            # Draw each well's NE marginal configured K-sigma position ellipse at the
            # actual pair. This is uncertainty visualization, not an SF boundary.
            covdata = planned_covariance(problem, e)
            start_md = float(problem.cfg["iscwsa"]["planned"].get("start_md_m", 0.0))
            pc = interpolate_cov(
                covdata["md"],
                covdata["cov"],
                np.array([item["reference_relative_md_m"] + start_md]),
            )[0]
            well = next(w for w in problem.engine.neighbors if w["name"] == item["neighbor"])
            _, oc = neighbor_at(well, np.array([item["offset_md_m"]]))
            for center, cov, label_eou, edge in (
                (planned, pc, f"Planned {problem.engine.k:g} sigma NE EOU", "royalblue"),
                (offset, oc[0], f"Offset {problem.engine.k:g} sigma NE EOU", "crimson"),
            ):
                eig, vec = np.linalg.eigh((cov[:2, :2] + cov[:2, :2].T) / 2)
                eig = np.maximum(eig, 0)
                order = np.argsort(eig)[::-1]
                angle = np.degrees(np.arctan2(vec[1, order[0]], vec[0, order[0]]))
                ellipse = Ellipse(
                    (center[1], center[0]),
                    width=2 * problem.engine.k * np.sqrt(eig[order[0]]),
                    height=2 * problem.engine.k * np.sqrt(eig[order[1]]),
                    angle=angle,
                    facecolor=edge,
                    edgecolor=edge,
                    alpha=0.14,
                    lw=1.2,
                    label=label_eou if idx == 0 else None,
                )
                detail_ax.add_patch(ellipse)
    first = entries[0]["problem"]
    for well in first.engine.neighbors:
        q = well["positions"]
        ax.plot(q[:, 1], q[:, 0], color="black", lw=1.8, label=f"Offset: {well['name']}")
        detail_ax.plot(q[:, 1], q[:, 0], color="black", lw=1.8, label=f"Offset: {well['name']}")
    ax.scatter(first.p0[1], first.p0[0], marker="s", s=38, color="green", label="Start")
    ax.scatter(first.pt[1], first.pt[0], marker="*", s=90, color="purple", label="Target")
    if first.position_mode == "sphere":
        ax.add_patch(
            plt.Circle(
                (first.pt[1], first.pt[0]),
                float(first.position_tol),
                fill=False,
                color="purple",
                ls=":",
                lw=1.1,
                label="Target tolerance",
            )
        )
    ax.set_title("Plan view: feasible trajectory layouts")
    detail_ax.set_title("Detail near minimum-SF locations")
    for a in (ax, detail_ax):
        a.set_xlabel("East (m)")
        a.set_ylabel("North (m)")
        a.grid(alpha=0.28)
        a.set_aspect("equal", adjustable="box")
    ax.legend(loc="best", fontsize=8, framealpha=0.92)
    detail_ax.legend(loc="best", fontsize=7, framealpha=0.92)
    if risk_points:
        rp = np.asarray(risk_points)
        center = rp[:, :2].mean(axis=0)
        # Include nearby path geometry so the zoom shows how the layouts pass
        # the neighbor, while retaining enough room for the uncertainty ellipses.
        cloud = np.vstack(
            [
                np.c_[
                    samples(x["problem"], x["final"], 0.5)[:, 4],
                    samples(x["problem"], x["final"], 0.5)[:, 3],
                ]
                for x in entries
            ]
        )
        d = np.linalg.norm(cloud - center[None, :], axis=1)
        local = cloud[d <= 18]
        focus = np.vstack([rp[:, [1, 0]], local]) if len(local) else rp[:, [1, 0]]
        span = np.maximum(np.ptp(focus, axis=0), 10.0)
        pad = np.maximum(span * 0.2, 3.0)
        detail_ax.set_xlim(focus[:, 0].min() - pad[0], focus[:, 0].max() + pad[0])
        detail_ax.set_ylim(focus[:, 1].min() - pad[1], focus[:, 1].max() + pad[1])
    fig.suptitle("Trajectory layout comparison with ISCWSA SF risk detail")
    fig.savefig(out / "trajectory_plan_comparison.png", dpi=170)
    plt.close(fig)
