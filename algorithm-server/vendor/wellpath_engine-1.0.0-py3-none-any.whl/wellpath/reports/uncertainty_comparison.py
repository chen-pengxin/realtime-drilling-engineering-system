"""Create figures, offline interactive views and the report for a completed scan."""

from __future__ import annotations

import argparse
import csv
import html
import json
import time
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import plotly.graph_objects as go
from matplotlib.colors import BoundaryNorm, ListedColormap
from plotly.offline import get_plotlyjs
from scipy.stats import spearmanr

from wellpath.anticollision.settings import scan_sf_settings, sf_formula
from wellpath.workflows.uncertainty_comparison import save_json, write_csv

matplotlib.use("Agg")


def read_csv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def run(output):
    start = time.perf_counter()
    output = Path(output)
    figures = output / "03_figures"
    figures.mkdir(exist_ok=True)
    tables = output / "02_comparison"
    summary = json.loads((tables / "model_summary.json").read_text())
    pair_rows = json.loads((tables / "pair_comparison.json").read_text())
    audit = json.loads((tables / "source_baseline_audit.json").read_text())
    config = json.loads((output / "00_inputs/scan_config.json").read_text())
    source_audit = json.loads((output / "00_inputs/source_audit.json").read_text())
    timing = json.loads((tables / "evaluation_timing.json").read_text())
    names = [r["model"] for r in summary]
    well_names = [f"井{i}" for i in range(1, 11)]
    labels = dict(
        iscwsa="ISCWSA",
        constant_covariance="固定协方差",
        constant_isotropic="固定各向同性",
        linear_std="标准差线性",
        random_walk="方差线性",
        tabulated_covariance="协方差表",
        md_scalar_radius="MD标量半径",
        simplified_mwd="简化MWD",
        iscwsa_rev0="ISCWSA Rev.0",
        wdw="WdW",
    )
    short = [labels.get(name, name) for name in names]
    count = len(names)
    config.setdefault("project_sf", {}).setdefault("sf_method", "project_rss")
    config.setdefault("common_sf", {}).setdefault("method", "additive_directional_radii")
    common_settings, project_settings = scan_sf_settings(config)
    common_description = f"{common_settings['method']}，K={common_settings['k_sigma']:g}；{sf_formula(common_settings['method'])}"
    project_description = f"{project_settings['sf_method']}，K={project_settings['k_sigma']:g}；{sf_formula(project_settings['sf_method'])}"
    color = plt.get_cmap("tab10")(np.arange(count))
    risk_colors = ["#dc2626", "#f97316", "#eab308", "#2563eb"]
    plt.rcParams.update(
        {
            "font.family": "Arial Unicode MS",
            "axes.unicode_minus": False,
            "font.size": 9,
            "figure.dpi": 130,
        }
    )
    data = read_csv(tables / "point_comparison.csv")
    groups = {well: [r for r in data if r["well"] == well] for well in well_names}
    md = {w: np.array([float(r["MD_m"]) for r in rows]) for w, rows in groups.items()}
    values = {
        name: {
            w: np.array([float(r[f"{name}_common_min_SF"]) for r in rows])
            for w, rows in groups.items()
        }
        for name in names
    }
    radius = {
        name: {
            w: np.array([float(r[f"{name}_max_axis_or_boundary_radius_m"]) for r in rows])
            for w, rows in groups.items()
        }
        for name in names
    }
    # Exact numeric labels on a shared four-level color scale.
    for convention, label in (("common", "半径和口径"), ("project", "项目配置口径")):
        fig, axes = plt.subplots(
            int(np.ceil(count / 4)),
            4,
            figsize=(16, 4.1 * int(np.ceil(count / 4))),
            layout="constrained",
        )
        for mi, (name, ax) in enumerate(zip(names, axes.flat)):
            matrix = np.full((10, 10), np.nan)
            for r in pair_rows:
                if r["model"] != name:
                    continue
                i = well_names.index(r["well_a"])
                j = well_names.index(r["well_b"])
                matrix[i, j] = matrix[j, i] = r[f"{convention}_min_SF"]
            ax.imshow(
                np.ma.masked_invalid(matrix),
                cmap=ListedColormap(risk_colors),
                norm=BoundaryNorm([0, 1, 1.5, 2.5, 1e6], 4),
            )
            ax.set_title(short[mi])
            ax.set_xticks(range(10), range(1, 11))
            ax.set_yticks(range(10), range(1, 11))
            for i in range(10):
                for j in range(10):
                    if i != j:
                        ax.text(
                            j,
                            i,
                            f"{matrix[i, j]:.2f}",
                            ha="center",
                            va="center",
                            fontsize=6.5,
                            color="white" if matrix[i, j] > 2.5 or matrix[i, j] <= 1 else "#111827",
                        )
        for ax in list(axes.flat)[count:]:
            ax.set_visible(False)
        fig.suptitle(
            f"10口井最小分离系数矩阵：{label}\n颜色按SF分级；中心距≤5 m的独立判红记录另见结果表",
            fontsize=13,
        )
        fig.savefig(figures / f"{convention}_SF_matrices.png", bbox_inches="tight")
        plt.close(fig)
    for kind, label, filename in (
        ("sf", "逐点最小SF（对数坐标）", "SF_profiles_all_wells.png"),
        ("radius", "最大轴1σ / 标量边界半径（m，对数坐标）", "uncertainty_profiles_all_wells.png"),
    ):
        fig, axes = plt.subplots(5, 2, figsize=(15, 16), layout="constrained")
        for well, ax in zip(well_names, axes.flat):
            for mi, name in enumerate(names):
                ax.plot(
                    md[well],
                    values[name][well] if kind == "sf" else radius[name][well],
                    color=color[mi],
                    lw=1.1,
                    label=short[mi],
                )
            if kind == "sf":
                for t, c in ((1, risk_colors[0]), (1.5, risk_colors[1]), (2.5, risk_colors[2])):
                    ax.axhline(t, color=c, lw=0.6, ls="--")
            ax.set_yscale("log")
            ax.set(title=well, xlabel="测深MD（m）", ylabel=label)
            ax.grid(alpha=0.18)
        handles, labels = axes.flat[0].get_legend_handles_labels()
        fig.legend(handles, labels, loc="outside lower center", ncol=4)
        fig.suptitle(
            "半径和SF口径沿程对比"
            if kind == "sf"
            else "误差尺度预测对比（协方差最大轴与确定性边界含义不同）",
            fontsize=14,
        )
        fig.savefig(figures / filename, bbox_inches="tight")
        plt.close(fig)
    fig, axes = plt.subplots(1, 3, figsize=(17, 5.6), layout="constrained")
    for metric, label, ax in (
        ("common", "半径和口径", axes[0]),
        ("project", "项目配置口径", axes[1]),
    ):
        bottom = np.zeros(count)
        for stage, c in zip(("red", "orange", "yellow", "blue"), risk_colors):
            v = np.array([r[f"{metric}_{stage}_points"] for r in summary])
            ax.barh(short, v, left=bottom, color=c, label=stage)
            bottom += v
        ax.set(xlabel="轨迹点数", title=f"{label}：红/橙/黄/蓝")
        ax.invert_yaxis()
        ax.legend(loc="lower right")
    axes[2].barh(
        short, [r["mean_abs_common_SF_difference_vs_md_scalar"] for r in summary], color=color
    )
    axes[2].set(title="相对MD标量半径的SF平均绝对差", xlabel="平均 |SF模型 − SF基线|")
    axes[2].invert_yaxis()
    fig.savefig(figures / "risk_and_SF_difference.png", bbox_inches="tight")
    plt.close(fig)
    independent = timing["independent_models"]
    if independent:
        fig, ax = plt.subplots(figsize=(12, 5.8), layout="constrained")
        left = np.zeros(len(independent))
        for key, label, c in [
            ("uncertainty_construction_seconds", "误差模型构造", "#a78bfa"),
            ("center_distance_seconds", "中心距评价", "#0d9488"),
            ("screening_seconds", "水平初筛", "#f59e0b"),
            ("interval_refinement_seconds", "候选区间细化", "#2563eb"),
            ("aggregation_and_control_seconds", "汇总及控制开销", "#94a3b8"),
        ]:
            values_time = np.array([r[key] for r in independent])
            ax.barh(short, values_time, left=left, label=label, color=c)
            left += values_time
        for i, r in enumerate(independent):
            ax.text(left[i] + 0.1, i, f"{r['evaluation_total_seconds']:.3f} s", va="center")
        ax.set(
            xlabel="墙钟时间（秒）",
            title="各模型独立评价：10口井、45井对，两种SF口径同时计算\n含误差构造、匹配和分级；不含文件读取、导出、绘图及独立复核",
        )
        ax.invert_yaxis()
        ax.set_xlim(0, float(left.max()) * 1.15)
        fig.legend(loc="outside lower center", ncol=3)
        fig.savefig(figures / "evaluation_timing_breakdown.png", bbox_inches="tight")
        plt.close(fig)
    stacked = np.array([np.concatenate([values[name][w] for w in well_names]) for name in names]).T
    correlation = spearmanr(stacked, axis=0).statistic
    write_csv(
        tables / "common_SF_spearman_correlation.csv",
        ["model"] + names,
        ([name] + correlation[i].tolist() for i, name in enumerate(names)),
    )
    fig, ax = plt.subplots(figsize=(9, 7), layout="constrained")
    im = ax.imshow(correlation, vmin=0, vmax=1, cmap="Blues")
    ax.set_xticks(range(count), short, rotation=30, ha="right")
    ax.set_yticks(range(count), short)
    for i in range(count):
        for j in range(count):
            ax.text(
                j,
                i,
                f"{correlation[i, j]:.3f}",
                ha="center",
                va="center",
                color="white" if correlation[i, j] > 0.65 else "black",
            )
    ax.set_title("38,297个逐点最小SF的Spearman相关系数\n相关性描述模型结果关系，不表示模型准确率")
    fig.colorbar(im, ax=ax, shrink=0.8)
    fig.savefig(figures / "SF_rank_correlation.png", bbox_inches="tight")
    plt.close(fig)
    # Error-scale differences vs the supplied scalar-radius rule.
    error_diff = []
    for well in well_names:
        base = radius["md_scalar_radius"][well]
        for name in names:
            predicted = radius[name][well]
            d = predicted - base
            error_diff.append(
                dict(
                    well=well,
                    model=name,
                    mean_radius_m=float(predicted.mean()),
                    max_radius_m=float(predicted.max()),
                    mean_signed_difference_m=float(d.mean()),
                    mean_absolute_difference_m=float(np.abs(d).mean()),
                    rms_difference_m=float(np.sqrt(np.mean(d * d))),
                    max_absolute_difference_m=float(np.abs(d).max()),
                )
            )
    write_csv(
        tables / "error_scale_difference_vs_md_scalar.csv",
        list(error_diff[0]),
        ([r[k] for k in error_diff[0]] for r in error_diff),
    )
    # Offline 3D with every scan point, model selector, risk legend and worst pairs.
    (figures / "plotly.min.js").write_text(get_plotlyjs(), encoding="utf-8")
    figure = go.Figure()
    traces_per_model = 14
    for mi, name in enumerate(names):
        for wi, well in enumerate(well_names):
            rows = groups[well]
            positions = np.array([[float(r[k]) for k in ("E_m", "N_m", "D_m")] for r in rows])
            codes = np.array([int(r[f"{name}_common_risk_code"]) for r in rows])
            # All points are retained in hover data; no geometry/scan downsampling.
            figure.add_trace(
                go.Scatter3d(
                    x=positions[:, 0],
                    y=positions[:, 1],
                    z=positions[:, 2],
                    mode="lines+markers",
                    name=well,
                    visible=mi == 0,
                    line=dict(color="#94a3b8", width=2),
                    marker=dict(
                        size=2.2,
                        color=codes,
                        cmin=0,
                        cmax=3,
                        colorscale=[
                            [0, risk_colors[0]],
                            [0.1666, risk_colors[0]],
                            [0.1667, risk_colors[1]],
                            [0.5, risk_colors[1]],
                            [0.5001, risk_colors[2]],
                            [0.8333, risk_colors[2]],
                            [0.8334, risk_colors[3]],
                            [1, risk_colors[3]],
                        ],
                    ),
                    customdata=np.column_stack(
                        [md[well], values[name][well], radius[name][well], codes]
                    ),
                    hovertemplate=well
                    + "<br>MD=%{customdata[0]:.3f} m<br>SF=%{customdata[1]:.6f}<br>最大轴/边界=%{customdata[2]:.4f} m<br>等级码=%{customdata[3]}<extra></extra>",
                )
            )
        for stage, c in zip(("红：危险", "橙：警告", "黄：关注", "蓝：安全"), risk_colors):
            figure.add_trace(
                go.Scatter3d(
                    x=[None],
                    y=[None],
                    z=[None],
                    mode="markers",
                    marker=dict(color=c, size=6),
                    name=stage,
                    visible=mi == 0,
                )
            )
    figure.update_layout(
        title=f"scenario_a：10口井，半径和SF口径，{names[0]}",
        height=820,
        scene=dict(
            xaxis_title="东坐标E（m）",
            yaxis_title="北坐标N（m）",
            zaxis=dict(title="垂深D（m）", autorange="reversed"),
            aspectmode="data",
        ),
        legend=dict(x=1.01, y=1),
        margin=dict(l=0, r=170, t=100, b=0),
        updatemenus=[
            dict(
                x=0.01,
                y=1.1,
                buttons=[
                    dict(
                        label=f"{short[mi]} ({name})",
                        method="update",
                        args=[
                            {
                                "visible": [
                                    j // traces_per_model == mi for j in range(len(figure.data))
                                ]
                            },
                            {"title": f"scenario_a：10口井，半径和SF口径，{name}"},
                        ],
                    )
                    for mi, name in enumerate(names)
                ],
            )
        ],
    )
    figure.write_html(
        figures / "trajectories_3d.html", include_plotlyjs="plotly.min.js", full_html=True
    )
    profile = go.Figure()
    for mi, name in enumerate(names):
        for wi, well in enumerate(well_names):
            profile.add_trace(
                go.Scatter(
                    x=md[well], y=values[name][well], mode="lines", name=well, visible=mi == 0
                )
            )
    profile.update_layout(
        title="逐点最小SF（半径和口径）",
        height=650,
        xaxis_title="测深MD（m）",
        yaxis=dict(title="最小SF", type="log"),
        updatemenus=[
            dict(
                buttons=[
                    dict(
                        label=short[mi],
                        method="update",
                        args=[{"visible": [j // 10 == mi for j in range(len(profile.data))]}],
                    )
                    for mi in range(count)
                ]
            )
        ],
        shapes=[
            dict(type="line", x0=0, x1=1, xref="paper", y0=t, y1=t, line=dict(color=c, dash="dash"))
            for t, c in ((1, risk_colors[0]), (1.5, risk_colors[1]), (2.5, risk_colors[2]))
        ],
    )
    profile.write_html(figures / "SF_profiles_interactive.html", include_plotlyjs="plotly.min.js")
    # Static plan/elevation with labelled well numbers.
    fig, axes = plt.subplots(1, 2, figsize=(14, 6), layout="constrained")
    for well in well_names:
        rows = groups[well]
        e = np.array([float(r["E_m"]) for r in rows])
        n = np.array([float(r["N_m"]) for r in rows])
        d = np.array([float(r["D_m"]) for r in rows])
        axes[0].plot(e, n, label=well)
        axes[1].plot(e, d, label=well)
        axes[0].annotate(well, (e[-1], n[-1]), fontsize=8)
    axes[0].set(xlabel="E（m）", ylabel="N（m）", title="水平投影")
    axes[0].axis("equal")
    axes[1].set(xlabel="E（m）", ylabel="垂深D（m）", title="E–D投影")
    axes[1].invert_yaxis()
    axes[1].legend(ncol=2)
    fig.savefig(figures / "trajectory_projections.png", bbox_inches="tight")
    plt.close(fig)
    # One file for browsing every deliverable.
    table_headers = [
        "模型",
        "最小SF（半径和）",
        "SF≤1.5井对",
        "红点",
        "橙点",
        "最大误差尺度(m)",
        "项目配置最小SF",
    ]
    tr = "".join(
        "<tr>"
        + "".join(
            f"<td>{html.escape(str(v))}</td>"
            for v in [
                short[i],
                f"{r['global_min_common_SF']:.6f}",
                r["common_risk_pairs"],
                r["common_red_points"],
                r["common_orange_points"],
                f"{r['max_error_radius_m']:.3f}",
                f"{r['global_min_project_SF']:.6f}",
            ]
        )
        + "</tr>"
        for i, r in enumerate(summary)
    )
    sections = "".join(
        f'<section><h2>{title}</h2><img src="03_figures/{filename}" loading="lazy"></section>'
        for title, filename in (
            ("井对最小SF矩阵：半径和口径", "common_SF_matrices.png"),
            ("井对最小SF矩阵：项目配置口径", "project_SF_matrices.png"),
            ("风险分级与SF差异", "risk_and_SF_difference.png"),
            *([("独立评价分阶段耗时", "evaluation_timing_breakdown.png")] if independent else []),
            ("逐井SF沿程曲线", "SF_profiles_all_wells.png"),
            ("误差尺度预测", "uncertainty_profiles_all_wells.png"),
            ("结果相关性", "SF_rank_correlation.png"),
            ("轨迹投影", "trajectory_projections.png"),
        )
    )
    dashboard = f"""<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>scenario_a{count}模型防碰扫描对比</title>
<style>body{{font-family:Arial,"PingFang SC",sans-serif;background:#f1f5f9;color:#172033;margin:0}}main{{max-width:1400px;margin:auto;padding:30px}}section{{background:white;padding:24px;margin:24px 0;border-radius:10px}}h1{{font-size:28px}}h2{{font-size:21px}}p{{line-height:1.8}}table{{border-collapse:collapse;width:100%;font-size:14px}}th,td{{padding:10px;text-align:right;border-bottom:1px solid #e2e8f0}}th:first-child,td:first-child{{text-align:left}}th{{background:#183653;color:white}}img{{width:100%;height:auto}}iframe{{width:100%;border:0}}a{{color:#1d4ed8}}nav a{{margin-right:22px}}</style>
<main><h1>scenario_a：10口井 × {count}种误差模型</h1><p>38,297个点；45个井对；1 m网格及70个非整数端点全部保留。所有扫描采用完整数值。</p>
<nav><a href="02_comparison/model_summary.csv">模型汇总CSV</a><a href="02_comparison/point_comparison.csv">完整逐点对比CSV</a><a href="report.md">方法与结果报告</a></nav>
<section><h2>比较条件</h2><p>common：{html.escape(common_description)}。project：{html.escape(project_description)}。地磁及经验参数为演示假设，未提供真实位置误差，结果反映模型敏感性，不能用于准确率排名。</p><table><tr>{"".join("<th>" + x + "</th>" for x in table_headers)}</tr>{tr}</table></section>
<section><h2>评价计时与公式含义</h2><p>{count}模型联合评价：总计{timing["batch"]["evaluation_total_seconds"]:.3f}秒，水平初筛{timing["batch"]["screening_seconds"]:.3f}秒，候选区间细化{timing["batch"]["interval_refinement_seconds"]:.3f}秒；总时间还包含误差模型构造、中心距评价及汇总。<a href="02_comparison/evaluation_timing.csv">完整计时CSV</a>。</p><p>common和project是两个可独立配置的评价通道，默认均为D/[k×(r1+r2)]、K=1；相同公式及K时结果相同。“项目配置”不表示更新的ISCWSA版本。具体公式与半径定义见报告及参数快照。</p></section>
<section><h2>三维轨迹与逐点风险</h2><p>左上角切换误差模型；悬停读取MD、最小SF和误差尺度。图例包含10口井和四级风险。所有轨迹点均保留。</p><iframe src="03_figures/trajectories_3d.html" height="850"></iframe></section>
<section><h2>交互SF曲线</h2><iframe src="03_figures/SF_profiles_interactive.html" height="690"></iframe></section>{sections}</main></html>"""
    (output / "index.html").write_text(dashboard, encoding="utf-8")
    create_report(output, summary, pair_rows, audit, source_audit, config)
    save_json(tables / "visualization_timing.json", dict(seconds=time.perf_counter() - start))
    print("Figures, interactive views and report saved:", output, flush=True)


def create_report(output, summary, pairs, audit, source, config):
    """Generate a report from effective settings; never assume historical formulae."""
    common, project = scan_sf_settings(config)
    count = len(summary)
    timing = json.loads((output / "02_comparison/evaluation_timing.json").read_text())
    batch = timing["batch"]
    verification = output / "02_comparison/verification.json"
    checked = json.loads(verification.read_text()) if verification.exists() else None
    sections = [
        f"# scenario_a：{count}模型防碰扫描结果",
        "## 输入与计算口径",
        f"**输入数据。** {source['well_count']}口井，{source['total_points']:,}个点，{source['well_pairs']}个井对；保留1 m网格和全部非整数端点，float64计算。SHA256：`{source['source_sha256']}`。原文件不修改，输入副本及有效配置见00_inputs。",
        f"**common通道。** `{common['method']}`，K={common['k_sigma']:g}，公式：`{sf_formula(common['method'])}`；标量分支：`{sf_formula(common['method'], True)}`。",
        f"**project通道。** `{project['sf_method']}`，K={project['k_sigma']:g}，公式：`{sf_formula(project['sf_method'])}`；标量分支：`{sf_formula(project['sf_method'], True)}`。",
        "**半径含义。** major_axis_sum中，协方差模型r=sqrt(lambda_max(C))，简化MWD取球形包络R，标量模型取单点经验边界。K只乘一次。两个通道默认相同，因此默认结果也相同；保留两通道用于选配公式对比，名称不表示模型版本。默认不扣井径、裕量或增加sigma_pa。",
        "**参数来源。** 本次复用示例参数进行数值敏感性验证，未以现场真实位置残差标定。每模型完整参数、有效参数和误差传播方式见01_models/<模型>/parameters.json；误差源协方差和测站文件单独保存。MD标量当前使用论文式(2-65)：M<500时2 m，否则2+0.003(M−500) m；源表原标注采用另一条规则，差异单独审计，不要求数值复现。",
        "**范围与判据。** 每个井对允许任意MD组合，取全部指定采样点对的最小值。水平AABB和最大误差尺度给出保守下界，只有不能改进任一逐点最小值时才剪枝。候选区间精算原采样点，未声称连续曲线全局极小。SF≤1红，≤1.5橙，≤2.5黄，其余蓝；中心距≤5 m独立判红。规划仍须SF>1.5及中心距>5 m。",
        "## 模型结果",
        "| 模型 | common最小SF | project最小SF | 风险井对 | 红点 | 橙点 | 最大半轴/边界m |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for r in summary:
        sections.append(
            f"| {r['model']} | {r['global_min_common_SF']:.9f} | {r['global_min_project_SF']:.9f} | {r['common_risk_pairs']} | {r['common_red_points']} | {r['common_orange_points']} | {r['max_error_radius_m']:.6f} |"
        )
    sections += [
        "## 运行时间",
        "**计时定义。** 评价总时间从内存轨迹开始，含误差构造、中心距、水平初筛、候选区间细化、匹配与分级汇总。不含Excel读取、导出、绘图和独立复核。初筛+细化不是总时间；以下为联合运行，不能把模型局部内核时间作为独立模型总耗时。",
        "| 阶段 | 秒 |",
        "|---|---:|",
    ]
    for label, key in [
        ("评价总时间", "evaluation_total_seconds"),
        ("水平初筛", "screening_seconds"),
        ("区间细化", "interval_refinement_seconds"),
        ("误差构造", "uncertainty_construction_seconds"),
        ("中心距", "center_distance_seconds"),
        ("汇总与控制", "aggregation_and_control_seconds"),
    ]:
        sections.append(f"| {label} | {batch[key]:.6f} |")
    sections.append(
        f"**文件操作。** 主数值过程及CSV导出合计{timing['main_numerical_and_csv_wall_seconds']:.6f} s。阶段明细见02_comparison/evaluation_timing.json。"
    )
    if timing["independent_models"]:
        sections += ["**独立模型计时。** 本次已逐模型重新评价并与联合结果核对，明细见计时JSON。"]
    else:
        sections += [
            "**独立模型计时。** 本次未另做逐模型独立计时；配置timing.independent_model_runs可启用。"
        ]
    sections += ["## 验证与产物"]
    if checked:
        sections.append(
            f"**独立核验。** 抽取首点、1/3处、中点和末点，对每一邻井的全部点穷举，共核验{checked['independent_SF_minima_checked']:,}个最小SF，common最大差{checked['max_common_SF_difference']:.3g}、project最大差{checked['max_project_SF_difference']:.3g}；{2 * count}个SF矩阵对称，逐点CSV与NPZ一致。详情及代入算例见verification.json/worked_examples.json。"
        )
    else:
        sections.append("**独立核验。** 尚未运行tests/test_scan_comparison.py。")
    sections.append(
        "**数据结构。** 00_inputs保存输入副本/轨迹/配置；01_models逐模型保存点结果、井对/单井结果、误差矩阵/半径、风险区间、对称SF矩阵及逐邻井NPZ匹配索引；02_comparison保存完整横向对比、源表差异与计时；03_figures保存静态图、含井名与风险图例的离线3D和交互SF曲线；index.html为浏览入口。没有保存全部笛卡尔积数十亿SF，输入与误差数据足以重算任意点对。模型差异不代表预测准确率。"
    )
    sections.append(
        "**复算命令。** 在项目目录运行，输出使用新目录：\n\n```bash\npython -B src/wellpath/workflows/uncertainty_comparison.py --config configs/experiments/scenario_A_all_models_default_SF.json --output results/new_scan\npython -B tests/test_scan_comparison.py --output results/new_scan\npython -B src/wellpath/reports/uncertainty_comparison.py --output results/new_scan\n```"
    )
    (output / "report.md").write_text("\n\n".join(sections) + "\n", encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    run(parser.parse_args().output)
