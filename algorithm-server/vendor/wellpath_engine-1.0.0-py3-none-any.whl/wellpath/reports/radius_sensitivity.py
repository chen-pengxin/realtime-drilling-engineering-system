"""Add effective-radius K sensitivity plots without regenerating scan results."""

import argparse
import csv
import hashlib
import json
import re
import shutil
import time
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.use("Agg")


plt.rcParams.update(
    {"font.family": "Arial Unicode MS", "axes.unicode_minus": False, "font.size": 10}
)
SECTION_START = "<!-- RADIUS_K_SECTION_START -->"
SECTION_END = "<!-- RADIUS_K_SECTION_END -->"
SCRIPT_START = "<!-- RADIUS_K_SCRIPT_START -->"
SCRIPT_END = "<!-- RADIUS_K_SCRIPT_END -->"

SECTION = (
    SECTION_START
    + """
<section id="radius-k-section"><h2>误差半径随 K 值变化</h2>
<p>本节的有效误差半径为 <b>r<sub>K</sub>(MD)=K×r(MD)</b>，单位为米。
基础半径 r 及模型参数保持不变；协方差模型的 r=√λ<sub>max</sub>(C)，对应放大后的 C<sub>K</sub>=K²C；
标量经验模型的 r 为其既有边界半径，乘 K 仅表示边界放大，不自动表示某一置信概率。
两井联合误差边界为 K(r₁+r₂)=r<sub>K,1</sub>+r<sub>K,2</sub>，SF=D/[K(r₁+r₂)]，只乘一次 K。</p>
<p>左图比较同一口井、同一模型在四个 K 下沿测深的变化；右图比较同一口井、同一测深点的十种模型。
下图比较本井组全部轨迹点的各模型最大有效半径。该最大值是汇总指标，不替代逐点半径参与 SF 计算。
上方“误差模型”和“K”选择与本节联动；着色方法不改变误差半径。</p>
<label>查看井 <select id="radius-well"></select></label>
<label>测深 MD（m） <input id="radius-md" type="number" min="0" step="1" style="width:120px;padding:8px"></label>
<label><button id="radius-end" type="button">定位井底</button></label>
<p id="radius-point-note" class="note"></p>
<div class="grid"><div id="radius-k-depth" class="smallplot"></div><div id="radius-k-point" class="smallplot"></div></div>
<div id="radius-k-maximum" style="height:560px"></div>
<p><a href="radius_K_comparison.html">单独打开本节曲线（离线交互）</a>　
<a href="radius_K_summary.csv">全部模型×井×K半径汇总CSV</a>　
<a href="radius_K_checkpoints.csv">指定测深点曲线CSV</a>　
<a href="radius_K_curves.md">公式、数据与使用说明</a></p>
<details><summary>静态图：十种模型各井最大半径随 K 变化</summary><img loading="lazy" src="figures/radius_K_maximum_by_model.png"></details>
<details><summary>静态图：默认 Rev.0 四个 K 的沿程半径对比</summary><img loading="lazy" src="figures/radius_K_Rev0_profiles.png"></details>
</section>
"""
    + SECTION_END
)

SCRIPT = (
    SCRIPT_START
    + r"""
<script>
const RADIUS_K=__PAYLOAD__;
const radiusWell=document.getElementById('radius-well'),radiusMD=document.getElementById('radius-md');
DATA.wells.forEach((w,i)=>radiusWell.add(new Option(w.name,i)));
radiusMD.value=DATA.wells[0].md.at(-1);
function updateRadiusK(){
 const wi=+radiusWell.value,w=DATA.wells[wi],m=model.value,k=+ks.value;
 let requested=+radiusMD.value;if(!Number.isFinite(requested))requested=w.md.at(-1);
 radiusMD.max=w.md.at(-1);radiusMD.min=w.md[0];
 const target=Math.max(w.md[0],Math.min(w.md.at(-1),requested));
 let pi=0;for(let i=1;i<w.md.length;i++)if(Math.abs(w.md[i]-target)<Math.abs(w.md[pi]-target))pi=i;
 const actual=w.md[pi],r=w.models[m].radius[pi],palette=['#2563eb','#0d9488','#f59e0b','#dc2626'];
 document.getElementById('radius-point-note').textContent=`${w.name}：请求MD=${requested.toFixed(3)} m，实际采样点MD=${actual.toFixed(6)} m（取最近现有点，不新增插值）。${DATA.labels[m]}基础半径=${r.toFixed(6)} m；K=${k}时有效半径=${(k*r).toFixed(6)} m。`;
 Plotly.react('radius-k-depth',DATA.k_values.map((value,i)=>({type:'scattergl',mode:'lines',name:'K='+value,x:w.md,y:w.models[m].radius.map(v=>value*v),line:{color:palette[i],width:value===k?3:1.6},hovertemplate:'MD=%{x:.3f} m<br>有效半径=%{y:.6f} m<extra>K='+value+'</extra>'})),{...base,title:{text:w.name+' · '+DATA.labels[m]+' · 四个K沿程对比'},xaxis:{title:{text:'测深 MD（m）'}},yaxis:{title:{text:'有效误差半径 K×r（m）'},rangemode:'tozero'},shapes:[{type:'line',xref:'x',yref:'paper',x0:actual,x1:actual,y0:0,y1:1,line:{color:'#64748b',dash:'dot',width:1}}]},buttons);
 const pointTraces=DATA.models.map(name=>({type:'scatter',mode:'lines+markers',name:DATA.labels[name],x:DATA.k_values,y:DATA.k_values.map(value=>value*w.models[name].radius[pi]),line:{width:name===m?3:1.5},marker:{size:7},hovertemplate:'K=%{x}<br>有效半径=%{y:.6f} m<extra>'+DATA.labels[name]+'</extra>'}));
 const klayout={...base,xaxis:{title:{text:'K（无量纲）'},tickvals:DATA.k_values},yaxis:{title:{text:'有效误差半径 K×r（m）'},rangemode:'tozero'},shapes:[{type:'line',xref:'x',yref:'paper',x0:k,x1:k,y0:0,y1:1,line:{color:'#64748b',dash:'dot',width:1}}],legend:{orientation:'h',y:-.25,font:{size:10}},margin:{l:75,r:30,t:65,b:160}};
 Plotly.react('radius-k-point',pointTraces,{...klayout,title:{text:w.name+' · MD='+actual.toFixed(3)+'m · 十模型随K变化'}},buttons);
 Plotly.react('radius-k-maximum',DATA.models.map(name=>({type:'scatter',mode:'lines+markers',name:DATA.labels[name],x:DATA.k_values,y:DATA.k_values.map(value=>value*RADIUS_K.group_maximum[name]),line:{width:name===m?3:1.5},hovertemplate:'K=%{x}<br>全井组最大有效半径=%{y:.6f} m<extra>'+DATA.labels[name]+'</extra>'})),{...klayout,title:{text:'本井组全部轨迹点 · 十模型最大有效半径随K变化'},yaxis:{title:{text:'max(K×r)（m）'},rangemode:'tozero'}},buttons);
}
radiusWell.addEventListener('change',()=>{radiusMD.value=DATA.wells[+radiusWell.value].md.at(-1);updateRadiusK();});
radiusMD.addEventListener('change',updateRadiusK);
document.getElementById('radius-end').addEventListener('click',()=>{radiusMD.value=DATA.wells[+radiusWell.value].md.at(-1);updateRadiusK();});
model.addEventListener('change',updateRadiusK);ks.addEventListener('change',updateRadiusK);updateRadiusK();
</script>
"""
    + SCRIPT_END
)


def write_csv(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def collect(data):
    summaries, checkpoints = [], []
    group_maximum = dict.fromkeys(data["models"], 0.0)
    for w in data["wells"]:
        md = np.asarray(w["md"], dtype=np.float64)
        for name in data["models"]:
            radius = np.asarray(w["models"][name]["radius"], dtype=np.float64)
            if len(radius) != len(md) or not np.all(np.isfinite(radius)) or np.any(radius < 0):
                raise ValueError(f"Invalid radius: {w['name']}, {name}")
            imax = int(np.argmax(radius))
            group_maximum[name] = max(group_maximum[name], float(radius[imax]))
            points = [
                ("wellhead", md[0], 0),
                ("well_end", md[-1], len(md) - 1),
                ("maximum_radius", md[imax], imax),
            ]
            points += [
                ("fixed_MD", float(x), int(np.argmin(np.abs(md - x))))
                for x in range(500, int(md[-1]) + 1, 500)
                if x >= md[0]
            ]
            for k in data["k_values"]:
                summaries.append(
                    dict(
                        group=data["group"],
                        model=name,
                        label=data["labels"][name],
                        well=w["name"],
                        K=k,
                        point_count=len(md),
                        base_minimum_radius_m=float(radius.min()),
                        base_mean_radius_m=float(radius.mean()),
                        base_maximum_radius_m=float(radius[imax]),
                        maximum_at_MD_m=float(md[imax]),
                        base_end_radius_m=float(radius[-1]),
                        effective_minimum_radius_m=float(k * radius.min()),
                        effective_mean_radius_m=float(k * radius.mean()),
                        effective_maximum_radius_m=float(k * radius[imax]),
                        effective_end_radius_m=float(k * radius[-1]),
                    )
                )
                for kind, requested, i in points:
                    checkpoints.append(
                        dict(
                            group=data["group"],
                            model=name,
                            label=data["labels"][name],
                            well=w["name"],
                            checkpoint=kind,
                            requested_MD_m=float(requested),
                            actual_MD_m=float(md[i]),
                            sample_index=i,
                            K=k,
                            base_radius_m=float(radius[i]),
                            effective_radius_m=float(k * radius[i]),
                        )
                    )
    return summaries, checkpoints, {"group_maximum": group_maximum}


def augment_html(document, payload):
    document = re.sub(
        re.escape(SECTION_START) + r".*?" + re.escape(SECTION_END), "", document, flags=re.S
    )
    document = re.sub(
        re.escape(SCRIPT_START) + r".*?" + re.escape(SCRIPT_END), "", document, flags=re.S
    )
    anchor = "<section><h2>全部井对（点击列名排序）</h2>"
    if anchor not in document:
        raise ValueError("Dashboard section anchor missing")
    document = document.replace(anchor, SECTION + "\n" + anchor, 1)
    script = SCRIPT.replace(
        "__PAYLOAD__", json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    )
    return document.replace("</body>", script + "\n</body>", 1)


def standalone(data, payload, plotly_js):
    # Contains only radii and MD, preserving every existing point; no SF scan rerun.
    reduced = {key: data[key] for key in ["models", "labels", "k_values"]}
    reduced["wells"] = [
        dict(
            name=w["name"],
            md=w["md"],
            models={m: {"radius": w["models"][m]["radius"]} for m in data["models"]},
        )
        for w in data["wells"]
    ]
    text = """<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>__N__口井 · 误差半径与K</title>
<style>body{font-family:Arial,"PingFang SC",sans-serif;background:#eef2f7;color:#172033;margin:0}main{max-width:1500px;margin:auto;padding:24px}section{background:white;border-radius:10px;padding:24px;margin:20px 0}p{line-height:1.8}select,input,button{font-size:15px;padding:8px;margin:6px}a{color:#1d4ed8}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.smallplot{height:600px}img{width:100%}summary{cursor:pointer}.note{color:#475569}@media(max-width:950px){.grid{display:block}}</style>
<script>__PLOTLY__</script></head><body><main><h1>__N__口井组 · 误差半径随K变化</h1>
<p><a href="index.html#radius-k-section">返回完整防碰报告</a>　<a href="../index.html">三个井组总览</a></p>
<label>误差模型 <select id="model"></select></label><label>K <select id="k"></select></label>
__SECTION__</main><script>
const DATA=__DATA__,model=document.getElementById('model'),ks=document.getElementById('k');
DATA.models.forEach(m=>model.add(new Option(DATA.labels[m],m)));model.value='iscwsa_rev0';DATA.k_values.forEach(k=>ks.add(new Option(k,k)));
const base={font:{family:'Arial, PingFang SC'},margin:{l:75,r:30,t:65,b:85},legend:{orientation:'h',y:-.18},uirevision:'preserve'};
const buttons={responsive:true,displaylogo:false,toImageButtonOptions:{format:'png',scale:2}};
</script>__SCRIPT__</body></html>"""
    for key, value in {
        "__N__": str(len(data["wells"])),
        "__PLOTLY__": plotly_js,
        "__SECTION__": SECTION.replace(
            '<a href="radius_K_comparison.html">单独打开本节曲线（离线交互）</a>　', ""
        ),
        "__DATA__": json.dumps(reduced, ensure_ascii=False, separators=(",", ":")).replace(
            "</", "<\\/"
        ),
        "__SCRIPT__": SCRIPT.replace("__PAYLOAD__", json.dumps(payload, ensure_ascii=False)),
    }.items():
        text = text.replace(key, value)
    return text


def static_figures(folder, data):
    out = folder / "figures"
    fig, axes = plt.subplots(2, 5, figsize=(24, 10), layout="constrained")
    for ax, name in zip(axes.flat, data["models"]):
        for w in data["wells"]:
            radius = max(w["models"][name]["radius"])
            ax.plot(
                data["k_values"], np.asarray(data["k_values"]) * radius, ".-", lw=1, label=w["name"]
            )
        ax.set(
            title=data["labels"][name],
            xlabel="K（无量纲）",
            ylabel="各井最大有效半径（m）",
            xticks=data["k_values"],
        )
        ax.set_ylim(bottom=0)
        ax.grid(alpha=0.2)
    handles, labels = axes.flat[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside lower center", ncol=10)
    fig.suptitle(
        f"{len(data['wells'])}口井组 · 十模型各井最大有效半径随K变化（r_K=K×r）", fontsize=16
    )
    fig.savefig(out / "radius_K_maximum_by_model.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    fig, axes = plt.subplots(2, 2, figsize=(17, 11), layout="constrained")
    for ax, k in zip(axes.flat, data["k_values"]):
        for w in data["wells"]:
            ax.plot(
                w["md"], np.asarray(w["models"]["iscwsa_rev0"]["radius"]) * k, lw=1, label=w["name"]
            )
        ax.set(title=f"K={k:g}", xlabel="测深MD（m）", ylabel="有效误差半径 K×r（m）")
        ax.set_ylim(bottom=0)
        ax.grid(alpha=0.2)
    upper = (
        max(max(w["models"]["iscwsa_rev0"]["radius"]) for w in data["wells"])
        * max(data["k_values"])
        * 1.04
    )
    for ax in axes.flat:
        ax.set_ylim(0, upper)
    handles, labels = axes.flat[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside lower center", ncol=10)
    fig.suptitle(
        f"{len(data['wells'])}口井组 · ISCWSA Rev.0 四个K沿程对比（统一纵轴）", fontsize=16
    )
    fig.savefig(out / "radius_K_Rev0_profiles.png", dpi=150, bbox_inches="tight")
    plt.close(fig)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(output):
    from plotly.offline import get_plotlyjs

    output = Path(output)
    start = time.perf_counter()
    reports = []
    for folder in sorted(output.glob("group_*")):
        data = json.loads((folder / "visualization_data.json").read_text())
        before = {
            name: sha(folder / name)
            for name in [
                "visualization_data.json",
                "all_model_K_pairs.csv",
                "model_K_summary.csv",
                "timing.json",
            ]
        }
        summaries, checkpoints, payload = collect(data)
        write_csv(folder / "radius_K_summary.csv", summaries)
        write_csv(folder / "radius_K_checkpoints.csv", checkpoints)
        static_figures(folder, data)
        (folder / "index.html").write_text(
            augment_html((folder / "index.html").read_text(), payload)
        )
        (folder / "radius_K_comparison.html").write_text(standalone(data, payload, get_plotlyjs()))
        notes = f"""# {len(data["wells"])}口井组：误差半径随K变化

## 1. 基础半径与有效半径

基础半径r(MD)取自当前十种模型的逐点输出。协方差模型为r=√λmax(C)，C单位m²；标量模型为既有经验半径，单位m。基础半径及模型参数不因K变化。有效半径r_K(MD)=K×r(MD)。协方差椭球按K放大时对应C_K=K²C；本次展示不修改原始协方差。

K=1、2、2.5、3时，同一轨迹点有效半径依次是基础半径的1、2、2.5、3倍。基础半径为零的点始终为零。对经验边界，K只作几何放大，不宣称为某个统计置信概率；对高斯三维误差，K也不能直接等同于一维正态置信概率。

## 2. 与分离系数一致的计算

两井点的联合误差边界R_K=K(r₁+r₂)=r_K,1+r_K,2，SF=D/R_K。这里的K就是项目配置的k_sigma，不额外重复乘K，不改变中心距D。所有既有防碰结果、轨迹与模型参数均保留，无需重新扫描。

## 3. 三类交互曲线

沿程对比：左图选择一口井和一个模型，同时显示四个K的完整采样点半径，横轴MD、纵轴Kr。

固定测深对比：右图选择一口井和请求MD，取最近实际采样点，十种模型同时显示随K变化的曲线，横轴K、纵轴Kr；显示实际MD，不对半径做额外插值。默认定位井1井底。

全组最大值对比：下图各模型取全井组所有采样点的最大基础半径，再按K放大。它是汇总展示指标，逐点SF仍使用各点自身的半径。

## 4. 数据与导出

radius_K_summary.csv：每个模型、每口井、每个K的最小/均值/最大/井底有效半径，以及基础半径和最大值所在MD。均值是全部实际采样点的算术均值，不是按测深积分加权均值。

radius_K_checkpoints.csv：井口、井底、最大半径点及井深范围内每500m参考点的四K半径。参考MD取最近实际点，保存请求MD、实际MD及0起始采样点索引，允许不同类别落在同一点。

全量基础半径仍保存在models/模型名/uncertainty_points.csv.gz的radius_m字段；全量任意正K有效半径按radius_m×K得到。当前页面保留原有全部采样点，不抽稀。

静态图figures/radius_K_maximum_by_model.png为十模型各井最大值随K对比；figures/radius_K_Rev0_profiles.png为默认Rev.0四K沿程对比，四子图统一纵轴。两图及独立HTML可从完整报告查看。

## 5. 复算与计时

在项目目录运行：python src/wellpath/reports/radius_sensitivity.py --output results/cluster_wellheads_spacing8m_20261113。

本次只做半径的K缩放、统计与绘图。补充耗时单独写入radius_K_addition.json，不计入原有防碰评价时间；数值扫描结果不重算。
"""
        (folder / "radius_K_curves.md").write_text(notes)
        report = folder / "report.md"
        existing = re.sub(
            r"\n<!-- RADIUS_K_NOTES_START -->.*?<!-- RADIUS_K_NOTES_END -->",
            "",
            report.read_text(),
            flags=re.S,
        )
        report.write_text(
            existing
            + "\n<!-- RADIUS_K_NOTES_START -->\n\n## 补充：误差半径随K变化\n\n有效半径r_K=K×r，联合误差边界K(r₁+r₂)，SF中K只使用一次。新增四K沿测深对比、固定采样点十模型K曲线及全组最大值K曲线，详见[曲线说明](radius_K_curves.md)和[交互页面](radius_K_comparison.html)。原评价数值与计时保留。\n<!-- RADIUS_K_NOTES_END -->\n"
        )
        after = {name: sha(folder / name) for name in before}
        assert before == after, "Existing numerical scan outputs changed"
        reports.append(
            dict(
                group=data["group"],
                summary_rows=len(summaries),
                checkpoint_rows=len(checkpoints),
                points=sum(len(w["md"]) for w in data["wells"]),
                protected_hashes=after,
                existing_numerical_results_unchanged=True,
            )
        )
        print(data["group"], "radius K curves complete", flush=True)
    root_index = output / "index.html"
    text = re.sub(
        r"<!-- RADIUS_K_ROOT_START -->.*?<!-- RADIUS_K_ROOT_END -->",
        "",
        root_index.read_text(),
        flags=re.S,
    )
    links = "　".join(
        f'<a href="group_{n}/radius_K_comparison.html">{n}口井组半径曲线</a>' for n in [15, 16, 20]
    )
    block = (
        "<!-- RADIUS_K_ROOT_START --><section><h2>补充：误差半径随K变化</h2><p>有效半径r_K=K×r；包含四K沿测深对比、固定测深点十模型K曲线、全井组最大半径K曲线及CSV下载。</p><p>"
        + links
        + "</p></section><!-- RADIUS_K_ROOT_END -->"
    )
    text = text.replace("</html>", block + "</html>")
    root_index.write_text(text)
    snapshot = output / "reproduction" / Path(__file__).name
    if Path(__file__).resolve() != snapshot.resolve():
        shutil.copy2(__file__, snapshot)
    record = dict(
        groups=reports,
        wall_seconds=time.perf_counter() - start,
        included_in_original_scan_timing=False,
        formula="effective_radius_m = K * base_radius_m",
    )
    (output / "radius_K_addition.json").write_text(json.dumps(record, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    run(parser.parse_args().output)
