"""Reports for the full segment-count/algorithm matrix, including infeasibility."""

import csv
import hashlib
import html
import json
import time
from pathlib import Path

import numpy as np
import plotly.graph_objects as go
from plotly.offline import get_plotlyjs
from plotly.subplots import make_subplots

from wellpath.anticollision.uncertainty import path_at
from wellpath.planning.geometry_problem import WellControlProblem
from wellpath.reports.algorithm_explanations import algorithm_explanations_html
from wellpath.reports.scenario_replanning import COLORS, div, dumps, table
from wellpath.workflows.scenario_replanning import save_csv, save_json

STYLE = """body{font:15px/1.7 Arial,"PingFang SC",sans-serif;background:#f2f5f9;color:#17243b;margin:0}main{max-width:1540px;margin:auto;padding:25px}section,header{background:white;border:1px solid #e1e7ef;border-radius:12px;padding:22px;margin:18px 0}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:9px;border-bottom:1px solid #ddd;text-align:left;white-space:nowrap}th{background:#1b3552;color:white}.scroll{overflow:auto}pre{background:#f4f6f9;padding:16px;overflow:auto;max-height:480px}a{color:#1762a3}.note{background:#fff4df;padding:14px;border-left:4px solid #e9a525}.controls{display:flex;flex-wrap:wrap;gap:14px;padding:14px;background:#eef3f8}select,button{padding:7px}h1{font-size:27px}h2{font-size:21px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:1000px){.grid{display:block}main{padding:8px}}"""


def page(title, body, script=""):
    return f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{html.escape(title)}</title><style>{STYLE}</style><script>{get_plotlyjs()}</script></head><body><main>{body}</main><script>{script}</script></body></html>'


def export_initial_failure(folder, data, s, problem, initial, setup_seconds, begin):
    status = initial["status"]
    reports = []
    for algorithm in s["algorithms"]:
        r = dict(
            scenario=data["scene"],
            algorithm=algorithm,
            n_segments=problem.n,
            free_control_variables=problem.dim,
            trajectory_mode=problem.trajectory_mode,
            segment_types=problem.segment_types,
            arc_segment_model=problem.arc_segment_model,
            geometry_metadata=problem.geometry_metadata,
            status=status,
            solver_executed=False,
            solver_success=None,
            final_check=None,
            final_total_length_m=None,
            full_well_final_MD_m=None,
            selected_candidate=None,
            optimization_seconds=0.0,
            validation_seconds=0.0,
            dense_final_verification_seconds=0.0,
            export_seconds=0.0,
            shared_preprocessing_seconds=setup_seconds,
            feasibility_construction_seconds=initial["elapsed_seconds"],
            method_wall_seconds=0.0,
            complete_flow_seconds=setup_seconds + initial["elapsed_seconds"],
            uncertainty_model=s["uncertainty_model"],
            effective_rev0_parameters=data["parameters"],
            k_sigma=s["k_sigma"],
            sf_method=s["sf_method"],
            constraints=problem.cfg,
            initial_status=status,
            necessary_condition_certificate=initial["necessary_condition_certificate"],
            message="Necessary condition proves infeasibility; optimizer not launched."
            if initial["necessary_condition_certificate"]["proven_infeasible"]
            else "No certified common feasible start found within the configured search; optimizer not launched. This is not proof of infeasibility.",
        )
        method_folder = folder / algorithm
        method_folder.mkdir(exist_ok=True)
        save_json(method_folder / "result.json", r)
        reports.append(r)
    save_json(folder / "algorithm_results.json", reports)
    save_csv(
        folder / "algorithm_comparison.csv",
        [
            "algorithm",
            "status",
            "solver_executed",
            "shared_initial_seconds",
            "complete_flow_seconds",
        ],
        (
            [r["algorithm"], status, False, initial["elapsed_seconds"], r["complete_flow_seconds"]]
            for r in reports
        ),
    )
    f3 = go.Figure()
    xy = go.Figure()
    vertical = go.Figure()
    start = np.array(data["audit"]["tie_in"]["position_m"])
    target = np.array(data["audit"]["common_target"]["position_m"])
    direction = (target - start)[:2]
    direction /= np.linalg.norm(direction)
    series = [
        (data["design"]["井1"]["positions"], "原设计", "#2563eb", "dash"),
        (data["actual"]["井1"]["positions"], "井1实钻", "#111827", "solid"),
    ]
    series += [
        (n["raw"]["positions"], n["raw"]["name"] + "实钻", "#a2acba", "solid")
        for n in data["neighbors"]
    ]
    candidate = initial.get("best_geometry_candidate")
    if candidate:
        geometry = WellControlProblem(problem.cfg)
        z = np.array(candidate["normalized_controls"])
        e = geometry.evaluate(z)
        ends = np.cumsum(e["physical"][:, 2])
        query = np.unique(np.r_[np.arange(0, ends[-1], 1.0), ends, 0.0])
        p, inc, azi = path_at(geometry, e, query)
        save_csv(
            folder / "unverified_geometry_candidate.csv",
            ["MD_m", "N_m", "E_m", "D_m", "inclination_deg", "azimuth_deg"],
            ([m + problem.start_md, *point, i, a] for m, point, i, a in zip(query, p, inc, azi)),
        )
        series.append((p, "未通过的几何候选（不是规划结果）", "#dc2626", "dot"))
    for p, name, color, dash in series:
        common = dict(name=name, line=dict(color=color, dash=dash), mode="lines")
        f3.add_trace(go.Scatter3d(x=p[:, 1], y=p[:, 0], z=p[:, 2], **common))
        xy.add_trace(go.Scatter(x=p[:, 1], y=p[:, 0], **common))
        vertical.add_trace(go.Scatter(x=(p[:, :2] - start[:2]) @ direction, y=p[:, 2], **common))
    f3.add_trace(
        go.Scatter3d(
            x=[target[1]],
            y=[target[0]],
            z=[target[2]],
            mode="markers",
            name="共同靶点",
            marker=dict(size=7, color="red"),
        )
    )
    xy.add_trace(go.Scatter(x=[target[1]], y=[target[0]], mode="markers", name="共同靶点"))
    vertical.add_trace(
        go.Scatter(
            x=[(target[:2] - start[:2]) @ direction], y=[target[2]], mode="markers", name="共同靶点"
        )
    )
    f3.update_layout(
        height=680,
        scene=dict(
            xaxis_title="E / m",
            yaxis_title="N / m",
            zaxis=dict(title="D / m", autorange="reversed"),
            aspectmode="data",
        ),
    )
    xy.update_layout(xaxis_title="E / m", yaxis=dict(title="N / m", scaleanchor="x"), height=520)
    vertical.update_layout(
        xaxis_title="沿起点→靶点剖面投影 / m",
        yaxis=dict(title="D / m", autorange="reversed"),
        height=520,
    )
    label = (
        "约束下已证明不可行"
        if initial["necessary_condition_certificate"]["proven_infeasible"]
        else "未找到通过验收的公共初值"
    )
    rows = [
        [r["algorithm"], label, "未启动", "—", "—", f"{r['complete_flow_seconds']:.6f}"]
        for r in reports
    ]
    body = f"""<header><h1>场景{data["scene"]} · {problem.n}段 · {"—".join("圆弧" if t == "arc" else "直线" for t in problem.segment_types)}</h1><p class="note">{label}。四算法均记录为未启动，不填写虚构的收敛曲线、可行进尺或防碰验收结果。完整流程时间为实际输入准备与初值检查时间；优化时间为0。</p></header>
<section><h2>四算法状态</h2>{table(["算法", "问题状态", "求解器", "可行进尺", "求解器时间", "流程时间s"], rows)}</section>
<section><h2>不可行依据与初值搜索</h2><p>1段为圆弧，2段为圆弧—直线。一条圆弧及其末端切线直线共面，必须同时满足目标位置与末端姿态。</p><pre>{html.escape(json.dumps(initial, ensure_ascii=False, indent=2))}</pre></section>
<section><h2>轨迹与靶点</h2>{div(f3, "trajectory3d")}<div class="grid">{div(xy, "horizontal")}{div(vertical, "vertical")}</div></section>
{algorithm_explanations_html(s)}<section><h2>全部配置</h2><pre>{html.escape(json.dumps(s, ensure_ascii=False, indent=2))}</pre><h2>实际约束</h2><pre>{html.escape(json.dumps(problem.cfg, ensure_ascii=False, indent=2))}</pre></section>"""
    if problem.arc_segment_model == "constant_toolface":
        body = body.replace(
            "1段为圆弧，2段为圆弧—直线。一条圆弧及其末端切线直线共面，必须同时满足目标位置与末端姿态。",
            "本次为恒曲率—恒工具面模型，通常不共面。已禁用旧平面圆弧的共面判据；下方只展示适用的必要条件与实际搜索结果。",
        )
    elif problem.trajectory_mode == "arc":
        body = body.replace(
            "1段为圆弧，2段为圆弧—直线。一条圆弧及其末端切线直线共面，必须同时满足目标位置与末端姿态。",
            "本次为全部圆弧布局，各段均为平面最小曲率圆弧；不同段可位于不同平面。仅有一个圆弧时检查共面必要条件，多圆弧不套用该判据。全部情况均检查总长度必要条件。",
        )
    (folder / f"场景{data['scene']}_再规划对比.html").write_text(
        page(f"场景{data['scene']} {problem.n}段 不可行性与初值记录", body)
    )
    for source in data["audit"]["sources"]:
        assert hashlib.sha256(Path(source["path"]).read_bytes()).hexdigest() == source["sha256"]
    save_json(
        folder / "scene_timing.json",
        dict(
            scenario_wall_seconds=time.perf_counter() - begin,
            preprocessing_seconds=setup_seconds,
            shared_initial_seconds=initial["elapsed_seconds"],
            algorithms_wall_seconds=0.0,
            source_files_unchanged=True,
            status=status,
        ),
    )
    return reports


def status_label(r):
    if not r.get("solver_executed", True):
        return (
            "约束下已证明不可行；未启动"
            if r["status"] == "proven_infeasible_under_configured_constraints"
            else "初值搜索未成功；未启动"
        )
    if (
        r.get("selected_after_dense_fallback_to_initial")
        or r.get("selected_candidate") == "verified_initial_point"
    ):
        return "采用公共可行初值"
    return "成功终止；采用可行结果" if r["solver_success"] else "未收敛；采用保留可行迭代"


def metric_rows(reports):
    rows = []
    for r in reports:
        c = r.get("final_check") or {}
        n = r["n_segments"]
        executed = r.get("solver_executed", True)
        row = dict(
            scenario=r["scenario"],
            n_segments=n,
            segment_types="-".join(r["segment_types"]),
            arc_segment_model=r.get("arc_segment_model", "minimum_curvature"),
            trajectory_mode=r.get("trajectory_mode", "arc-straight"),
            decision_variables=r.get(
                "free_control_variables",
                3 * r["segment_types"].count("arc") + r["segment_types"].count("straight"),
            ),
            algorithm=r["algorithm"],
            status=status_label(r),
            feasible=bool(c.get("feasible", False)),
            solver_executed=executed,
            solver_success=r.get("solver_success"),
            selected_source=r.get("selected_candidate"),
            new_length_m=r.get("final_total_length_m"),
            final_MD_m=r.get("full_well_final_MD_m"),
            position_error_m=c.get("position_error_m"),
            inclination_error_deg=c.get("inclination_error_deg"),
            azimuth_error_deg=c.get("azimuth_error_deg"),
            max_DLS_deg_per_30m=c.get("maximum_dls_deg_per_30m"),
            min_SF=c.get("minimum_sf"),
            centerline_lower_bound_m=c.get("minimum_centerline_distance_m"),
            complete_flow_s=r["complete_flow_seconds"],
            shared_preprocessing_s=r["shared_preprocessing_seconds"],
            initial_construction_s=r["feasibility_construction_seconds"],
            solver_s=r["optimization_seconds"],
            solver_validation_s=r["validation_seconds"],
            final_1m_scan_s=r["dense_final_verification_seconds"],
            export_s=r["export_seconds"],
        )
        for phase, label in [
            ("optimization_module_profile", "optimizer"),
            ("final_verification_module_profile", "final_scan"),
        ]:
            seconds = r.get(phase, {}).get("seconds", {})
            calls = r.get(phase, {}).get("calls", {})
            row[f"{label}_trajectory_sampling_s"] = seconds.get("final_trajectory_sampling", 0.0)
            for k in [
                "trajectory_and_target_constraints",
                "rev0_propagation_and_radius",
                "sf_screening",
                "sf_refinement",
                "sf_control",
                "centerline_screening",
                "centerline_refinement",
                "constraint_assembly",
            ]:
                source_key = "final_" + k if label == "final_scan" and k.startswith("sf_") else k
                row[f"{label}_{k}_s"] = seconds.get(source_key, 0.0)
                row[f"{label}_{k}_calls"] = calls.get(source_key, 0)
        rows.append(row)
    return rows


def csv_dicts(path, rows):
    if rows:
        with Path(path).open("w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)


def read_track(path):
    with Path(path).open(encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    return dict(
        positions=np.array([[float(r[k]) for k in ("N_m", "E_m", "D_m")] for r in rows]),
        md=np.array([float(r["MD_m"]) for r in rows]),
        sf=np.array([float(r.get("minimum_SF", "nan")) for r in rows]),
    )


def scene_comparison(out, scene, config, reports, rows):
    from wellpath.data_io.scenarios import TARGET

    folder = out / f"scene_{scene}"
    folder.mkdir(exist_ok=True)
    figures = folder / "figures"
    figures.mkdir(exist_ok=True)
    folders = {n: out / f"segments_{n:02d}" / f"scene_{scene}" for n in config["segment_counts"]}
    audit = json.loads(
        next(
            d / "input_audit.json" for d in folders.values() if (d / "input_audit.json").exists()
        ).read_text()
    )
    start = np.array(audit["tie_in"]["position_m"])
    target = np.array(TARGET["position_m"])
    direction = (target - start)[:2]
    direction /= np.linalg.norm(direction)
    reference = next(d for d in folders.values() if (d / "input_audit.json").exists())
    series = []
    for name, color, dash, sub in [
        ("井1 原设计", "#2563eb", "dash", "design_input"),
        ("井1 已钻历史", "#111827", "solid", "actual_input"),
    ]:
        track = read_track(reference / sub / "well_1.csv")
        series.append(
            dict(
                **track,
                name=name,
                color=color,
                dash=dash,
                base="original" if sub == "design_input" else "history",
                n=0,
                m="",
            )
        )
    for j in range(2, 11):
        track = read_track(reference / "actual_input" / f"井{j}.csv")
        series.append(
            dict(
                **track,
                name=f"井{j} 实钻",
                color="#b4bdcb",
                dash="solid",
                base="neighbors",
                n=0,
                m="",
            )
        )
    dashes = {1: "solid", 2: "dot", 3: "dash", 4: "longdash", 5: "dashdot"}
    tracks = {}
    for r in reports:
        if r.get("final_check") and r["final_check"]["feasible"]:
            n = r["n_segments"]
            m = r["algorithm"]
            track = read_track(folders[n] / m / "selected_trajectory.csv")
            tracks[n, m] = track
            series.append(
                dict(
                    **track, name=f"{n}段 · {m}", color=COLORS[m], dash=dashes[n], base="", n=n, m=m
                )
            )
    f3 = go.Figure()
    xy = go.Figure()
    vertical = go.Figure()
    sf = go.Figure()
    for s in series:
        p = s["positions"]
        custom = np.column_stack([s["md"], p])
        meta = {k: s[k] for k in ("n", "m", "base")}
        common = dict(
            name=s["name"],
            mode="lines",
            line=dict(
                color=s["color"], dash=s["dash"], width=1.4 if s["base"] == "neighbors" else 3
            ),
            meta=meta,
            legendgroup=s["name"],
            customdata=custom,
            hovertemplate="MD=%{customdata[0]:.3f}<br>N=%{customdata[1]:.3f}<br>E=%{customdata[2]:.3f}<br>D=%{customdata[3]:.3f}<extra>%{fullData.name}</extra>",
        )
        f3.add_trace(go.Scatter3d(x=p[:, 1], y=p[:, 0], z=p[:, 2], **common))
        xy.add_trace(go.Scatter(x=p[:, 1], y=p[:, 0], **common))
        vertical.add_trace(go.Scatter(x=(p[:, :2] - start[:2]) @ direction, y=p[:, 2], **common))
        if s["n"]:
            sf.add_trace(
                go.Scatter(
                    x=s["md"],
                    y=s["sf"],
                    **{k: v for k, v in common.items() if k not in ("customdata", "hovertemplate")},
                )
            )
    for p, label, color in [(start, "纠偏点", "#111827"), (target, "共同靶点", "#dc2626")]:
        f3.add_trace(
            go.Scatter3d(
                x=[p[1]],
                y=[p[0]],
                z=[p[2]],
                mode="markers",
                name=label,
                marker=dict(size=7, color=color),
            )
        )
        xy.add_trace(
            go.Scatter(
                x=[p[1]], y=[p[0]], mode="markers", name=label, marker=dict(size=9, color=color)
            )
        )
        vertical.add_trace(
            go.Scatter(
                x=[(p[:2] - start[:2]) @ direction],
                y=[p[2]],
                mode="markers",
                name=label,
                marker=dict(size=9, color=color),
            )
        )
    f3.update_layout(
        title="所有通过验收的采用轨迹｜颜色区分算法，线型区分段数",
        height=730,
        scene=dict(
            xaxis_title="东 E / m",
            yaxis_title="北 N / m",
            zaxis=dict(title="垂深 D / m", autorange="reversed"),
            aspectmode="data",
        ),
    )
    xy.update_layout(
        title="水平投影",
        height=590,
        xaxis_title="东 E / m",
        yaxis=dict(title="北 N / m", scaleanchor="x"),
    )
    vertical.update_layout(
        title="沿起点→靶点方向的垂直剖面",
        height=590,
        xaxis_title="剖面投影距离 / m",
        yaxis=dict(title="垂深 D / m", autorange="reversed"),
    )
    sf.update_layout(
        title="各采用轨迹逐点最小SF", height=470, xaxis_title="全井 MD / m", yaxis_title="最小SF"
    )
    sf.add_hline(y=config["sf_threshold"], line_dash="dash", line_color="red")
    metrics = make_subplots(
        rows=2,
        cols=2,
        subplot_titles=[
            "认证采用进尺（无可行解留空）",
            "完整流程时间（未启动仅含输入和初值检查）",
            "最小SF",
            "连续中心距下界",
        ],
    )
    time_modules = go.Figure()
    for method in config["algorithms"]:
        selected = [
            next((r for r in rows if r["n_segments"] == n and r["algorithm"] == method), None)
            for n in config["segment_counts"]
        ]
        for row, col, key in [
            (1, 1, "new_length_m"),
            (1, 2, "complete_flow_s"),
            (2, 1, "min_SF"),
            (2, 2, "centerline_lower_bound_m"),
        ]:
            metrics.add_trace(
                go.Scatter(
                    x=config["segment_counts"],
                    y=[r[key] if r else None for r in selected],
                    name=method,
                    mode="lines+markers",
                    connectgaps=False,
                    legendgroup=method,
                    showlegend=(row, col) == (1, 1),
                    line=dict(color=COLORS[method]),
                ),
                row=row,
                col=col,
            )
    metrics.update_layout(height=750)
    metrics.update_xaxes(title_text="段数", dtick=1)
    metrics.update_yaxes(title_text="m", row=1, col=1)
    metrics.update_yaxes(title_text="秒", row=1, col=2)
    center_values = [
        r["centerline_lower_bound_m"] for r in rows if r["centerline_lower_bound_m"] is not None
    ]
    if center_values:
        pad = max(0.01, 0.08 * (max(center_values) - min(center_values)))
        metrics.update_yaxes(
            range=[min(center_values) - pad, max(center_values) + pad],
            tickformat=".3f",
            title_text="m",
            row=2,
            col=2,
        )
    for label, key, color in [
        ("输入/模型", "shared_preprocessing_s", "#94a3b8"),
        ("公共初值", "initial_construction_s", "#a78bfa"),
        ("优化器", "solver_s", "#0d9488"),
        ("内部验收", "solver_validation_s", "#38bdf8"),
        ("最终1m复评", "final_1m_scan_s", "#f59e0b"),
        ("导出", "export_s", "#fb7185"),
    ]:
        time_modules.add_trace(
            go.Bar(
                x=[f"{r['n_segments']}段 {r['algorithm']}" for r in rows],
                y=[r[key] for r in rows],
                name=label,
                marker_color=color,
            )
        )
    keys = [
        "shared_preprocessing_s",
        "initial_construction_s",
        "solver_s",
        "solver_validation_s",
        "final_1m_scan_s",
        "export_s",
    ]
    time_modules.add_trace(
        go.Bar(
            x=[f"{r['n_segments']}段 {r['algorithm']}" for r in rows],
            y=[max(0.0, r["complete_flow_s"] - sum(r[k] for k in keys)) for r in rows],
            name="调度/其他开销",
        )
    )
    time_modules.update_layout(
        title="各组合完整流程耗时拆解",
        height=550,
        barmode="stack",
        yaxis_title="秒",
        xaxis_tickangle=-35,
    )
    heat = []
    for method in config["algorithms"]:
        line = []
        for n in config["segment_counts"]:
            r = next(
                (r for r in reports if r["algorithm"] == method and r["n_segments"] == n), None
            )
            if r is None:
                code = None
            elif not r.get("solver_executed", True):
                code = 0 if r["status"] == "proven_infeasible_under_configured_constraints" else 1
            elif (
                r.get("selected_after_dense_fallback_to_initial")
                or r.get("selected_candidate") == "verified_initial_point"
            ):
                code = 2
            else:
                code = 4 if r["solver_success"] else 3
            line.append(code)
        heat.append(line)
    state = go.Figure(
        go.Heatmap(
            z=heat,
            x=config["segment_counts"],
            y=config["algorithms"],
            zmin=0,
            zmax=4,
            colorscale=[
                [0, "#dc2626"],
                [0.1249, "#dc2626"],
                [0.125, "#f97316"],
                [0.3749, "#f97316"],
                [0.375, "#94a3b8"],
                [0.6249, "#94a3b8"],
                [0.625, "#eab308"],
                [0.8749, "#eab308"],
                [0.875, "#10b981"],
                [1, "#10b981"],
            ],
            colorbar=dict(
                tickvals=list(range(5)),
                ticktext=[
                    "已证明不可行",
                    "初值搜索未成功",
                    "采用公共初值",
                    "未收敛，保留可行解",
                    "成功终止并采用解",
                ],
            ),
            text=[
                [
                    {
                        0: "证明不可行",
                        1: "未找到初值",
                        2: "公共初值",
                        3: "可行/未收敛",
                        4: "可行/成功",
                    }.get(x, "未计算")
                    for x in row
                ]
                for row in heat
            ],
            texttemplate="%{text}",
            hovertemplate="%{y} / %{x}段：%{text}<extra></extra>",
        )
    )
    state.update_layout(
        title="问题可行性、求解器终止与采用来源分别记录",
        height=380,
        xaxis=dict(title="段数", dtick=1),
    )
    convergence_time = make_subplots(rows=2, cols=2, subplot_titles=config["algorithms"])
    convergence_iteration = make_subplots(rows=2, cols=2, subplot_titles=config["algorithms"])
    violation = make_subplots(rows=2, cols=2, subplot_titles=config["algorithms"])
    curve_rows = []
    count_colors = {1: "#94a3b8", 2: "#2563eb", 3: "#0d9488", 4: "#d97706", 5: "#db2777"}
    for r in reports:
        if not r.get("solver_executed", True):
            continue
        m = r["algorithm"]
        n = r["n_segments"]
        idx = config["algorithms"].index(m)
        row = idx // 2 + 1
        col = idx % 2 + 1
        h = r["runs"][0]["history"]
        best = r["initial_total_length_m"]
        times = [0.0]
        bests = [best]
        for j, v in enumerate(h):
            if v["maximum_scaled_constraint_violation"] <= 1e-8:
                best = min(best, v["length_m"])
            times.append(v["elapsed_seconds"])
            bests.append(best)
            curve_rows.append(
                dict(
                    scenario=scene,
                    n_segments=n,
                    algorithm=m,
                    callback_index_1based=j + 1,
                    solver_seconds=v["elapsed_seconds"],
                    new_length_m=v["length_m"],
                    max_scaled_violation=v["maximum_scaled_constraint_violation"],
                    minimum_SF_optimization_grid=v["minimum_sf"],
                    best_grid_feasible_length_m=best,
                )
            )
        name = f"{n}段"
        common = dict(
            name=name, legendgroup=name, showlegend=idx == 0, line=dict(color=count_colors[n])
        )
        convergence_time.add_trace(go.Scatter(x=times, y=bests, **common), row=row, col=col)
        convergence_time.add_trace(
            go.Scatter(
                x=[r["optimization_seconds"]],
                y=[r["final_total_length_m"]],
                mode="markers",
                name=name + "最终认证",
                showlegend=False,
                marker=dict(color=count_colors[n], symbol="star", size=10),
            ),
            row=row,
            col=col,
        )
        convergence_iteration.add_trace(
            go.Scatter(x=list(range(1, len(h) + 1)), y=[v["length_m"] for v in h], **common),
            row=row,
            col=col,
        )
        violation.add_trace(
            go.Scatter(
                x=[v["elapsed_seconds"] for v in h],
                y=[max(1e-12, v["maximum_scaled_constraint_violation"]) for v in h],
                **common,
            ),
            row=row,
            col=col,
        )
    for fig, title, xlabel in [
        (
            convergence_time,
            "累计最短网格可行进尺—求解器运行时间（星号为最终认证采用值）",
            "求解器秒数",
        ),
        (convergence_iteration, "原始迭代进尺—回调序号", "实际callback序号"),
        (violation, "最大归一化约束违反量—求解器运行时间", "求解器秒数"),
    ]:
        fig.update_layout(title=title, height=740)
        fig.update_xaxes(title_text=xlabel)
    violation.update_yaxes(type="log")
    csv_dicts(folder / "convergence_history.csv", curve_rows)
    csv_dicts(folder / "algorithm_segment_comparison.csv", rows)
    initial_rows = []
    initial_json = {}
    initial_bar = go.Figure()
    for n, d in folders.items():
        if not (d / "initialization.json").exists():
            continue
        i = json.loads((d / "initialization.json").read_text())
        initial_json[str(n)] = i
        t = i["timing_breakdown"]
        if (d / "shared_initial_controls.json").exists():
            i["accepted_shared_controls"] = json.loads(
                (d / "shared_initial_controls.json").read_text()
            )
            i["accepted_shared_hash"] = next(
                r["shared_initial_hash"] for r in reports if r["n_segments"] == n
            )
        initial_rows.append(
            [
                n,
                i["status"],
                len(i["attempts"]),
                f"{t.get('geometric_fit_seconds', 0):.6f}",
                f"{t.get('geometric_feasibility_restoration_seconds', 0):.6f}",
                f"{t.get('feasibility_restoration_seconds', 0):.6f}",
                f"{t.get('final_1m_verification_seconds', 0):.6f}",
                f"{i['elapsed_seconds']:.6f}",
            ]
        )
    for key, label in [
        ("geometric_fit_seconds", "几何/目标拟合"),
        ("geometric_feasibility_restoration_seconds", "几何可行性恢复"),
        ("feasibility_restoration_seconds", "全约束恢复"),
        ("final_1m_verification_seconds", "1m核验"),
        ("coarse_constraint_validation_and_control_seconds", "前置判定/粗检查/控制开销"),
    ]:
        initial_bar.add_trace(
            go.Bar(
                x=list(initial_json),
                y=[i["timing_breakdown"].get(key, 0) for i in initial_json.values()],
                name=label,
            )
        )
    initial_bar.update_layout(
        title="每个段数的公共初值构建耗时（四算法共享）",
        height=420,
        barmode="stack",
        xaxis_title="段数",
        yaxis_title="秒",
    )

    def fmt(v, digits=6):
        return "—" if v is None else f"{v:.{digits}f}"

    summary = [
        [
            r["n_segments"],
            r["algorithm"],
            r["status"],
            "是" if r["feasible"] else "否",
            fmt(r["new_length_m"]),
            fmt(r["position_error_m"]),
            fmt(r["max_DLS_deg_per_30m"]),
            fmt(r["min_SF"]),
            fmt(r["centerline_lower_bound_m"]),
            fmt(r["solver_s"], 3),
            fmt(r["complete_flow_s"], 3),
        ]
        for r in rows
    ]
    segment_rows = []
    constraint_rows = []
    for r in reports:
        if not r.get("final_check"):
            continue
        n = r["n_segments"]
        m = r["algorithm"]
        for seg in json.loads((folders[n] / m / "selected_segments.json").read_text()):
            segment_rows.append(
                [
                    n,
                    m,
                    seg["segment"],
                    seg["type"],
                    fmt(seg["length_m"]),
                    fmt(seg["dls_deg_per_30m"]),
                    fmt(seg["initial_toolface_deg"]),
                ]
            )
        c = r["final_check"]
        constraint_rows.append(
            [
                n,
                m,
                fmt(c["position_error_m"]),
                fmt(c["inclination_error_deg"]),
                fmt(c["azimuth_error_deg"]),
                fmt(c["maximum_dls_deg_per_30m"]),
                fmt(c["minimum_sf"]),
                fmt(c["minimum_centerline_distance_m"]),
                c["feasible"],
            ]
        )
    failed_reasons = []
    for n, i in initial_json.items():
        certificate = i["necessary_condition_certificate"]
        for c in certificate["checks"]:
            if not c["passed"]:
                failed_reasons.append([n, c["name"], json.dumps(c, ensure_ascii=False)])
    method_controls = "".join(
        f'<label><input type="checkbox" data-method="{m}" checked>{m}</label>'
        for m in config["algorithms"]
    )
    controls = (
        '<label>段数 <select id="countSelect"><option value="all">全部段数</option>'
        + "".join(f'<option value="{n}">{n}段</option>' for n in config["segment_counts"])
        + "</select></label>"
        + method_controls
    )
    controls += "".join(
        f'<label><input type="checkbox" data-base="{key}" checked>{label}</label>'
        for key, label in [
            ("original", "原设计"),
            ("history", "井1实钻"),
            ("neighbors", "9口实钻邻井"),
        ]
    )
    details = "".join(
        f'<li><a href="../segments_{n:02d}/scene_{scene}/场景{scene}_再规划对比.html">{n}段：'
        + "—".join("圆弧" if j % 2 == 0 else "直线" for j in range(n))
        + "</a></li>"
        for n in config["segment_counts"]
    )
    compact = []
    for r in reports:
        item = {k: v for k, v in r.items() if k != "runs"}
        item["runs"] = [
            {k: v for k, v in run.items() if k != "history"} for run in r.get("runs", [])
        ]
        compact.append(item)
    body = f"""<header><p>场景{scene} · 井1续钻 · ISCWSA Rev.0默认参数 · k=1</p><h1>圆弧—直线交替模式：1～5段 × 四种算法</h1><p>当前共同工程约束下，{sum(r["feasible"] for r in rows)}/{len(rows)}个组合有通过独立1m复评的采用轨迹。未启动、未收敛和采用公共初值均单独标记。</p><p>共同靶点 N=-1333 / E=1000 / D=2200 m；末端井斜89°±0.5°、方位145.9°±0.5°；位置误差≤0.5 m；DLS&lt;6°/30m；SF&gt;1.5；连续中心距下界&gt;5 m。</p><p class="note">保持上一轮的圆弧段长[10,1800]m、直线段长[10,2200]m和全部误差参数。1段式因此受长度上限限制，不可行原因属于当前配置。2段式还受单圆弧与末端直线共面的几何限制。不给未启动组合填入虚构进尺、收敛时间或SF。</p></header>
<section><h2>全部20个组合与可行性</h2>{div(state, "feasibility")}{table(["段数", "算法", "状态/采用来源", "最终可行", "新段进尺m", "靶点误差m", "最大DLS", "最小SF", "中心距下界m", "求解器s", "完整流程s"], summary)}{div(metrics, "metrics")}<p>进尺优劣只在满足同一约束的采用轨迹之间比较。预算75s限制每次求解器运行；完整流程还包含准备、初值、验收和导出，允许超过75s。每算法单次同初值比较，未证明全局最优。</p></section>
<section><h2>所有段数和算法的轨迹叠加</h2><div class="controls">{controls}<button onclick="focusNew()">聚焦纠偏段</button></div><p id="selectionStatus"></p>{div(f3, "trajectory3d")}<div class="grid">{div(xy, "horizontal")}{div(vertical, "vertical")}</div>{div(sf, "sfprofile")}<p>选择器同步控制3D、水平投影、垂直剖面和SF曲线；每幅图仍有完整图例。未获得认证采用结果的组合不画成规划成功轨迹。</p></section>
<section><h2>初始值：如何构建与实际耗时</h2><p>先验证弧长必要条件及单圆弧共面必要条件；可行性未被排除时，构造MC几何种子，均分段长、向所有圆弧分配转角。带界least_squares拟合位置/姿态，必要时用几何约束违反量恢复，再接入真实Rev.0全部约束并做1m独立核验。每个场景和段数只构造一次，四算法共享相同初值哈希。没有跨段数或跨算法继承求解结果。</p>{table(["段数", "状态", "尝试数", "几何拟合s", "几何恢复s", "全约束恢复s", "1m核验s", "初值总s"], initial_rows)}{div(initial_bar, "initialtiming")}<h3>解析不可行判据</h3>{table(["段数", "必要条件", "计算依据"], failed_reasons)}<p>单圆弧和切线直线的位移与初末切向共面。令w为目标位移在初切向正交平面中的投影，目标切向偏离该平面的角度必须≤井斜容差+方位容差+asin(位置容差/||w||)。这是保守必要条件，违反时可证明不可行；通过不保证可行。普通多起点搜索失败则仅标记“未找到初值”。</p><details><summary>各段数初值的完整构建、控制与检查记录</summary><pre>{html.escape(json.dumps(initial_json, ensure_ascii=False, indent=2))}</pre></details></section>
<section><h2>时间拆解、初筛与细化</h2>{div(time_modules, "time_modules")}<p>完整流程=输入/模型准备+公共初值构造/核验+该算法优化/验收/导出。每算法对比计入一次共享成本；批量实际耗时按每单元共享一次统计，不能将20个完整流程简单相加。全部初筛/细化/Rev.0传播的模块秒数和次数包含在下方完整报告及CSV中，属于外层流程内部，不能再重复相加。</p></section>
<section><h2>收敛曲线与运行时间曲线</h2>{div(convergence_time, "convergence_time")}{div(convergence_iteration, "convergence_iterations")}{div(violation, "constraint_convergence")}<p>累计最优线由公共初值出发，仅在callback最大归一化违反量≤1e-8时更新；这些中间点没有逐个做1m认证。星号单列最终认证采用进尺。未收敛曲线终点表示实际停止时间；未启动组合没有收敛曲线。对数图将0显示为1e-12，原始CSV保留0。</p></section>
<section><h2>逐组合验收与分段控制</h2>{table(["段数", "算法", "位置误差m", "井斜差°", "方位差°", "最大DLS", "最小SF", "中心距下界m", "验收通过"], constraint_rows)}{table(["段数", "算法", "井段", "类型", "段长m", "DLS °/30m", "起始工具面°"], segment_rows)}</section>
<section><h2>算法原理与约束处理</h2><p>每弧的决策变量是起始工具面角。沿圆弧前进，当地高边/增方位参考系随切向变化，所以相对工具面角通常随程变化；ω(s)=atan2[n(s)·eA(s),n(s)·eI(s)]。段交界保证位置和切向连续，当前未添加工具面跳变、转速或曲率连续约束。直线曲率为0，几何轨迹不定义唯一造斜工具面。scenario_a三段SLSQP第一圆弧起始/末端约7.478396°/3.036857°，第三圆弧约2.370118°/2.024137°。每个试探控制都执行MC轨迹、完整历史Rev.0、SF及中心距评价并把g≥0传入求解器。SF=D/[k(r1+r2)]，r为各井1σ最大半轴。自由变量数：1～5段分别3、4、7、8、11。以下以三段示例说明接口，其他段数自动按维度构造相同数学问题。</p>{algorithm_explanations_html(dict(config, n_segments=3))}</section>
<section><h2>全部配置、报告及详细数据入口</h2><ul>{details}</ul><p><a href="algorithm_segment_comparison.csv">全部指标与模块耗时CSV</a> · <a href="convergence_history.csv">收敛曲线原始CSV</a>。每个段数详情保存原始数值、1m轨迹、逐邻井/逐点SF、完整协方差和25源NPZ。</p><details><summary>共同配置及全部Rev.0参数</summary><pre>{html.escape(json.dumps(config, ensure_ascii=False, indent=2))}</pre></details><details><summary>全部算法报告（迭代历史另见原始CSV和各段数详情）</summary><pre>{html.escape(json.dumps(compact, ensure_ascii=False, indent=2))}</pre></details><details><summary>输入数据与假设审计</summary><pre>{html.escape(json.dumps(audit, ensure_ascii=False, indent=2))}</pre></details><p class="note">仅新钻段可控；已钻历史不改动。保持当前参考误差预算和合成测站假设，未将1m插值点当独立新测量。最终SF是指定1m采样集合的最小值，中心距按连续折线并扣除MC弦误差界验收。原设计末点不等于共同靶点，不能据其末深声称精确长度收益。</p></section>"""
    script = f"""const focus={dumps(np.vstack([start, target, *[t["positions"] for t in tracks.values()]]))};
function updateSelection(){{const selected=document.getElementById('countSelect').value;let count=0;for(const id of ['trajectory3d','horizontal','vertical','sfprofile']){{const plot=document.getElementById(id);const values=plot.data.map(t=>{{if(!t.meta)return true;const q=t.meta;if(q.base)return document.querySelector('input[data-base="'+q.base+'"]').checked?true:'legendonly';const on=(selected==='all'||Number(selected)===q.n)&&document.querySelector('input[data-method="'+q.m+'"]').checked;if(id==='trajectory3d'&&on)count++;return on?true:'legendonly';}});Plotly.restyle(plot,{{visible:values}});}}document.getElementById('selectionStatus').textContent=count?'当前显示 '+count+' 条通过验收的采用轨迹。':'当前筛选下没有认证采用轨迹；请查看可行性表和不可行依据。';}}
document.querySelectorAll('.controls input,.controls select').forEach(e=>e.addEventListener('change',updateSelection));
function focusNew(){{function range(j){{const v=focus.map(p=>p[j]);const a=Math.min(...v),b=Math.max(...v),pad=Math.max(25,.08*(b-a));return[a-pad,b+pad];}}Plotly.relayout('trajectory3d',{{'scene.xaxis.range':range(1),'scene.yaxis.range':range(0),'scene.zaxis.range':range(2).reverse()}});}}
updateSelection();"""
    if config.get("arc_segment_model", "minimum_curvature") == "constant_toolface":
        body = body.replace(
            "2段式还受单圆弧与末端直线共面的几何限制。",
            "本次非直线段使用恒曲率—恒工具面方程，一般不共面；旧圆弧共面判据已禁用。",
        )
        body = body.replace("相对工具面角通常随程变化", "相对工具面角在段内恒定")
        body = body.replace(
            "scenario_a三段SLSQP第一圆弧起始/末端约7.478396°/3.036857°，第三圆弧约2.370118°/2.024137°。",
            "这些旧圆弧数值不适用于新恒工具面结果；新段的起末工具面均等于该段控制值。",
        )
        body = body.replace(
            "单圆弧和切线直线的位移与初末切向共面。令w为目标位移在初切向正交平面中的投影，目标切向偏离该平面的角度必须≤井斜容差+方位容差+asin(位置容差/||w||)。这是保守必要条件，违反时可证明不可行；通过不保证可行。",
            "恒工具面空间曲线一般不共面，不使用旧平面圆弧共面判据；仍检查总段长与起终点弦长的必要关系。",
        )
        body = body.replace("圆弧—直线交替模式", "恒工具面曲线—直线交替模式")
    (folder / f"场景{scene}_1至5段_四算法对比.html").write_text(
        page(f"场景{scene} 1～5段四算法完整对比", body, script)
    )
    static_comparison(figures, scene, config, rows, tracks, start, direction, reference)


def static_comparison(folder, scene, config, rows, tracks, start, direction, reference):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update(
        {
            "font.family": "Arial Unicode MS",
            "axes.unicode_minus": False,
            "figure.dpi": 140,
            "font.size": 10,
        }
    )
    fig, axes = plt.subplots(2, 2, figsize=(14, 9), layout="constrained")
    for method in config["algorithms"]:
        series = [
            next((r for r in rows if r["n_segments"] == n and r["algorithm"] == method), None)
            for n in config["segment_counts"]
        ]
        for ax, key, title in [
            (axes[0, 0], "new_length_m", "认证采用进尺 / m（无可行解留空）"),
            (axes[0, 1], "complete_flow_s", "完整流程 / s"),
            (axes[1, 0], "min_SF", "最小SF"),
            (axes[1, 1], "centerline_lower_bound_m", "连续中心距下界 / m"),
        ]:
            ax.plot(
                config["segment_counts"],
                [r[key] if r and r[key] is not None else np.nan for r in series],
                "-o",
                label=method,
                color=COLORS[method],
            )
            ax.set(title=title, xlabel="段数", xticks=config["segment_counts"])
            ax.grid(alpha=0.2)
    axes[0, 0].legend()
    fig.suptitle(f"场景{scene}：1～5段 × 四算法，固定共同约束，单次同初值比较")
    centers = [
        r["centerline_lower_bound_m"] for r in rows if r["centerline_lower_bound_m"] is not None
    ]
    if centers:
        from matplotlib.ticker import FormatStrFormatter

        pad = max(0.01, 0.08 * (max(centers) - min(centers)))
        axes[1, 1].set_ylim(min(centers) - pad, max(centers) + pad)
        axes[1, 1].yaxis.set_major_formatter(FormatStrFormatter("%.3f"))
    fig.savefig(folder / "segments_solver_length_time_safety.png", bbox_inches="tight")
    plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(15, 7), layout="constrained")
    for sub, name, color, ls in [
        ("design_input", "原设计", "#2563eb", "--"),
        ("actual_input", "井1实钻", "#111827", "-"),
    ]:
        p = read_track(reference / sub / "well_1.csv")["positions"]
        axes[0].plot(p[:, 1], p[:, 0], color=color, ls=ls, label=name)
        axes[1].plot((p[:, :2] - start[:2]) @ direction, p[:, 2], color=color, ls=ls, label=name)
    styles = {1: "-", 2: ":", 3: "--", 4: "-.", 5: (0, (4, 1, 1, 1, 1, 1))}
    for (n, m), track in tracks.items():
        p = track["positions"]
        axes[0].plot(p[:, 1], p[:, 0], label=f"{n}段 {m}", color=COLORS[m], ls=styles[n])
        axes[1].plot((p[:, :2] - start[:2]) @ direction, p[:, 2], color=COLORS[m], ls=styles[n])
    axes[0].set(title="水平投影", xlabel="E / m", ylabel="N / m")
    axes[0].axis("equal")
    axes[0].legend(fontsize=7, ncol=2)
    axes[1].set(title="垂直剖面", xlabel="沿起点→靶点剖面投影 / m", ylabel="D / m")
    axes[1].invert_yaxis()
    fig.suptitle(f"场景{scene}：所有通过验收的段数/算法采用轨迹")
    fig.savefig(folder / "all_trajectories_projections.png", bbox_inches="tight")
    plt.close(fig)


def render_comparison(out):
    out = Path(out)
    config = json.loads((out / "experiment_config.json").read_text())
    reports = json.loads((out / "all_results.json").read_text())
    reports.sort(
        key=lambda r: (r["scenario"], r["n_segments"], config["algorithms"].index(r["algorithm"]))
    )
    rows = metric_rows(reports)
    csv_dicts(out / "all_scenarios_segment_algorithm_comparison.csv", rows)
    for scene in config["scenarios"]:
        selected = [r for r in reports if r["scenario"] == scene]
        if selected:
            scene_comparison(
                out, scene, config, selected, [r for r in rows if r["scenario"] == scene]
            )
    summary = []
    for scene in config["scenarios"]:
        for n in config["segment_counts"]:
            selected = [r for r in rows if r["scenario"] == scene and r["n_segments"] == n]
            feasible = [r for r in selected if r["feasible"]]
            best = min(feasible, key=lambda r: r["new_length_m"]) if feasible else None
            summary.append(
                [
                    scene,
                    n,
                    "—".join("圆弧" if j % 2 == 0 else "直线" for j in range(n)),
                    f"{len(feasible)}/{len(selected)}",
                    best["algorithm"] if best else "—",
                    f"{best['new_length_m']:.6f}" if best else "—",
                    f"{best['complete_flow_s']:.3f}" if best else "—",
                    selected[0]["status"] if not feasible and selected else "见各算法明细",
                ]
            )
    links = "".join(
        f'<li><a href="scene_{s}/场景{s}_1至5段_四算法对比.html">场景{s}：1～5段全部算法、交互3D/2D、初值/约束/时间与收敛曲线</a></li>'
        for s in config["scenarios"]
    )
    body = f"""<header><h1>A/B/C：圆弧—直线交替模式 1～5段全方法对比</h1><p>共{len(reports)}个组合；Rev.0默认参数、k=1、同一共同靶点、DLS&lt;6°/30m、位置误差≤0.5m、SF&gt;1.5、中心距&gt;5m。1/2/3/4/5段分别为圆弧 / 圆弧—直线 / 圆弧—直线—圆弧 / 圆弧—直线—圆弧—直线 / 圆弧—直线—圆弧—直线—圆弧。</p><ul>{links}</ul><p class="note">保持原有分段约束，不为获得可行结果而放宽长度、姿态或防碰条件。1段式三场景受圆弧长度上限1800m限制；2段式B/C受共面几何必要条件限制。未启动算法与已运行但未收敛的算法分别记录。</p></header><section><h2>各场景、各段数最短可行采用结果</h2>{table(["场景", "段数", "轨迹类型", "可行组合", "最短采用算法", "新段进尺m", "该算法完整流程s", "说明"], summary)}<p>最短指本次四算法采用结果中的最短，未证明全局最优。采用初值或未收敛保留解亦明确标记。</p></section><section><h2>数据与复算</h2><p><a href="all_scenarios_segment_algorithm_comparison.csv">下载60组合指标、状态和模块耗时CSV</a> · <a href="all_results.json">完整报告JSON</a> · <a href="experiment_config.json">配置快照</a> · <a href="experiment_guide.md">使用说明与结果解读</a></p><p>每场景单文件HTML内嵌Plotly及全部对比图。segments_01～segments_05保存每个段数下的独立细节；历史三段式实验文件和原始Excel均保留。</p></section>"""
    if config.get("arc_segment_model", "minimum_curvature") == "constant_toolface":
        body = body.replace(
            "2段式B/C受共面几何必要条件限制。",
            "本次采用恒曲率—恒工具面空间曲线，旧共面判据不适用；具体可行性按各单元实际搜索与验收报告。",
        )
        body = body.replace("圆弧—直线交替模式", "恒工具面曲线—直线交替模式")
    (out / "index.html").write_text(page("A/B/C 1～5段四算法对比", body))
    write_results_explanation(out, config, reports, rows, summary)


def write_results_explanation(out, config, reports, rows, summary):
    executed = [r for r in reports if r.get("solver_executed", True)]
    feasible = [r for r in rows if r["feasible"]]
    successful = [r for r in executed if r["solver_success"]]
    proven = sum(
        r.get("status") == "proven_infeasible_under_configured_constraints" for r in reports
    )
    search_failed = len(reports) - len(executed) - proven
    lines = [
        "# A/B/C：圆弧—直线1～5段四算法对比结果",
        "",
        f"**完成范围。** 3场景×1～5段×4算法，共{len(reports)}个组合。其中{len(executed)}个实际启动求解器，{len(successful)}个求解器成功终止；{len(feasible)}条最终采用轨迹通过独立1m验收。{proven}个组合在必要条件检查阶段已证明不可行，{search_failed}个组合未找到认证初值；这些组合的求解器未启动。求解器成功、最终可行和采用来源分别报告。",
        "",
        "**结果入口。** [全部场景入口](index.html)。[scenario_a](scene_A/scenario_a_segments_1_to_5_comparison.html)、[scenario_b](scene_B/scenario_b_segments_1_to_5_comparison.html)、[scenario_c](scene_C/scenario_c_segments_1_to_5_comparison.html)各为一个可离线打开的完整交互HTML，含全部段数和算法。",
        "",
        "**共同配置。** 保留当前Rev.0全部默认参数、SF=D/[k(r1+r2)]且k=1。圆弧DLS上界5.999°/30m，直线0；圆弧段长[10,1800]m、直线[10,2200]m。最终位置误差≤0.5m、末端井斜89°±0.5°、方位145.9°±0.5°、SF>1.5、连续中心距下界>5m。优化采用0.49m、SF1.53、中心距5.1m保护量。全部其他约束、参数和预算在experiment_config.json及每场景HTML公开。",
        "",
        "## 各段数最短可行采用结果",
        "",
        "|场景|段数|井段排列|可行组合|最短采用算法|新段进尺m|完整流程s|说明|",
        "|---|---:|---|---:|---|---:|---:|---|",
    ]
    lines += ["|" + "|".join(str(v) for v in row) + "|" for row in summary]
    lines += [
        "",
        "**结果口径。** 最短只表示本次四算法找到并采用的可行结果中的最短。未收敛保留解和公共初值回退均如实标记；未证明全局最优。更多段会增加自由变量，不能保证在同一75s预算内得到更短的已找到解。",
        "",
        "## 不可行布局及原因",
        "",
        "**1段式。** 三场景均不可行：单圆弧最大长度1800m小于到靶点直线距离扣除0.5m容差后的必要长度。A/B/C直线距离约1841.438、1869.037、1874.571m。结论依赖本次共同段长上限，不表示任意单圆弧问题都不可行。",
        "",
        "**2段式。** scenario_a实际求解；B、C违反单圆弧—末端直线的共面必要条件。期望末端切向偏离起始切向/目标位移平面约3.439°、11.811°，超过容差允许的保守上界约1.045°、1.027°。完整推导见[使用说明](../../segment_comparison.md)，每单元initialization.json保存具体证书。",
        "",
        "**未启动组合。** 保留四算法状态及前置检查耗时，优化时间为0，认证进尺和SF为空；不伪造曲线，也不将其较短流程时间当作优化速度优势。",
        "",
        "## 初值、算法原理与时间",
        "",
        "**公共初值。** 每个场景和段数独立构建：解析必要条件→MC几何种子→带界位置/姿态拟合→必要的几何可行性恢复→真实Rev.0全约束检查/恢复→独立1m核验。四算法从相同初值哈希出发，不继承其他算法或段数的结果。各阶段和总时间均在initialization.json及HTML记录。",
        "",
        "**算法原理。** SLSQP为序列二次规划，trust-constr为信赖域内点法，COBYLA为线性插值无导数约束优化，COBYQA为二次插值信赖域SQP。约束在每个试探控制上重新计算并参与优化；报告列出公式、接口、实际选项、执行流程和技术依据。",
        "",
        "**耗时。** 同一75s求解预算，算法顺序执行。完整流程包含共享输入/模型准备、初值、优化、内部验收、最终1m复评与导出；初筛/细化/Rev.0传播属于内层模块，不重复相加。批量实际耗时只计每单元共享阶段一次。单次当前机器墙钟时间，未做重复实验统计。",
        "",
        "**曲线。** 每场景提供按段数/算法的实际callback进尺、网格约束违反量、按时间的累计最短网格可行进尺和最终认证标记；停止时间与成功收敛分别报告。原始记录保存在convergence_history.csv，不平滑、不补造。",
        "",
        "## 文件、数据保持与复算",
        "",
        "**详细文件。** 根目录CSV覆盖60组合完整指标及模块耗时；scene_A/B/C保存总对比HTML、CSV和静态图；segments_01～05保存每单元详细HTML、各算法1m轨迹、分段控制、逐点/逐邻井SF、最危险匹配索引、协方差/25误差源及末次候选。source_before/source_after保存源码快照。",
        "",
        "**数据保持。** 原始六份Excel与三份说明文档、上一轮完整三段式结果均使用SHA256核验不变。numerical_trial_report_recovery保留扩展报告时的展示调试结果，不属于最终比较；最终2段式A已完整重跑，所有最终单元均有实际完整计时。",
        "",
        "**测站与比较边界。** 保留分段固定测站数、最大间距30m的合成测站策略，不同段数总测站数不同，因此跨段数SF差异还受该假设影响。真实测站和工具校准资料缺失时未宣称现场标定。原设计末点不同于共同靶点，不能用它声称精确进尺收益。最终SF是指定1m采样集合最小值，中心距用连续折线并扣除MC弦误差界验收。",
        "",
        "**核验入口。** verification.json记录数值与原始文件核验，final_tests.log记录回归测试，html_browser_qa.json记录交互筛选和WebGL浏览核验。",
        "",
        "```bash",
        "python -B src/wellpath/workflows/segment_comparison.py --config configs/experiments/replanning_segments1to5.json --output results/new_segments",
        "python -B tests/test_replan_segments.py --output results/new_segments",
        "```",
        "",
    ]
    if config.get("arc_segment_model", "minimum_curvature") == "constant_toolface":
        lines = [
            (
                "**2段式。** 本次采用恒工具面空间曲线，旧单圆弧共面判据不适用；各场景状态按真实初值搜索、求解与验收报告。"
                if line.startswith("**2段式。**")
                else line
            )
            for line in lines
        ]
        lines.insert(
            2,
            "**新增模型。** arc_segment_model=constant_toolface：每个非直线段曲率和当地高边工具面全程恒定，一般不再是平面圆弧；误差传播仍按配置测站基准离散计算。",
        )
    (out / "experiment_guide.md").write_text("\n".join(lines), encoding="utf-8")
