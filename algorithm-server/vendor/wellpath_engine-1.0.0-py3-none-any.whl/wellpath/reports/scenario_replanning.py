"""Self-contained offline HTML, interactive 3D/2D controls and comparison figures."""

import csv
import html
import json
from pathlib import Path

import numpy as np
import plotly.graph_objects as go
from plotly.offline import get_plotlyjs
from plotly.subplots import make_subplots

from wellpath.data_io.naming import artifact_name
from wellpath.data_io.scenarios import TARGET
from wellpath.reports.algorithm_explanations import algorithm_explanations_html

COLORS = {"SLSQP": "#00796b", "trust-constr": "#7c3aed", "COBYLA": "#d97706", "COBYQA": "#db2777"}
LABEL = {
    "SLSQP": "SLSQP（序列二次规划）",
    "trust-constr": "trust-constr（信赖域内点法）",
    "COBYLA": "COBYLA（线性近似无导数）",
    "COBYQA": "COBYQA（二次近似无导数）",
}


def dumps(x):
    return json.dumps(
        x,
        ensure_ascii=False,
        default=lambda v: v.tolist() if isinstance(v, np.ndarray) else v.item(),
    ).replace("</", "<\\/")


def table(headers, rows):
    return (
        '<div class="scroll"><table><thead><tr>'
        + "".join("<th>" + html.escape(str(v)) + "</th>" for v in headers)
        + "</tr></thead><tbody>"
        + "".join(
            "<tr>" + "".join("<td>" + html.escape(str(v)) + "</td>" for v in row) + "</tr>"
            for row in rows
        )
        + "</tbody></table></div>"
    )


def div(figure, name):
    figure.update_layout(
        template="plotly_white",
        font=dict(family="Arial, PingFang SC, sans-serif", size=13),
        margin=dict(l=60, r=30, t=60, b=65),
        legend=dict(groupclick="togglegroup"),
        uirevision="keep-camera",
    )
    return figure.to_html(
        full_html=False,
        include_plotlyjs=False,
        div_id=name,
        config=dict(responsive=True, displaylogo=False, scrollZoom=True),
    )


def create_scene_html(folder, data, settings, reports, tracks, initial, initial_info, history):
    scene = data["scene"]
    figures = folder / "figures"
    figures.mkdir(exist_ok=True)
    n_segments = int(settings.get("n_segments", 3))
    constant_tf = settings.get("arc_segment_model", "minimum_curvature") == "constant_toolface"
    curve_label = "恒曲率恒工具面段" if constant_tf else "圆弧"
    types = [
        curve_label
        if settings.get("trajectory_mode", "arc-straight") == "arc" or i % 2 == 0
        else "直线"
        for i in range(n_segments)
    ]
    arc_count = sum(t != "直线" for t in types)
    path_label = "—".join(types)
    dim = reports[0].get("free_control_variables", 3 * arc_count + n_segments - arc_count)
    start = np.array(data["audit"]["tie_in"]["position_m"])
    target = np.array(TARGET["position_m"])
    direction = (target - start)[:2]
    direction /= np.linalg.norm(direction)
    series = []
    for n in data["neighbors"]:
        w = n["raw"]
        series.append(
            dict(
                name=w["name"] + " 实钻",
                group="neighbors",
                p=w["positions"],
                md=w["md"],
                color="#a2acba",
                width=1.5,
                dash="solid",
                visible=True,
            )
        )
    original = data["design"]["井1"]
    actual = data["actual"]["井1"]
    series.extend(
        [
            dict(
                name="井1 原设计（原表完整值）",
                group="original",
                p=original["positions"],
                md=original["md"],
                color="#2563eb",
                width=3,
                dash="dash",
                visible=True,
            ),
            dict(
                name="井1 已钻历史（固定）",
                group="history",
                p=actual["positions"],
                md=actual["md"],
                color="#111827",
                width=4,
                dash="solid",
                visible=True,
            ),
            dict(
                name="公共可行初值",
                group="initial",
                p=initial["positions"],
                md=initial["md"],
                color="#64748b",
                width=2,
                dash="dot",
                visible=False,
            ),
        ]
    )
    for r in reports:
        method = r["algorithm"]
        v = tracks[method]
        series.append(
            dict(
                name=method + " 采用轨迹",
                group=method,
                p=v["positions"],
                md=v["md"],
                color=COLORS[method],
                width=4,
                dash="solid",
                visible=True,
            )
        )
        with (folder / method / "raw_solver_candidate_trajectory.csv").open(
            encoding="utf-8-sig"
        ) as f:
            raw = list(csv.DictReader(f))
        p = np.array([[float(row[k]) for k in ("N_m", "E_m", "D_m")] for row in raw])
        md = np.array([float(row["MD_m"]) for row in raw])
        series.append(
            dict(
                name=method + " 末次候选",
                group=method + "_raw",
                p=p,
                md=md,
                color=COLORS[method],
                width=2,
                dash="dot",
                visible=False,
            )
        )
    f3 = go.Figure()
    fxy = go.Figure()
    fv = go.Figure()
    for s in series:
        p = s["p"]
        custom = np.column_stack([s["md"], p])
        common = dict(
            name=s["name"],
            legendgroup=s["group"],
            visible=True if s["visible"] else "legendonly",
            customdata=custom,
            line=dict(color=s["color"], width=s["width"], dash=s["dash"]),
            meta=dict(group=s["group"]),
            mode="lines",
        )
        hover = "MD=%{customdata[0]:.3f} m<br>N=%{customdata[1]:.3f}<br>E=%{customdata[2]:.3f}<br>D=%{customdata[3]:.3f}<extra>%{fullData.name}</extra>"
        f3.add_trace(go.Scatter3d(x=p[:, 1], y=p[:, 0], z=p[:, 2], hovertemplate=hover, **common))
        fxy.add_trace(go.Scatter(x=p[:, 1], y=p[:, 0], hovertemplate=hover, **common))
        distance = (p[:, :2] - start[:2]) @ direction
        fv.add_trace(go.Scatter(x=distance, y=p[:, 2], hovertemplate=hover, **common))
    for point, label, color, symbol in (
        (start, "纠偏起点", "#111827", "circle"),
        (target, "共同靶点", "#dc2626", "diamond"),
    ):
        f3.add_trace(
            go.Scatter3d(
                x=[point[1]],
                y=[point[0]],
                z=[point[2]],
                mode="markers",
                name=label,
                marker=dict(color=color, size=7, symbol=symbol),
            )
        )
        fxy.add_trace(
            go.Scatter(
                x=[point[1]],
                y=[point[0]],
                mode="markers",
                name=label,
                marker=dict(color=color, size=10, symbol=symbol),
            )
        )
        fv.add_trace(
            go.Scatter(
                x=[(point[:2] - start[:2]) @ direction],
                y=[point[2]],
                mode="markers",
                name=label,
                marker=dict(color=color, size=10, symbol=symbol),
            )
        )
    f3.update_layout(
        title="三维轨迹｜拖动旋转、滚轮缩放、图例单击隐藏/双击独显",
        height=730,
        scene=dict(
            xaxis_title="东 E / m",
            yaxis_title="北 N / m",
            zaxis=dict(title="垂深 D / m", autorange="reversed"),
            aspectmode="data",
        ),
    )
    fxy.update_layout(
        title="水平面投影 E–N",
        height=610,
        xaxis_title="东 E / m",
        yaxis=dict(title="北 N / m", scaleanchor="x", scaleratio=1),
    )
    fv.update_layout(
        title="垂直剖面｜沿纠偏点→共同靶点的水平投影方向",
        height=610,
        xaxis_title="沿剖面投影距离 / m（纠偏点为0）",
        yaxis=dict(title="垂深 D / m", autorange="reversed"),
    )
    comp = make_subplots(
        rows=1,
        cols=2,
        subplot_titles=[
            "新钻段总进尺（越短越好，须先可行）",
            "各阶段完整流程耗时（共享阶段按每算法计一次）",
        ],
    )
    methods = [r["algorithm"] for r in reports]
    comp.add_trace(
        go.Bar(
            x=methods,
            y=[r["final_total_length_m"] for r in reports],
            marker_color=[COLORS[m] for m in methods],
            text=[f"{r['final_total_length_m']:.3f} m" for r in reports],
            textposition="outside",
            name="新钻进尺",
        ),
        row=1,
        col=1,
    )
    phase_fields = [
        ("输入/模型准备", "shared_preprocessing_seconds", "#94a3b8"),
        ("可行初值构造及核验", "feasibility_construction_seconds", "#a78bfa"),
        ("求解器优化", "optimization_seconds", "#0d9488"),
        ("求解器内部验收", "validation_seconds", "#38bdf8"),
        ("最终1m复评", "dense_final_verification_seconds", "#f59e0b"),
        ("导出", "export_seconds", "#fb7185"),
    ]
    for label, key, color in phase_fields:
        comp.add_trace(
            go.Bar(x=methods, y=[r[key] for r in reports], name=label, marker_color=color),
            row=1,
            col=2,
        )
    residual = [
        max(0.0, r["complete_flow_seconds"] - sum(r[k] for _, k, _ in phase_fields))
        for r in reports
    ]
    comp.add_trace(
        go.Bar(x=methods, y=residual, name="调度/其他开销", marker_color="#cbd5e1"), row=1, col=2
    )
    comp.update_layout(height=480, barmode="stack")
    comp.update_yaxes(title_text="m", row=1, col=1)
    comp.update_yaxes(title_text="秒", row=1, col=2)
    profile = go.Figure()
    for r in reports:
        method = r["algorithm"]
        v = tracks[method]
        profile.add_trace(
            go.Scatter(x=v["md"], y=v["minimum_sf"], name=method, line=dict(color=COLORS[method]))
        )
    profile.add_hline(
        y=settings["sf_threshold"],
        line_dash="dash",
        line_color="#dc2626",
        annotation_text="SF > 1.5",
    )
    profile.update_layout(
        title="新钻段逐点最小SF｜每点对全部9口实钻邻井扫描",
        height=420,
        xaxis_title="全井测深 MD / m",
        yaxis_title="最小 SF",
    )
    converge = make_subplots(
        rows=1, cols=2, subplot_titles=["迭代总进尺", "最大归一化约束违反量（越小越好）"]
    )
    for r in reports:
        h = r["runs"][0]["history"]
        method = r["algorithm"]
        if h:
            converge.add_trace(
                go.Scatter(
                    x=[v["elapsed_seconds"] for v in h],
                    y=[v["length_m"] for v in h],
                    name=method,
                    line=dict(color=COLORS[method]),
                ),
                row=1,
                col=1,
            )
            converge.add_trace(
                go.Scatter(
                    x=[v["elapsed_seconds"] for v in h],
                    y=[max(v["maximum_scaled_constraint_violation"], 1e-12) for v in h],
                    name=method,
                    showlegend=False,
                    line=dict(color=COLORS[method]),
                ),
                row=1,
                col=2,
            )
    converge.update_layout(height=420)
    converge.update_xaxes(title_text="求解器累计秒")
    converge.update_yaxes(type="log", row=1, col=2)
    iteration_plot = make_subplots(
        rows=1,
        cols=3,
        subplot_titles=["进尺—迭代次数", "最大归一化约束违反量—迭代次数", "最小SF—迭代次数"],
    )
    time_plot = make_subplots(
        rows=1,
        cols=3,
        subplot_titles=[
            "累计最短网格可行进尺—运行时间",
            "最小SF—运行时间",
            "求解器终止时间（非全部收敛）",
        ],
    )
    curve_rows = []
    stop_rows = []
    for r in reports:
        method = r["algorithm"]
        h = r["runs"][0]["history"]
        best_length = r["initial_total_length_m"]
        times = [0.0]
        best_values = [best_length]
        for j, v in enumerate(h):
            if v["maximum_scaled_constraint_violation"] <= 1e-8:
                best_length = min(best_length, v["length_m"])
            times.append(v["elapsed_seconds"])
            best_values.append(best_length)
            curve_rows.append(
                [
                    method,
                    j + 1,
                    v["elapsed_seconds"],
                    v["length_m"],
                    v["maximum_scaled_constraint_violation"],
                    v["minimum_sf"],
                    best_length,
                ]
            )
        if h:
            for col, key in (
                (1, "length_m"),
                (2, "maximum_scaled_constraint_violation"),
                (3, "minimum_sf"),
            ):
                values = [max(v[key], 1e-12) if col == 2 else v[key] for v in h]
                iteration_plot.add_trace(
                    go.Scatter(
                        x=np.arange(1, len(h) + 1),
                        y=values,
                        name=method,
                        legendgroup=method,
                        showlegend=col == 1,
                        line=dict(color=COLORS[method]),
                    ),
                    row=1,
                    col=col,
                )
            time_plot.add_trace(
                go.Scatter(
                    x=[v["elapsed_seconds"] for v in h],
                    y=[v["minimum_sf"] for v in h],
                    name=method,
                    legendgroup=method,
                    showlegend=False,
                    line=dict(color=COLORS[method]),
                ),
                row=1,
                col=2,
            )
        time_plot.add_trace(
            go.Scatter(
                x=times,
                y=best_values,
                name=method,
                legendgroup=method,
                line=dict(color=COLORS[method], shape="hv"),
            ),
            row=1,
            col=1,
        )
        # The certified adopted endpoint is marked separately; grid callbacks
        # have not individually passed the later full 1m verification.
        time_plot.add_trace(
            go.Scatter(
                x=[r["optimization_seconds"]],
                y=[r["final_total_length_m"]],
                mode="markers",
                marker=dict(symbol="star", size=11, color=COLORS[method]),
                name=method + " 最终采用",
                showlegend=False,
            ),
            row=1,
            col=1,
        )
        success = r["solver_success"]
        time_plot.add_trace(
            go.Bar(
                x=[method],
                y=[r["optimization_seconds"]],
                name=method,
                marker_color=COLORS[method],
                showlegend=False,
                text=["成功终止" if success else "未声明收敛"],
                textposition="outside",
            ),
            row=1,
            col=3,
        )
        stop_rows.append(
            [
                method,
                "成功终止" if success else "未声明收敛",
                f"{r['optimization_seconds']:.6f}",
                r["runs"][0]["iterations"],
                r["runs"][0]["objective_calls"],
                r["runs"][0]["message"],
            ]
        )
    iteration_plot.update_layout(height=430)
    iteration_plot.update_xaxes(title_text="callback记录序号（1起）")
    iteration_plot.update_yaxes(type="log", row=1, col=2)
    time_plot.update_layout(height=450)
    time_plot.update_xaxes(title_text="求解器秒数", row=1, col=1)
    time_plot.update_xaxes(title_text="求解器秒数", row=1, col=2)
    time_plot.update_yaxes(title_text="秒", row=1, col=3)
    time_plot.add_hline(
        y=settings["sf_threshold"], line_dash="dash", line_color="#dc2626", row=1, col=2
    )
    with (folder / "convergence_history.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(
            [
                "algorithm",
                "callback_index_1based",
                "solver_elapsed_seconds",
                "new_length_m",
                "max_scaled_violation",
                "minimum_SF_optimization_grid",
                "best_grid_feasible_length_m",
            ]
        )
        writer.writerows(curve_rows)
    init_times = initial_info.get("timing_breakdown", {})
    init_rows = [
        [label, f"{init_times.get(key, 0.0):.9f}"]
        for label, key in [
            ("几何猜测及有界目标拟合", "geometric_fit_seconds"),
            ("几何可行性恢复", "geometric_feasibility_restoration_seconds"),
            ("防碰/工程可行性恢复", "feasibility_restoration_seconds"),
            ("独立1m核验", "final_1m_verification_seconds"),
            (
                "优化网格全约束检查、种子与控制开销",
                "coarse_constraint_validation_and_control_seconds",
            ),
        ]
    ]
    init_rows.append(["初值构建总时间", f"{initial_info['elapsed_seconds']:.9f}"])
    init_segments = [
        [j + 1, types[j], f"{d:.9f}", "—" if types[j] == "直线" else f"{w:.9f}", f"{L:.9f}"]
        for j, (d, w, L) in enumerate(initial["physical"])
    ]
    init_figure = go.Figure()
    for label, key in [
        ("几何/目标拟合", "geometric_fit_seconds"),
        ("几何可行性恢复", "geometric_feasibility_restoration_seconds"),
        ("全约束可行性恢复", "feasibility_restoration_seconds"),
        ("1m核验", "final_1m_verification_seconds"),
        ("粗检查与控制", "coarse_constraint_validation_and_control_seconds"),
    ]:
        init_figure.add_trace(go.Bar(x=["公共初值构建"], y=[init_times.get(key, 0.0)], name=label))
    init_figure.update_layout(
        title="初值构建阶段耗时（四算法共享，同场景只构建一次）",
        height=330,
        barmode="stack",
        yaxis_title="秒",
    )
    initial_section = f"""<section id="initial-construction"><h2>初始值如何构建、是否可行、花了多久</h2>
<p><strong>第一步：几何猜测。</strong> 由纠偏点与目标的切向量求夹角β和圆弧平面法向；用单位长度最小曲率位移v，将目标位移投影到v估计总长度L̂=clip((x_target−x_start)·v/(v·v))。{n_segments}段长度先均分；总转角分配给{arc_count}个弯曲段，直线段严格为零曲率，再转为各段初始工具面并映射到[0,1]变量范围。这只是种子；后续拟合与全部约束评价使用当前选定的轨迹方程。</p>
<p><strong>第二步：有界拟合。</strong> scipy.optimize.least_squares拟合几何残差，目标是让位置/姿态中靶并满足段内井斜、转角与DLS限制：残差向量为[e_position/100 m，e_angle/10°，10 min(g_geometry,0)]。本场景共尝试{len(initial_info["attempts"])}次，首个接受尝试的拟合函数评价nfev={initial_info["attempts"][-1]["nfev"]}。变量范围始终由bounds=(0,1)控制。</p>
<p><strong>第三步：全部约束检查与恢复。</strong> 将拟合控制传入真实Rev.0防碰引擎，检查SF、连续中心距及全部工程/目标约束。若不满足，求解min ||min(g(z)−10⁻⁶,0)||²进行可行性恢复；本次恢复耗时为0表示无需调用该步骤，不是漏做防碰检查。</p>
<p><strong>第四步：1m验收后冻结。</strong> 通过新段1m点/端点对邻井原始全部点的SF扫描及连续中心距下界验收后，冻结为四算法共同初值。共享控制哈希为<code>{reports[0]["shared_initial_hash"]}</code>；四算法分别从此控制开始，不继承其他算法结果。</p>
{table(["初值构建阶段", "实际秒数"], init_rows)}{div(init_figure, "initialtiming")}
<h3>实际采用的公共初始控制</h3>{table(["段", "类型", "DLS °/30m", "初始工具面 °", "段长 m"], init_segments)}
<p>公共初值新段总长{float(initial["physical"][:, 2].sum()):.6f} m；首个接受初值的1m最小SF={initial_info["attempts"][-1]["final_check"]["minimum_sf"]:.6f}，靶点误差={initial_info["attempts"][-1]["final_check"]["position_error_m"]:.9f} m。初值构造秒数单列，也已计入各算法完整流程时间，不应再加第二遍。</p></section>"""
    algorithm_section = algorithm_explanations_html(dict(settings, free_control_variables=dim))
    module = go.Figure()
    module_labels = {
        "trajectory_and_target_constraints": "轨迹与几何约束",
        "rev0_propagation_and_radius": "Rev0传播/特征值",
        "sf_screening": "SF水平初筛",
        "sf_refinement": "SF区间细化",
        "sf_control": "SF控制开销",
        "centerline_screening": "中心距初筛",
        "centerline_refinement": "中心距精算",
        "constraint_assembly": "约束组装",
    }
    for key, label in module_labels.items():
        module.add_trace(
            go.Bar(
                x=methods,
                y=[r["optimization_module_profile"]["seconds"].get(key, 0.0) for r in reports],
                name=label,
            )
        )
    module.update_layout(
        title="求解阶段内部模块耗时｜包含求解器内部验收，勿与外层阶段重复相加",
        height=430,
        barmode="stack",
        yaxis_title="秒",
    )
    summary_rows = []
    constraints_rows = []
    timing_rows = []
    segment_rows = []
    for r in reports:
        c = r["final_check"]
        m = r["algorithm"]
        source = (
            "公共初值回退"
            if r["selected_after_dense_fallback_to_initial"]
            or r["selected_candidate"] == "verified_initial_point"
            else "算法保留的可行结果"
        )
        summary_rows.append(
            [
                m,
                "通过" if c["feasible"] else "未通过",
                "成功终止" if r["solver_success"] else "未声明收敛",
                source,
                f"{r['final_total_length_m']:.6f}",
                f"{r['full_well_final_MD_m']:.6f}",
                f"{r['complete_flow_seconds']:.3f}",
                f"{c['position_error_m']:.6f}",
                f"{c['minimum_sf']:.6f}",
            ]
        )
        p = tracks[m]["physical"]
        e = RecheckValues(r, p, settings)
        constraints_rows.extend([[m, *row] for row in e])
        timing_rows.append(
            [
                m,
                *[
                    f"{r[k]:.6f}"
                    for k in (
                        "shared_preprocessing_seconds",
                        "feasibility_construction_seconds",
                        "optimization_seconds",
                        "validation_seconds",
                        "dense_final_verification_seconds",
                        "export_seconds",
                        "complete_flow_seconds",
                    )
                ],
            ]
        )
        for i, (d, w, L) in enumerate(p):
            segment_rows.append(
                [
                    m,
                    i + 1,
                    types[i],
                    f"{L:.6f}",
                    f"{d:.6f}",
                    "—" if types[i] == "直线" else f"{w:.6f}",
                    f"{d * L / 30:.6f}",
                ]
            )
    neighbor_rows = []
    for r in reports:
        for pair in r["final_check"]["separation_details"]:
            neighbor_rows.append(
                [
                    r["algorithm"],
                    pair["neighbor"],
                    f"{pair['minimum_sf']:.6f}",
                    f"{pair['reference_md_m']:.6f}",
                    f"{pair['offset_md_m']:.6f}",
                    f"{pair['reference_radius_m']:.6f}",
                    f"{pair['offset_radius_m']:.6f}",
                    f"{pair['centerline']['distance_lower_bound_m']:.6f}",
                    "通过"
                    if pair["minimum_sf"] > settings["sf_threshold"]
                    and pair["centerline"]["distance_lower_bound_m"]
                    > settings["centerline_min_distance_m"]
                    else "未通过",
                ]
            )
    effective_parameters = data["parameters"]
    parameter_rows = [[k, v] for k, v in effective_parameters.items()]
    setting_rows = [
        ["模型", "iscwsa_rev0，25误差源，minimum_curvature雅可比"],
        ["SF", "D/[k×(r1+r2)]，r为各井1σ最大半轴；k=1"],
        [
            "轨迹模式",
            f"{n_segments}段：{path_label}；{dim}个自由变量（每弧DLS/初始工具面/长度，每直线长度）",
        ],
        [
            "狗腿度",
            f"圆弧[{settings['arc_dls_lower_deg_per_30m']}, {settings['dls_upper_deg_per_30m']}] °/30m，直线严格0；要求<6",
        ],
        [
            "段长",
            f"圆弧{settings['arc_length_bounds_m']} m；直线{settings['straight_length_bounds_m']} m",
        ],
        [
            "默认工具面（分段可覆盖）",
            str(
                settings.get(
                    "toolface_control", settings.get("toolface_bounds_deg", [-180.0, 180.0])
                )
            )
            + "，每圆弧起始工具面，非沿程恒工具面",
        ],
        ["全过程井斜", str(settings["inclination_bounds_deg"]) + "°；解析求段内极值"],
        ["每弧总转角", "≤150°，保持短圆弧唯一性"],
        ["位置中靶", "三维欧氏误差≤0.5 m；优化留0.49 m保护半径"],
        ["末端姿态", "井斜89°±0.5°、网格方位145.9°±0.5°"],
        ["SF", "最终>1.5；优化≥1.53"],
        ["中心距", "最终连续中心线距离下界>5 m；优化额外留0.1 m"],
        ["初始协方差", "0矩阵；未加任意0.5 m先验；从井口传播实钻历史"],
        [
            "测站假设",
            "邻井/历史：合成30 m测站+非整数分段端点；新段：固定分段测站数确保最大间距≤30 m",
        ],
        [
            "优化/验收",
            "优化每段24个MC区间、邻井10 m；最终新段1 m+段端点，对邻井原表全部点；中心距加弦误差界",
        ],
        [
            "算法预算",
            f"每算法单初值，最大{settings['solver']['max_seconds_per_run']} s；详细迭代/函数预算见完整配置",
        ],
    ]
    tie = data["audit"]["tie_in"]
    best = min(reports, key=lambda r: r["final_total_length_m"])
    groups = [
        ("original", "原设计", True),
        ("history", "已钻井1", True),
        ("neighbors", "9口实钻邻井", True),
        ("initial", "公共初值", False),
    ]
    groups += [(m, m, True) for m in methods] + [
        (m + "_raw", m + "末次候选", False) for m in methods
    ]
    controls = "".join(
        f'<label><input type="checkbox" data-group="{html.escape(g)}" {"checked" if on else ""}>{html.escape(label)}</label>'
        for g, label, on in groups
    )
    messages = "".join(
        "<details><summary>"
        + html.escape(r["algorithm"])
        + " 求解终止信息与原始候选</summary><p>"
        + html.escape(r["runs"][0]["message"])
        + "</p><pre>"
        + html.escape(
            json.dumps(
                dict(
                    raw_candidate_check=r["raw_solver_candidate_check"],
                    selected_candidate=r["selected_candidate"],
                    selected_candidate_solver_success=r["selected_candidate_solver_success"],
                    interrupted=r["runs"][0]["interrupted"],
                ),
                ensure_ascii=False,
                indent=2,
            )
        )
        + "</pre></details>"
        for r in reports
    )
    html_text = f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>场景{scene}｜井1 Rev.0 再规划</title>
<style>body{{margin:0;background:#f2f5f9;color:#17243b;font:15px/1.7 Arial,"PingFang SC",sans-serif}}main{{max-width:1500px;margin:auto;padding:26px}}section,header{{background:#fff;border:1px solid #e1e7ef;border-radius:14px;padding:24px;margin:20px 0}}h1{{font-size:29px;margin:5px 0}}h2{{font-size:22px}}h3{{font-size:17px}}p{{margin:12px 0}}.muted{{color:#64748b}}.note{{background:#fff8e9;padding:15px;border-left:4px solid #e9a525}}.pill{{display:inline-block;padding:4px 12px;background:#e6f6f1;color:#006b55;border-radius:20px;margin:4px}}.scroll{{overflow:auto}}table{{border-collapse:collapse;width:100%;font-size:13px}}th,td{{padding:10px 12px;border-bottom:1px solid #e5eaf0;text-align:left;white-space:nowrap}}th{{background:#1b3552;color:white}}td:last-child{{white-space:normal}}.controls{{display:flex;gap:12px;flex-wrap:wrap;align-items:center;background:#f1f5f9;padding:16px;border-radius:9px}}label{{font-size:13px}}button{{background:#173f70;color:white;border:0;border-radius:6px;padding:8px 13px;cursor:pointer}}pre{{font-size:12px;overflow:auto;max-height:550px;padding:15px;background:#f5f7fa}}details{{padding:12px 0}}a{{color:#1762a3}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:10px}}@media(max-width:1000px){{.grid{{display:block}}main{{padding:10px}}section{{padding:12px}}}}</style><script>{get_plotlyjs()}</script></head><body><main>
<header><div class="muted">井1再规划 · 场景{scene} · ISCWSA Rev.0 · k=1</div><h1>{n_segments}段 · {path_label}：四算法对比</h1><span class="pill">{sum(r["final_check"]["feasible"] for r in reports)}/{len(reports)} 条采用轨迹通过复评</span><span class="pill">最短采用结果 {best["algorithm"]} · {best["final_total_length_m"]:.3f} m</span><p>共同靶点：N −1333 / E 1000 / D 2200 m；末端井斜89°、方位145.9°。从井1实钻最后一点续钻，井2—井10均为已钻邻井。</p><p>纠偏起点：MD {tie["md_m"]:.6f} m；N {tie["position_m"][0]:.6f}，E {tie["position_m"][1]:.6f}，D {tie["position_m"][2]:.6f} m；井斜{tie["inclination_deg"]:.6f}°，方位{tie["azimuth_deg"]:.6f}°。</p><p class="note">原设计末点距共同靶点 {data["audit"]["original_design_endpoint_to_common_target_m"]:.6f} m。中靶按场景说明给定坐标验收，原设计按原表完整显示。新段总进尺与全井最终MD分别报告；不把未达到同一靶点的原设计末点视为公平的长度优化基线。</p></header>
{initial_section}{algorithm_section}<section><h2>算法结果与可行性</h2>{table(["算法", "最终采用轨迹", "求解器终止", "采用来源", "新段进尺 m", "全井最终MD m", "完整流程 s", "靶点误差 m", "最小SF"], summary_rows)}<p class="muted">可行性取决于约束复评，不能用求解器success替代。预算到期或不收敛时可采用该算法已保留的可行迭代，若无改进则明确标记公共初值回退；不宣称全局最优。当前为每算法单次、同初值比较。</p>{div(comp, "comparison")}{messages}</section>
<section><h2>轨迹叠加与交互</h2><p>勾选项同步控制3D、水平投影、垂直剖面。各图图例亦可单独隐藏轨迹。末次候选默认隐藏，可能不满足约束；实线为已验证采用结果。</p><div class="controls">{controls}<button onclick="zoomNew()">聚焦纠偏段</button><button onclick="zoomAll()">显示完整井场</button></div>{div(f3, "trajectory3d")}<div class="grid">{div(fxy, "horizontal")}{div(fv, "vertical")}</div><p>垂直剖面沿纠偏点指向靶点的水平投影方向，方位{np.rad2deg(np.arctan2(direction[1], direction[0])) % 360:.6f}°；横轴为投影距离，非测深，三维轨迹在剖面中的重叠不代表真实相交。</p></section>
<section><h2>全部约束与逐算法验收</h2>{table(["配置项", "实际配置与说明"], setting_rows)}{table(["算法", "检查项", "要求", "实际值", "判定"], constraints_rows)}<h3>分段控制变量</h3>{table(["算法", "段", "类型", "段长 m", "DLS °/30m", "初始工具面 °", "总转角 °"], segment_rows)}{div(profile, "sfprofile")}<h3>逐邻井防碰验收与最危险点对</h3>{table(["算法", "邻井", "最小SF", "本井对应MD m", "邻井对应MD m", "本井半轴m", "邻井半轴m", "中心距下界m", "判定"], neighbor_rows)}<p>优化的0.49 m位置保护量不替代最终≤0.5 m验收；末次数值解允许用最终规定进行独立验收。最终SF按新段全部1 m点及端点与邻井原表全部点组合取最小，使用水平包围盒安全剪枝；它是该采样集合的最小值，未声称连续曲线SF的全局最小值。中心距则按连续折线精算并扣除MC弦误差界，使用距离下界验收。</p></section>
<section><h2>算法时间与模块拆解</h2>{table(["算法", "输入/模型准备 s", "可行初值 s", "优化 s", "内部验收 s", "最终1m复评 s", "导出 s", "完整流程 s"], timing_rows)}<p>完整流程=该场景共享输入/模型准备+共享初值构造与核验+该算法运行/验收/导出。共享部分为公平比较按每算法计一次；批量实际总耗时不重复计共享步骤。可视化生成和固定已钻历史审计不计入算法流程，在scene_timing.json单列。计时为当前机器单次墙钟时间。</p>{div(module, "modules")}<h3>按迭代次数的收敛曲线</h3>{div(iteration_plot, "convergence_iterations")}<h3>按实际运行时间的进展曲线</h3>{div(converge, "convergence")}{div(time_plot, "convergence_time")}
<p><strong>曲线定义。</strong> callback序号是本算法实际记录的迭代回调次数，各算法单次工作量不同；时间横轴为求解器运行墙钟秒数。累计最优曲线从公共初值出发，在记录点最大归一化违反量≤10⁻⁸时更新，属于优化网格可行记录，不代表每个中间点都已做1m验收；星号单独表示最终经过1m复评的采用进尺。对数图将0违反量显示为10⁻¹²以便绘图，原始CSV保留0。未收敛算法曲线只到实际停止时刻，不能将其停止时间称为收敛时间。</p>
{table(["算法", "停止状态", "实际求解器运行时间s", "迭代/回调数", "目标函数调用数", "停止原因"], stop_rows)}<p><a href="convergence_history.csv">下载全部迭代与时间曲线原始CSV</a>。记录来自本次真实回调，不进行平滑或补造迭代。</p><details><summary>内部模块完整秒数与调用次数（不与外层墙钟重复求和）</summary><pre>{html.escape(json.dumps({r["algorithm"]: {"optimization": r["optimization_module_profile"], "final": r["final_verification_module_profile"]} for r in reports}, ensure_ascii=False, indent=2))}</pre></details></section>
<section><h2>误差模型参数、历史与数据依据</h2><p>本次使用当前Rev.0的全部默认参数，25误差源；角度参数按各自单位转为rad，位置雅可比与名义轨迹均按最小曲率。半轴从完整1σ协方差特征值获得，k不重复预乘。参数保留的是项目参考预算，未因这些Excel自动获得现场校准。</p>{table(["Rev.0参数字段（单位见字段名）", "采用值"], parameter_rows)}<p class="note">实钻历史另行评价最小SF={history["minimum_sf"]:.6f}。这些点已固定，不把历史风险隐去，也不让剩余段求解假装能够消除历史风险。下面的“最终可行”专指本次新钻段满足全部约束。</p><details><summary>固定历史逐邻井评价</summary><pre>{html.escape(json.dumps(history, ensure_ascii=False, indent=2))}</pre></details><p>资料是1 m插值轨迹，缺少实际测量站/工具校准记录。误差传播以合成测站表示，不将每个1 m点当独立新测量。默认地磁B=48000 nT、磁倾角58°、偏角2°保留；网格方位暂按收敛角0°转换作为地理方位，属于显式假设。用于现场前应以真实测站、坐标基准和工具参数替换。</p><details><summary>原始数据、哈希、MC一致性和假设审计</summary><pre>{html.escape(json.dumps(data["audit"], ensure_ascii=False, indent=2))}</pre></details><details><summary>公共初值构造与约束核验</summary><pre>{html.escape(json.dumps(initial_info, ensure_ascii=False, indent=2, default=lambda v: v.tolist() if isinstance(v, np.ndarray) else v.item()))}</pre></details></section>
<section><h2>完整配置与数值结果</h2><p>本HTML内嵌全部图和Plotly，可单文件离线查看。以下配套数值文件便于程序复核：<a href="algorithm_comparison.csv">算法对比CSV</a> · <a href="algorithm_results.json">完整算法报告JSON</a> · <a href="problem.json">问题/约束配置</a> · <a href="input_audit.json">数据审计</a>。每算法文件夹内包含selected_trajectory.csv、各井对/逐点SF、匹配索引、完整协方差及25源NPZ、分段控制和末次候选。原始Excel不修改。</p><details><summary>实验全部配置（可复制重算）</summary><pre>{html.escape(json.dumps(settings, ensure_ascii=False, indent=2))}</pre></details><button onclick="downloadResults()">下载内嵌完整算法报告JSON</button></section>
</main><script>
const reports={dumps(reports)};
const focus={dumps(np.vstack([start, target, *[tracks[m]["positions"] for m in methods]]))};
document.querySelectorAll('input[data-group]').forEach(el=>el.addEventListener('change',()=>{{for(const id of ['trajectory3d','horizontal','vertical']){{const plot=document.getElementById(id);const ids=plot.data.map((t,i)=>t.meta&&t.meta.group===el.dataset.group?i:-1).filter(i=>i>=0);Plotly.restyle(plot,{{visible:el.checked?true:'legendonly'}},ids);}}}}));
function range(j){{const v=focus.map(p=>p[j]);const a=Math.min(...v),b=Math.max(...v),pad=Math.max(25,(b-a)*.08);return[a-pad,b+pad];}}
function zoomNew(){{Plotly.relayout('trajectory3d',{{'scene.xaxis.range':range(1),'scene.yaxis.range':range(0),'scene.zaxis.range':range(2).reverse()}});}}
function zoomAll(){{Plotly.relayout('trajectory3d',{{'scene.xaxis.autorange':true,'scene.yaxis.autorange':true,'scene.zaxis.autorange':'reversed'}});}}
function downloadResults(){{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(reports,null,2)],{{type:'application/json'}}));a.download='scene_{scene}_algorithm_results.json';a.click();URL.revokeObjectURL(a.href);}}
</script></body></html>"""
    if constant_tf:
        html_text = html_text.replace(
            "每圆弧起始工具面，非沿程恒工具面", "每个曲线段全程恒定的当地高边工具面，段间可独立设置"
        )
        html_text = html_text.replace(
            "minimum_curvature雅可比", "测站minimum_curvature雅可比（对非圆弧名义轨迹的离散近似）"
        )
        html_text = html_text.replace(
            "位置雅可比与名义轨迹均按最小曲率",
            "位置雅可比沿测站使用最小曲率离散近似，名义轨迹按恒曲率—恒工具面方程积分",
        )
        html_text = html_text.replace("；解析求段内极值", "；井斜随局部测深线性变化，检查两端极值")
        html_text = html_text.replace("MC弦误差界", "恒曲率曲线弦误差界")
        html_text = html_text.replace("≤150°，保持短圆弧唯一性", "≤150°，限制沿程累计曲率κL")
        note = "<section><h2>新增几何选项：段内恒工具面</h2><p>arc_segment_model=constant_toolface。每个非直线段的曲率κ和当地高边工具面ω在段内恒定：dI/ds=κcosω，dA/ds=κsinω/sinI，dx/ds=t(I,A)。名义位置按该方程计算，通常不再是平面圆弧；不将有限长度该段宣称为精确最小曲率圆弧。直线仍保持κ=0。段点位置和切向连续，工具面和曲率可以跳变，没有添加跨段旋转速率约束。</p><p>误差模型和参数保留，Rev.0按合成测站的最小曲率雅可比传播，是对新名义曲线的离散近似。Rev.0误差预算参数toolface_deg与轨迹控制ω含义不同，没有自动相互覆盖。</p></section>"
        html_text = html_text.replace(initial_section, note + initial_section)
    if "discrete_toolface_selection" in settings:
        note = (
            "<section><h2>当前离散角组合</h2><p>工具面已在初值构造和NLP开始前固定；下面只有曲率、长度及其他连续控制参与当前NLP。此页描述当前固定组合，不是所有枚举组合的累计时间。</p><pre>"
            + html.escape(
                json.dumps(settings["discrete_toolface_selection"], ensure_ascii=False, indent=2)
            )
            + "</pre></section>"
        )
        html_text = html_text.replace(initial_section, note + initial_section)
    (folder / f"场景{scene}_再规划对比.html").write_text(html_text, encoding="utf-8")
    static_figures(figures, data, reports, tracks, direction, start)


def RecheckValues(r, p, s):
    c = r["final_check"]
    rows = []

    def add(name, limit, value, ok):
        rows.append([name, limit, value, "通过" if ok else "未通过"])

    add("三维中靶误差", "≤0.5 m", f"{c['position_error_m']:.9f} m", c["position_error_m"] <= 0.5)
    add(
        "末端井斜差",
        "≤0.5°",
        f"{c['inclination_error_deg']:.9f}°",
        abs(c["inclination_error_deg"]) <= s["target_inclination_tolerance_deg"] + 1e-6,
    )
    add(
        "末端方位差",
        "≤0.5°",
        f"{c['azimuth_error_deg']:.9f}°",
        abs(c["azimuth_error_deg"]) <= s["target_azimuth_tolerance_deg"] + 1e-6,
    )
    add("狗腿度", "<6 °/30m", f"{p[:, 0].max():.9f}", p[:, 0].max() < 6)
    add("最小分离系数", ">1.5", f"{c['minimum_sf']:.9f}", c["minimum_sf"] > s["sf_threshold"])
    add(
        "连续中心距下界",
        ">5 m",
        f"{c['minimum_centerline_distance_m']:.9f} m",
        c["minimum_centerline_distance_m"] > s["centerline_min_distance_m"],
    )
    add(
        "全过程井斜",
        str(s["inclination_bounds_deg"]) + "°",
        f"{c.get('minimum_inclination_deg', float('nan')):.6f}～{c.get('maximum_inclination_deg', float('nan')):.6f}°",
        c.get("minimum_inclination_deg", -1) >= s["inclination_bounds_deg"][0] - 1e-6
        and c.get("maximum_inclination_deg", 181) <= s["inclination_bounds_deg"][1] + 1e-6,
    )
    add(
        "每弧累计转角",
        "≤150°",
        f"{c.get('maximum_segment_bend_deg', float('nan')):.6f}°",
        c.get("maximum_segment_bend_deg", 181) <= s["max_segment_bend_deg"] + 1e-6,
    )
    add(
        "段长/工具面界",
        "逐段配置范围内",
        "归一化边界检查",
        c.get("segment_variable_bounds_satisfied", False),
    )
    return rows


def static_figures(folder, data, reports, tracks, direction, start):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update(
        {
            "font.family": "Arial Unicode MS",
            "axes.unicode_minus": False,
            "figure.dpi": 140,
            "font.size": 10,
        }
    )
    fig, axes = plt.subplots(1, 2, figsize=(14, 6), layout="constrained")
    for n in data["neighbors"]:
        p = n["raw"]["positions"]
        axes[0].plot(p[:, 1], p[:, 0], color="#b6c0ce", lw=0.7)
        axes[1].plot((p[:, :2] - start[:2]) @ direction, p[:, 2], color="#b6c0ce", lw=0.7)
    for w, label, color, ls in [
        (data["design"]["井1"], "原设计", "#2563eb", "--"),
        (data["actual"]["井1"], "井1实钻", "#111827", "-"),
    ]:
        p = w["positions"]
        axes[0].plot(p[:, 1], p[:, 0], label=label, color=color, ls=ls)
        axes[1].plot((p[:, :2] - start[:2]) @ direction, p[:, 2], label=label, color=color, ls=ls)
    for r in reports:
        m = r["algorithm"]
        p = tracks[m]["positions"]
        axes[0].plot(p[:, 1], p[:, 0], color=COLORS[m], label=m)
        axes[1].plot((p[:, :2] - start[:2]) @ direction, p[:, 2], color=COLORS[m], label=m)
    target = np.array(TARGET["position_m"])
    axes[0].scatter(target[1], target[0], marker="*", s=90, c="#dc2626", label="共同靶点")
    axes[1].scatter((target[:2] - start[:2]) @ direction, target[2], marker="*", s=90, c="#dc2626")
    axes[0].set(xlabel="东 E / m", ylabel="北 N / m", title="水平投影")
    axes[0].axis("equal")
    axes[0].legend(ncol=2, fontsize=8)
    axes[1].set(xlabel="沿剖面投影距离 / m", ylabel="垂深 D / m", title="垂直剖面")
    axes[1].invert_yaxis()
    axes[1].legend(ncol=2, fontsize=8)
    fig.suptitle(f"场景{data['scene']}：原设计、实钻与四算法再规划")
    fig.savefig(folder / "trajectory_projections_comparison.png", bbox_inches="tight")
    plt.close(fig)
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.7), layout="constrained")
    methods = [r["algorithm"] for r in reports]
    for ax, key, title in [
        (axes[0], "final_total_length_m", "新钻段进尺 / m"),
        (axes[1], "complete_flow_seconds", "完整流程耗时 / s"),
    ]:
        values = [r[key] for r in reports]
        ax.bar(methods, values, color=[COLORS[m] for m in methods])
        ax.set_title(title)
        ax.tick_params(axis="x", rotation=15)
        for i, v in enumerate(values):
            ax.text(i, v, f"{v:.3f}", ha="center", va="bottom", fontsize=9)
    for r in reports:
        m = r["algorithm"]
        v = tracks[m]
        axes[2].plot(v["md"], v["minimum_sf"], label=m, color=COLORS[m])
    axes[2].axhline(1.5, color="#dc2626", ls="--")
    axes[2].set(title="新钻段逐点最小SF", xlabel="MD / m")
    axes[2].legend(fontsize=8)
    fig.savefig(folder / "legacy_d43e044ff3dc.png", bbox_inches="tight")
    plt.close(fig)
    fig, axes = plt.subplots(2, 3, figsize=(17, 9), layout="constrained")
    for r in reports:
        method = r["algorithm"]
        h = r["runs"][0]["history"]
        color = COLORS[method]
        if not h:
            continue
        iteration = np.arange(1, len(h) + 1)
        seconds = np.array([v["elapsed_seconds"] for v in h])
        length = np.array([v["length_m"] for v in h])
        violation = np.array([v["maximum_scaled_constraint_violation"] for v in h])
        sf = np.array([v["minimum_sf"] for v in h])
        axes[0, 0].plot(iteration, length, label=method, color=color)
        axes[0, 1].plot(iteration, np.maximum(violation, 1e-12), label=method, color=color)
        axes[0, 2].plot(iteration, sf, label=method, color=color)
        axes[1, 0].plot(seconds, length, label=method, color=color)
        axes[1, 1].plot(seconds, np.maximum(violation, 1e-12), label=method, color=color)
        current = r["initial_total_length_m"]
        incumbents = []
        for value in h:
            if value["maximum_scaled_constraint_violation"] <= 1e-8:
                current = min(current, value["length_m"])
            incumbents.append(current)
        axes[1, 2].step(
            np.r_[0.0, seconds],
            np.r_[r["initial_total_length_m"], incumbents],
            where="post",
            label=method,
            color=color,
        )
        axes[1, 2].scatter(
            r["optimization_seconds"], r["final_total_length_m"], marker="*", s=70, color=color
        )
    titles = [
        ["进尺—迭代次数", "最大归一化违反量—迭代次数", "最小SF—迭代次数"],
        ["进尺—求解器运行时间", "最大归一化违反量—运行时间", "累计最短网格可行进尺—时间"],
    ]
    for i in range(2):
        for j in range(3):
            axes[i, j].set(
                title=titles[i][j], xlabel="callback记录序号" if i == 0 else "求解器秒数"
            )
            axes[i, j].grid(alpha=0.2)
    axes[0, 1].set_yscale("log")
    axes[1, 1].set_yscale("log")
    axes[0, 2].axhline(1.5, color="#dc2626", ls="--")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside lower center", ncol=4)
    fig.suptitle(
        f"场景{data['scene']}：真实迭代及时间进展（星号为最终1m认证采用进尺；停止不等于收敛）"
    )
    fig.savefig(folder / "convergence_iteration_and_time.png", bbox_inches="tight")
    plt.close(fig)
    init = json.loads((folder.parent / "initialization.json").read_text())
    parts = init.get("timing_breakdown", {})
    fig, ax = plt.subplots(figsize=(9, 4), layout="constrained")
    bottom = 0.0
    for label, key, color in [
        ("几何/目标拟合", "geometric_fit_seconds", "#0d9488"),
        ("几何可行性恢复", "geometric_feasibility_restoration_seconds", "#ec4899"),
        ("全约束恢复", "feasibility_restoration_seconds", "#a78bfa"),
        ("独立1m核验", "final_1m_verification_seconds", "#2563eb"),
        ("粗检查/种子与控制", "coarse_constraint_validation_and_control_seconds", "#f59e0b"),
    ]:
        value = parts.get(key, 0.0)
        ax.bar(["公共初值"], [value], bottom=[bottom], label=f"{label}: {value:.6f}s", color=color)
        bottom += value
    ax.set(
        title=f"场景{data['scene']}公共初值构建：合计{init['elapsed_seconds']:.6f}s（四算法共享）",
        ylabel="秒",
    )
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1))
    fig.savefig(folder / "initialization_time.png", bbox_inches="tight")
    plt.close(fig)


def create_index(out, reports):
    scenes = list(dict.fromkeys(r["scenario"] for r in reports))
    rows = []
    for r in reports:
        c = r.get("final_check") or {}
        fmt = lambda v: "—" if v is None else f"{v:.6f}"
        rows.append(
            [
                r["scenario"],
                r["algorithm"],
                "通过" if c.get("feasible") else "无认证结果",
                fmt(r.get("final_total_length_m")),
                fmt(r.get("full_well_final_MD_m")),
                f"{r['complete_flow_seconds']:.3f}",
                fmt(c.get("position_error_m")),
                fmt(c.get("minimum_sf")),
            ]
        )
    links = "".join(
        f'<li><a href="scene_{s}/场景{s}_再规划对比.html">场景{s}：轨迹交互图、初值构建、四算法原理与流程、收敛曲线和完整结果</a></li>'
        for s in scenes
    )
    count = reports[0].get("n_segments", 3) if reports else 3
    constant = bool(reports and reports[0].get("arc_segment_model") == "constant_toolface")
    curve = "恒曲率恒工具面段" if constant else "圆弧"
    path = (
        "—".join(
            curve if reports[0].get("trajectory_mode") == "arc" or i % 2 == 0 else "直线"
            for i in range(count)
        )
        if reports
        else ""
    )
    successes = sum(bool(r.get("solver_success")) for r in reports)
    feasible = sum(bool((r.get("final_check") or {}).get("feasible")) for r in reports)
    (out / "index.html").write_text(
        '<!doctype html><meta charset="utf-8"><title>ABC再规划结果</title><style>body{font:16px/1.8 Arial,PingFang SC,sans-serif;max-width:1400px;margin:40px auto;padding:20px}table{border-collapse:collapse;width:100%}th,td{padding:10px;border:1px solid #ddd}th{background:#183653;color:white}a{color:#1762a3}</style><h1>A / B / C 井1再规划对比</h1><p>统一Rev.0默认参数，'
        + html.escape(path)
        + "；共同靶点N=-1333、E=1000、D=2200 m；DLS&lt;6°/30m，终点误差≤0.5 m。SF=D/[k(r1+r2)]，k=1，SF&gt;1.5及中心距&gt;5 m。</p><ul>"
        + links
        + '</ul><p>每场景报告均包含：公共可行初值的构建公式与实测耗时、算法原理及执行流程、约束参与方式、按迭代和秒数绘制的收敛曲线，以及初筛/细化/误差传播等模块耗时。完整说明另见 <a href="../../optimization_algorithms.md">算法原理与流程</a>、<a href="../../scenario_replanning.md">再规划使用说明</a>。</p>'
        + table(
            [
                "场景",
                "算法",
                "采用轨迹可行",
                "新段进尺m",
                "全井最终MD m",
                "完整流程s",
                "中靶误差m",
                "最小SF",
            ],
            rows,
        )
        + f"<p>单次同初值算法对比，未宣称全局最优。{feasible}/{len(reports)}条采用轨迹通过复评；{successes}/{len(reports)}个求解器成功终止。求解器停止原因、最终可行性和采用来源分别报告。每场景HTML均内嵌图表与结果，可单文件离线打开。</p>",
        encoding="utf-8",
    )


def render_saved_scene(folder, settings):
    """Rebuild presentation from recorded numerical results, without optimizing again."""
    import time

    from wellpath.data_io.scenarios import prepare_scene

    begin = time.perf_counter()
    folder = Path(folder)
    scene = folder.name[-1]
    data = prepare_scene(scene, settings)
    covdir = folder / "neighbor_covariance"
    covdir.mkdir(exist_ok=True)
    for n in data["neighbors"]:
        np.savez_compressed(
            covdir / artifact_name(f"{n['scan']['name']}.npz"),
            md_m=n["scan"]["md"],
            cov_nev_m2=n["scan"]["cov"],
            survey_md_m=n["stations"]["md"],
            survey_cov_nev_m2=n["stations"]["cov"],
        )
    reports = json.loads((folder / "algorithm_results.json").read_text())

    def load_track(path, label):
        with (path / f"{label}_trajectory.csv").open(encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
        with np.load(path / f"{label}_uncertainty.npz") as u:
            cov = u["cov_nev_m2"].copy()
            radius = u["radius_m"].copy()
        segments = json.loads((path / f"{label}_segments.json").read_text())
        return dict(
            md=np.array([float(r["MD_m"]) for r in rows]),
            positions=np.array([[float(r[k]) for k in ("N_m", "E_m", "D_m")] for r in rows]),
            minimum_sf=np.array([float(r["minimum_SF"]) for r in rows]),
            cov=cov,
            radius=radius,
            physical=np.array(
                [
                    [r["dls_deg_per_30m"], r["initial_toolface_deg"] or 0.0, r["length_m"]]
                    for r in segments
                ]
            ),
        )

    tracks = {r["algorithm"]: load_track(folder / r["algorithm"], "selected") for r in reports}
    initial = load_track(folder, "shared_initial")
    create_scene_html(
        folder,
        data,
        settings,
        reports,
        tracks,
        initial,
        json.loads((folder / "initialization.json").read_text()),
        json.loads((folder / "fixed_history_evaluation.json").read_text()),
    )
    timing_path = folder / "scene_timing.json"
    if timing_path.exists():
        timing = json.loads(timing_path.read_text())
        timing["presentation_rebuild_seconds"] = time.perf_counter() - begin
        timing_path.write_text(json.dumps(timing, ensure_ascii=False, indent=2) + "\n")
