"""Read-only field scenario ingestion, history preservation and audited MC sampling."""

import hashlib
from xml.etree import ElementTree as ET
from zipfile import ZipFile

import numpy as np
from openpyxl import load_workbook

from wellpath.anticollision.error_models.propagation import REV0_DEFAULTS, rev0_covariance
from wellpath.anticollision.uncertainty import interpolate_cov
from wellpath.geometry.arc import minimum_curvature_increment, tangent
from wellpath.geometry.minimum_curvature import interpolate_minimum_curvature
from wellpath.paths import PROJECT_ROOT

ROOT = PROJECT_ROOT
TARGET = dict(position_m=[-1333.0, 1000.0, 2200.0], inclination_deg=89.0, azimuth_deg=145.9)


def read_workbook(path):
    book = load_workbook(path, read_only=True, data_only=True)
    wells = {}
    try:
        for sh in book:
            rows = []
            source = []
            for j, row in enumerate(sh.values, 1):
                if j <= 2 or not row or not isinstance(row[0], (int, float)):
                    continue
                rows.append(row[:6])
                source.append(j)
            a = np.asarray(rows, dtype=np.float64)
            if (
                a.ndim != 2
                or a.shape[1] != 6
                or not np.isfinite(a).all()
                or np.any(np.diff(a[:, 0]) <= 0)
            ):
                raise ValueError(f"{path}:{sh.title}: invalid MD/attitude/coordinates")
            wells[sh.title] = dict(
                name=sh.title,
                md=a[:, 0],
                inc=a[:, 1],
                azi=a[:, 2],
                positions=a[:, [5, 4, 3]],
                source_rows=np.array(source),
            )
    finally:
        book.close()
    if set(wells) != {f"井{i}" for i in range(1, 11)}:
        raise ValueError("Expected ten wells")
    return wells


def mc_residual(w):
    t = tangent(w["inc"], w["azi"]).T
    # tangent utility also accepts arrays.
    residual = []
    for j in range(len(w["md"]) - 1):
        residual.append(
            np.linalg.norm(
                minimum_curvature_increment(t[j], t[j + 1], w["md"][j + 1] - w["md"][j])
                - (w["positions"][j + 1] - w["positions"][j])
            )
        )
    return float(max(residual, default=0.0))


def sample_well(w, step, extra=()):
    md = w["md"]
    fractional = md[abs(md - np.round(md)) > 1e-7]
    query = np.unique(np.r_[np.arange(md[0], md[-1], step), fractional, extra, md[0], md[-1]])
    query = query[(query >= md[0]) & (query <= md[-1])]
    positions, inc, azi = interpolate_minimum_curvature(
        md, w["inc"], w["azi"], w["positions"], query
    )
    return dict(name=w["name"], md=query, positions=positions, inc=inc, azi=azi)


def prepare_scene(scene, settings):
    folder = ROOT / "data/scenarios" / f"scenario_{scene.lower()}"
    actual_path = folder / f"scenario_{scene.lower()}_actual.xlsx"
    design_path = folder / "trajectory_1m_collision.xlsx"
    actual = read_workbook(actual_path)
    design = read_workbook(design_path)
    with ZipFile(folder / f"scenario_{scene.lower()}_description.docx") as z:
        description = "".join(ET.fromstring(z.read("word/document.xml")).itertext())
    for token in ("-1333", "1000", "2200", "89", "145.9"):
        if token not in description:
            raise ValueError("Target differs from configured common target")
    current = actual["井1"]
    history = sample_well(current, settings["history_survey_interval_m"], extra=[996.0])
    # History remains from MD zero; covariance is never reset at the replan point.
    params = dict(REV0_DEFAULTS, **settings["uncertainty_model"].get("parameters", {}))
    cov0 = np.asarray(settings["start_cov_nev_m2"])
    neighbors = []
    for i in range(2, 11):
        w = actual[f"井{i}"]
        stations = sample_well(w, settings["history_survey_interval_m"])
        r = rev0_covariance(
            stations["md"], stations["inc"], stations["azi"], stations["positions"], params
        )
        stations["cov"] = r["cov"] + cov0
        stations["radius"] = np.sqrt(np.maximum(np.linalg.eigvalsh(stations["cov"])[:, -1], 0))
        scan = dict(w)
        scan["cov"] = interpolate_cov(stations["md"], stations["cov"], w["md"])
        scan["radius"] = np.sqrt(np.maximum(np.linalg.eigvalsh(scan["cov"])[:, -1], 0))
        opt = sample_well(w, settings["neighbor_optimization_step_m"])
        opt["cov"] = interpolate_cov(stations["md"], stations["cov"], opt["md"])
        opt["radius"] = np.sqrt(np.maximum(np.linalg.eigvalsh(opt["cov"])[:, -1], 0))
        neighbors.append(dict(raw=w, stations=stations, scan=scan, opt=opt))
    audit = dict(
        scene=scene,
        description=description,
        common_target=TARGET,
        sources=[
            dict(path=str(p.resolve()), sha256=hashlib.sha256(p.read_bytes()).hexdigest())
            for p in (
                actual_path,
                design_path,
                folder / f"scenario_{scene.lower()}_description.docx",
            )
        ],
        actual_wells={
            name: dict(
                points=len(w["md"]), end_md_m=float(w["md"][-1]), max_MC_residual_m=mc_residual(w)
            )
            for name, w in actual.items()
        },
        tie_in=dict(
            md_m=float(current["md"][-1]),
            position_m=current["positions"][-1].tolist(),
            inclination_deg=float(current["inc"][-1]),
            azimuth_deg=float(current["azi"][-1]),
        ),
        original_design_endpoint_to_common_target_m=float(
            np.linalg.norm(design["井1"]["positions"][-1] - TARGET["position_m"])
        ),
        planned_history_station_count=len(history["md"]),
        parameters=params,
        initial_cov_nev_m2=cov0.tolist(),
        original_coordinates_preserved=True,
        azimuth_reference="grid; Rev0 geographic azimuth assumed grid=true with convergence 0 deg; declination 2 deg is model default",
        assumptions=[
            "1 m interpolated points are not independent measurements; uncertainty propagated on synthetic 30 m stations plus fractional segment endpoints and known deviation MD996.",
            "Rev0 current defaults retained, not field-calibrated; actual station times/tool calibration/field reference metadata are unavailable.",
            "Only new section of well1 is controllable. Fixed drilled history evaluated separately and never altered.",
            "Nominal point coordinates retained; max MC mismatch audited. No additional arbitrary 0.5 m position prior.",
        ],
    )
    return dict(
        scene=scene,
        actual=actual,
        design=design,
        history=history,
        neighbors=neighbors,
        audit=audit,
        parameters=params,
    )


def trajectory_bounds(s):
    """Scene bounds shared by continuous and finite-set dispatchers."""
    default = dict(
        dls_deg_per_30m=[s["arc_dls_lower_deg_per_30m"], s["dls_upper_deg_per_30m"]],
        start_toolface_deg=s.get("toolface_bounds_deg", [-180.0, 180.0]),
        length_m=s["arc_length_bounds_m"],
    )
    if "toolface_control" in s:
        default["toolface_control"] = s["toolface_control"]
    overrides = {
        str(i): dict(length_m=s["straight_length_bounds_m"])
        for i in range(2, s.get("n_segments", 3) + 1, 2)
        if s.get("trajectory_mode", "arc-straight") == "arc-straight"
    }
    raw = s.get("segment_bounds", {})
    if isinstance(raw, list):
        if raw and len(raw) != s.get("n_segments", 3):
            raise ValueError("segment_bounds list must match n_segments")
        raw = {str(i + 1): v for i, v in enumerate(raw)}
    if not isinstance(raw, dict):
        raise ValueError("segment_bounds must be an object or list")
    for key, value in raw.items():
        if (
            not isinstance(key, str)
            or not key.isdigit()
            or str(int(key)) != key
            or not 1 <= int(key) <= s.get("n_segments", 3)
        ):
            raise ValueError("Invalid scene segment_bounds index")
        overrides.setdefault(key, {}).update(value)
    return default, overrides


def problem_configuration(data, s):
    start = data["audit"]["tie_in"]
    history = data["history"]
    default, overrides = trajectory_bounds(s)
    return dict(
        description=f"Scenario {data['scene']}; actual well1 replan; nine drilled offsets; common documented target",
        trajectory_mode=s.get("trajectory_mode", "arc-straight"),
        n_segments=s.get("n_segments", 3),
        arc_segment_model=s.get("arc_segment_model", "minimum_curvature"),
        start=dict(
            position_m=start["position_m"],
            inclination_deg=start["inclination_deg"],
            azimuth_deg=start["azimuth_deg"],
        ),
        target=dict(
            TARGET,
            position_mode="sphere",
            position_tolerance_m=s["target_position_tolerance_m"],
            inclination_tolerance_deg=s["target_inclination_tolerance_deg"],
            azimuth_tolerance_deg=s["target_azimuth_tolerance_deg"],
        ),
        default_segment_bounds=default,
        segment_bounds=overrides,
        inclination_bounds_deg=s["inclination_bounds_deg"],
        max_segment_bend_deg=s["max_segment_bend_deg"],
        max_dls_deg_per_30m=s["dls_upper_deg_per_30m"],
        solver=s["solver"],
        iscwsa=dict(
            sf_method=s["sf_method"],
            k_sigma=s["k_sigma"],
            sf_threshold=s["sf_threshold"],
            optimization_sf_buffer=s["optimization_sf_buffer"],
            centerline_min_distance_m=s["centerline_min_distance_m"],
            centerline_optimization_buffer_m=s["centerline_buffer_m"],
            planned=dict(
                uncertainty_model=s["uncertainty_model"],
                start_cov_nev_m2=s["start_cov_nev_m2"],
                start_md_m=start["md_m"],
                survey_interval_m=s["planned_survey_max_step_m"],
                history=dict(
                    md_m=history["md"].tolist(),
                    inclination_deg=history["inc"].tolist(),
                    azimuth_deg=history["azi"].tolist(),
                    positions_m=history["positions"].tolist(),
                ),
            ),
            neighbors=[],
        ),
    )
