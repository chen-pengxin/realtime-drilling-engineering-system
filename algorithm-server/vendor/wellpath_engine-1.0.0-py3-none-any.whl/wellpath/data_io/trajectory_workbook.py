"""Full-precision XLSX trajectory input."""

import numpy as np


def _normal_header(value):
    return "".join(ch.lower() for ch in str(value) if ch.isalnum() or "\u4e00" <= ch <= "\u9fff")


def load_xlsx_trajectory(path, settings=None):
    """Read full-precision MD/N/E/D trajectory points from an XLSX sheet.

    ``header_row`` is one-based and defaults to row 2, matching the supplied
    field workbooks (title in row 1, headers in row 2). Values are converted
    directly to float64; displayed Excel rounding is never used.
    """
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise ImportError("XLSX trajectory input requires openpyxl>=3.1.") from exc
    settings = settings or {}
    wb = load_workbook(path, read_only=True, data_only=True)
    requested = settings.get("sheet_name")
    if requested is None:
        if len(wb.sheetnames) != 1:
            raise ValueError("XLSX input has multiple sheets; set survey.sheet_name explicitly.")
        requested = wb.sheetnames[0]
    if requested not in wb.sheetnames:
        raise ValueError(f"XLSX sheet {requested!r} not found; available: {wb.sheetnames}.")
    ws = wb[requested]
    header_row = int(settings.get("header_row", 2))
    if header_row < 1:
        raise ValueError("XLSX header_row is one-based and must be >=1.")
    rows = ws.iter_rows(values_only=True)
    header = None
    for index, row in enumerate(rows, 1):
        if index == header_row:
            header = list(row)
            break
    if header is None:
        raise ValueError("XLSX header_row is beyond the worksheet.")
    aliases = {
        "md": ("md", "测深", "measureddepth"),
        "inc": ("inc", "inclination", "井斜"),
        "azi": ("azi", "azimuth", "方位", "网格方位"),
        "tvd": ("tvd", "verticaldepth", "垂深", "深度", "d"),
        "east": ("east", "easting", "东坐标", "e"),
        "north": ("north", "northing", "北坐标", "n"),
    }
    normalized = [_normal_header(x) for x in header]
    columns = {}
    configured = settings.get("columns", {})
    for key, choices in aliases.items():
        wanted = configured.get(key)
        if wanted is not None:
            wanted = _normal_header(wanted)
            matches = [i for i, name in enumerate(normalized) if name == wanted]
        else:
            matches = [
                i
                for i, name in enumerate(normalized)
                if any(
                    name == choice if len(choice) == 1 else _normal_header(choice) in name
                    for choice in choices
                )
            ]
        if matches:
            columns[key] = matches[0]
    required = ("md", "north", "east", "tvd")
    if any(key not in columns for key in required):
        raise ValueError(
            f"XLSX trajectory needs MD, north, east and TVD columns; found headers {header!r}."
        )
    data = []
    for row_number, row in enumerate(rows, header_row + 1):
        if not row or columns["md"] >= len(row) or row[columns["md"]] in (None, ""):
            continue
        try:
            values = {
                key: float(row[index])
                for key, index in columns.items()
                if index < len(row) and row[index] not in (None, "")
            }
        except (TypeError, ValueError) as exc:
            wb.close()
            raise ValueError(
                f"XLSX sheet {requested!r} row {row_number} contains a nonnumeric trajectory value."
            ) from exc
        if not all(key in values for key in required):
            wb.close()
            raise ValueError(
                f"XLSX sheet {requested!r} row {row_number} has incomplete MD/N/E/D values."
            )
        data.append(values)
    wb.close()
    if len(data) < 2:
        raise ValueError("XLSX trajectory must contain at least two numeric points.")
    md = np.asarray([row["md"] for row in data], dtype=np.float64)
    positions = np.asarray(
        [[row["north"], row["east"], row["tvd"]] for row in data], dtype=np.float64
    )
    if not np.isfinite(md).all() or not np.isfinite(positions).all() or np.any(np.diff(md) <= 0):
        raise ValueError(
            "XLSX MD must be finite and strictly increasing; coordinates must be finite."
        )
    inc = np.asarray([row.get("inc", 0.0) for row in data], dtype=np.float64)
    azi = np.asarray([row.get("azi", 0.0) for row in data], dtype=np.float64)
    return dict(
        md=md,
        inc=inc,
        azi=azi,
        positions=positions,
        source_path=str(path),
        sheet_name=requested,
        source_kind="xlsx",
        has_attitude=("inc" in columns and "azi" in columns),
    )
