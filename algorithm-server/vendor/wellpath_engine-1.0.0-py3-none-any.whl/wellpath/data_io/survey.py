"""Survey import adapters and explicit coordinate/azimuth normalization."""

from __future__ import annotations

import csv
import re
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np

from wellpath.geometry.arc import minimum_curvature_increment, tangent

ALIASES = {
    "md": ("md", "measureddepth", "测深", "depth"),
    "inc": ("inc", "inclination", "井斜", "incl"),
    "azi": ("azi", "azimuth", "方位"),
    "tvd": ("tvd", "verticaldepth", "垂深"),
    "north": ("north", "northing", "dispns", "北坐标", "北位移", "n"),
    "east": ("east", "easting", "dispew", "东坐标", "东位移", "e"),
}


def _norm(value):
    return "".join(c.lower() for c in str(value) if c.isalnum() or "\u4e00" <= c <= "\u9fff")


def _column_map(headers, configured):
    normalized = [_norm(h) for h in headers]
    result = {}
    for key, names in ALIASES.items():
        wanted = configured.get(key)
        if wanted is not None:
            match = [i for i, value in enumerate(normalized) if value == _norm(wanted)]
        else:
            match = [
                i
                for i, value in enumerate(normalized)
                if any(
                    value == _norm(name) if len(name) == 1 else _norm(name) in value
                    for name in names
                )
            ]
        if match:
            result[key] = match[0]
    return result


def _read_delimited(path, settings):
    lines = Path(path).read_text(encoding=settings.get("encoding", "utf-8-sig")).splitlines()
    header_row = int(settings.get("header_row", 1))
    if not 1 <= header_row <= len(lines):
        raise ValueError("Text survey header_row is one-based and must exist.")
    header = lines[header_row - 1]
    delimiter = settings.get("delimiter")
    if delimiter is None:
        try:
            delimiter = (
                csv.Sniffer()
                .sniff("\n".join(lines[header_row - 1 : header_row + 10]), delimiters=",;\t|")
                .delimiter
            )
        except csv.Error:
            delimiter = None
    split = (
        (lambda value: next(csv.reader([value], delimiter=delimiter)))
        if delimiter
        else (lambda value: re.split(r"\s+", value.strip()))
    )
    headers = split(header)
    columns = _column_map(headers, settings.get("columns", {}))
    rows = []
    for line_no, line in enumerate(lines[header_row:], header_row + 1):
        if not line.strip() or line.lstrip().startswith(("#", "//")):
            continue
        fields = split(line)
        record = {
            key: fields[index]
            for key, index in columns.items()
            if index < len(fields) and fields[index].strip()
        }
        if not record:
            continue
        try:
            rows.append({key: float(value) for key, value in record.items()})
        except ValueError as exc:
            raise ValueError(f"{path}:{line_no} contains a nonnumeric survey value.") from exc
    return rows


def _read_xlsx(path, settings):
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise ImportError("XLSX survey input requires openpyxl>=3.1.") from exc
    wb = load_workbook(path, read_only=True, data_only=True)
    sheet = settings.get("sheet_name")
    if sheet is None:
        if len(wb.sheetnames) != 1:
            wb.close()
            raise ValueError("Multi-sheet XLSX input requires sheet_name.")
        sheet = wb.sheetnames[0]
    if sheet not in wb.sheetnames:
        wb.close()
        raise ValueError(f"Unknown XLSX sheet {sheet!r}.")
    ws = wb[sheet]
    header_row = int(settings.get("header_row", 2))
    rows = ws.iter_rows(values_only=True)
    header = None
    for n, row in enumerate(rows, 1):
        if n == header_row:
            header = list(row)
            break
    if header is None:
        wb.close()
        raise ValueError("XLSX header_row is beyond worksheet end.")
    columns = _column_map(header, settings.get("columns", {}))
    records = []
    if "md" not in columns:
        wb.close()
        raise ValueError("XLSX survey needs an MD column; configure columns.md.")
    for line_no, row in enumerate(rows, header_row + 1):
        if not row or columns.get("md", -1) >= len(row) or row[columns["md"]] in (None, ""):
            continue
        record = {
            key: row[index]
            for key, index in columns.items()
            if index < len(row) and row[index] not in (None, "")
        }
        try:
            records.append({key: float(value) for key, value in record.items()})
        except (TypeError, ValueError) as exc:
            wb.close()
            raise ValueError(f"XLSX row {line_no} has nonnumeric survey values.") from exc
    wb.close()
    return records


def _xml_value(element, names):
    children = {
        child.tag.rsplit("}", 1)[-1].lower(): child
        for child in element.iter()
        if child is not element
    }
    for name in names:
        child = children.get(name.lower())
        if child is None or child.text is None:
            continue
        value = float(child.text)
        unit = (child.attrib.get("uom") or child.attrib.get("unit") or "").lower()
        if unit in ("ft", "feet", "foot"):
            value *= 0.3048
        elif unit in ("rad", "radian", "radians") and name in (
            "incl",
            "inclination",
            "azi",
            "azimuth",
        ):
            value = np.rad2deg(value)
        return value
    return None


def _read_witsml(path):
    root = ET.parse(path).getroot()
    stations = []
    for element in root.iter():
        if element.tag.rsplit("}", 1)[-1].lower() != "trajectorystation":
            continue
        record = {
            "md": _xml_value(element, ("md", "measuredDepth")),
            "inc": _xml_value(element, ("incl", "inclination")),
            "azi": _xml_value(element, ("azi", "azimuth")),
            "tvd": _xml_value(element, ("tvd", "trueVerticalDepth")),
            "north": _xml_value(element, ("dispNs", "northing")),
            "east": _xml_value(element, ("dispEw", "easting")),
        }
        stations.append({key: value for key, value in record.items() if value is not None})
    if len(stations) < 2:
        raise ValueError("WITSML XML needs at least two trajectoryStation elements.")
    return stations


def normalize_survey(records, settings=None):
    """Normalize into true-north N/E/D; reconstruct missing positions using MC.

    East declination and convergence are positive: Atrue=Amag+declination,
    Atrue=Agrid+convergence. Origin and target must use the same projected CRS.
    """
    settings = settings or {}
    if len(records) < 2 or any("md" not in row for row in records):
        raise ValueError("Survey needs at least two numeric MD stations.")
    length_unit = str(settings.get("length_unit", "m")).lower()
    angle_unit = str(settings.get("angle_unit", "deg")).lower()
    if length_unit not in ("m", "ft"):
        raise ValueError("length_unit must be m or ft.")
    if angle_unit not in ("deg", "rad"):
        raise ValueError("angle_unit must be deg or rad.")
    scale = 0.3048 if length_unit == "ft" else 1.0
    md = np.asarray([row["md"] for row in records], dtype=np.float64) * scale
    has_attitude = all("inc" in row and "azi" in row for row in records)
    partial = any("inc" in row or "azi" in row for row in records)
    if partial and not has_attitude:
        raise ValueError("Inclination and azimuth must both be present at every station.")
    inc = np.asarray([row.get("inc", 0.0) for row in records], dtype=np.float64)
    azi = np.asarray([row.get("azi", 0.0) for row in records], dtype=np.float64)
    if angle_unit == "rad":
        inc = np.rad2deg(inc)
        azi = np.rad2deg(azi)
    if (
        not np.isfinite(np.c_[md, inc, azi]).all()
        or np.any(md < 0)
        or np.any(np.diff(md) <= 0)
        or np.any((inc < 0) | (inc > 180))
    ):
        raise ValueError(
            "Survey needs finite, nonnegative increasing MD and inclination in [0,180]."
        )
    reference = str(settings.get("azimuth_reference", "true")).lower()
    declination = float(settings.get("magnetic_declination_deg", 0.0))
    convergence = float(settings.get("grid_convergence_deg", 0.0))
    if not np.isfinite([declination, convergence]).all():
        raise ValueError("Coordinate correction angles must be finite.")
    if reference == "magnetic":
        azi += declination
    elif reference == "grid":
        azi += convergence
    elif reference != "true":
        raise ValueError("azimuth_reference must be true, grid or magnetic.")
    azi %= 360.0
    has_positions = all(all(key in row for key in ("north", "east", "tvd")) for row in records)
    partial_positions = any(any(key in row for key in ("north", "east")) for row in records)
    if partial_positions and not has_positions:
        raise ValueError(
            "Provide all N/E/TVD coordinates, or supply only MD/inclination/azimuth for reconstruction."
        )
    origin = np.asarray(settings.get("wellhead_nev_m", [0.0, 0.0, 0.0]), dtype=np.float64)
    if origin.shape != (3,) or not np.isfinite(origin).all():
        raise ValueError("wellhead_nev_m must contain three finite metres.")
    coordinate_reference = str(settings.get("coordinate_reference", "true")).lower()
    if coordinate_reference not in ("true", "grid"):
        raise ValueError("coordinate_reference must be true or grid.")
    angle = np.deg2rad(convergence)
    if has_positions:
        positions = (
            np.asarray(
                [[row["north"], row["east"], row["tvd"]] for row in records], dtype=np.float64
            )
            * scale
        )
        if coordinate_reference == "grid":
            # Rotate displacement vectors, never large absolute eastings about zero.
            pivot = np.zeros(3) if settings.get("coordinates_are_offsets", False) else origin
            if (
                not settings.get("coordinates_are_offsets", False)
                and "wellhead_nev_m" not in settings
            ):
                raise ValueError(
                    "Absolute grid coordinates require a wellhead_nev_m rotation pivot."
                )
            n, e = (positions - pivot)[:, :2].T
            positions[:, 0] = n * np.cos(angle) - e * np.sin(angle) + pivot[0]
            positions[:, 1] = n * np.sin(angle) + e * np.cos(angle) + pivot[1]
        if settings.get("coordinates_are_offsets", False):
            positions += origin
    else:
        if not has_attitude:
            raise ValueError("Survey needs N/E/TVD positions or MD/inclination/azimuth.")
        if "start_position_nev_m" in settings:
            start = np.asarray(settings["start_position_nev_m"], dtype=np.float64)
        elif abs(md[0]) < 1e-9:
            start = origin.copy()
        else:
            raise ValueError(
                "A survey starting below MD zero requires start_position_nev_m at its first MD."
            )
        if start.shape != (3,) or not np.isfinite(start).all():
            raise ValueError("start_position_nev_m must contain three metres.")
        positions = np.empty((len(md), 3), dtype=np.float64)
        positions[0] = start
        for i in range(len(md) - 1):
            positions[i + 1] = positions[i] + minimum_curvature_increment(
                tangent(inc[i], azi[i]), tangent(inc[i + 1], azi[i + 1]), md[i + 1] - md[i]
            )
    if not np.isfinite(positions).all():
        raise ValueError("Survey positions must be finite.")
    return dict(
        md=md,
        inc=inc,
        azi=azi,
        positions=positions,
        has_attitude=has_attitude,
        coordinate_reference="true",
        azimuth_reference="true",
        coordinate_source="supplied" if has_positions else "minimum_curvature",
        source_kind=settings.get("source_kind", "survey"),
    )


def load_survey(path, settings=None):
    settings = dict(settings or {})
    path = Path(path)
    kind = str(settings.get("format", path.suffix.lstrip("."))).lower()
    if kind in ("xlsx", "xlsm"):
        records = _read_xlsx(path, settings)
    elif kind in ("csv", "txt", "dat", "prn"):
        records = _read_delimited(path, settings)
    elif kind in ("witsml", "xml"):
        records = _read_witsml(path)
    else:
        raise ValueError(f"Unsupported survey format {kind!r}; use XLSX, CSV, TXT or WITSML XML.")
    settings["source_kind"] = kind
    if kind in ("witsml", "xml"):
        settings["length_unit"] = "m"
        settings["angle_unit"] = "deg"
    return normalize_survey(records, settings)
