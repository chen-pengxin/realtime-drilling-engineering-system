"""ASCII artifact filenames without altering user-facing well names."""

import hashlib
import re


def artifact_name(value):
    """Keep English names, translate numbered wells, hash other Unicode names.

    Only call on a filename component, not on an absolute path or a well label.
    Existing numbered-well caches use the same well_14 spelling.
    """
    value = re.sub(r"井(\d+)", r"well_\1", str(value))
    if value.isascii():
        return value
    return re.sub(
        r"[^\x00-\x7f]+",
        lambda m: "u_" + hashlib.sha256(m.group().encode("utf-8")).hexdigest()[:12],
        value,
    )
