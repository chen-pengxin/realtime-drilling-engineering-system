"""Single executable entry point; workflow dependencies are loaded on demand."""

import argparse
import json
import sys

WORKFLOWS = {
    "plan": "workflows.planning_experiments",
    "scan": "workflows.uncertainty_comparison",
    "scan-clusters": "workflows.cluster_comparison",
    "replan": "workflows.scenario_replanning",
    "compare-segments": "workflows.segment_comparison",
    "compare-geometries": "workflows.geometry_comparison",
    "replan-local": "workflows.local_replanning",
    "initialize-splice": "optimization.splice_initialization",
    "update-local": "workflows.incremental_update",
    "report-local": "reports.local_replanning",
    "install-local-workbook": "exports.local_workbook",
    "install-cluster-workbooks": "exports.cluster_workbook",
    "report-clusters": "reports.cluster_comparison",
    "report-scan": "reports.uncertainty_comparison",
    "report-radius": "reports.radius_sensitivity",
    "compare-paper-models": "workflows.paper_comparison",
    "demo-models": "examples.error_models",
    "demo-toolface": "examples.constant_toolface",
}


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] in WORKFLOWS:
        command, rest = argv[0], argv[1:]
        # Preserve each workflow's existing arguments, including its own --help.
        original = sys.argv
        try:
            sys.argv = [f"wellpath {command}", *rest]
            import runpy

            runpy.run_module(f"wellpath.{WORKFLOWS[command]}", run_name="__main__")
        finally:
            sys.argv = original
        return
    parser = argparse.ArgumentParser(
        prog="wellpath",
        description="Well trajectory planning and collision evaluation",
        epilog="Workflow commands: " + ", ".join(WORKFLOWS),
    )
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("models", help="List registered error models")
    profile = sub.add_parser("model-config", help="Print a model parameter profile as JSON")
    profile.add_argument("name", nargs="?", default="iscwsa_rev0")
    args = parser.parse_args(argv)
    if args.command == "models":
        from .anticollision.error_models.registry import MODEL_NAMES

        print("\n".join(MODEL_NAMES))
    elif args.command == "model-config":
        from .anticollision.error_models.registry import load_model_settings

        print(json.dumps(load_model_settings(args.name), indent=2))
    else:
        parser.print_help()
