"""Enable python -m wellpath."""

from .cli import main

if __name__ == "__main__":
    main()
