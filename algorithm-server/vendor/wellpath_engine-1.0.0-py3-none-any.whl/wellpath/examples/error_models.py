"""Reproduce the manual's eight uncertainty-model examples, without collision code.

Run: python src/wellpath/configs/experiments/error_models.py --output configs/experiments/uncertainty_model_results.json
"""

from __future__ import annotations

import argparse
import importlib.metadata
import json
from pathlib import Path

import numpy as np

from wellpath.anticollision.uncertainty import (
    empirical_covariance,
    make_survey,
    scalar_radius,
    simplified_mwd_uncertainty,
)


def examples():
    results = {}
    specs = {
        "constant_covariance": dict(
            type="constant_covariance", cov_nev_m2=[[0.25, 0.06, 0], [0.06, 0.36, 0], [0, 0, 0.49]]
        ),
        "constant_isotropic": dict(type="constant_isotropic", sigma_m=0.5),
        "linear_std": dict(
            type="linear_std",
            depth_origin_m=0,
            sigma0_nev_m=[0.5, 0.5, 0.5],
            slope_nev_per_m=[0.001, 0.001, 0.002],
            correlation=[[1, 0.2, 0], [0.2, 1, 0], [0, 0, 1]],
        ),
        "random_walk": dict(
            type="random_walk",
            depth_origin_m=0,
            sigma0_nev_m=[0.5, 0.5, 0.5],
            q_nev_m2_per_m=[0.0001, 0.0001, 0.0002],
        ),
        "tabulated_covariance": dict(
            type="tabulated_covariance",
            md_m=[0, 1000],
            cov_nev_m2=[
                np.diag([0.25, 0.25, 0.25]).tolist(),
                [[1, 0.1, 0], [0.1, 1.44, 0], [0, 0, 2.25]],
            ],
        ),
    }
    for kind, spec in specs.items():
        if kind == "random_walk":
            md = [0, 1000, 4000]
        elif kind == "constant_covariance":
            md = [0, 1000, 2000]
        else:
            md = [0, 500, 1000]
        cov = empirical_covariance(md, {"uncertainty_model": spec})
        results[kind] = dict(
            configuration=spec,
            md_m=md,
            cov_nev_m2=cov.tolist(),
            std_nev_m=np.sqrt(np.diagonal(cov, axis1=1, axis2=2)).tolist(),
        )
    md = [0, 500, 501, 1000, 1500, 1800, 2000]
    spec = {"type": "md_scalar_radius"}
    results["md_scalar_radius"] = dict(
        configuration=spec,
        md_m=md,
        radius_m=scalar_radius(md, {"uncertainty_model": spec}).tolist(),
    )

    md = [0.0, 1000.0, 2000.0]
    inc = [30.0] * 3
    spec = dict(
        type="simplified_mwd",
        sigma_md_m=0.6,
        sigma_inc_deg=0.2,
        sigma_azi_deg=0.3,
        depth_origin_m=0.0,
    )
    mwd = simplified_mwd_uncertainty(md, inc, {"uncertainty_model": spec})
    results["simplified_mwd"] = dict(
        configuration=spec,
        md_m=md,
        inclination_deg=inc,
        **{
            key: (value.tolist() if isinstance(value, np.ndarray) else value)
            for key, value in mwd.items()
            if key != "cov"
        },
        cov_nev_m2=mwd["cov"].tolist(),
    )

    settings = dict(
        error_model="ISCWSA MWD Rev5.11",
        header=dict(
            latitude=40.0,
            longitude=116.0,
            b_total=50000.0,
            dip=60.0,
            declination=0.0,
            convergence=0.0,
            azi_reference="true",
        ),
        start_cov_nev_m2=(0.25 * np.eye(3)).tolist(),
    )
    md = [0.0, 100.0, 200.0]
    positions = [[100.0, 200.0, 0.0], [100.0, 200.0, 100.0], [100.0, 200.0, 200.0]]
    survey = make_survey(md, [0.0] * 3, [0.0] * 3, positions, settings)
    terms = {
        name: dict(propagation=term.propagation, cov_nev_m2=term.cov_NEV.tolist())
        for name, term in survey.err.errors.errors.items()
    }
    reconstructed = np.sum([term.cov_NEV for term in survey.err.errors.errors.values()], axis=0)
    reconstructed += np.asarray(settings["start_cov_nev_m2"])[None, :, :]
    discrepancy = float(np.max(np.abs(reconstructed - survey.cov_nev)))
    if discrepancy > 1e-10:
        raise ValueError(
            f"Term covariances and initial prior do not reproduce the result: {discrepancy}"
        )
    results["iscwsa"] = dict(
        configuration=settings,
        md_m=md,
        inclination_deg=[0.0] * 3,
        azimuth_deg=[0.0] * 3,
        positions_m=positions,
        cov_nev_m2=survey.cov_nev.tolist(),
        std_nev_m=np.sqrt(np.diagonal(survey.cov_nev, axis1=1, axis2=2)).tolist(),
        iscwsa_definition=survey.err.iscwsa_definition,
        tool_term_count=len(terms),
        term_contributions=terms,
        term_reconstruction_max_abs_error_m2=discrepancy,
    )
    return dict(
        library_versions={name: importlib.metadata.version(name) for name in ("numpy", "welleng")},
        models=results,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Optional JSON output path.")
    args = parser.parse_args()
    result = examples()
    text = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
        print(f"Wrote eight model examples: {args.output}")
        print(
            "ISCWSA term reconstruction error (m²):",
            result["models"]["iscwsa"]["term_reconstruction_max_abs_error_m2"],
        )
    else:
        print(text)
