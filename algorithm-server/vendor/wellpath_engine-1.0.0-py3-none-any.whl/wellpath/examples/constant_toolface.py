"""Offline side-by-side geometry/toolface demonstration; never edits old runs."""

import csv
import html
import json
from pathlib import Path

import numpy as np
import plotly.graph_objects as go
from plotly.offline import get_plotlyjs
from plotly.subplots import make_subplots

from wellpath.geometry.arc import angles, local_basis, tangent
from wellpath.geometry.segments import segment_state
from wellpath.paths import PROJECT_ROOT
from wellpath.reports.scenario_replanning import div, table

ROOT = PROJECT_ROOT


def demonstrate(out):
    out = Path(out)
    out.mkdir(exist_ok=True, parents=True)
    controls = np.array([[3.0, 60.0, 150.0], [0.0, 0.0, 100.0], [2.5, -45.0, 180.0]])
    start = np.zeros(3)
    t0 = tangent(35, 20)
    series = {}
    checks = []
    for model in ["minimum_curvature", "constant_toolface"]:
        p = start.copy()
        t = t0.copy()
        md = 0.0
        records = []
        for j, (dls, w, length) in enumerate(controls):
            query = np.linspace(0, length, int(np.ceil(length)) + 1)
            pp, tt, nn = segment_state(p, t, dls, w, query, model)
            recovered = []
            for ti, ni in zip(tt, nn):
                ea, ep = local_basis(ti)
                recovered.append(
                    float(np.rad2deg(np.arctan2(ni @ ep, ni @ ea))) if dls > 0 else np.nan
                )
            ia = np.array([angles(ti) for ti in tt])
            values = np.array(recovered)
            for s, point, (i, a), tf in zip(query, pp, ia, values):
                records.append([j + 1, md + s, *point, i, a, tf, dls])
            if dls > 0:
                deviation = float(np.max(np.abs((values - w + 180) % 360 - 180)))
                checks.append(
                    dict(
                        model=model,
                        segment=j + 1,
                        command_toolface_deg=w,
                        reconstructed_start_toolface_deg=values[0],
                        reconstructed_end_toolface_deg=values[-1],
                        maximum_command_deviation_deg=deviation,
                    )
                )
                if model == "constant_toolface":
                    assert deviation < 1e-10
            p = pp[-1]
            t = tt[-1]
            md += length
        data = np.array(records)
        series[model] = data
        with (out / f"{model}_same_controls_trajectory.csv").open(
            "w", encoding="utf-8-sig", newline=""
        ) as f:
            w = csv.writer(f)
            w.writerow(
                [
                    "segment",
                    "relative_MD_m",
                    "N_m",
                    "E_m",
                    "D_m",
                    "inclination_deg",
                    "azimuth_deg",
                    "actual_local_toolface_deg",
                    "DLS_deg_per_30m",
                ]
            )
            w.writerows(data)
    f3 = go.Figure()
    xy = go.Figure()
    vertical = go.Figure()
    tf = go.Figure()
    ia = make_subplots(rows=1, cols=2, subplot_titles=["井斜", "方位"])
    labels = {
        "minimum_curvature": "原模型：最小曲率平面圆弧",
        "constant_toolface": "新增：段内恒曲率、恒工具面",
    }
    colors = {"minimum_curvature": "#2563eb", "constant_toolface": "#d97706"}
    for model, data in series.items():
        common = dict(
            name=labels[model],
            line=dict(color=colors[model], width=3),
            legendgroup=model,
            meta=dict(group=model),
        )
        f3.add_trace(go.Scatter3d(x=data[:, 3], y=data[:, 2], z=data[:, 4], mode="lines", **common))
        xy.add_trace(go.Scatter(x=data[:, 3], y=data[:, 2], mode="lines", **common))
        vertical.add_trace(
            go.Scatter(x=np.hypot(data[:, 2], data[:, 3]), y=data[:, 4], mode="lines", **common)
        )
        tf.add_trace(
            go.Scatter(x=data[:, 1], y=data[:, 7], mode="lines", connectgaps=False, **common)
        )
        ia.add_trace(go.Scatter(x=data[:, 1], y=data[:, 5], **common), row=1, col=1)
        ia.add_trace(
            go.Scatter(x=data[:, 1], y=data[:, 6], showlegend=False, **common), row=1, col=2
        )
    f3.update_layout(
        height=680,
        title="完全相同的起点、段长、曲率和工具面控制；不同段内几何",
        scene=dict(
            xaxis_title="东 E / m",
            yaxis_title="北 N / m",
            zaxis=dict(title="垂深 D / m", autorange="reversed"),
            aspectmode="data",
        ),
    )
    xy.update_layout(
        title="水平投影",
        height=470,
        xaxis_title="东 E / m",
        yaxis=dict(title="北 N / m", scaleanchor="x"),
    )
    vertical.update_layout(
        title="垂深—距起点水平距离",
        height=470,
        xaxis_title="水平距离 / m",
        yaxis=dict(title="D / m", autorange="reversed"),
    )
    tf.update_layout(
        title="工具面从曲率方向反算｜新增模型在各非直线段严格恒定",
        height=440,
        xaxis_title="相对测深 / m",
        yaxis_title="当地高边工具面 / °",
    )
    for x in [150.0, 250.0]:
        tf.add_vline(x=x, line_dash="dot", line_color="gray")
    tf.add_vrect(
        x0=150,
        x1=250,
        fillcolor="gray",
        opacity=0.1,
        line_width=0,
        annotation_text="直线段：工具面不定义",
    )
    ia.update_layout(title="新旧模型姿态对比", height=430)
    ia.update_xaxes(title_text="相对测深 / m")
    ia.update_yaxes(title_text="度")
    rows = [
        [
            v["model"],
            v["segment"],
            f"{v['command_toolface_deg']:.6f}",
            f"{v['reconstructed_start_toolface_deg']:.6f}",
            f"{v['reconstructed_end_toolface_deg']:.6f}",
            f"{v['maximum_command_deviation_deg']:.9f}",
        ]
        for v in checks
    ]
    solver_root = out / "solver_validation"
    solver_rows = []
    for p in sorted(solver_root.glob("*/result.json")):
        r = json.loads(p.read_text())
        c = r["final_check"]
        maximum = 0.0
        with (p.parent / "optimized_trajectory.csv").open() as f:
            data = list(csv.DictReader(f))
        solver_segments = r["segments"]
        for point in data:
            j = int(float(point["segment"])) - 1
            if solver_segments[j]["type"] == "straight":
                continue
            w = solver_segments[j]["initial_toolface_deg"]
            observed = float(point["actual_toolface_deg"])
            maximum = max(maximum, abs((observed - w + 180) % 360 - 180))
        assert maximum < 1e-10
        assert r["arc_segment_model"] == "constant_toolface" and c["feasible"]
        solver_rows.append(
            [
                r["algorithm"],
                "通过",
                "成功终止" if r["solver_success"] else "未收敛，采用已验证可行结果",
                f"{r['final_total_length_m']:.6f}",
                f"{r['optimization_seconds']:.6f}",
                f"{c['position_error_m']:.9f}",
                f"{c['minimum_sf']:.6f}",
                f"{maximum:.10f}",
                f'<a href="solver_validation/{p.parent.name}/trajectory_3d.html">轨迹</a>',
            ]
        )
    difference = float(
        np.linalg.norm(series["minimum_curvature"][-1, 2:5] - series["constant_toolface"][-1, 2:5])
    )
    config = """{
  "trajectory_mode": "arc-straight",
  "n_segments": 3,
  "arc_segment_model": "constant_toolface"
}"""
    body = f"""<header><h1>新增“段内恒工具面”｜旧模型和默认值保留</h1><p>选项<code>arc_segment_model="constant_toolface"</code>：每个非直线段从起点到终点的曲率和当地高边工具面均保持恒定。默认仍为<code>minimum_curvature</code>，原配置和历史结果保持原状。</p><p class="note">一般的恒曲率—恒工具面空间曲线不再是平面圆弧。下面用完全相同的控制比较两种几何，终点位置相差{difference:.6f} m；这是两种控制规律不同造成的结果，不是把旧曲线的工具面标签改成常数。</p></header>
<section><h2>如何启用</h2><pre>{html.escape(config)}</pre><p>该片段只展示新增选择，完整配置见<a href="../../examples/constant_toolface_validation.json">四算法验证配置</a>、<a href="../../examples/replanning_ABC_constant_toolface.json">A/B/C新增模式配置</a>；字段与公式见<a href="../../constant_toolface.md">完整使用说明</a>。当前演示是合成算例，未覆盖或重新命名旧A/B/C的60组合结果。</p></section>
<section><h2>同控制下的新旧轨迹</h2><p>起始井斜35°、方位20°；第一非直线段[DLS=3°/30m，ω=60°，L=150m]，直线L=100m，第三非直线段[DLS=2.5°/30m，ω=−45°，L=180m]。图例可隐藏新旧轨迹。</p>{div(f3, "trajectory3d")}<div class="grid">{div(xy, "horizontal")}{div(vertical, "vertical")}</div></section>
<section><h2>工具面是否真的不变</h2>{div(tf, "toolface")}{table(["模型", "段", "命令工具面°", "反算起点°", "反算终点°", "段内最大命令偏差°"], rows)}<p>直线曲率为0，没有唯一的有效造斜工具面，曲线在直线区间留空。各段可以取不同工具面；没有额外加入跨段工具面连续或旋转速率约束，位置和切向仍连续。</p>{div(ia, "attitude")}</section>
<section><h2>计算原理与原模型边界</h2><pre>dI/ds = κ cosω
dA/ds = κ sinω / sinI
dx/ds = [sinI cosA, sinI sinA, cosI]
κ = DLS × π / (180 × 30)
ω：每个非直线段内的同一个常数
I(s) = I₀ + κ cosω s
A(s) = A₀ + tanω log[tan(I(s)/2) / tan(I₀/2)]   (cosω≠0)</pre><p>姿态采用解析表达式，位置一般采用DOP853积分；恒井斜螺旋、子午弧、直线采用解析特殊解。轨迹插值、防碰与绘图调用同一新几何。Rev.0等误差预算保留，测站最小曲率雅可比是对新非圆弧名义曲线的离散近似，不冒称整段精确圆弧，也不修改误差预算toolface_deg。</p></section>
<section><h2>四算法实际集成验证</h2><p>独立合成目标及远邻井，Rev.0默认参数、k=1。初值、优化、中靶、防碰、轨迹导出及绘图均真实执行。此处只验证新增模式链路，不代替真实三场景对比；成功终止与可行采用分别列出。</p>{table(["算法", "最终可行", "求解器状态", "新段进尺m", "求解器s", "中靶误差m", "最小SF", "导出工具面最大偏差°", "轨迹入口"], solver_rows)}<p>每算法独立目录均有result.json、optimized_trajectory.csv、uncertainty_covariance.json、交互3D和diagnostics.png。</p></section>
<section><h2>复现与验证</h2><pre>python -B src/wellpath/workflows/planning_experiments.py --config examples/constant_toolface_validation.json --output results/new_constant_tf
python -B tests/test_constant_toolface.py</pre><p>独立5状态ODE核对位置和姿态、有限差分核对曲率/单位速度、从法向反算恒工具面、检查多段连接和直线、核对默认内核与历史结果不变。详细记录见<a href="geometry_tests.log">新几何测试</a>、<a href="final_tests.log">完整测试</a>及<a href="verification.json">交付核验</a>。</p></section>"""
    # Escape-safe table helper intentionally escapes cell HTML; replace only
    # these locally constructed static anchors so users can open solver plots.
    for p in solver_root.glob("*/result.json"):
        anchor = f'<a href="solver_validation/{p.parent.name}/trajectory_3d.html">轨迹</a>'
        body = body.replace(html.escape(anchor), anchor)
    style = """body{font:15px/1.75 Arial,"PingFang SC",sans-serif;background:#f2f5f9;color:#17243b;margin:0}main{max-width:1450px;margin:auto;padding:24px}header,section{background:white;border:1px solid #e1e7ef;border-radius:12px;padding:24px;margin:20px 0}.note{background:#fff6e5;padding:14px;border-left:4px solid #e9a525}pre{background:#f4f6f9;padding:16px;overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:10px;border-bottom:1px solid #ddd;text-align:left;white-space:nowrap}th{background:#1b3552;color:white}.scroll{overflow:auto}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}a{color:#1762a3}@media(max-width:1000px){.grid{display:block}main{padding:8px}}"""
    (out / "index.html").write_text(
        f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>新增段内恒工具面</title><style>{style}</style><script>{get_plotlyjs()}</script></head><body><main>{body}</main></body></html>'
    )
    (out / "same_control_geometry_comparison.json").write_text(
        json.dumps(
            dict(
                controls=controls.tolist(),
                start_inclination_deg=35,
                start_azimuth_deg=20,
                endpoint_distance_between_models_m=difference,
                reconstructed_toolface_checks=checks,
            ),
            ensure_ascii=False,
            indent=2,
        )
        + "\n"
    )
    return dict(
        endpoint_distance_between_models_m=difference,
        reconstructed_toolface_checks=checks,
        solver_results=len(solver_rows),
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(demonstrate(args.output), ensure_ascii=False, indent=2))
