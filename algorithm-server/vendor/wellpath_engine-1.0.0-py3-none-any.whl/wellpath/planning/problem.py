"""Planning problem with explicit segment types and ISCWSA separation factors."""

import copy

import numpy as np

from wellpath.anticollision.engine import SeparationEngine
from wellpath.planning.geometry_problem import WellControlProblem


class PlanningProblem(WellControlProblem):
    def __init__(self, cfg, config_dir=None):
        cfg = copy.deepcopy(cfg)
        if cfg.get("neighbor_wells"):
            raise ValueError(
                "Use iscwsa.neighbors with MD/inc/azimuth surveys; geometry-only neighbors are insufficient."
            )
        cfg["neighbor_wells"] = []
        super().__init__(cfg, config_dir)
        self.engine = SeparationEngine(self)
        self.scan_factor = 1
        self.buffer = float(cfg["iscwsa"].get("optimization_sf_buffer", 0.03))
        if self.buffer < 0:
            raise ValueError("optimization_sf_buffer must be nonnegative.")
        self._cache_z = None
        self._cache_e = None
        # Prevent duplicate neighbor names from aliasing cached surveys.
        names = [w["name"] for w in self.engine.neighbors]
        if len(names) != len(set(names)):
            raise ValueError("Neighbor names must be unique.")

    def evaluate(self, z, collision_cells=None):
        if self._cache_z is not None and np.array_equal(z, self._cache_z):
            return self._cache_e
        e = super().evaluate(z)
        if self.engine.neighbors:
            sf = self.engine.evaluate(e, factor=self.scan_factor)
            gsf = sf["sf_g"] - max(self.buffer, 1e-6) / self.engine.threshold
            e["g"] = np.r_[e["g"], gsf, sf["centerline_g"]]
            e["separation"] = sf
        else:
            e["separation"] = dict(minimum_sf=None, details=[], profiles=[], g=np.array([]))
        self._cache_z = np.array(z).copy()
        self._cache_e = e
        return e

    def check(self, z, dense=False):
        result = super().check(z, dense=False)
        e = self.evaluate(z)
        sf = e["separation"]
        if dense and self.engine.neighbors:
            sf = self.engine.evaluate(
                e, factor=self.cfg["iscwsa"].get("validation_scan_factor", 4), refine=True
            )
        minimum = sf["minimum_sf"]
        threshold = self.engine.threshold
        required = threshold
        center_minimum = sf.get("minimum_centerline_distance_m")
        center_required = self.engine.centerline_threshold
        result["feasible"] = bool(
            result["feasible"]
            and (minimum is None or minimum > required)
            and (center_minimum is None or center_minimum > center_required)
        )
        result.update(
            minimum_sf=minimum,
            sf_threshold=threshold,
            sf_margin=None if minimum is None else minimum - threshold,
            minimum_centerline_distance_m=center_minimum,
            centerline_minimum_m=center_required,
            centerline_margin_m=None
            if center_minimum is None
            else center_minimum - center_required,
            separation_details=sf["details"],
            centerline_details=sf.get("centerline_details", []),
            verification=(
                "1 m full Cartesian scan + exact segment endpoints"
                if self.engine.scalar_radius_mode
                else "fine grid + continuous local refinement"
                if dense
                else "optimization grid"
            ),
        )
        result.pop("certified_minimum_clearance_margin_m", None)
        result.pop("collision_cells_per_arc", None)
        return result
