"""Continuous intervals and exact finite-set toolface choices.

Finite choices are enumerated before NLP; no rounding of an optimized angle.
Angles are cyclic. Discrete values use the canonical [-180,180) representation.
"""

import copy
import itertools
import math

from wellpath.planning.configuration import resolve_trajectory


def canonical_angle(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError("Toolface values must be finite numeric degrees")
    result = (float(value) + 180.0) % 360.0 - 180.0
    return 0.0 if abs(result) < 1e-12 else result


def _overrides(cfg, n):
    raw = cfg.get("segment_bounds", [])
    if isinstance(raw, dict):
        result = [{} for _ in range(n)]
        for key, value in raw.items():
            if (
                not isinstance(key, str)
                or not key.isdigit()
                or str(int(key)) != key
                or not 1 <= int(key) <= n
            ):
                raise ValueError("segment_bounds keys must be canonical 1-based indices")
            result[int(key) - 1] = copy.deepcopy(value)
        return result
    if not isinstance(raw, list) or (raw and len(raw) != n):
        raise ValueError("segment_bounds list length must equal n_segments")
    return copy.deepcopy(raw) if raw else [{} for _ in range(n)]


def _spec(default, override):
    if "toolface_control" in override:
        return override["toolface_control"]
    if "start_toolface_deg" in override:
        return dict(mode="continuous", bounds_deg=override["start_toolface_deg"])
    return default.get(
        "toolface_control",
        dict(mode="continuous", bounds_deg=default.get("start_toolface_deg", [-180.0, 180.0])),
    )


def specifications(cfg):
    _, types = resolve_trajectory(cfg)
    overrides = _overrides(cfg, len(types))
    default = cfg["default_segment_bounds"]
    specs = []
    if not isinstance(default, dict) or any(not isinstance(v, dict) for v in overrides):
        raise ValueError("Segment bounds entries must be objects")
    for index, (kind, override) in enumerate(zip(types, overrides)):
        if kind == "straight":
            if "toolface_control" in override:
                raise ValueError(
                    f"Segment {index + 1} is straight; steering toolface has no geometric definition"
                )
            specs.append(None)
            continue
        spec = _spec(default, override)
        if not isinstance(spec, dict):
            raise ValueError("toolface_control must be an object")
        mode = spec.get("mode")
        if mode == "continuous":
            bounds = spec.get("bounds_deg")
            if (
                not isinstance(bounds, list)
                or len(bounds) != 2
                or any(
                    isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x)
                    for x in bounds
                )
                or bounds[0] > bounds[1]
            ):
                raise ValueError("continuous toolface requires finite ordered bounds_deg [lo,hi]")
            if "values_deg" in spec:
                raise ValueError("continuous toolface uses bounds_deg, not values_deg")
            specs.append(dict(mode=mode, bounds_deg=list(map(float, bounds))))
        elif mode == "discrete":
            if cfg.get("arc_segment_model", "minimum_curvature") != "constant_toolface":
                raise ValueError("Discrete toolface currently requires constant_toolface geometry")
            raw = spec.get("values_deg")
            if not isinstance(raw, list) or not raw:
                raise ValueError("discrete toolface requires a nonempty values_deg list")
            if "bounds_deg" in spec:
                raise ValueError("discrete toolface uses values_deg, not bounds_deg")
            values = []
            for v in raw:
                w = canonical_angle(v)
                if not any(abs((w - old + 180) % 360 - 180) < 1e-10 for old in values):
                    values.append(w)
            specs.append(dict(mode=mode, values_deg=values, requested_values_deg=raw))
        else:
            raise ValueError("toolface_control.mode must be continuous or discrete")
    return specs, overrides


def has_discrete_toolface(cfg):
    return any(s and s["mode"] == "discrete" for s in specifications(cfg)[0])


def continuous_configuration(cfg):
    # Fast path preserves the original inputs/default behavior.
    if "toolface_control" not in cfg.get("default_segment_bounds", {}) and not any(
        "toolface_control" in v
        for v in (
            cfg.get("segment_bounds", {}).values()
            if isinstance(cfg.get("segment_bounds"), dict)
            else cfg.get("segment_bounds", [])
        )
    ):
        return cfg
    specs, overrides = specifications(cfg)
    if any(s and s["mode"] == "discrete" for s in specs):
        raise ValueError(
            "Unresolved discrete toolface: use the experiment/replanning runner to enumerate finite choices before NLP"
        )
    out = copy.deepcopy(cfg)
    out["default_segment_bounds"].pop("toolface_control", None)
    for spec, override in zip(specs, overrides):
        override.pop("toolface_control", None)
        if spec:
            override["start_toolface_deg"] = spec["bounds_deg"]
    out["segment_bounds"] = overrides
    return out


def expand_toolface_configs(cfg, max_assignments=4096):
    specs, overrides = specifications(cfg)
    indices = [i for i, s in enumerate(specs) if s and s["mode"] == "discrete"]
    count = math.prod(len(specs[i]["values_deg"]) for i in indices)
    if type(max_assignments) is not int or max_assignments < 1:
        raise ValueError("max_toolface_assignments must be a positive integer")
    if count > max_assignments:
        raise ValueError(
            f"{count} discrete assignments exceed max_toolface_assignments={max_assignments}; no assignments silently dropped"
        )
    for assignment in itertools.product(*(specs[i]["values_deg"] for i in indices)):
        out = copy.deepcopy(cfg)
        out["default_segment_bounds"].pop("toolface_control", None)
        fixed = dict(zip(indices, assignment))
        current = copy.deepcopy(overrides)
        for index, (spec, override) in enumerate(zip(specs, current)):
            override.pop("toolface_control", None)
            if spec:
                override["start_toolface_deg"] = (
                    [fixed[index], fixed[index]] if index in fixed else spec["bounds_deg"]
                )
        out["segment_bounds"] = current
        metadata = dict(
            assignment_deg={str(i + 1): v for i, v in fixed.items()},
            assignment_count=count,
            normalized_specifications=specs,
            enumeration="complete Cartesian product; angle fixed before initialization and NLP; no post-solve rounding",
        )
        if indices:
            out["discrete_toolface_selection"] = metadata
        yield out, metadata
