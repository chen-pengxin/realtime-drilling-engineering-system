"""Shared deterministic geometry/target constraints; use src/wellpath/workflows/planning_experiments.py as entry point.

ISCWSA separation constraints and algorithms are implemented in src/wellpath/planning/problem.py,
src/wellpath/anticollision/uncertainty.py and src/wellpath/optimization/runner.py. Explicit straight segments eliminate controls.
"""

from __future__ import annotations

import copy
import csv
from pathlib import Path

import numpy as np

from wellpath.geometry.arc import (
    angle_error_deg,
    angles,
    arc_vertical_extrema,
    local_basis,
    minimum_curvature_increment,
    tangent,
)
from wellpath.geometry.segments import (
    constant_toolface_inclination_extrema,
    geometry_metadata,
    resolve_arc_segment_model,
    segment_state,
)
from wellpath.planning.configuration import resolve_trajectory


def segment_distances(p0, p1, q0, q1):
    """All pairwise finite-line-segment distances, shape (len(p0), len(q0)).

    Global minimum on each parameter square: check four edges and the interior
    stationary point. Handles parallel and zero-length segments as well.
    """
    p0, p1, q0, q1 = [np.asarray(v, float) for v in (p0, p1, q0, q1)]
    u = (p1 - p0)[:, None, :]
    v = (q1 - q0)[None, :, :]
    w = p0[:, None, :] - q0[None, :, :]
    a = np.sum(u * u, axis=2)
    b = np.sum(u * v, axis=2)
    c = np.sum(v * v, axis=2)
    d = np.sum(u * w, axis=2)
    e = np.sum(v * w, axis=2)
    safe_a, safe_c = np.maximum(a, 1e-30), np.maximum(c, 1e-30)
    candidates = []
    for s in (np.zeros_like(b), np.ones_like(b)):
        t = np.clip((e + b * s) / safe_c, 0, 1)
        candidates.append(np.sum((w + s[..., None] * u - t[..., None] * v) ** 2, axis=2))
    for t in (np.zeros_like(b), np.ones_like(b)):
        s = np.clip((b * t - d) / safe_a, 0, 1)
        candidates.append(np.sum((w + s[..., None] * u - t[..., None] * v) ** 2, axis=2))
    # Cross-product form avoids catastrophic cancellation of a*c-b*b for
    # nearly parallel segments, where an interior crossing still matters.
    uv = np.cross(u, v)
    den = np.sum(uv * uv, axis=2)
    interior = den > 1e-280
    s = np.divide(np.sum(np.cross(v, w) * uv, axis=2), den, out=np.zeros_like(b), where=interior)
    t = np.divide(np.sum(np.cross(u, w) * uv, axis=2), den, out=np.zeros_like(b), where=interior)
    valid = interior & (s >= 0) & (s <= 1) & (t >= 0) & (t <= 1)
    dist2 = np.sum((w + s[..., None] * u - t[..., None] * v) ** 2, axis=2)
    candidates.append(np.where(valid, dist2, np.inf))
    result = np.sqrt(np.maximum(np.minimum.reduce(candidates), 0))
    # In an extreme underflow case return a conservative lower bound.
    return np.where((den > 0) & ~interior, 0.0, result)


def arc_grid(p0, t0, dls, toolface, length, cells, model="minimum_curvature"):
    s = np.linspace(0, length, cells + 1)
    k = np.deg2rad(dls) / 30
    points, _, _ = segment_state(p0, t0, dls, toolface, s, model)
    # R*(1-cos(k*length/(2*cells))) in a stable form, including k=0.
    delta_theta = k * length / cells
    sagitta = (
        k
        * (length / cells) ** 2
        / 8
        * (np.sinc(delta_theta / (4 * np.pi)) ** 2 if model == "minimum_curvature" else 1.0)
    )
    return points, float(sagitta)


class WellControlProblem:
    def __init__(self, cfg, config_dir=None):
        from wellpath.planning.toolface import continuous_configuration

        cfg = continuous_configuration(cfg)
        self.cfg = copy.deepcopy(cfg)
        self.config_dir = Path(config_dir or ".")
        self.trajectory_mode, self.segment_types = resolve_trajectory(cfg)
        self.arc_segment_model = resolve_arc_segment_model(cfg)
        self.geometry_metadata = geometry_metadata(self.arc_segment_model)
        self.n = n = len(self.segment_types)
        self.cfg["trajectory_mode"] = self.trajectory_mode
        self.p0 = np.asarray(cfg["start"]["position_m"], float)
        self.pt = np.asarray(cfg["target"]["position_m"], float)
        self.t0 = tangent(cfg["start"]["inclination_deg"], cfg["start"]["azimuth_deg"])
        self.tt = tangent(cfg["target"]["inclination_deg"], cfg["target"]["azimuth_deg"])
        self.scale = max(float(np.linalg.norm(self.pt - self.p0)), 1.0)
        self.base_bounds = cfg["default_segment_bounds"]
        overrides = cfg.get("segment_bounds", [])
        if isinstance(overrides, dict):
            indexed = [{} for _ in range(n)]
            for key, value in overrides.items():
                if not isinstance(key, str) or not key.isdigit() or not 1 <= int(key) <= n:
                    raise ValueError(
                        "segment_bounds keys must be 1-based segment indices within n_segments."
                    )
                if str(int(key)) != key:
                    raise ValueError('segment_bounds indices must use canonical strings, e.g. "1".')
                indexed[int(key) - 1] = value
            overrides = indexed
        elif not isinstance(overrides, list) or (overrides and len(overrides) != n):
            raise ValueError(
                "segment_bounds must be empty, a list of n_segments objects, "
                "or an object keyed by 1-based segment indices."
            )
        if any(not isinstance(item, dict) for item in overrides):
            raise ValueError("Each segment_bounds entry must be an object.")
        self.lower, self.upper = [], []
        for i in range(n):
            b = dict(self.base_bounds)
            if overrides:
                if "curvature_1_per_m" in overrides[i]:
                    b.pop("dls_deg_per_30m", None)
                if "dls_deg_per_30m" in overrides[i]:
                    b.pop("curvature_1_per_m", None)
                b.update(overrides[i])
            if self.segment_types[i] == "straight":
                pairs = np.asarray([[0.0, 0.0], [0.0, 0.0], b["length_m"]], float)
            else:
                if "curvature_1_per_m" in b and "dls_deg_per_30m" in b:
                    raise ValueError("Choose curvature_1_per_m OR dls_deg_per_30m per segment.")
                db = b.get("dls_deg_per_30m")
                if db is None:
                    db = np.rad2deg(b["curvature_1_per_m"]) * 30
                pairs = np.asarray([db, b["start_toolface_deg"], b["length_m"]], float)
            if pairs.shape != (3, 2):
                raise ValueError("Segment control bounds must each be [lower, upper].")
            self.lower.append(pairs[:, 0])
            self.upper.append(pairs[:, 1])
        self.lower = np.asarray(self.lower)
        self.upper = np.asarray(self.upper)
        self.width = self.upper - self.lower
        self.active = self.width.ravel() > 0
        self.dim = int(self.active.sum())
        self.max_dls = float(cfg.get("max_dls_deg_per_30m", max(self.upper[:, 0].max(), 1.0)))
        if not np.isfinite(self.max_dls) or self.max_dls <= 0:
            raise ValueError("max_dls_deg_per_30m must be finite and positive.")
        if not np.isfinite(np.r_[self.lower.ravel(), self.upper.ravel()]).all():
            raise ValueError("All variable bounds must be finite.")
        if np.any(self.width < 0) or np.any(self.lower[:, 0] < 0) or np.any(self.lower[:, 2] <= 0):
            raise ValueError("Bounds must not decrease, curvature >= 0 and lengths > 0.")
        if self.dim < 1:
            raise ValueError("At least one variable must be free.")
        self.amin, self.amax = np.deg2rad(cfg["inclination_bounds_deg"])
        if self.arc_segment_model == "constant_toolface":
            if not 0 < self.amin <= self.amax < np.pi:
                raise ValueError("constant_toolface requires 0 < inclination bounds < 180 degrees")
            if not 0 < cfg["start"]["inclination_deg"] < 180:
                raise ValueError(
                    "constant_toolface high-side reference requires nonvertical initial inclination"
                )
        self.theta_max = np.deg2rad(cfg.get("max_segment_bend_deg", 150))
        if not (0 < self.amin < self.amax < np.pi and 0 < self.theta_max < np.pi):
            raise ValueError("Inclination bounds exclude 0/180 deg; bend must be below 180 deg.")
        target = cfg["target"]
        self.position_mode = target.get("position_mode", "sphere")
        self.position_tol = np.asarray(target["position_tolerance_m"], float)
        if self.position_mode == "sphere":
            if self.position_tol.shape != ():
                raise ValueError("Sphere position_tolerance_m is a scalar radius.")
        elif self.position_mode == "box":
            self.position_tol = np.broadcast_to(self.position_tol, (3,)).copy()
        else:
            raise ValueError("position_mode must be sphere or box.")
        self.angle_tol = np.asarray(
            [target["inclination_tolerance_deg"], target["azimuth_tolerance_deg"]], float
        )
        if np.any(self.position_tol <= 0) or np.any(self.angle_tol <= 0):
            raise ValueError("Target tolerances must be positive; they are actual NLP constraints.")
        self.angle_scale = 30.0  # dimensionless scaling: angle residual / 30 degrees
        self.collision_cells = int(cfg.get("collision_cells_per_arc", 12))
        if self.collision_cells < 1:
            raise ValueError("collision_cells_per_arc must be >= 1.")
        if self.p0.shape != (3,) or self.pt.shape != (3,):
            raise ValueError("position_m must be [north, east, TVD].")
        if not np.isfinite(
            np.r_[self.p0, self.pt, self.t0, self.tt, self.angle_tol, self.position_tol.ravel()]
        ).all():
            raise ValueError("Coordinates, angles and target tolerances must be finite.")
        for key in ("start", "target"):
            a = np.deg2rad(cfg[key]["inclination_deg"])
            if not self.amin <= a <= self.amax:
                raise ValueError(f"{key} inclination is outside global inclination bounds.")
        solver = cfg.get("solver", {})
        if (
            int(solver.get("initial_search_attempts", 12)) < 1
            or int(solver.get("optimization_starts", 3)) < 1
        ):
            raise ValueError("Search attempt counts must be positive.")
        self.neighbors = []
        planned_radius = float(cfg.get("planned_well_radius_m", 0.1))
        if planned_radius < 0:
            raise ValueError("planned_well_radius_m must be nonnegative.")
        for well in cfg.get("neighbor_wells", []):
            if "csv_file" in well:
                with (self.config_dir / well["csv_file"]).open(encoding="utf-8-sig") as f:
                    rows = list(csv.DictReader(f))
                pts = np.asarray(
                    [[float(r[k]) for k in ("north_m", "east_m", "tvd_m")] for r in rows]
                )
            else:
                pts = np.asarray(well["points_m"], float)
            if pts.ndim != 2 or pts.shape[1] != 3 or len(pts) < 2 or not np.isfinite(pts).all():
                raise ValueError(
                    "Each neighbor needs >=2 finite N/E/TVD points, ordered along the well."
                )
            terms = [
                planned_radius,
                float(well.get("radius_m", 0.1)),
                float(well.get("safety_margin_m", 5.0)),
                float(well.get("uncertainty_buffer_m", 0.0)),
                float(well.get("polyline_error_bound_m", 0.0)),
            ]
            if min(terms) < 0 or not np.isfinite(terms).all():
                raise ValueError("All radii/margins/buffers must be finite and nonnegative.")
            self.neighbors.append(dict(name=well["name"], points=pts, required=sum(terms)))

    def pack(self, physical):
        v = (np.asarray(physical) - self.lower).ravel()
        return v[self.active] / self.width.ravel()[self.active]

    def unpack(self, z):
        result = self.lower.ravel().copy()
        result[self.active] += np.asarray(z) * self.width.ravel()[self.active]
        return result.reshape(self.n, 3)

    def evaluate(self, z, collision_cells=None):
        physical = self.unpack(z)
        p, t = self.p0.copy(), self.t0.copy()
        g, records, extrema, collision = [], [], [], []
        cells = collision_cells or self.collision_cells
        for i, (dls, w, L) in enumerate(physical):
            p1, t1, _ = segment_state(p, t, dls, w, L, self.arc_segment_model)
            _, _, n0 = segment_state(p, t, dls, w, 0, self.arc_segment_model)
            theta = np.deg2rad(dls) * L / 30
            if self.arc_segment_model == "constant_toolface":
                imin, imax = constant_toolface_inclination_extrema(t, dls, w, L)
                inclination_g = [imin - self.amin, self.amax - imax]
            else:
                zmin, zmax = arc_vertical_extrema(t, n0, theta)
                imin, imax = np.arccos(np.clip([zmax, zmin], -1, 1))
                inclination_g = [np.cos(self.amin) - zmax, zmin - np.cos(self.amax)]
            g.extend(
                [
                    *inclination_g,
                    (self.theta_max - theta) / self.theta_max,
                    (self.max_dls - dls) / self.max_dls,
                ]
            )
            extrema.append(np.rad2deg([imin, imax]))
            if self.neighbors:
                points, sagitta = arc_grid(p, t, dls, w, L, cells, self.arc_segment_model)
                for well in self.neighbors:
                    pts = well["points"]
                    chord_distance = segment_distances(
                        points[:-1], points[1:], pts[:-1], pts[1:]
                    ).min(axis=1)
                    lower = chord_distance - sagitta
                    margin = lower - well["required"]
                    g.extend(margin / max(well["required"], 1.0))
                    collision.append(
                        dict(
                            segment=i + 1,
                            neighbor=well["name"],
                            required_centerline_distance_m=well["required"],
                            certified_distance_lower_bound_m=float(lower.min()),
                            certified_clearance_margin_m=float(margin.min()),
                            maximum_arc_chord_sagitta_m=sagitta,
                        )
                    )
            records.append((p.copy(), t.copy(), p1.copy(), t1.copy()))
            p, t = p1, t1
        err = p - self.pt
        if self.position_mode == "sphere":
            radius = float(self.position_tol)
            g.append((radius**2 - float(err @ err)) / (2 * self.scale * radius))
        else:
            g.extend((self.position_tol - err) / self.scale)
            g.extend((self.position_tol + err) / self.scale)
        a, az = angles(t)
        delta = np.array(
            [
                a - self.cfg["target"]["inclination_deg"],
                np.rad2deg(
                    np.arctan2(
                        np.sin(np.deg2rad(az - self.cfg["target"]["azimuth_deg"])),
                        np.cos(np.deg2rad(az - self.cfg["target"]["azimuth_deg"])),
                    )
                ),
            ]
        )
        g.extend((self.angle_tol - delta) / self.angle_scale)
        g.extend((self.angle_tol + delta) / self.angle_scale)
        return dict(
            physical=physical,
            p=p,
            t=t,
            g=np.asarray(g),
            records=records,
            inclination_extrema_deg=np.asarray(extrema),
            collision=collision,
            position_error=err,
            angle_errors=delta,
        )

    def check(self, z, dense=False):
        e = self.evaluate(z, max(4 * self.collision_cells, 48) if dense else None)
        pos_ok = (
            np.linalg.norm(e["position_error"]) <= float(self.position_tol) + 1e-6
            if self.position_mode == "sphere"
            else np.all(np.abs(e["position_error"]) <= self.position_tol + 1e-6)
        )
        angle_ok = np.all(np.abs(e["angle_errors"]) <= self.angle_tol + 1e-6)
        geometry_ok = (
            np.min(e["inclination_extrema_deg"][:, 0]) >= np.rad2deg(self.amin) - 1e-6
            and np.max(e["inclination_extrema_deg"][:, 1]) <= np.rad2deg(self.amax) + 1e-6
            and np.all(e["physical"][:, 0] <= self.max_dls + 1e-6)
            and np.all(
                e["physical"][:, 0] * e["physical"][:, 2] / 30 <= np.rad2deg(self.theta_max) + 1e-6
            )
        )
        bound_ok = np.all(np.asarray(z) >= -1e-8) and np.all(np.asarray(z) <= 1 + 1e-8)
        collision_margin = min(
            [c["certified_clearance_margin_m"] for c in e["collision"]], default=None
        )
        collision_ok = collision_margin is None or collision_margin >= -1e-6
        # Feasibility uses the optimization certificate and, separately, a finer one.
        return dict(
            feasible=bool(pos_ok and angle_ok and geometry_ok and bound_ok and collision_ok),
            position_error_m=float(np.linalg.norm(e["position_error"])),
            position_error_components_m=e["position_error"].tolist(),
            inclination_error_deg=float(e["angle_errors"][0]),
            azimuth_error_deg=float(e["angle_errors"][1]),
            tangent_direction_error_deg=angle_error_deg(e["t"], self.tt),
            certified_minimum_clearance_margin_m=collision_margin,
            minimum_scaled_constraint=float(e["g"].min()),
            collision_cells_per_arc=(
                max(4 * self.collision_cells, 48) if dense else self.collision_cells
            ),
        )

    def seed(self, rng, attempt):
        beta = np.arctan2(np.linalg.norm(np.cross(self.t0, self.tt)), np.dot(self.t0, self.tt))
        if 1e-7 < beta < np.pi - 1e-7:
            n0 = (self.tt - np.cos(beta) * self.t0) / np.sin(beta)
            v = minimum_curvature_increment(self.t0, self.tt, 1.0)
            length = float(
                np.clip(
                    (self.pt - self.p0) @ v / (v @ v),
                    self.lower[:, 2].sum(),
                    self.upper[:, 2].sum(),
                )
            )
            physical = []
            arc_count = self.segment_types.count("arc")
            arc_index = 0
            for i in range(self.n):
                if self.segment_types[i] == "straight":
                    physical.append([0.0, 0.0, length / self.n])
                    continue
                theta = beta * arc_index / arc_count
                t = np.cos(theta) * self.t0 + np.sin(theta) * n0
                n = -np.sin(theta) * self.t0 + np.cos(theta) * n0
                ea, ep = local_basis(t)
                w = np.rad2deg(np.arctan2(n @ ep, n @ ea))
                physical.append(
                    [np.rad2deg(beta / (length / self.n * arc_count)) * 30, w, length / self.n]
                )
                arc_index += 1
            z = np.clip(self.pack(physical), 1e-7, 1 - 1e-7)
        else:
            z = np.full(self.dim, 0.5)
        provided = self.cfg.get("initial_controls")
        if provided is not None and attempt == 0:
            if np.asarray(provided).shape != (self.n, 3):
                raise ValueError(
                    "initial_controls rows must be [DLS_deg_per_30m,start_toolface_deg,length_m]."
                )
            z = np.clip(self.pack(provided), 1e-7, 1 - 1e-7)
        if attempt:
            z = (
                np.clip(z + rng.normal(0, 0.22, len(z)), 1e-7, 1 - 1e-7)
                if attempt % 3
                else rng.uniform(0.03, 0.97, len(z))
            )
        return z


def samples(problem, z, step=0.25):
    out = []
    md = 0.0
    for i, ((dls, w, L), rec) in enumerate(zip(problem.unpack(z), problem.evaluate(z)["records"])):
        if problem.arc_segment_model == "constant_toolface":
            ss = np.linspace(0, L, max(2, int(np.ceil(L / step)) + 1))
            pp, tt, nn = segment_state(rec[0], rec[1], dls, w, ss, problem.arc_segment_model)
            inc = np.rad2deg(np.arctan2(np.hypot(tt[:, 0], tt[:, 1]), tt[:, 2]))
            azi = np.rad2deg(np.arctan2(tt[:, 1], tt[:, 0])) % 360
            # Local normal is cos(w)e_I+sin(w)e_A at every curved point.
            actual = float((w + 180) % 360 - 180) if dls > 0 else np.nan
            out.extend(
                np.column_stack(
                    [
                        np.full(len(ss), i + 1),
                        ss,
                        md + ss,
                        pp,
                        inc,
                        azi,
                        np.full(len(ss), actual),
                        np.full(len(ss), dls),
                    ]
                )
            )
            md += L
            continue
        for s in np.linspace(0, L, max(2, int(np.ceil(L / step)) + 1)):
            p, t, n = segment_state(rec[0], rec[1], dls, w, s, problem.arc_segment_model)
            ea, ep = local_basis(t)
            actual = np.rad2deg(np.arctan2(n @ ep, n @ ea)) if dls > 1e-6 else np.nan
            out.append([i + 1, s, md + s, *p, *angles(t), actual, dls])
        md += L
    return np.asarray(out)
