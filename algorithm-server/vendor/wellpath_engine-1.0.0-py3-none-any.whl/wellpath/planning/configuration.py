"""Generate segment types from one trajectory mode and a total segment count."""

from itertools import product

TRAJECTORY_MODES = ("arc", "arc-straight")
_ALIASES = {"圆弧": "arc", "圆弧-直线": "arc-straight"}


def resolve_trajectory(config):
    if "segment_types" in config:
        raise ValueError(
            "segment_types is generated internally. Configure trajectory_mode "
            "(arc or arc-straight) and n_segments instead."
        )
    n = config.get("n_segments")
    if not isinstance(n, int) or isinstance(n, bool) or n < 1:
        raise ValueError("n_segments must be an integer >= 1 (total number of segments).")
    mode = config.get("trajectory_mode", "arc")
    if not isinstance(mode, str):
        raise ValueError("trajectory_mode must be arc or arc-straight.")
    mode = _ALIASES.get(mode, mode)
    if mode not in TRAJECTORY_MODES:
        raise ValueError(f"trajectory_mode must be one of {TRAJECTORY_MODES}.")
    types = ["arc" if mode == "arc" or i % 2 == 0 else "straight" for i in range(n)]
    return mode, types


def experiment_layouts(exp, base):
    """Single selection or mode/count Cartesian product; no named well types."""
    if exp.get("mode", "single") == "single":
        layout = {
            key: exp.get(key, base.get(key, "arc" if key == "trajectory_mode" else None))
            for key in ("trajectory_mode", "n_segments")
        }
        for key in (
            "segment_bounds",
            "default_segment_bounds",
            "initial_controls",
            "arc_segment_model",
        ):
            if key in exp:
                layout[key] = exp[key]
        layout["name"] = "single"
        layouts = [layout]
    elif exp["mode"] == "comparison":
        if "layouts" in exp:
            if "trajectory_modes" in exp or "segment_counts" in exp:
                raise ValueError("Choose layouts OR trajectory_modes/segment_counts, not both.")
            layouts = [dict(item) for item in exp["layouts"]]
        else:
            modes = exp.get("trajectory_modes", [base.get("trajectory_mode", "arc")])
            counts = exp.get("segment_counts", [base["n_segments"]])
            if not isinstance(modes, list) or not isinstance(counts, list):
                raise ValueError("trajectory_modes and segment_counts must be lists.")
            layouts = [
                dict(trajectory_mode=mode, n_segments=n) for mode, n in product(modes, counts)
            ]
    else:
        raise ValueError("Experiment mode must be single or comparison.")
    if not layouts:
        raise ValueError("Select at least one trajectory mode/count combination.")
    names = set()
    for layout in layouts:
        if "arc_segment_model" in exp:
            layout.setdefault("arc_segment_model", exp["arc_segment_model"])
        mode, types = resolve_trajectory(layout)
        layout["trajectory_mode"] = mode
        layout.setdefault("name", f"{mode}_{len(types)}")
        if (
            not isinstance(layout["name"], str)
            or not layout["name"]
            or "/" in layout["name"]
            or "\\" in layout["name"]
            or layout["name"] in (".", "..")
        ):
            raise ValueError(
                "Layout name must be a nonempty directory name without path separators."
            )
        if layout["name"] in names:
            raise ValueError("Mode/count combinations or layout names must be unique.")
        names.add(layout["name"])
    return layouts


def layout_configuration(base, layout, comparison=False):
    """Apply one selection; segment bounds refer to its actual segment indices."""
    import copy

    cfg = copy.deepcopy(base)
    if comparison:
        cfg["segment_bounds"] = []
        cfg.pop("initial_controls", None)
    for key in (
        "trajectory_mode",
        "n_segments",
        "segment_bounds",
        "default_segment_bounds",
        "initial_controls",
        "arc_segment_model",
    ):
        if key in layout:
            cfg[key] = copy.deepcopy(layout[key])
    resolve_trajectory(cfg)
    return cfg
