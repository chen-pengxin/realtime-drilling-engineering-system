"""Profiled selectable nominal geometry, full-history Rev0 and dense acceptance.

Optimization constraints include SF and continuous-centerline clearance. Final
SF scans retain every supplied offset point and all 1 m planned points/endpoints.
Rev0 uses survey-station MC sensitivities; these remain a discrete approximation
when the selected nominal segment is a nonplanar constant-toolface curve.
"""

import time
from collections import defaultdict
from contextlib import contextmanager

import numpy as np
from scipy.spatial import cKDTree

from wellpath.anticollision.engine import pointwise_separation_minimum
from wellpath.anticollision.error_models.propagation import rev0_covariance
from wellpath.anticollision.uncertainty import interpolate_cov, path_at
from wellpath.geometry.arc import tangent
from wellpath.planning.geometry_problem import WellControlProblem


class Profiler:
    def __init__(self):
        self.seconds = defaultdict(float)
        self.calls = defaultdict(int)

    @contextmanager
    def measure(self, name):
        begin = time.perf_counter()
        try:
            yield
        finally:
            self.seconds[name] += time.perf_counter() - begin
            self.calls[name] += 1

    def snapshot(self):
        return dict(seconds=dict(self.seconds), calls=dict(self.calls))

    def since(self, before):
        return dict(
            seconds={k: v - before["seconds"].get(k, 0.0) for k, v in self.seconds.items()},
            calls={k: v - before["calls"].get(k, 0) for k, v in self.calls.items()},
        )


def paired_segment_distances(p0, p1, q0, q1):
    """Distances for corresponding segment pairs, including interior crossings."""
    u = p1 - p0
    v = q1 - q0
    w = p0 - q0
    a = np.einsum("ij,ij->i", u, u)
    b = np.einsum("ij,ij->i", u, v)
    c = np.einsum("ij,ij->i", v, v)
    d = np.einsum("ij,ij->i", u, w)
    e = np.einsum("ij,ij->i", v, w)
    candidates = []
    for s in (0.0, 1.0):
        t = np.clip((e + b * s) / np.maximum(c, 1e-30), 0, 1)
        candidates.append(np.sum((w + s * u - t[:, None] * v) ** 2, axis=1))
    for t in (0.0, 1.0):
        s = np.clip((b * t - d) / np.maximum(a, 1e-30), 0, 1)
        candidates.append(np.sum((w + s[:, None] * u - t * v) ** 2, axis=1))
    uv = np.cross(u, v)
    den = np.sum(uv * uv, axis=1)
    s = np.divide(
        np.sum(np.cross(v, w) * uv, axis=1), den, out=np.zeros_like(den), where=den > 1e-280
    )
    t = np.divide(
        np.sum(np.cross(u, w) * uv, axis=1), den, out=np.zeros_like(den), where=den > 1e-280
    )
    valid = (den > 1e-280) & (s >= 0) & (s <= 1) & (t >= 0) & (t <= 1)
    candidates.append(
        np.where(valid, np.sum((w + s[:, None] * u - t[:, None] * v) ** 2, axis=1), np.inf)
    )
    return np.sqrt(np.maximum(np.min(candidates, axis=0), 0))


class OffsetPolyline:
    def __init__(self, w):
        self.points = w["positions"]
        self.a = self.points[:-1]
        self.b = self.points[1:]
        self.mid = (self.a + self.b) / 2
        self.half = np.linalg.norm(self.b - self.a, axis=1) / 2
        self.tree = cKDTree(self.points)
        self.segments = cKDTree(self.mid)
        self.lo = np.minimum(self.a, self.b)
        self.hi = np.maximum(self.a, self.b)
        t = tangent(w["inc"], w["azi"]).T
        dot = np.einsum("ij,ij->i", t[:-1], t[1:])
        beta = np.arccos(np.clip(dot, -1, 1))
        length = np.diff(w["md"])
        self.sagitta = float(np.max(length * beta / 8 * np.sinc(beta / (4 * np.pi)) ** 2))

    def minimum(self, p, sagitta, profiler):
        with profiler.measure("centerline_screening"):
            bound = float(np.min(self.tree.query(p)[0]))
            pa = p[:-1]
            pb = p[1:]
            mid = (pa + pb) / 2
            ids = self.segments.query_ball_point(
                mid, np.linalg.norm(pb - pa, axis=1) / 2 + self.half.max() + bound + 1e-10
            )
            ii = np.repeat(np.arange(len(pa)), [len(x) for x in ids])
            jj = np.concatenate(ids).astype(int)
            if not len(ii):
                raise RuntimeError("Centerline screening lost all candidates")
            lo = np.minimum(pa[ii], pb[ii])
            hi = np.maximum(pa[ii], pb[ii])
            gap = np.maximum(
                0.0, np.maximum(lo[:, :2] - self.hi[jj, :2], self.lo[jj, :2] - hi[:, :2])
            )
            keep = np.linalg.norm(gap, axis=1) <= bound + 1e-10
            ii = ii[keep]
            jj = jj[keep]
        with profiler.measure("centerline_refinement"):
            distance = paired_segment_distances(pa[ii], pb[ii], self.a[jj], self.b[jj])
            at = int(np.argmin(distance))
            d = float(distance[at])
            err = float(sagitta + self.sagitta + 1e-8)
            return dict(
                distance_m=d,
                distance_lower_bound_m=max(0.0, d - err),
                curve_error_bound_m=err,
                planned_chord_index=int(ii[at]),
                offset_chord_index=int(jj[at]),
                refined_segment_pairs=len(ii),
                total_segment_pairs=len(pa) * len(self.a),
            )


class ReplanningProblem(WellControlProblem):
    def __init__(self, cfg, data, settings):
        super().__init__(cfg)
        self.data = data
        self.settings = settings
        self.profiler = Profiler()
        self._cache_z = None
        self._cache_e = None
        self.offsets = [OffsetPolyline(n["opt"]) for n in data["neighbors"]]
        self.offsets_dense = [OffsetPolyline(n["scan"]) for n in data["neighbors"]]
        self.history = data["history"]
        self.start_md = float(data["audit"]["tie_in"]["md_m"])
        self.k = float(settings["k_sigma"])
        self.sf_threshold = float(settings["sf_threshold"])
        self.dim = len(self.width.ravel()[self.active])
        # src/wellpath/optimization/runner.py uses these common attributes / check interface.

    def uncertainty(self, e):
        # Fixed cells per variable segment keep finite-difference constraints and
        # measurement topology stable; spacing is no larger than configured max.
        cells = [
            int(np.ceil(upper / self.settings["planned_survey_max_step_m"]))
            for upper in self.upper[:, 2]
        ]
        ends = np.cumsum(e["physical"][:, 2])
        starts = np.r_[0.0, ends[:-1]]
        rel = np.unique(
            np.concatenate([np.linspace(a, b, n + 1) for a, b, n in zip(starts, ends, cells)])
        )
        p, inc, azi = path_at(self, e, rel)
        h = self.history
        md = np.r_[h["md"][:-1], rel + self.start_md]
        fullp = np.vstack([h["positions"][:-1], p])
        fulli = np.r_[h["inc"][:-1], inc]
        fulla = np.r_[h["azi"][:-1], azi]
        r = rev0_covariance(md, fulli, fulla, fullp, self.data["parameters"])
        r["cov"] += np.asarray(self.settings["start_cov_nev_m2"])
        return dict(
            md=md,
            cov=r["cov"],
            positions=fullp,
            inc=fulli,
            azi=fulla,
            result=r,
            geometry=self.arc_segment_model,
            geometry_metadata=self.geometry_metadata,
            covariance_geometry="survey-station minimum_curvature approximation"
            if self.arc_segment_model == "constant_toolface"
            else "minimum_curvature",
            history_preserved=True,
            measurement_topology="fixed per-segment cells, max configured station step, synthetic",
        )

    def evaluate(self, z, collision_cells=None):
        if self._cache_z is not None and np.array_equal(z, self._cache_z):
            return self._cache_e
        with self.profiler.measure("trajectory_and_target_constraints"):
            e = super().evaluate(z)
            ends = np.cumsum(e["physical"][:, 2])
            starts = np.r_[0.0, ends[:-1]]
            cells = int(self.settings["optimization_cells_per_segment"])
            rel = np.unique(
                np.concatenate([np.linspace(a, b, cells + 1) for a, b in zip(starts, ends)])
            )
            p, _, _ = path_at(self, e, rel)
            sagitta = float(
                np.max(
                    np.deg2rad(e["physical"][:, 0]) / 30 * (e["physical"][:, 2] / cells) ** 2 / 8
                )
            )
        with self.profiler.measure("rev0_propagation_and_radius"):
            cov = self.uncertainty(e)
            c = interpolate_cov(cov["md"], cov["cov"], rel + self.start_md)
            radius = np.sqrt(np.maximum(np.linalg.eigvalsh(c)[:, -1], 0.0))
        g = []
        details = []
        profiles = []
        centers = []
        for n, poly in zip(self.data["neighbors"], self.offsets):
            other = n["opt"]
            # Horizontal AABB -> candidate intervals -> exact 3D/SF.
            scan = pointwise_separation_minimum(
                p,
                other["positions"],
                ra=radius,
                rb=other["radius"],
                k=self.k,
                block_rows=128,
                block_columns=128,
                sf_method="major_axis_sum",
            )
            self.record_scan_timing(scan, "sf_")
            g.extend(
                (scan["minimum_by_a"] - self.sf_threshold - self.settings["optimization_sf_buffer"])
                / self.sf_threshold
            )
            center = poly.minimum(p, sagitta, self.profiler)
            center["neighbor"] = other["name"]
            centers.append(center)
            g.append(
                (
                    center["distance_lower_bound_m"]
                    - self.settings["centerline_min_distance_m"]
                    - self.settings["centerline_buffer_m"]
                )
                / 5.0
            )
            details.append(
                dict(
                    neighbor=other["name"],
                    minimum_sf=scan["minimum_sf"],
                    sf_screening=scan["screening"],
                )
            )
            profiles.append(
                dict(neighbor=other["name"], relative_md_m=rel, minimum_sf=scan["minimum_by_a"])
            )
        # A small positional buffer protects strict final 0.5 m acceptance.
        with self.profiler.measure("constraint_assembly"):
            e["g"] = np.r_[
                e["g"],
                (
                    self.settings["optimization_target_radius_m"] ** 2
                    - float(e["position_error"] @ e["position_error"])
                )
                / (2 * self.scale * 0.5),
                (self.settings["optimization_target_radius_m"] - e["position_error"]) / self.scale,
                (self.settings["optimization_target_radius_m"] + e["position_error"]) / self.scale,
                g,
            ]
            e["separation"] = dict(
                minimum_sf=min(x["minimum_sf"] for x in details),
                details=details,
                profiles=profiles,
                minimum_centerline_distance_m=min(x["distance_lower_bound_m"] for x in centers),
                centerline_details=centers,
            )
            e["uncertainty"] = cov
        self._cache_z = np.array(z).copy()
        self._cache_e = e
        return e

    def record_scan_timing(self, scan, prefix):
        for key, name in (
            ("screening_seconds", "screening"),
            ("refinement_seconds", "refinement"),
            ("control_seconds", "control"),
        ):
            self.profiler.seconds[prefix + name] += scan["timing"][key]
            self.profiler.calls[prefix + name] += 1

    def check(self, z, dense=False):
        result = super().check(z, False)
        e = self.evaluate(z)
        sep = e["separation"]
        result.update(
            minimum_sf=sep["minimum_sf"],
            minimum_centerline_distance_m=sep["minimum_centerline_distance_m"],
            sf_threshold=self.sf_threshold,
            centerline_minimum_m=self.settings["centerline_min_distance_m"],
            separation_details=sep["details"],
            centerline_details=sep["centerline_details"],
        )
        result["feasible"] = bool(
            result["feasible"]
            and sep["minimum_sf"] > self.sf_threshold
            and sep["minimum_centerline_distance_m"] > self.settings["centerline_min_distance_m"]
        )
        result["verification"] = (
            "optimization grid with continuous polyline-centerline lower bound; final 1m scan performed separately"
        )
        return result

    def final_verify(self, z):
        begin = time.perf_counter()
        e = self.evaluate(z)
        ends = np.cumsum(e["physical"][:, 2])
        total = ends[-1]
        rel = np.unique(
            np.r_[np.arange(0.0, total, self.settings["final_scan_step_m"]), ends, 0.0, total]
        )
        with self.profiler.measure("final_trajectory_sampling"):
            p, inc, azi = path_at(self, e, rel)
            cov = e["uncertainty"]
            c = interpolate_cov(cov["md"], cov["cov"], rel + self.start_md)
            radius = np.sqrt(np.maximum(np.linalg.eigvalsh(c)[:, -1], 0))
        rows = []
        minimum = np.full(len(p), np.inf)
        centers = []
        profiles = []
        for n, poly in zip(self.data["neighbors"], self.offsets_dense):
            other = n["scan"]
            _tick = time.perf_counter()
            scan = pointwise_separation_minimum(
                p,
                other["positions"],
                ra=radius,
                rb=other["radius"],
                k=self.k,
                block_rows=128,
                block_columns=128,
                sf_method="major_axis_sum",
            )
            self.record_scan_timing(scan, "final_sf_")
            minimum = np.minimum(minimum, scan["minimum_by_a"])
            # Full curve between 1m planned/neighbor points, not only point distance.
            sagitta = float(
                np.max(np.deg2rad(e["physical"][:, 0]) / 30)
                / 8
                * self.settings["final_scan_step_m"] ** 2
            )
            center = poly.minimum(p, sagitta, self.profiler)
            center["neighbor"] = other["name"]
            centers.append(center)
            i, j = scan["reference_index"], scan["offset_index"]
            rows.append(
                dict(
                    neighbor=other["name"],
                    minimum_sf=scan["minimum_sf"],
                    reference_md_m=float(rel[i] + self.start_md),
                    offset_md_m=float(other["md"][j]),
                    center_distance_at_sf_min_m=scan["centerline_distance_m"],
                    reference_radius_m=float(radius[i]),
                    offset_radius_m=float(other["radius"][j]),
                    combined_boundary_m=scan["combined_error_boundary_m"],
                    sf_screening=scan["screening"],
                    centerline=center,
                )
            )
            profiles.append(
                dict(
                    neighbor=other["name"],
                    minimum_sf=scan["minimum_by_a"],
                    matching_index=scan["offset_indices_by_a"],
                )
            )
        check = self.check(z)
        minimum_sf = min(r["minimum_sf"] for r in rows)
        center_min = min(r["distance_lower_bound_m"] for r in centers)
        geometry_ok = check["position_error_m"] <= 0.5 and np.max(e["physical"][:, 0]) < 6.0
        check.update(
            minimum_inclination_deg=float(e["inclination_extrema_deg"][:, 0].min()),
            maximum_inclination_deg=float(e["inclination_extrema_deg"][:, 1].max()),
            maximum_segment_bend_deg=float(np.max(e["physical"][:, 0] * e["physical"][:, 2] / 30)),
            segment_variable_bounds_satisfied=bool(np.all(z >= -1e-8) and np.all(z <= 1 + 1e-8)),
        )
        check.update(
            feasible=bool(
                check["feasible"]
                and geometry_ok
                and minimum_sf > self.sf_threshold
                and center_min > self.settings["centerline_min_distance_m"]
            ),
            minimum_sf=minimum_sf,
            minimum_centerline_distance_m=center_min,
            maximum_dls_deg_per_30m=float(e["physical"][:, 0].max()),
            separation_details=rows,
            verification="All original offset 1m points × all new 1m points + exact segment endpoints; safe horizontal screening; continuous-centerline chord-error lower bound",
            centerline_details=centers,
            final_verification_seconds=time.perf_counter() - begin,
        )
        return dict(
            check=check,
            md=rel + self.start_md,
            relative_md=rel,
            positions=p,
            inc=inc,
            azi=azi,
            cov=c,
            radius=radius,
            minimum_sf=minimum,
            profiles=profiles,
            uncertainty=cov,
            physical=e["physical"],
            arc_segment_model=self.arc_segment_model,
            geometry_metadata=self.geometry_metadata,
        )
