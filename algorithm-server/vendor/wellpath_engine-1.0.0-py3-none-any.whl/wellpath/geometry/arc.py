"""Liu-style planar circular arcs + feasibility search + SLSQP.

Coordinates: north, east, TVD positive down. Public inputs: degrees, metres,
and total dogleg severity in degrees per 30 m. All internal trigonometry uses
radians. Toolface is measured from high side toward increasing azimuth.
"""

from __future__ import annotations

import numpy as np

DISPLAY_STRAIGHT_DLS = 1e-6  # deg/30m; reporting only, never changes propagation


def tangent(inclination_deg: float, azimuth_deg: float) -> np.ndarray:
    a, p = np.deg2rad([inclination_deg, azimuth_deg])
    return np.array([np.sin(a) * np.cos(p), np.sin(a) * np.sin(p), np.cos(a)])


def angles(t: np.ndarray) -> tuple[float, float]:
    """Inclination and azimuth in degrees, without arccos roundoff issues."""
    a = np.arctan2(np.hypot(t[0], t[1]), t[2])
    p = np.arctan2(t[1], t[0]) % (2 * np.pi)
    return float(np.rad2deg(a)), float(np.rad2deg(p))


def local_basis(t: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """High side e_alpha and increasing-azimuth e_phi.

    At a vertical trial state, atan2(0, 0) supplies a numerical chart only.
    Configured inclination bounds exclude vertical accepted trajectories.
    """
    a = np.arctan2(np.hypot(t[0], t[1]), t[2])
    p = np.arctan2(t[1], t[0])
    return (
        np.array([np.cos(a) * np.cos(p), np.cos(a) * np.sin(p), -np.sin(a)]),
        np.array([-np.sin(p), np.cos(p), 0.0]),
    )


def angle_error_deg(t: np.ndarray, target_t: np.ndarray) -> float:
    return float(np.rad2deg(np.arctan2(np.linalg.norm(np.cross(t, target_t)), np.dot(t, target_t))))


def minimum_curvature_state(p0, t0, n0, curvature_1_per_m, distance_m):
    """Shared directed circular-arc kernel, scalar or vector distance in metres.

    For |theta|<pi this is exactly the standard minimum-curvature increment
    s/2 * RF(theta) * (t0+t(s)), evaluated with its stable sinc identity.
    Keeping the directed normal permits smooth infeasible NLP trial states
    beyond pi; accepted design segments are constrained strictly below pi.
    Zero curvature is the exact straight-line limit. This is geometry only,
    not an uncertainty Jacobian or an error model.
    """
    s = np.asarray(distance_m, dtype=float)
    theta = curvature_1_per_m * s
    sinc = np.sinc(theta / np.pi)
    cosc = 0.5 * theta * np.sinc(theta / (2 * np.pi)) ** 2
    p = np.asarray(p0) + (s * sinc)[..., None] * t0 + (s * cosc)[..., None] * n0
    t = np.cos(theta)[..., None] * t0 + np.sin(theta)[..., None] * n0
    n = -np.sin(theta)[..., None] * t0 + np.cos(theta)[..., None] * n0
    return p, t, n


def arc_state(
    p0: np.ndarray, t0: np.ndarray, dls: float, toolface_deg: float, distance_m: float
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Control adapter: fixed start normal, never a constant local toolface.

    Liu's planar-arc controls and minimum curvature describe the same short
    circular arc. Preserve this public API for solvers, sampling and figures.
    """
    ea, ep = local_basis(t0)
    w = np.deg2rad(toolface_deg)
    n0 = np.cos(w) * ea + np.sin(w) * ep
    return minimum_curvature_state(p0, t0, n0, np.deg2rad(dls) / 30.0, distance_m)


def minimum_curvature_between(p0, t0, t1, length_m, distance_m):
    """Survey adapter: unique short arc specified by MD and end tangents.

    Coordinates supplied by callers are anchors; this function does not infer
    attitudes from arbitrary XYZ points. An antipodal pair has no unique plane.
    """
    beta = np.arctan2(np.linalg.norm(np.cross(t0, t1)), np.dot(t0, t1))
    if beta >= np.pi - 1e-8:
        raise ValueError("Minimum-curvature arc is ambiguous near a 180 degree dogleg.")
    if not np.isfinite(length_m) or length_m <= 0:
        raise ValueError("Minimum-curvature survey interval must have positive finite length.")
    if beta < 1e-12:
        n0 = local_basis(t0)[0]
        return minimum_curvature_state(p0, t0, n0, 0.0, distance_m)
    axis = np.cross(t0, t1)
    n0 = np.cross(axis / np.linalg.norm(axis), t0)
    return minimum_curvature_state(p0, t0, n0, beta / length_m, distance_m)


def arc_vertical_extrema(t0: np.ndarray, n0: np.ndarray, theta_end: float) -> tuple[float, float]:
    """Exact min/max of tangent's vertical component on the entire arc."""
    candidates = [0.0, theta_end]
    stationary = np.arctan2(n0[2], t0[2])
    # The configured maximum bend is strictly below pi.
    for j in range(-2, 3):
        value = stationary + j * np.pi
        if 0.0 < value < theta_end:
            candidates.append(value)
    c = np.asarray(candidates)
    z = t0[2] * np.cos(c) + n0[2] * np.sin(c)
    return float(z.min()), float(z.max())


def minimum_curvature_increment(t0: np.ndarray, t1: np.ndarray, length_m: float) -> np.ndarray:
    """Independent standard minimum-curvature formula; short arc only."""
    beta = np.arctan2(np.linalg.norm(np.cross(t0, t1)), np.dot(t0, t1))
    if beta >= np.pi - 1e-8:
        raise ValueError("The minimum-curvature short arc is ambiguous near pi.")
    rf = (
        1.0 + beta**2 / 12.0 + beta**4 / 120.0 if beta < 1e-5 else (2.0 * np.tan(beta / 2.0) / beta)
    )
    return 0.5 * length_m * rf * (t0 + t1)
