"""Minimum-curvature survey interpolation and centerline proximity screening."""

from __future__ import annotations

import numpy as np

from wellpath.anticollision.methods.center_distance import centerline_minimum_distance
from wellpath.anticollision.policy import classify_separation
from wellpath.geometry.arc import minimum_curvature_between, tangent


def interpolate_minimum_curvature(md, inc, azi, positions, query):
    """Interpolate N/E/D and attitude from survey stations with minimum curvature."""
    md = np.asarray(md, dtype=np.float64)
    inc = np.asarray(inc, dtype=np.float64)
    azi = np.asarray(azi, dtype=np.float64)
    positions = np.asarray(positions, dtype=np.float64)
    query = np.asarray(query, dtype=np.float64)
    if md.ndim != 1 or len(md) < 2 or np.any(np.diff(md) <= 0):
        raise ValueError("Minimum-curvature surveys need strictly increasing MD stations.")
    if (
        not np.isfinite(md).all()
        or not np.isfinite(inc).all()
        or not np.isfinite(azi).all()
        or not np.isfinite(positions).all()
    ):
        raise ValueError("Survey MD, attitude and coordinates must be finite.")
    if inc.shape != md.shape or azi.shape != md.shape or positions.shape != (len(md), 3):
        raise ValueError("Survey MD, attitude and N/E/D array lengths must match.")
    if np.any(query < md[0] - 1e-9) or np.any(query > md[-1] + 1e-9):
        raise ValueError("Minimum-curvature interpolation cannot extrapolate beyond survey MD.")
    idx = np.searchsorted(md, query, side="right").clip(1, len(md) - 1) - 1
    out = np.empty((len(query), 3))
    out_inc = np.empty(len(query))
    out_azi = np.empty(len(query))
    for i in np.unique(idx):
        rows = np.flatnonzero(idx == i)
        t0 = tangent(inc[i], azi[i])
        t1 = tangent(inc[i + 1], azi[i + 1])
        length = md[i + 1] - md[i]
        s = np.clip(query[rows] - md[i], 0.0, length)
        out[rows], direction, _ = minimum_curvature_between(positions[i], t0, t1, length, s)
        out_inc[rows] = np.rad2deg(
            np.arctan2(np.hypot(direction[:, 0], direction[:, 1]), direction[:, 2])
        )
        out_azi[rows] = np.rad2deg(np.arctan2(direction[:, 1], direction[:, 0])) % 360.0
    exact = np.searchsorted(md, query).clip(0, len(md) - 1)
    mask = md[exact] == query
    out[mask] = positions[exact[mask]]
    out_inc[mask] = inc[exact[mask]]
    out_azi[mask] = azi[exact[mask]] % 360.0
    return out, out_inc, out_azi


def resample_minimum_curvature(md, inc, azi, positions, max_step_m=2.0, tolerance_m=0.01):
    """Densify each measured interval until its MC chord sagitta is bounded."""
    if max_step_m <= 0 or tolerance_m <= 0:
        raise ValueError("Resampling step and tolerance must be positive.")
    md = np.asarray(md, dtype=np.float64)
    inc = np.asarray(inc, dtype=np.float64)
    azi = np.asarray(azi, dtype=np.float64)
    positions = np.asarray(positions, dtype=np.float64)
    dense = [float(md[0])]
    for i, (start, end) in enumerate(zip(md[:-1], md[1:])):
        length = float(end - start)
        beta = np.arctan2(
            np.linalg.norm(np.cross(tangent(inc[i], azi[i]), tangent(inc[i + 1], azi[i + 1]))),
            np.clip(tangent(inc[i], azi[i]) @ tangent(inc[i + 1], azi[i + 1]), -1.0, 1.0),
        )
        if beta < 1e-12:
            n = max(1, int(np.ceil(length / max_step_m)))
        else:
            radius = length / beta
            max_angle = 2 * np.arccos(np.clip(1 - tolerance_m / radius, -1.0, 1.0))
            n = max(
                1, int(np.ceil(length / max_step_m)), int(np.ceil(beta / max(max_angle, 1e-12)))
            )
        dense.extend(np.linspace(start, end, n + 1)[1:].tolist())
    dense = np.asarray(dense, dtype=np.float64)
    points, inc_dense, azi_dense = interpolate_minimum_curvature(md, inc, azi, positions, dense)
    return dense, points, inc_dense, azi_dense


__all__ = [
    "interpolate_minimum_curvature",
    "resample_minimum_curvature",
    "centerline_minimum_distance",
    "classify_separation",
]
