"""Selectable nominal geometry; the existing minimum-curvature arc is default.

constant_toolface means a constant gravity/high-side referenced toolface and
constant total curvature. It is generally a spatial curve, not a planar circle.
Angles are degrees in the public API; coordinates are N/E/down in metres.
"""

from collections import OrderedDict

import numpy as np
from scipy.integrate import solve_ivp

from wellpath.geometry.arc import angles, arc_state

ARC_SEGMENT_MODELS = ("minimum_curvature", "constant_toolface")
POLE_EPS_RAD = 1e-8
_POSITION_SOLUTIONS = OrderedDict()
_POSITION_CACHE_LIMIT = 128


def clear_position_cache():
    """Release optional dense-integral memoization (no effect on geometry)."""
    _POSITION_SOLUTIONS.clear()


def resolve_arc_segment_model(config):
    value = config.get("arc_segment_model", "minimum_curvature")
    if value not in ARC_SEGMENT_MODELS:
        raise ValueError(f"arc_segment_model must be one of {ARC_SEGMENT_MODELS}")
    return value


def geometry_metadata(model):
    if model == "constant_toolface":
        return dict(
            arc_segment_model=model,
            nominal_geometry="constant_curvature_constant_local_toolface",
            toolface_reference="local high-side toward increasing azimuth; radians internally",
            toolface_behavior="constant within each curved segment; independent between segments; undefined steering direction on straight segments",
            position_calculation="analytic inclination/azimuth with DOP853 position quadrature; exact helix/meridian/straight special cases",
            uncertainty_geometry="configured survey-station propagation (MC by default), a discrete approximation for this non-circular nominal path",
        )
    return dict(
        arc_segment_model=model,
        nominal_geometry="minimum_curvature_planar_arc",
        toolface_reference="local high-side toward increasing azimuth; radians internally",
        toolface_behavior="configured initial toolface; local toolface may vary along each planar arc",
        position_calculation="existing exact directed minimum-curvature arc kernel",
    )


def constant_toolface_angles(t0, dls, toolface_deg, distance_m):
    """Analytic I(s), A(s); invalid pole-crossing trials freeze at a safe pole.

    Accepted paths must remain inside configured 0<I_min<=I<=I_max<180 deg.
    The pole extension only keeps infeasible optimizer trials finite and is
    never accepted: the raw inclination extrema are constrained separately.
    """
    i0, a0 = np.deg2rad(angles(np.asarray(t0)))
    w = np.deg2rad(toolface_deg)
    k = np.deg2rad(dls) / 30.0
    s = np.asarray(distance_m, dtype=float)
    rate = k * np.cos(w)
    if not np.isfinite(np.r_[i0, a0, k, w, s.ravel()]).all() or np.any(s < 0) or k < 0:
        raise ValueError("Constant-toolface inputs must be finite, distance/curvature nonnegative")
    i0 = float(np.clip(i0, POLE_EPS_RAD, np.pi - POLE_EPS_RAD))
    if abs(rate) < 1e-16:
        limit = np.inf
        used = s
        inc = np.full_like(s, i0)
        azi = a0 + k * np.sin(w) / np.sin(i0) * s
    else:
        boundary = np.pi - POLE_EPS_RAD if rate > 0 else POLE_EPS_RAD
        limit = max(0.0, (boundary - i0) / rate)
        used = np.minimum(s, limit)
        delta = rate * used
        inc = i0 + delta
        q = np.tan(delta / 2)
        t = np.tan(i0 / 2)
        logratio = np.log1p(np.maximum(q / t, -1 + 1e-15)) - np.log1p(
            np.maximum(-t * q, -1 + 1e-15)
        )
        azi = a0 + np.sin(w) / np.cos(w) * logratio
    return inc, azi, float(limit)


def constant_toolface_state(p0, t0, dls, toolface_deg, distance_m):
    """Return positions, unit tangents and curvature normals for any query s."""
    s = np.asarray(distance_m, dtype=float)
    flat = s.ravel()
    p0 = np.asarray(p0, float)
    t0 = np.asarray(t0, float)
    inc, azi, limit = constant_toolface_angles(t0, dls, toolface_deg, s)
    t = np.stack([np.sin(inc) * np.cos(azi), np.sin(inc) * np.sin(azi), np.cos(inc)], axis=-1)
    ea = np.stack([np.cos(inc) * np.cos(azi), np.cos(inc) * np.sin(azi), -np.sin(inc)], axis=-1)
    ep = np.stack([-np.sin(azi), np.cos(azi), np.zeros_like(azi)], axis=-1)
    w = np.deg2rad(toolface_deg)
    k = np.deg2rad(dls) / 30.0
    normal = np.cos(w) * ea + np.sin(w) * ep
    if not flat.size:
        return np.empty(s.shape + (3,)), t, normal
    maximum = float(flat.max(initial=0.0))
    if k == 0 or maximum == 0:
        return p0 + s[..., None] * t0, t, normal
    if abs(np.sin(w)) < 1e-14 and maximum <= limit:
        # A meridian has constant azimuth and is exactly the old planar arc.
        return arc_state(p0, t0, dls, toolface_deg, s)
    i0, a0 = np.deg2rad(angles(t0))
    if abs(k * np.cos(w)) < 1e-16:
        # Constant inclination -> helix, including the horizontal circle limit.
        rate = k * np.sin(w) / np.sin(i0)
        turn = rate * s
        half = turn / 2
        horizontal = np.sin(i0) * s * np.sinc(half / np.pi)
        displacement = np.stack(
            [horizontal * np.cos(a0 + half), horizontal * np.sin(a0 + half), np.cos(i0) * s],
            axis=-1,
        )
        return p0 + displacement, t, normal
    end = min(maximum, limit)

    def derivative(at, _):
        i, a, _ = constant_toolface_angles(t0, dls, toolface_deg, at)
        return np.array([np.sin(i) * np.cos(a), np.sin(i) * np.sin(a), np.cos(i)])

    if end > 0:
        # Position quadrature depends on initial direction and controls, not on
        # the global origin. Endpoint, collision and survey queries reuse the
        # same dense solution; only longer requests require a new integration.
        # A small extension also covers nearby length finite differences.
        key = (*map(float, t0), float(dls), float(toolface_deg))
        cached = _POSITION_SOLUTIONS.get(key)
        if cached is not None and cached[0] >= end:
            solution = cached[1]
            _POSITION_SOLUTIONS.move_to_end(key)
        else:
            integration_end = min(limit, end * 1.0001)
            solution = solve_ivp(
                derivative,
                (0.0, integration_end),
                np.zeros(3),
                method="DOP853",
                rtol=2e-11,
                atol=1e-10,
                dense_output=True,
            )
            if not solution.success:
                raise RuntimeError(
                    "Constant-toolface position integration failed: " + solution.message
                )
            _POSITION_SOLUTIONS[key] = (integration_end, solution)
            _POSITION_SOLUTIONS.move_to_end(key)
            if len(_POSITION_SOLUTIONS) > _POSITION_CACHE_LIMIT:
                _POSITION_SOLUTIONS.popitem(last=False)
        displacement = solution.sol(np.minimum(flat, end)).T
    else:
        displacement = np.zeros((len(flat), 3))
    if maximum > limit:
        boundary_t = derivative(end, None)
        displacement += np.maximum(flat - limit, 0.0)[:, None] * boundary_t
    return p0 + displacement.reshape(s.shape + (3,)), t, normal


def segment_state(p0, t0, dls, toolface_deg, distance_m, model="minimum_curvature"):
    if model == "minimum_curvature":
        return arc_state(p0, t0, dls, toolface_deg, distance_m)
    if model == "constant_toolface":
        if dls == 0:
            # Keep the exact old straight limit even if start is vertical.
            return arc_state(p0, t0, dls, toolface_deg, distance_m)
        return constant_toolface_state(p0, t0, dls, toolface_deg, distance_m)
    raise ValueError("Unknown arc_segment_model")


def constant_toolface_inclination_extrema(t0, dls, w, length):
    i0 = np.deg2rad(angles(t0)[0])
    iend = i0 + np.deg2rad(dls) / 30 * np.cos(np.deg2rad(w)) * length
    return min(i0, iend), max(i0, iend)
