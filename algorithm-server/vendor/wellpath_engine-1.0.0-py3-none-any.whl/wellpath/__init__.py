"""Well trajectory planning and collision evaluation engine."""

__version__ = "1.0.0"
