"""Run the complete A/B/C x alternating 1..5 segments x four NLP methods."""

import argparse
import copy
import hashlib
import json
import time
from pathlib import Path

from wellpath.optimization.segment_initialization import make_segment_initial
from wellpath.paths import PROJECT_ROOT
from wellpath.workflows.scenario_replanning import run_scene, save_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "configs/experiments/replanning_segments1to5.json",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--scenarios", nargs="+", choices=list("ABC"))
    parser.add_argument("--counts", type=int, nargs="+")
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    out = args.output
    out.mkdir(exist_ok=True, parents=True)
    if config.get("trajectory_mode") != "arc-straight":
        raise ValueError("This comparison requires alternating arc-straight mode")
    counts = config["segment_counts"]
    if (
        not counts
        or len(set(counts)) != len(counts)
        or any(type(n) is not int or not 1 <= n <= 5 for n in counts)
    ):
        raise ValueError("segment_counts must contain unique integer counts from 1 to 5")
    if (
        config["uncertainty_model"]["type"] != "iscwsa_rev0"
        or config["sf_method"] != "major_axis_sum"
    ):
        raise ValueError("This runner compares Rev0 with the configured major-axis SF path")
    if (
        not 0 < config["dls_upper_deg_per_30m"] < 6
        or not 0 < config["target_position_tolerance_m"] <= 0.5
    ):
        raise ValueError("Require DLS upper <6 and target tolerance <=0.5m")
    previous = out / "experiment_config.json"
    if previous.exists() and json.loads(previous.read_text()) != config:
        raise ValueError("Refusing to mix experiments with different configurations")
    save_json(previous, config)
    begin = time.perf_counter()
    reports = []
    historical_manifest = out / "historical_result_hashes_before.json"
    if not historical_manifest.exists():
        historical = PROJECT_ROOT / "results/replanning_ABC_Rev0_20261112"
        save_json(
            historical_manifest,
            {
                str(p.relative_to(historical)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in historical.rglob("*")
                if p.is_file()
            },
        )
    for count in args.counts or config["segment_counts"]:
        if count not in config["segment_counts"]:
            raise ValueError("Count outside configured comparison")
        s = copy.deepcopy(config)
        s["n_segments"] = count
        count_folder = out / f"segments_{count:02d}"
        count_folder.mkdir(exist_ok=True)
        save_json(count_folder / "experiment_config.json", s)
        for scene in args.scenarios or s["scenarios"]:
            folder = count_folder / f"scene_{scene}"
            if args.resume and (folder / "scene_timing.json").exists():
                reports.extend(json.loads((folder / "algorithm_results.json").read_text()))
                continue
            print(f"===== SEGMENTS {count} SCENE {scene} =====", flush=True)
            result = run_scene(scene, s, count_folder, initial_builder=make_segment_initial)
            reports.extend(result)
            save_json(out / "all_results.json", reports)
            print(
                f"Completed segments={count} scene={scene}; feasible={sum(bool(r['final_check'] and r['final_check']['feasible']) for r in result)}/{len(result)}",
                flush=True,
            )
    # Include every completed cell on resume/partial runs without mixing order.
    reports = []
    for p in sorted(out.glob("segments_*/scene_*/algorithm_results.json")):
        if (p.parent / "scene_timing.json").exists():
            reports.extend(json.loads(p.read_text()))
    save_json(out / "all_results.json", reports)
    save_json(
        out / "batch_timing.json",
        dict(
            current_invocation_wall_seconds=time.perf_counter() - begin,
            completed_cells=len(reports) // len(config["algorithms"]),
            total_cells=len(config["segment_counts"]) * len(config["scenarios"]),
            actual_cell_wall_seconds=sum(
                (json.loads(p.read_text()).get("scenario_wall_seconds") or 0.0)
                for p in out.glob("segments_*/scene_*/scene_timing.json")
            ),
            cells_with_unavailable_original_wall=[
                str(p.parent.relative_to(out))
                for p in out.glob("segments_*/scene_*/scene_timing.json")
                if json.loads(p.read_text()).get("scenario_wall_seconds") is None
            ],
            note="Algorithms ran sequentially; actual_cell_wall_seconds is the sum of completed cell wall times, including cell reporting; current invocation time additionally includes the final combined-report rendering. cell preparation and initial construction occur once per cell. Per-algorithm complete-flow times charge the shared cost once for fair comparison; they must not be summed as batch wall time.",
        ),
    )
    from wellpath.reports.segment_comparison import render_comparison

    render_comparison(out)
    print("COMPLETE", out.resolve(), flush=True)


if __name__ == "__main__":
    main()
