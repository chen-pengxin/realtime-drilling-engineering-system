"""Project uncertainty comparison on the thesis Table 4.1 MC trajectory.

This uses the audited active kernels, not the obsolete paper_model_reproduction
module. Output must be a new directory, so historical results remain intact.
"""

from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

from wellpath.anticollision.error_models.propagation import rev0_covariance, wdw_covariance
from wellpath.anticollision.uncertainty import scalar_radius
from wellpath.geometry.arc import minimum_curvature_increment, tangent
from wellpath.paths import PROJECT_ROOT

matplotlib.use("Agg")


ROOT = PROJECT_ROOT
# Only MD/I/A are used. Published N/E entries are not silently treated as truth.
TABLE = np.array(
    [
        [0, 0, 0],
        [2000, 0, 0],
        [3600, 32, 2],
        [5000, 32, 2],
        [5525.54, 32, 32],
        [6051.08, 32, 62],
        [6576.62, 32, 92],
        [7102.16, 32, 122],
        [9398.50, 60, 220],
        [12500, 60, 220],
    ],
    dtype=float,
)


def main(output=None):
    out = (
        Path(output)
        if output
        else ROOT / "results" / ("paper_MC_comparison_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
    )
    if out.exists():
        raise FileExistsError(
            "Choose a new output directory; historical results will not be overwritten."
        )
    out.mkdir(parents=True)
    md = TABLE[:, 0] * 0.3048
    inc = TABLE[:, 1]
    azi = TABLE[:, 2]
    pos = np.vstack(
        [
            np.zeros(3),
            np.cumsum(
                [
                    minimum_curvature_increment(
                        tangent(inc[j], azi[j]), tangent(inc[j + 1], azi[j + 1]), md[j + 1] - md[j]
                    )
                    for j in range(len(md) - 1)
                ],
                axis=0,
            ),
        ]
    )
    # Original stations carry the measurement error budget; virtual display
    # stations are not additional independent measurements.
    rev = rev0_covariance(md, inc, azi, pos)
    wdw = wdw_covariance(md, inc, azi)
    radius = scalar_radius(md, {"uncertainty_model": {"type": "md_scalar_radius"}})
    models = {
        "scalar_radius": radius[:, None, None] ** 2 * np.eye(3),
        "wdw": wdw["cov"],
        "iscwsa_rev0": rev["cov"],
    }
    axes = {name: np.sqrt(np.linalg.eigvalsh(cov).clip(0))[:, ::-1] for name, cov in models.items()}
    fields = ["MD_m", "inclination_deg", "azimuth_deg", "N_m", "E_m", "D_m"] + [
        f"{name}_{axis}_m" for name in models for axis in ("major", "middle", "minor")
    ]
    with (out / "station_results.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(fields)
        for k in range(len(md)):
            writer.writerow(
                [md[k], inc[k], azi[k], *pos[k], *[v for name in models for v in axes[name][k]]]
            )
    for name, r in (("iscwsa_rev0", rev), ("wdw", wdw)):
        np.savez_compressed(
            out / f"{name}_sources.npz",
            md_m=md,
            cov_nev_m2=r["cov"],
            **{f"cov_source__{key}": v for key, v in r["terms"].items()},
        )
    meta = {
        "trajectory": "Zhou Cong Table 4.1 MD/I/A; ft converted to m; positions reconstructed by MC",
        "propagation": "minimum_curvature; Rev.0 station Jacobian and WdW quadrature integrals",
        "parameters": {"iscwsa_rev0": rev["parameters"], "wdw": wdw["parameters"]},
        "K": 1.0,
        "parameter_provenance": "rev0_wdw_parameter_audit.md",
        "limitations": [
            "Rev.0 profile combines Fig.4.12 with Tables3.2/3.3 and Table4.1 environmental values.",
            "WdW source magnitudes are an assumed comparison profile, not a complete published tool profile.",
            "Only ten published stations define source samples. This coarse example does not establish field survey accuracy.",
        ],
    }
    (out / "parameters.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2) + "\n")
    fig, axs = plt.subplots(3, 1, figsize=(9, 9), sharex=True, layout="constrained")
    for axis, ax in enumerate(axs):
        for name in models:
            ax.plot(md, axes[name][:, axis], marker=".", label=name)
        ax.set_ylabel(("Major", "Middle", "Minor")[axis] + " semi-axis (m)")
        ax.grid(alpha=0.3)
        ax.legend()
    axs[-1].set_xlabel("MD (m)")
    fig.savefig(out / "axes_comparison.png", dpi=170)
    plt.close(fig)
    print(out)
    return out


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output")
    args = parser.parse_args()
    main(args.output)
