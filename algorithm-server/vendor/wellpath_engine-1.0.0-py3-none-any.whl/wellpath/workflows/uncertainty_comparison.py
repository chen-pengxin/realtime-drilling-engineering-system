"""Reproducible all-well/all-model 1 m SF comparison with exact sampled minima.

Run from this folder:
python src/wellpath/workflows/uncertainty_comparison.py --config configs/experiments/scenario_A_scan_comparison.json \
    --output results/scenario_A_uncertainty_comparison

XLSX inputs are read only. Numerical results are float64 CSV/NPZ; a separate
artifact-tool builder creates the review workbook from the comparison tables.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import shutil
import time
from pathlib import Path

import numpy as np
from openpyxl import load_workbook
from scipy.spatial import cKDTree

from wellpath.anticollision.settings import scan_sf_settings, sf_formula
from wellpath.anticollision.uncertainty import (
    empirical_covariance,
    interpolate_cov,
    make_survey,
    propagated_uncertainty,
    scalar_radius,
    simplified_mwd_uncertainty,
)
from wellpath.data_io.naming import artifact_name
from wellpath.geometry.minimum_curvature import interpolate_minimum_curvature


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )


def write_csv(path, fields, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(fields)
        for row in rows:
            writer.writerow(
                [
                    format(float(v), ".17g") if isinstance(v, (float, np.floating)) else v
                    for v in row
                ]
            )


def read_wells(path, config):
    workbook = load_workbook(path, read_only=True, data_only=True)
    wells = []
    for sheet in workbook:
        records = []
        baseline = []
        source_rows = []
        for row_number, row in enumerate(sheet.iter_rows(values_only=True), 1):
            if row_number <= config["header_row"] or not row or row[0] is None:
                continue
            records.append([float(v) for v in row[:6]])
            baseline.append([float(row[15]), str(row[17]), float(row[18]), float(row[19])])
            source_rows.append(row_number)
        a = np.asarray(records, dtype=np.float64)
        if a.ndim != 2 or a.shape[1] != 6 or not np.isfinite(a).all():
            raise ValueError(f"{sheet.title}: invalid coordinates/attitudes.")
        if np.any(np.diff(a[:, 0]) <= 0) or np.max(np.diff(a[:, 0])) > 1.0 + 1e-8:
            raise ValueError(f"{sheet.title}: not a complete <=1 m grid.")
        if np.any((a[:, 1] < 0) | (a[:, 1] > 180)):
            raise ValueError(f"{sheet.title}: invalid inclination.")
        wells.append(
            dict(
                name=sheet.title,
                md=a[:, 0],
                inc=a[:, 1],
                azi=a[:, 2],
                positions=a[:, [5, 4, 3]],
                source_rows=np.asarray(source_rows),
                baseline=baseline,
            )
        )
    workbook.close()
    if len(wells) != config["expected_wells"]:
        raise ValueError("Unexpected number of wells.")
    return wells


def prepare_models(wells, config, output=None, verbose=True):
    names = list(config["models"])
    models = []
    timings = []
    for name in names:
        begin = time.perf_counter()
        settings = config["models"][name]
        prepared = []
        for w in wells:
            md = w["md"]
            extra = {}
            station_count = len(md)
            if name == "iscwsa":
                interval = config["iscwsa_survey_interval_m"]
                endpoints = md[np.abs(md - np.round(md)) > 1e-7]
                survey_md = np.unique(
                    np.r_[np.arange(md[0], md[-1], interval), endpoints, md[0], md[-1]]
                )
                positions, inc, azi = interpolate_minimum_curvature(
                    md, w["inc"], w["azi"], w["positions"], survey_md
                )
                survey = make_survey(survey_md, inc, azi, positions, settings)
                cov = interpolate_cov(survey_md, np.asarray(survey.cov_nev), md)
                station_count = len(survey_md)
                extra = dict(survey_md=survey_md, survey_cov=np.asarray(survey.cov_nev))
            elif settings.get("uncertainty_model", {}).get("type") in ("iscwsa_rev0", "wdw"):
                interval = float(
                    settings.get("survey_interval_m", config["iscwsa_survey_interval_m"])
                )
                if not np.isfinite(interval) or interval <= 0:
                    raise ValueError("Invalid survey_interval_m")
                endpoints = md[np.abs(md - np.round(md)) > 1e-7]
                survey_md = np.unique(
                    np.r_[np.arange(md[0], md[-1], interval), endpoints, md[0], md[-1]]
                )
                positions, inc, azi = interpolate_minimum_curvature(
                    md, w["inc"], w["azi"], w["positions"], survey_md
                )
                result = propagated_uncertainty(survey_md, inc, azi, positions, settings)
                cov = interpolate_cov(survey_md, result["cov"], md)
                station_count = len(survey_md)
                extra = dict(
                    survey_md=survey_md,
                    survey_cov=result["cov"],
                    terms=result["terms"],
                    propagation_basis=result["propagation_basis"],
                    effective_parameters=result["parameters"],
                )
            elif name == "md_scalar_radius":
                radius = scalar_radius(md, settings)
                cov = None
            elif name == "simplified_mwd":
                result = simplified_mwd_uncertainty(md, w["inc"], settings)
                cov = result["cov"]
                extra = dict(
                    envelope_1sigma_m=result["envelope_1sigma_m"],
                    sigma_perp_m=result["sigma_perp_m"],
                )
            else:
                cov = empirical_covariance(md, settings)
            if cov is not None:
                eig = np.maximum(np.linalg.eigvalsh(cov), 0.0)
                radius = np.sqrt(eig[:, -1])
                if not np.isfinite(cov).all() or np.linalg.eigvalsh(cov).min() < -1e-8:
                    raise ValueError("Invalid covariance.")
            prepared.append(dict(cov=cov, radius=radius, station_count=station_count, **extra))
        models.append(prepared)
        timings.append(time.perf_counter() - begin)
        if output is not None:
            folder = output / "01_models" / name
            folder.mkdir(parents=True, exist_ok=True)
            save_json(
                folder / "parameters.json",
                dict(
                    model=name,
                    settings=settings,
                    assumed=True,
                    iscwsa_survey_interval_m=config["iscwsa_survey_interval_m"]
                    if name == "iscwsa"
                    else None,
                    construction_seconds=timings[-1],
                ),
            )
        if verbose:
            print(f"Prepared {name}: {timings[-1]:.3f}s", flush=True)
    return names, models, timings


def directional_variance(cov, indices, ux, uy, uz, by_row):
    c = cov[indices]
    at = (lambda x: x[:, None]) if by_row else (lambda x: x[None, :])
    return np.maximum(
        at(c[:, 0, 0]) * ux**2
        + at(c[:, 1, 1]) * uy**2
        + at(c[:, 2, 2]) * uz**2
        + 2 * (at(c[:, 0, 1]) * ux * uy + at(c[:, 0, 2]) * ux * uz + at(c[:, 1, 2]) * uy * uz),
        0.0,
    )


def scan_pair(a, b, models_a, models_b, config):
    """One symmetric pass: both directed point minima and both SF conventions.

    Horizontal AABBs bound distance below and maximum covariance eigenvalues
    bound each projected uncertainty above. A tile is discarded only if its
    lower SF bound cannot improve ANY point in either direction/convention.
    """
    begin = time.perf_counter()
    p = a["positions"]
    q = b["positions"]
    m = len(models_a)
    best_a = np.full((m, 2, len(p)), np.inf)
    best_b = np.full((m, 2, len(q)), np.inf)
    arg_a = np.full(best_a.shape, -1, dtype=np.int32)
    arg_b = np.full(best_b.shape, -1, dtype=np.int32)
    stage = time.perf_counter()
    center_a, center_arg_a = cKDTree(q).query(p, k=1, eps=0, workers=1)
    center_b, center_arg_b = cKDTree(p).query(q, k=1, eps=0, workers=1)
    center_seconds = time.perf_counter() - stage
    stage = time.perf_counter()
    block = int(config["block_size"])
    tiles = []
    for i in range(0, len(p), block):
        ii = np.arange(i, min(i + block, len(p)))
        x = p[ii]
        lo = x.min(axis=0)
        hi = x.max(axis=0)
        for j in range(0, len(q), block):
            jj = np.arange(j, min(j + block, len(q)))
            y = q[jj]
            yl = y.min(axis=0)
            yh = y.max(axis=0)
            horizontal = float(
                np.linalg.norm(np.maximum(0.0, np.maximum(lo[:2] - yh[:2], yl[:2] - hi[:2])))
            )
            order = float(np.linalg.norm((lo + hi - yl - yh) / 2))
            tiles.append((order, ii, jj, horizontal))
    tiles.sort(key=lambda t: t[0])
    theoretical = len(p) * len(q)
    evaluated = np.zeros(m, dtype=np.int64)
    seconds = np.zeros(m)
    common_settings, native = scan_sf_settings(config)
    common_method = common_settings["method"]
    common_k = common_settings["k_sigma"]
    native_method = native["sf_method"]
    native_k = native["k_sigma"]
    channels = ((common_method, common_k, common_settings), (native_method, native_k, native))
    setup_seconds = time.perf_counter() - stage
    decision_seconds = 0.0
    geometry_seconds = 0.0
    for _, ii, jj, h in tiles:
        stage = time.perf_counter()
        candidates = []
        for model, (ma, mb) in enumerate(zip(models_a, models_b)):
            scalar = ma["cov"] is None
            radius_a = float(np.max(ma["radius"][ii]))
            radius_b = float(np.max(mb["radius"][jj]))
            lower_bounds = []
            for method, k, settings in channels:
                if scalar or method != "project_rss":
                    scale = 1.0 if scalar and method == "project_rss" else k
                    lower = h / max(scale * (radius_a + radius_b), 1e-14)
                else:
                    margin = 2 * settings["well_radius_m"] + settings["surface_margin_m"]
                    upper = k * np.sqrt(radius_a**2 + radius_b**2 + settings["sigma_pa_m"] ** 2)
                    lower = max(h - margin, 0.0) / max(upper, 1e-14)
                lower_bounds.append(lower)
            can_improve = False
            for metric, lower in enumerate(lower_bounds):
                if (
                    lower
                    <= max(np.max(best_a[model, metric, ii]), np.max(best_b[model, metric, jj]))
                    + 1e-12
                ):
                    can_improve = True
                    break
            if can_improve:
                candidates.append(model)
        decision_seconds += time.perf_counter() - stage
        if not candidates:
            continue
        stage = time.perf_counter()
        delta = q[jj][None, :, :] - p[ii][:, None, :]
        distance = np.linalg.norm(delta, axis=2)
        u = np.divide(
            delta,
            distance[:, :, None],
            out=np.zeros_like(delta),
            where=distance[:, :, None] > 1e-14,
        )
        ux, uy, uz = u[:, :, 0], u[:, :, 1], u[:, :, 2]
        geometry_seconds += time.perf_counter() - stage
        for model in candidates:
            tick = time.perf_counter()
            ma, mb = models_a[model], models_b[model]
            total_radius = ma["radius"][ii, None] + mb["radius"][None, jj]
            variances = None
            sf_channels = []
            for method, k, settings in channels:
                if ma["cov"] is None:
                    scale = 1.0 if method == "project_rss" else k
                    values = distance / np.maximum(scale * total_radius, 1e-14)
                elif method == "major_axis_sum":
                    values = distance / np.maximum(k * total_radius, 1e-14)
                else:
                    if variances is None:
                        variances = (
                            directional_variance(ma["cov"], ii, ux, uy, uz, True),
                            directional_variance(mb["cov"], jj, ux, uy, uz, False),
                        )
                    va, vb = variances
                    if method == "directional_sum":
                        values = distance / np.maximum(k * (np.sqrt(va) + np.sqrt(vb)), 1e-14)
                    else:
                        margin = 2 * settings["well_radius_m"] + settings["surface_margin_m"]
                        values = np.maximum(distance - margin, 0.0) / np.maximum(
                            k * np.sqrt(va + vb + settings["sigma_pa_m"] ** 2), 1e-14
                        )
                sf_channels.append(values)
            common, native_sf = sf_channels
            for metric, sf in enumerate((common, native_sf)):
                for axis, indices, other, best, arg in (
                    (1, ii, jj, best_a, arg_a),
                    (0, jj, ii, best_b, arg_b),
                ):
                    local = np.argmin(sf, axis=axis)
                    value = (
                        sf[np.arange(len(ii)), local]
                        if axis == 1
                        else sf[local, np.arange(len(jj))]
                    )
                    target = other[local]
                    old = best[model, metric, indices]
                    change = (value < old) | (
                        (value == old) & (target < arg[model, metric, indices])
                    )
                    best[model, metric, indices[change]] = value[change]
                    arg[model, metric, indices[change]] = target[change]
            evaluated[model] += len(ii) * len(jj)
            seconds[model] += time.perf_counter() - tick
    if not np.isfinite(best_a).all() or not np.isfinite(best_b).all():
        raise ValueError("Incomplete scan.")
    timing = dict(
        center_distance_seconds=center_seconds,
        screening_setup_seconds=setup_seconds,
        screening_decision_seconds=decision_seconds,
        refinement_geometry_seconds=geometry_seconds,
        refinement_sf_seconds=float(seconds.sum()),
    )
    timing["screening_seconds"] = setup_seconds + decision_seconds
    timing["interval_refinement_seconds"] = geometry_seconds + float(seconds.sum())
    wall_seconds = time.perf_counter() - begin
    timing["aggregation_and_control_seconds"] = (
        wall_seconds
        - center_seconds
        - timing["screening_seconds"]
        - timing["interval_refinement_seconds"]
    )
    return dict(
        best_a=best_a,
        best_b=best_b,
        arg_a=arg_a,
        arg_b=arg_b,
        center_a=center_a,
        center_b=center_b,
        center_arg_a=center_arg_a,
        center_arg_b=center_arg_b,
        total_point_pairs=theoretical,
        evaluated=evaluated,
        kernel_seconds=seconds,
        wall_seconds=wall_seconds,
        horizontal_box_tiles=len(tiles),
        timing=timing,
    )


def classify(sf, center, config):
    t = config["thresholds"]
    codes = np.select(
        [sf <= t["red_sf"], sf <= t["orange_sf"], sf <= t["yellow_sf"]], [0, 1, 2], default=3
    )
    return np.where(center <= t["center_distance_red_m"], 0, codes)


def evaluate(wells, config, verbose=True):
    """Pure in-memory evaluation; all stage durations are elapsed wall time.

    Includes model construction, both SF conventions, exact sampled center
    distances, point matching and grading. Excludes all files, plots and checks.
    """
    start = time.perf_counter()
    stage = time.perf_counter()
    names, models, construction = prepare_models(wells, config, verbose=False)
    uncertainty_seconds = time.perf_counter() - stage
    n = len(wells)
    m = len(names)
    pair_records = [[] for _ in names]
    kernel = np.zeros(m)
    pair_timing = []
    global_sf = [np.full((m, 2, len(w["md"]), n), np.inf) for w in wells]
    global_arg = [np.full((m, 2, len(w["md"]), n), -1, dtype=np.int32) for w in wells]
    centers = [np.full((len(w["md"]), n), np.inf) for w in wells]
    center_args = [np.full((len(w["md"]), n), -1, dtype=np.int32) for w in wells]
    for count, (i, j) in enumerate(itertools.combinations(range(n), 2), 1):
        result = scan_pair(
            wells[i], wells[j], [v[i] for v in models], [v[j] for v in models], config
        )
        global_sf[i][:, :, :, j] = result["best_a"]
        global_sf[j][:, :, :, i] = result["best_b"]
        global_arg[i][:, :, :, j] = result["arg_a"]
        global_arg[j][:, :, :, i] = result["arg_b"]
        centers[i][:, j] = result["center_a"]
        centers[j][:, i] = result["center_b"]
        center_args[i][:, j] = result["center_arg_a"]
        center_args[j][:, i] = result["center_arg_b"]
        kernel += result["kernel_seconds"]
        pair_timing.append(
            dict(
                well_a=wells[i]["name"],
                well_b=wells[j]["name"],
                wall_seconds=result["wall_seconds"],
                theoretical_point_pairs=result["total_point_pairs"],
                horizontal_box_tiles=result["horizontal_box_tiles"],
                **result["timing"],
            )
        )
        for model, name in enumerate(names):
            ci = int(np.argmin(result["center_a"]))
            cj = int(result["center_arg_a"][ci])
            row = dict(
                well_a=wells[i]["name"],
                well_b=wells[j]["name"],
                center_min_m=float(result["center_a"][ci]),
                center_md_a_m=float(wells[i]["md"][ci]),
                center_md_b_m=float(wells[j]["md"][cj]),
                total_point_pairs=result["total_point_pairs"],
                evaluated_point_pairs=int(result["evaluated"][model]),
                screened_point_pairs=int(result["total_point_pairs"] - result["evaluated"][model]),
                kernel_seconds=float(result["kernel_seconds"][model]),
            )
            for metric, label in enumerate(("common", "project")):
                ia = int(np.argmin(result["best_a"][model, metric]))
                ib = int(result["arg_a"][model, metric, ia])
                sf = float(result["best_a"][model, metric, ia])
                pa = wells[i]["positions"][ia]
                pb = wells[j]["positions"][ib]
                if not np.isclose(sf, result["best_b"][model, metric].min(), atol=1e-12):
                    raise ValueError("Asymmetric SF minimum.")
                row.update(
                    {
                        f"{label}_min_SF": sf,
                        f"{label}_md_a_m": float(wells[i]["md"][ia]),
                        f"{label}_md_b_m": float(wells[j]["md"][ib]),
                        f"{label}_distance_at_SF_min_m": float(np.linalg.norm(pa - pb)),
                        f"{label}_classification": int(
                            classify(np.array(sf), np.array(row["center_min_m"]), config)
                        ),
                        **{
                            f"{label}_{axis}_{well}_m": float(point[k])
                            for well, point in (("a", pa), ("b", pb))
                            for k, axis in enumerate(("N", "E", "D"))
                        },
                    }
                )
            pair_records[model].append(row)
        if verbose:
            print(
                f"Pair {count:02d}/45 {wells[i]['name']}-{wells[j]['name']}: {result['wall_seconds']:.2f}s; evaluated fraction {np.sum(result['evaluated']) / (m * result['total_point_pairs']):.1%}",
                flush=True,
            )
    point_results = []
    for wi, w in enumerate(wells):
        center = centers[wi].min(axis=1)
        common = global_sf[wi][:, 0].min(axis=2)
        project = global_sf[wi][:, 1].min(axis=2)
        point_results.append(
            dict(
                common_min_sf=common,
                project_min_sf=project,
                common_class=classify(common, center, config),
                project_class=classify(project, center, config),
            )
        )
    timing = {
        key: sum(r[key] for r in pair_timing)
        for key in (
            "center_distance_seconds",
            "screening_setup_seconds",
            "screening_decision_seconds",
            "screening_seconds",
            "refinement_geometry_seconds",
            "refinement_sf_seconds",
            "interval_refinement_seconds",
        )
    }
    timing.update(
        evaluation_total_seconds=time.perf_counter() - start,
        uncertainty_construction_seconds=uncertainty_seconds,
        model_count=m,
        well_pairs=len(pair_timing),
        pair_scan_wall_seconds=sum(r["wall_seconds"] for r in pair_timing),
    )
    timing["aggregation_and_control_seconds"] = timing["evaluation_total_seconds"] - sum(
        timing[k]
        for k in (
            "uncertainty_construction_seconds",
            "center_distance_seconds",
            "screening_seconds",
            "interval_refinement_seconds",
        )
    )
    timing["evaluation_components_sum_seconds"] = sum(
        timing[k]
        for k in (
            "uncertainty_construction_seconds",
            "center_distance_seconds",
            "screening_seconds",
            "interval_refinement_seconds",
            "aggregation_and_control_seconds",
        )
    )
    assert timing["aggregation_and_control_seconds"] >= 0
    return dict(
        names=names,
        models=models,
        construction=construction,
        kernel=kernel,
        pairs=pair_records,
        sfs=global_sf,
        args=global_arg,
        centers=centers,
        center_args=center_args,
        point_results=point_results,
        pair_timing=pair_timing,
        timing=timing,
    )


def run(config_path, output):
    start = time.perf_counter()
    config_path = Path(config_path)
    config = json.loads(config_path.read_text())
    config["common_sf"], config["project_sf"] = scan_sf_settings(config)
    source = (config_path.parent / config["input_file"]).resolve()
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    inputs = output / "00_inputs"
    inputs.mkdir(exist_ok=True)
    shutil.copyfile(source, inputs / "source.xlsx")
    save_json(inputs / "scan_config.json", config)
    wells = read_wells(source, config)
    input_seconds = time.perf_counter() - start
    result = evaluate(wells, config)
    names = result["names"]
    models = result["models"]
    construction = result["construction"]
    kernel = result["kernel"]
    pair_records = result["pairs"]
    global_sf = result["sfs"]
    global_arg = result["args"]
    centers = result["centers"]
    center_args = result["center_args"]
    pair_timing = result["pair_timing"]
    independent = []
    independent_pairs = []
    benchmark_start = time.perf_counter()
    if config.get("timing", {}).get("independent_model_runs", False):
        for mi, name in enumerate(names):
            single_config = {**config, "models": {name: config["models"][name]}}
            one = evaluate(wells, single_config, verbose=False)
            for wi in range(len(wells)):
                np.testing.assert_allclose(one["sfs"][wi][0], global_sf[wi][mi], rtol=0, atol=1e-12)
                np.testing.assert_allclose(one["centers"][wi], centers[wi], rtol=0, atol=0)
                for key in ("common_class", "project_class"):
                    np.testing.assert_array_equal(
                        one["point_results"][wi][key][0], result["point_results"][wi][key][mi]
                    )
            independent.append(dict(model=name, **one["timing"], matches_batched_results=True))
            independent_pairs.extend(dict(model=name, **r) for r in one["pair_timing"])
            print(
                f"Independent {name}: evaluation={one['timing']['evaluation_total_seconds']:.3f}s; "
                f"screening={one['timing']['screening_seconds']:.3f}s; refinement={one['timing']['interval_refinement_seconds']:.3f}s",
                flush=True,
            )
            del one
    benchmark_seconds = time.perf_counter() - benchmark_start
    export_start = time.perf_counter()
    for mi, name in enumerate(names):
        folder = output / "01_models" / name
        folder.mkdir(parents=True, exist_ok=True)
        save_json(
            folder / "parameters.json",
            dict(
                model=name,
                settings=config["models"][name],
                assumed=True,
                iscwsa_survey_interval_m=config["iscwsa_survey_interval_m"]
                if name == "iscwsa"
                else None,
                construction_seconds=construction[mi],
                sf_settings=dict(common=config["common_sf"], project=config["project_sf"]),
                effective_parameters=models[mi][0].get("effective_parameters"),
                propagation_basis=models[mi][0].get("propagation_basis"),
            ),
        )
    for w in wells:
        write_csv(
            inputs / artifact_name(f"{w['name']}_trajectory.csv"),
            [
                "source_row",
                "MD_m",
                "inclination_deg",
                "azimuth_grid_deg",
                "N_m",
                "E_m",
                "D_m",
                "source_min_SF",
            ],
            (
                [r, md, i, a, *p, old[0]]
                for r, md, i, a, p, old in zip(
                    w["source_rows"], w["md"], w["inc"], w["azi"], w["positions"], w["baseline"]
                )
            ),
        )
    export_results(
        output,
        config,
        wells,
        names,
        models,
        construction,
        kernel,
        pair_records,
        global_sf,
        global_arg,
        centers,
        center_args,
    )
    save_json(output / "02_comparison/pair_timing.json", pair_timing)
    export_seconds = time.perf_counter() - export_start
    timing_report = dict(
        batch=result["timing"],
        independent_models=independent,
        input_read_and_copy_seconds=input_seconds,
        result_postprocessing_and_export_seconds=export_seconds,
        independent_benchmark_wall_seconds=benchmark_seconds,
        main_numerical_and_csv_wall_seconds=time.perf_counter() - start - benchmark_seconds,
        pipeline_including_benchmarks_seconds=time.perf_counter() - start,
        definitions=dict(
            evaluation_total="Model construction + sampled center distances + horizontal screening + candidate interval refinement + matching, grading and aggregation; excludes file IO, verification and plots.",
            screening="Horizontal AABB construction/order + conservative SF bound tests and candidate selection.",
            interval_refinement="3D distances/directions for candidate intervals + selected uncertainty-radius evaluation + both configured SF formulae + bidirectional minimum/matching updates; no adaptive resampling.",
            center_distance="Independent exact sampled-point KD-tree center-distance evaluation.",
            independent_models="Each model reconstructs its uncertainty and evaluates all 45 pairs independently. Input points remain in memory; no shared geometry computation or file IO. One sequential repeat; not a statistical benchmark.",
            batch="Configured models evaluated together; geometric computations are shared. Never add independent times to batch time.",
        ),
    )
    save_json(output / "02_comparison/evaluation_timing.json", timing_report)
    timing_rows = [
        dict(run=f"batch_{len(names)}_models", **result["timing"]),
        *[
            dict(
                run=r["model"],
                **{k: v for k, v in r.items() if k not in ("model", "matches_batched_results")},
            )
            for r in independent
        ],
    ]
    write_csv(
        output / "02_comparison/evaluation_timing.csv",
        list(timing_rows[0]),
        ([r[k] for k in timing_rows[0]] for r in timing_rows),
    )
    if independent_pairs:
        save_json(output / "02_comparison/independent_pair_timing.json", independent_pairs)
    n = len(wells)
    m = len(names)
    source_audit = dict(
        source_file=str(source),
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        well_count=n,
        total_points=sum(len(w["md"]) for w in wells),
        model_count=m,
        well_pairs=n * (n - 1) // 2,
        fractional_endpoint_count=sum(
            int((np.abs(w["md"] - np.round(w["md"])) > 1e-7).sum()) for w in wells
        ),
        theoretical_unordered_point_pairs=sum(x["theoretical_point_pairs"] for x in pair_timing),
        numeric_dtype="float64",
        source_values_rounded=False,
        scan_interval_m=1.0,
        hypotheses=config["assumptions"],
        numerical_and_csv_wall_seconds=timing_report["main_numerical_and_csv_wall_seconds"],
        evaluation_timing_file="02_comparison/evaluation_timing.json",
        evaluation_total_seconds=result["timing"]["evaluation_total_seconds"],
        formulae=dict(
            common=sf_formula(config["common_sf"]["method"]),
            common_scalar=sf_formula(config["common_sf"]["method"], True),
            project_covariance=sf_formula(config["project_sf"]["sf_method"]),
            project_scalar=sf_formula(config["project_sf"]["sf_method"], True),
        ),
        effective_sf_settings=dict(common=config["common_sf"], project=config["project_sf"]),
    )
    save_json(inputs / "source_audit.json", source_audit)
    print(
        "Numerical/CSV scan complete:",
        source_audit["numerical_and_csv_wall_seconds"],
        "s",
        flush=True,
    )


def export_results(
    output,
    config,
    wells,
    names,
    models,
    construction,
    kernel,
    pairs,
    sfs,
    args,
    centers,
    center_args,
):
    n = len(wells)
    baseline_index = names.index("md_scalar_radius")
    model_summary = []
    well_summaries = []
    audit = []
    baseline = [sfs[i][baseline_index, 0].min(axis=1) for i in range(n)]
    point_comparison = []
    _error_profiles = []
    for mi, name in enumerate(names):
        folder = output / "01_models" / name
        summary_rows = []
        scan_rows = []
        uncertainty_rows = []
        intervals = []
        for wi, w in enumerate(wells):
            md = w["md"]
            p = w["positions"]
            data = models[mi][wi]
            common = sfs[wi][mi, 0]
            native = sfs[wi][mi, 1]
            common_min = common.min(axis=1)
            native_min = native.min(axis=1)
            common_well = common.argmin(axis=1)
            native_well = native.argmin(axis=1)
            center = centers[wi].min(axis=1)
            center_well = centers[wi].argmin(axis=1)
            common_code = classify(common_min, center, config)
            native_code = classify(native_min, center, config)
            row = dict(
                model=name,
                well=w["name"],
                points=len(md),
                min_common_SF=float(common_min.min()),
                min_project_SF=float(native_min.min()),
                min_center_m=float(center.min()),
                max_error_radius_m=float(data["radius"].max()),
                common_sf_le_1_5_points=int((common_min <= 1.5).sum()),
                project_sf_le_1_5_points=int((native_min <= 1.5).sum()),
                common_red_points=int((common_code == 0).sum()),
                common_orange_points=int((common_code == 1).sum()),
                common_yellow_points=int((common_code == 2).sum()),
                common_blue_points=int((common_code == 3).sum()),
                project_red_points=int((native_code == 0).sum()),
                project_orange_points=int((native_code == 1).sum()),
                project_yellow_points=int((native_code == 2).sum()),
                project_blue_points=int((native_code == 3).sum()),
            )
            summary_rows.append(row)
            well_summaries.append(row)
            others = [j for j in range(n) if j != wi]
            np.savez_compressed(
                folder / artifact_name(f"{w['name']}_all_neighbors.npz"),
                md_m=md,
                neighbor_names=np.array([wells[j]["name"] for j in others]),
                common_min_sf_by_neighbor=common[:, others],
                project_min_sf_by_neighbor=native[:, others],
                common_matching_point_index=args[wi][mi, 0][:, others],
                project_matching_point_index=args[wi][mi, 1][:, others],
                center_min_by_neighbor_m=centers[wi][:, others],
                center_matching_point_index=center_args[wi][:, others],
            )
            if "survey_md" in data:
                np.savez_compressed(
                    folder / artifact_name(f"{w['name']}_iscwsa_survey.npz"),
                    md_m=data["survey_md"],
                    cov_nev_m2=data["survey_cov"],
                )
                if "terms" in data:
                    np.savez_compressed(
                        folder / artifact_name(f"{w['name']}_source_terms.npz"),
                        md_m=data["survey_md"],
                        **{f"cov_source__{key}": value for key, value in data["terms"].items()},
                    )
            for k in range(len(md)):
                ca = common_well[k]
                na = native_well[k]
                ci = int(args[wi][mi, 0, k, ca])
                ni = int(args[wi][mi, 1, k, na])
                cw = int(center_well[k])
                cidx = int(center_args[wi][k, cw])
                cov = data["cov"]
                values = (
                    [None] * 9
                    if cov is None
                    else [
                        *np.sqrt(np.maximum(np.diag(cov[k]), 0)),
                        cov[k, 0, 0],
                        cov[k, 1, 1],
                        cov[k, 2, 2],
                        cov[k, 0, 1],
                        cov[k, 0, 2],
                        cov[k, 1, 2],
                    ]
                )
                uncertainty_rows.append(
                    [
                        w["name"],
                        w["source_rows"][k],
                        md[k],
                        w["inc"][k],
                        w["azi"][k],
                        data["radius"][k],
                        *values,
                        "boundary_radius"
                        if cov is None
                        else "spherical_proxy"
                        if name == "simplified_mwd"
                        else "1sigma_covariance",
                        data.get("sigma_perp_m", np.full(1, np.nan))[k]
                        if name == "simplified_mwd"
                        else None,
                    ]
                )
                scan_rows.append(
                    [
                        w["name"],
                        w["source_rows"][k],
                        md[k],
                        *p[k],
                        common_min[k],
                        wells[ca]["name"],
                        wells[ca]["md"][ci],
                        *wells[ca]["positions"][ci],
                        float(np.linalg.norm(wells[ca]["positions"][ci] - p[k])),
                        int(common_code[k]),
                        "|".join(wells[j]["name"] for j in others if common[k, j] <= 1.5),
                        native_min[k],
                        wells[na]["name"],
                        wells[na]["md"][ni],
                        *wells[na]["positions"][ni],
                        int(native_code[k]),
                        center[k],
                        wells[cw]["name"],
                        wells[cw]["md"][cidx],
                        common_min[k] - baseline[wi][k],
                        w["baseline"][k][0],
                    ]
                )
            for label, code, sf in (
                ("common", common_code, common_min),
                ("project", native_code, native_min),
            ):
                boundaries = np.r_[0, np.flatnonzero(np.diff(code) != 0) + 1, len(code)]
                for a, b in zip(boundaries[:-1], boundaries[1:]):
                    intervals.append(
                        [
                            w["name"],
                            label,
                            int(code[a]),
                            md[a],
                            md[b - 1],
                            b - a,
                            float(sf[a:b].min()),
                            float(center[a:b].min()),
                        ]
                    )
            if name == "md_scalar_radius":
                old = np.array([r[0] for r in w["baseline"]])
                delta = common_min - old
                audit.append(
                    dict(
                        well=w["name"],
                        points=len(md),
                        max_abs_SF_difference=float(np.abs(delta).max()),
                        rms_SF_difference=float(np.sqrt(np.mean(delta**2))),
                        all_SF_match_atol_1e_10=bool(
                            np.allclose(common_min, old, rtol=0, atol=1e-10)
                        ),
                        original_risk_points=int((old < 1.5).sum()),
                        recomputed_strict_risk_points=int((common_min < 1.5).sum()),
                        minimum_matching_distance_difference_m=float(
                            np.max(
                                np.abs(
                                    np.array([r[3] for r in w["baseline"]])
                                    - np.array(
                                        [
                                            np.linalg.norm(
                                                wells[common_well[k]]["positions"][
                                                    int(args[wi][mi, 0, k, common_well[k]])
                                                ]
                                                - p[k]
                                            )
                                            for k in range(len(md))
                                        ]
                                    )
                                )
                            )
                        ),
                    )
                )

        def dictionaries(path, rows):
            write_csv(path, list(rows[0]), ([r[k] for k in rows[0]] for r in rows))

        dictionaries(folder / "pair_scan.csv", pairs[mi])
        dictionaries(folder / "well_summary.csv", summary_rows)
        write_csv(
            folder / "point_scan.csv",
            [
                "well",
                "source_row",
                "MD_m",
                "N_m",
                "E_m",
                "D_m",
                "common_min_SF",
                "common_neighbor",
                "common_neighbor_MD_m",
                "common_neighbor_N_m",
                "common_neighbor_E_m",
                "common_neighbor_D_m",
                "common_distance_at_SF_min_m",
                "common_risk_code",
                "common_all_neighbors_SF_le_1_5",
                "project_min_SF",
                "project_neighbor",
                "project_neighbor_MD_m",
                "project_neighbor_N_m",
                "project_neighbor_E_m",
                "project_neighbor_D_m",
                "project_risk_code",
                "center_min_m",
                "center_neighbor",
                "center_neighbor_MD_m",
                "common_SF_delta_vs_md_scalar",
                "source_min_SF",
            ],
            scan_rows,
        )
        write_csv(
            folder / "uncertainty_profiles.csv",
            [
                "well",
                "source_row",
                "MD_m",
                "inclination_deg",
                "azimuth_grid_deg",
                "max_axis_or_boundary_radius_m",
                "sigma_N_m",
                "sigma_E_m",
                "sigma_D_m",
                "C_NN_m2",
                "C_EE_m2",
                "C_DD_m2",
                "C_NE_m2",
                "C_ND_m2",
                "C_ED_m2",
                "representation",
                "sigma_perp_m",
            ],
            uncertainty_rows,
        )
        write_csv(
            folder / "risk_intervals.csv",
            [
                "well",
                "SF_convention",
                "risk_code",
                "MD_start_m",
                "MD_end_m",
                "point_count",
                "min_SF",
                "min_center_m",
            ],
            intervals,
        )
        for metric, label in ((0, "common"), (1, "project")):
            matrix = np.full((n, n), np.nan)
            for (i, j), record in zip(itertools.combinations(range(n), 2), pairs[mi]):
                matrix[i, j] = matrix[j, i] = record[f"{label}_min_SF"]
            write_csv(
                folder / f"{label}_SF_matrix.csv",
                ["well"] + [w["name"] for w in wells],
                (
                    [wells[i]["name"]] + [None if i == j else matrix[i, j] for j in range(n)]
                    for i in range(n)
                ),
            )
        values = np.concatenate([sfs[i][mi, 0].min(axis=1) for i in range(n)])
        native_values = np.concatenate([sfs[i][mi, 1].min(axis=1) for i in range(n)])
        old = np.concatenate(baseline)
        radii = np.concatenate([v["radius"] for v in models[mi]])
        base_radii = np.concatenate([v["radius"] for v in models[baseline_index]])
        model_summary.append(
            dict(
                model=name,
                points=len(values),
                well_pairs=len(pairs[mi]),
                global_min_common_SF=float(values.min()),
                global_min_project_SF=float(native_values.min()),
                common_risk_pairs=int(
                    sum(r["common_min_SF"] <= 1.5 or r["center_min_m"] <= 5 for r in pairs[mi])
                ),
                project_risk_pairs=int(
                    sum(r["project_min_SF"] <= 1.5 or r["center_min_m"] <= 5 for r in pairs[mi])
                ),
                common_red_points=sum(r["common_red_points"] for r in summary_rows),
                common_orange_points=sum(r["common_orange_points"] for r in summary_rows),
                common_yellow_points=sum(r["common_yellow_points"] for r in summary_rows),
                common_blue_points=sum(r["common_blue_points"] for r in summary_rows),
                project_red_points=sum(r["project_red_points"] for r in summary_rows),
                project_orange_points=sum(r["project_orange_points"] for r in summary_rows),
                project_yellow_points=sum(r["project_yellow_points"] for r in summary_rows),
                project_blue_points=sum(r["project_blue_points"] for r in summary_rows),
                common_sf_le_1_5_points=int((values <= 1.5).sum()),
                project_sf_le_1_5_points=int((native_values <= 1.5).sum()),
                max_error_radius_m=float(radii.max()),
                median_error_radius_m=float(np.median(radii)),
                mean_error_radius_difference_vs_md_scalar_m=float(np.mean(radii - base_radii)),
                mean_abs_common_SF_difference_vs_md_scalar=float(np.mean(np.abs(values - old))),
                max_abs_common_SF_difference_vs_md_scalar=float(np.max(np.abs(values - old))),
                risk_decision_changes_vs_md_scalar=int(
                    np.count_nonzero((values <= 1.5) != (old <= 1.5))
                ),
                covariance_construction_seconds=construction[mi],
                scan_kernel_seconds=float(kernel[mi]),
                theoretical_point_pairs=sum(r["total_point_pairs"] for r in pairs[mi]),
                evaluated_point_pairs=sum(r["evaluated_point_pairs"] for r in pairs[mi]),
            )
        )
        print("Saved complete model results:", name, flush=True)
    comparison = output / "02_comparison"
    comparison.mkdir(exist_ok=True)
    for filename, rows in (
        ("model_summary.csv", model_summary),
        ("well_summary.csv", well_summaries),
        ("source_baseline_audit.csv", audit),
    ):
        write_csv(comparison / filename, list(rows[0]), ([r[k] for k in rows[0]] for r in rows))
        save_json(comparison / filename.replace(".csv", ".json"), rows)
    pair_comparison = [dict(model=name, **r) for name, rows in zip(names, pairs) for r in rows]
    write_csv(
        comparison / "pair_comparison.csv",
        list(pair_comparison[0]),
        ([r[k] for k in pair_comparison[0]] for r in pair_comparison),
    )
    save_json(comparison / "pair_comparison.json", pair_comparison)
    fields = ["well", "source_row", "MD_m", "N_m", "E_m", "D_m", "center_min_m", "source_min_SF"]
    fields += [
        f"{name}_{kind}"
        for name in names
        for kind in (
            "common_min_SF",
            "project_min_SF",
            "common_risk_code",
            "max_axis_or_boundary_radius_m",
        )
    ]
    for wi, w in enumerate(wells):
        center = centers[wi].min(axis=1)
        common = [sfs[wi][mi, 0].min(axis=1) for mi in range(len(names))]
        native = [sfs[wi][mi, 1].min(axis=1) for mi in range(len(names))]
        classes = [classify(v, center, config) for v in common]
        for k in range(len(w["md"])):
            row = [
                w["name"],
                w["source_rows"][k],
                w["md"][k],
                *w["positions"][k],
                center[k],
                w["baseline"][k][0],
            ]
            for mi in range(len(names)):
                row += [
                    common[mi][k],
                    native[mi][k],
                    int(classes[mi][k]),
                    models[mi][wi]["radius"][k],
                ]
            point_comparison.append(row)
    write_csv(comparison / "point_comparison.csv", fields, point_comparison)
    save_json(comparison / "point_comparison_columns.json", fields)
    # Review-workbook builder consumes small summaries; all points remain CSV/NPZ.
    save_json(
        comparison / "review_workbook_data.json",
        dict(
            models=model_summary,
            wells=well_summaries,
            pairs=pair_comparison,
            audit=audit,
            parameters=[
                dict(model=name, parameter=key, value=json.dumps(value, ensure_ascii=False))
                for name, settings in config["models"].items()
                for key, value in settings.items()
            ],
        ),
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    run(arguments.config, arguments.output)
