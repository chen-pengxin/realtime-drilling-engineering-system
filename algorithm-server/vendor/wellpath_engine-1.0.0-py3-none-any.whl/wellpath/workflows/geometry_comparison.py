"""A/B/C x two geometries x two layouts x 1..5 segments x four NLP methods.

Cells and algorithms run sequentially to avoid concurrent wall-time bias.
Completed cells are resumable only with an identical configuration.
"""

import argparse
import copy
import itertools
import json
import os
import platform
import sys
import time
from pathlib import Path

import numpy as np
import scipy

from wellpath.optimization.segment_initialization import make_segment_initial
from wellpath.paths import PROJECT_ROOT
from wellpath.workflows.scenario_replanning import run_scene, save_json

ROOT = PROJECT_ROOT
MODELS = ("minimum_curvature", "constant_toolface")
LAYOUTS = ("arc", "arc-straight")


def cell_settings(config, model, layout, count):
    settings = copy.deepcopy(config)
    settings.update(arc_segment_model=model, trajectory_mode=layout, n_segments=count)
    if model in config.get("toolface_control_by_model", {}):
        settings["toolface_control"] = copy.deepcopy(config["toolface_control_by_model"][model])
    return settings


def collect(out):
    results = []
    for p in sorted(out.glob("*/arc*/segments_*/scene_*/algorithm_results.json")):
        if (p.parent / "scene_timing.json").exists():
            for result in json.loads(p.read_text()):
                result["result_directory"] = str((p.parent / result["algorithm"]).relative_to(out))
                results.append(result)
    return results


def validate_config(config):
    if len(config["arc_segment_models"]) != 2 or set(config["arc_segment_models"]) != set(MODELS):
        raise ValueError("Require both geometries exactly once")
    if len(config["trajectory_modes"]) != 2 or set(config["trajectory_modes"]) != set(LAYOUTS):
        raise ValueError("Require both layouts exactly once")
    if len(config["scenarios"]) != 3 or set(config["scenarios"]) != set("ABC"):
        raise ValueError("Require scenarios A/B/C exactly once; use CLI filters for partial runs")
    if config["segment_counts"] != [1, 2, 3, 4, 5]:
        raise ValueError("Require segment counts 1..5")
    if len(config["algorithms"]) != 4 or set(config["algorithms"]) != {
        "SLSQP",
        "trust-constr",
        "COBYLA",
        "COBYQA",
    }:
        raise ValueError("Require four solvers exactly once")
    if not set(config.get("toolface_control_by_model", {})) <= set(MODELS):
        raise ValueError("Unknown geometry in toolface_control_by_model")
    if (
        config["uncertainty_model"]["type"] != "iscwsa_rev0"
        or config["sf_method"] != "major_axis_sum"
    ):
        raise ValueError("Require configured Rev0/major axis SF")
    if not 0 < config["dls_upper_deg_per_30m"] < 6:
        raise ValueError("DLS must be <6")
    if not 0 < config["target_position_tolerance_m"] <= 0.5:
        raise ValueError("Target must be <=0.5m")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config", type=Path, default=ROOT / "configs/experiments/replanning_geometry_matrix.json"
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--models", nargs="+", choices=MODELS)
    parser.add_argument("--modes", nargs="+", choices=LAYOUTS)
    parser.add_argument("--counts", type=int, nargs="+")
    parser.add_argument("--scenarios", nargs="+", choices=list("ABC"))
    parser.add_argument("--render-only", action="store_true")
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    validate_config(config)
    out = args.output.resolve()
    out.mkdir(exist_ok=True, parents=True)
    saved = out / "experiment_config.json"
    if saved.exists() and json.loads(saved.read_text()) != config:
        raise ValueError("Refusing to mix configurations")
    save_json(saved, config)
    if args.render_only:
        from wellpath.reports.geometry_comparison import render_matrix

        render_matrix(out)
        return
    begin = time.perf_counter()
    completed_now = []
    invocation = dict(
        started_local=time.strftime("%Y-%m-%d %H:%M:%S %z"),
        python=sys.executable,
        python_version=platform.python_version(),
        numpy_version=np.__version__,
        scipy_version=scipy.__version__,
        execution="sequential cells, sequential algorithms; no cross-algorithm warm starts",
        thread_settings={
            k: os.environ.get(k)
            for k in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")
        },
    )
    invocations = out / "invocations"
    invocations.mkdir(exist_ok=True)
    invocation_file = invocations / f"{time.time_ns()}.json"
    save_json(invocation_file, invocation)
    cells = list(
        itertools.product(
            args.models or config["arc_segment_models"],
            args.modes or config["trajectory_modes"],
            args.counts or config["segment_counts"],
            args.scenarios or config["scenarios"],
        )
    )
    for index, (model, layout, count, scene) in enumerate(cells):
        if count not in config["segment_counts"]:
            raise ValueError("Count outside configuration")
        settings = cell_settings(config, model, layout, count)
        parent = out / model / layout / f"segments_{count:02d}"
        parent.mkdir(exist_ok=True, parents=True)
        save_json(parent / "experiment_config.json", settings)
        folder = parent / f"scene_{scene}"
        if args.resume and (folder / "scene_timing.json").exists():
            continue
        print(f"CELL {index + 1}/{len(cells)} {model} {layout} n={count} scene={scene}", flush=True)
        run_scene(scene, settings, parent, initial_builder=make_segment_initial)
        completed_now.append(str(folder.relative_to(out)))
        reports = collect(out)
        save_json(out / "all_results.json", reports)
        save_json(
            out / "progress.json",
            dict(
                completed_cells=len(reports) // 4,
                total_cells=60,
                completed_combinations=len(reports),
                total_combinations=240,
                feasible=sum(bool((r.get("final_check") or {}).get("feasible")) for r in reports),
                solver_executed=sum(bool(r.get("solver_executed")) for r in reports),
                last_completed=completed_now[-1],
                invocation_elapsed_seconds=time.perf_counter() - begin,
            ),
        )
        print("CELL COMPLETE", completed_now[-1], flush=True)
    reports = collect(out)
    save_json(out / "all_results.json", reports)
    invocation.update(
        completed_now=completed_now, computation_wall_seconds=time.perf_counter() - begin
    )
    save_json(invocation_file, invocation)
    render_begin = time.perf_counter()
    from wellpath.reports.geometry_comparison import render_matrix

    render_matrix(out)
    invocation.update(
        combined_report_seconds=time.perf_counter() - render_begin,
        total_wall_seconds=time.perf_counter() - begin,
    )
    save_json(invocation_file, invocation)
    print("COMPLETE", out, flush=True)


if __name__ == "__main__":
    main()
