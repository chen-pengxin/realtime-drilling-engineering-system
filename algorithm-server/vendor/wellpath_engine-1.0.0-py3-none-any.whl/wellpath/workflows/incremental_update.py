"""Incremental Rev0 collision update after the accepted local well14 splice.

Reuse 171 unrelated well pairs and unchanged well14 prefix. Rescan changed
geometry/error suffix against each neighbor, repair reverse minima invalidated
by deletion, and retain exact sampled minima. No global model/pair rebuild.
"""

import argparse
import copy
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl import load_workbook
from scipy.spatial import cKDTree

from wellpath.anticollision.engine import pointwise_separation_minimum
from wellpath.anticollision.error_models.propagation import rev0_covariance
from wellpath.anticollision.uncertainty import interpolate_cov, path_at
from wellpath.data_io.naming import artifact_name
from wellpath.geometry.arc import (
    minimum_curvature_between,
    minimum_curvature_increment,
    tangent,
)
from wellpath.geometry.minimum_curvature import interpolate_minimum_curvature
from wellpath.workflows.local_replanning import BASE, SOURCE, LocalReplanningProblem, load_data
from wellpath.workflows.scenario_replanning import save_csv, save_json
from wellpath.workflows.uncertainty_comparison import scan_pair

LEVELS = ["红色危险", "橙色警告", "黄色关注", "蓝色安全"]


def subset(w, mask):
    return {
        k: (v[mask] if isinstance(v, np.ndarray) and len(v) == len(w["md"]) else v)
        for k, v in w.items()
    }


def mc_compare(problem, e, md, p, inc, azi, out):
    ts = tangent(inc, azi).T
    mc = np.empty_like(p)
    mc[0] = p[0]
    for j in range(1, len(md)):
        mc[j] = mc[j - 1] + minimum_curvature_increment(ts[j - 1], ts[j], md[j] - md[j - 1])
    ends = problem.start_md + np.cumsum(e["physical"][:, 2])
    nodes = np.r_[problem.start_md, ends]
    np_, ni, na = path_at(problem, e, nodes - problem.start_md)
    nt = tangent(ni, na).T
    coarse = np.empty_like(p)
    origin = np_[0].copy()
    for j in range(3):
        mask = (md >= nodes[j] - 1e-8) & (md <= nodes[j + 1] + 1e-8)
        dist = np.clip(md[mask] - nodes[j], 0, nodes[j + 1] - nodes[j])
        coarse[mask] = minimum_curvature_between(
            origin, nt[j], nt[j + 1], nodes[j + 1] - nodes[j], dist
        )[0]
        origin = origin + minimum_curvature_increment(nt[j], nt[j + 1], nodes[j + 1] - nodes[j])
    fields = [
        "MD_m",
        "N_constant_toolface_m",
        "E_constant_toolface_m",
        "D_constant_toolface_m",
        "N_MC_1m_m",
        "E_MC_1m_m",
        "D_MC_1m_m",
        "delta_N_MC1m_m",
        "delta_E_MC1m_m",
        "delta_D_MC1m_m",
        "distance_difference_MC1m_m",
        "N_MC_control_nodes_m",
        "E_MC_control_nodes_m",
        "D_MC_control_nodes_m",
        "distance_difference_MC_nodes_m",
    ]
    save_csv(
        out / "minimum_curvature_comparison_1m.csv",
        fields,
        (
            [m, *x, *y, *(y - x), np.linalg.norm(y - x), *z, np.linalg.norm(z - x)]
            for m, x, y, z in zip(md, p, mc, coarse)
        ),
    )
    delta = mc - p
    dc = coarse - p
    result = dict(
        one_m_MC=dict(
            maximum_position_difference_m=float(np.linalg.norm(delta, axis=1).max()),
            endpoint_position_difference_m=float(np.linalg.norm(delta[-1])),
            rms_position_difference_m=float(np.sqrt(np.mean(np.sum(delta * delta, axis=1)))),
            maximum_absolute_NE_D_difference_m=np.max(abs(delta), axis=0).tolist(),
        ),
        control_node_only_MC=dict(
            maximum_position_difference_m=float(np.linalg.norm(dc, axis=1).max()),
            endpoint_position_difference_m=float(np.linalg.norm(dc[-1])),
        ),
        definition="Sequential MC integration from the same start and sampled attitudes; never force the recomputed endpoint to nominal. Control-node-only MC is a separate coarse approximation, not a recomputation from the full 1m table.",
    )
    save_json(out / "minimum_curvature_comparison.json", result)
    return result


def run(out):
    begin = time.perf_counter()
    report = json.loads((out / "result.json").read_text())
    assert report["final_check"]["feasible"]
    start, end = report["old_interval_MD_m"]
    delta = report["downstream_MD_shift_m"]
    data = load_data(start, end, out / "backup_before_replan.xlsx")
    old = data["original"]
    wells = data["wells"]
    own_index = next(i for i, w in enumerate(wells) if w["name"] == "井14")
    cfg = json.loads((out / "problem.json").read_text())
    settings = json.loads((out / "settings.json").read_text())
    problem = LocalReplanningProblem(cfg, data, settings)
    controls = np.asarray(json.loads((out / "selected_controls.json").read_text()))
    z = problem.pack(controls)
    e = problem.evaluate(z)
    ends = np.cumsum(controls[:, 2])
    finish = start + ends[-1]
    # Include absolute integer-MD grid and all three segment endpoints exactly.
    rel = np.unique(np.r_[np.arange(0.0, ends[-1], 1.0), 0.0, ends])
    md_adjust = start + rel
    p_adjust, i_adjust, a_adjust = path_at(problem, e, rel)
    prefix = old["md"] < start
    suffix = old["md"] > end
    new = copy.deepcopy(old)
    new["md"] = np.r_[old["md"][prefix], md_adjust, old["md"][suffix] + delta]
    new["positions"] = np.vstack([old["positions"][prefix], p_adjust, old["positions"][suffix]])
    new["inc"] = np.r_[old["inc"][prefix], i_adjust, old["inc"][suffix]]
    new["azi"] = np.r_[old["azi"][prefix], a_adjust, old["azi"][suffix]]
    new["source_rows"] = np.arange(3, len(new["md"]) + 3)
    count_prefix = int(prefix.sum())
    count_adjust = len(md_adjust)
    tick = time.perf_counter()
    # Keep measurement-station identity on the retained suffix. A shifted 1m
    # tabulation is not misinterpreted as thousands of new survey stations.
    previous = np.load(BASE / "models/iscwsa_rev0/well_14_survey_covariance.npz")
    stations = np.unique(
        np.r_[
            e["uncertainty"]["md"], previous["md_m"][previous["md_m"] > end] + delta, new["md"][-1]
        ]
    )
    ps = np.empty((len(stations), 3))
    ii = np.empty(len(stations))
    aa = np.empty(len(stations))
    pre = stations < start
    local = (stations >= start) & (stations <= finish)
    post = stations > finish
    ps[pre], ii[pre], aa[pre] = interpolate_minimum_curvature(
        old["md"], old["inc"], old["azi"], old["positions"], stations[pre]
    )
    ps[local], ii[local], aa[local] = path_at(problem, e, stations[local] - start)
    ps[post], ii[post], aa[post] = interpolate_minimum_curvature(
        old["md"], old["inc"], old["azi"], old["positions"], stations[post] - delta
    )
    unc = rev0_covariance(stations, ii, aa, ps, data["parameters"])
    cov = interpolate_cov(stations, unc["cov"], new["md"])
    new["radius"] = np.sqrt(np.maximum(np.linalg.eigvalsh(cov)[:, -1], 0.0))
    np.testing.assert_allclose(
        new["radius"][:count_prefix], old["radius"][prefix], rtol=1e-12, atol=1e-12
    )
    uncertainty_seconds = time.perf_counter() - tick
    np.savez_compressed(
        out / "updated_well14_covariance.npz",
        md_m=new["md"],
        cov_nev_m2=cov,
        radius_m=new["radius"],
        survey_md_m=stations,
        survey_inc_deg=ii,
        survey_azi_deg=aa,
        survey_positions_m=ps,
        survey_cov_nev_m2=unc["cov"],
        **{f"source__{key}": value for key, value in unc["terms"].items()},
    )
    comparison = mc_compare(problem, e, md_adjust, p_adjust, i_adjust, a_adjust, out)
    # Read cached directed minima, restricted to Rev0. All other models remain
    # historical pre-replan results rather than silently relabeled new results.
    cached = []
    for w in wells:
        c = np.load(BASE / "shared" / artifact_name(f"{w['name']}_all_neighbors_K1.npz"))
        mi = list(c["model_names"]).index("iscwsa_rev0")
        cached.append(
            dict(
                neighbor_names=c["neighbor_names"].tolist(),
                sf=c["minimum_sf_K1"][mi].copy(),
                args=c["matching_point_indices"][mi].copy(),
                center=c["center_distance_m"].copy(),
                center_args=c["center_matching_point_indices"].copy(),
            )
        )
    owncache = cached[own_index]
    owncache = {
        k: (v[:count_prefix].copy() if isinstance(v, np.ndarray) else v)
        for k, v in owncache.items()
    }
    for k in ["sf", "center"]:
        owncache[k] = np.vstack([owncache[k], np.full((len(new["md"]) - count_prefix, 19), np.inf)])
    for k in ["args", "center_args"]:
        owncache[k] = np.vstack(
            [owncache[k], np.full((len(new["md"]) - count_prefix, 19), -1, dtype=np.int32)]
        )
    cached[own_index] = owncache
    changed = subset(new, np.arange(len(new["md"])) >= count_prefix)
    retained_prefix = subset(new, np.arange(len(new["md"])) < count_prefix)
    scan_cfg = json.loads((BASE / "config.json").read_text())
    scan_cfg["block_size"] = 64
    pair_times = []
    repairs = 0
    for j, w in enumerate(wells):
        if j == own_index:
            continue
        tick = time.perf_counter()
        scan = scan_pair(
            changed,
            w,
            [dict(cov=None, radius=changed["radius"])],
            [dict(cov=None, radius=w["radius"])],
            scan_cfg,
        )
        ci = owncache["neighbor_names"].index(w["name"])
        cj = cached[j]["neighbor_names"].index("井14")
        owncache["sf"][count_prefix:, ci] = scan["best_a"][0, 0]
        owncache["args"][count_prefix:, ci] = scan["arg_a"][0, 0]
        owncache["center"][count_prefix:, ci] = scan["center_a"]
        owncache["center_args"][count_prefix:, ci] = scan["center_arg_a"]
        reverse = cached[j]
        invalid = reverse["args"][:, cj] >= data["start_index"]
        sf_prefix = reverse["sf"][:, cj].copy()
        args_prefix = reverse["args"][:, cj].copy()
        restore_time = dict(
            screening_seconds=0.0, refinement_seconds=0.0, control_seconds=0.0, total_seconds=0.0
        )
        if invalid.any():
            repair = pointwise_separation_minimum(
                w["positions"][invalid],
                retained_prefix["positions"],
                ra=w["radius"][invalid],
                rb=retained_prefix["radius"],
                k=1.0,
                sf_method="major_axis_sum",
            )
            sf_prefix[invalid] = repair["minimum_by_a"]
            args_prefix[invalid] = repair["offset_indices_by_a"]
            restore_time = repair["timing"]
            repairs += int(invalid.sum())
        take = scan["best_b"][0, 0] < sf_prefix
        reverse["sf"][:, cj] = np.where(take, scan["best_b"][0, 0], sf_prefix)
        reverse["args"][:, cj] = np.where(take, scan["arg_b"][0, 0] + count_prefix, args_prefix)
        # Center minima use the same deletion repair, independently of SF.
        cinvalid = reverse["center_args"][:, cj] >= data["start_index"]
        center_prefix = reverse["center"][:, cj].copy()
        cargs_prefix = reverse["center_args"][:, cj].copy()
        if cinvalid.any():
            dd, jj = cKDTree(retained_prefix["positions"]).query(w["positions"][cinvalid])
            center_prefix[cinvalid] = dd
            cargs_prefix[cinvalid] = jj
        take = scan["center_b"] < center_prefix
        reverse["center"][:, cj] = np.where(take, scan["center_b"], center_prefix)
        reverse["center_args"][:, cj] = np.where(
            take, scan["center_arg_b"] + count_prefix, cargs_prefix
        )
        pair_times.append(
            dict(
                neighbor=w["name"],
                wall_seconds=time.perf_counter() - tick,
                changed_points=len(changed["md"]),
                neighbor_points=len(w["md"]),
                reverse_SF_repairs=int(invalid.sum()),
                reverse_center_repairs=int(cinvalid.sum()),
                scan_timing=scan["timing"],
                repair_timing=restore_time,
                total_changed_point_pairs=scan["total_point_pairs"],
                refined_point_pairs=int(scan["evaluated"][0]),
            )
        )
        print(w["name"], "incremental scan complete", flush=True)
    wells[own_index] = new
    point_records = []
    patches = []
    pair_records = []
    current = pd.read_csv(BASE / "K_1/iscwsa_rev0/point_scan.csv.gz", low_memory=False)
    # Original worksheet rows/style identities are mapped explicitly for splice.
    old_source_indices = np.r_[
        np.flatnonzero(prefix), np.full(count_adjust, -1), np.flatnonzero(suffix)
    ]
    for wi, (w, c) in enumerate(zip(wells, cached)):
        nn = np.argmin(c["sf"], axis=1)
        sf = c["sf"][np.arange(len(nn)), nn]
        center = c["center"].min(axis=1)
        code = np.select([sf <= 1.0, sf <= 1.5, sf <= 2.5], [0, 1, 2], default=3)
        code = np.where(center <= 5.0, 0, code)
        annotations = []
        records = []
        for i in range(len(w["md"])):
            other = c["neighbor_names"][int(nn[i])]
            q = next(q for q in wells if q["name"] == other)
            index = int(c["args"][i, nn[i]])
            distance = float(np.linalg.norm(w["positions"][i] - q["positions"][index]))
            boundary = float(w["radius"][i] + q["radius"][index])
            assert np.isclose(sf[i], distance / max(boundary, 1e-14), rtol=1e-11, atol=1e-11)
            risky = "|".join(
                name for j, name in enumerate(c["neighbor_names"]) if c["sf"][i, j] <= 1.5
            )
            label = LEVELS[int(code[i])] + ("（中心距≤5m）" if center[i] <= 5 else "")
            ann = [float(sf[i]), risky or None, other, float(q["md"][index]), distance, label]
            annotations.append(ann)
            is_adjusted = wi == own_index and count_prefix <= i < count_prefix + count_adjust
            record = dict(
                well=w["name"],
                source_row=i + 3,
                MD_m=float(w["md"][i]),
                N_m=float(w["positions"][i, 0]),
                E_m=float(w["positions"][i, 1]),
                D_m=float(w["positions"][i, 2]),
                inclination_deg=float(w["inc"][i]),
                azimuth_grid_deg=float(w["azi"][i]),
                minimum_SF=float(sf[i]),
                minimum_center_m=float(center[i]),
                own_radius_m=float(w["radius"][i]),
                SF_neighbor=other,
                neighbor_MD_m=float(q["md"][index]),
                neighbor_point_index_0based=index,
                neighbor_radius_m=float(q["radius"][index]),
                distance_at_SF_min_m=distance,
                combined_risk_code=int(code[i]),
                combined_risk=label,
                adjusted_section=bool(is_adjusted),
            )
            records.append(record)
        point_records.extend(records)
        if wi == own_index:
            changes = [dict(row=i + 3, values=ann) for i, ann in enumerate(annotations)]
        else:
            before = current[current.well == w["name"]].reset_index(drop=True)
            changes = []
            for i, ann in enumerate(annotations):
                oldann = [
                    float(before.minimum_SF[i]),
                    None
                    if pd.isna(before.all_SF_le_1_5_neighbors[i])
                    else str(before.all_SF_le_1_5_neighbors[i]),
                    str(before.SF_neighbor[i]),
                    float(before.neighbor_MD_m[i]),
                    float(before.distance_at_SF_min_m[i]),
                    str(before.combined_risk[i]),
                ]
                equal = all(
                    (
                        abs(v - u) <= 1e-10 * max(1, abs(u))
                        if isinstance(v, float) and isinstance(u, float)
                        else v == u
                    )
                    for v, u in zip(ann, oldann)
                )
                if not equal:
                    changes.append(dict(row=i + 3, values=ann))
        patches.append(dict(sheet=w["name"], annotation_changes=changes))
        np.savez_compressed(
            out / artifact_name(f"{w['name']}_Rev0_incremental_neighbors.npz"),
            md_m=w["md"],
            neighbor_names=np.array(c["neighbor_names"]),
            minimum_sf_K1=c["sf"],
            matching_point_indices=c["args"],
            center_distance_m=c["center"],
            center_matching_point_indices=c["center_args"],
        )
    frame = pd.DataFrame(point_records)
    frame.to_csv(
        out / "updated_Rev0_K1_all_points.csv.gz",
        index=False,
        encoding="utf-8-sig",
        float_format="%.17g",
    )
    for i, w in enumerate(wells):
        for j in range(i + 1, len(wells)):
            q = wells[j]
            c = cached[i]
            col = c["neighbor_names"].index(q["name"])
            r = int(np.argmin(c["sf"][:, col]))
            b = int(c["args"][r, col])
            ci = int(np.argmin(c["center"][:, col]))
            cb = int(c["center_args"][ci, col])
            assert np.isclose(
                c["sf"][:, col].min(),
                cached[j]["sf"][:, cached[j]["neighbor_names"].index(w["name"])].min(),
                rtol=1e-12,
            )
            pair_records.append(
                dict(
                    well_a=w["name"],
                    well_b=q["name"],
                    minimum_SF=float(c["sf"][r, col]),
                    SF_MD_a_m=float(w["md"][r]),
                    SF_MD_b_m=float(q["md"][b]),
                    minimum_center_m=float(c["center"][ci, col]),
                    center_MD_a_m=float(w["md"][ci]),
                    center_MD_b_m=float(q["md"][cb]),
                    status="incrementally_updated"
                    if i == own_index or j == own_index
                    else "reused_unchanged_pair",
                )
            )
    pd.DataFrame(pair_records).to_csv(
        out / "updated_Rev0_K1_pairs.csv", index=False, encoding="utf-8-sig", float_format="%.17g"
    )
    ownframe = frame[frame.well == "井14"]
    ownframe.to_csv(
        out / "updated_well14_1m.csv", index=False, encoding="utf-8-sig", float_format="%.17g"
    )
    affected = ownframe[ownframe.adjusted_section]
    assert (affected.minimum_SF > 1.5).all() and (affected.minimum_center_m > 5.0).all()
    # All well14 points (including retained history/suffix) must remain safe.
    assert (ownframe.minimum_SF > 1.5).all() and (ownframe.minimum_center_m > 5.0).all()
    t = tangent(new["inc"], new["azi"]).T
    dogleg = np.r_[
        0.0,
        np.rad2deg(
            np.arctan2(
                np.linalg.norm(np.cross(t[:-1], t[1:]), axis=1),
                np.einsum("ni,ni->n", t[:-1], t[1:]),
            )
        )
        * 30
        / np.diff(new["md"]),
    ]
    assert dogleg.max() < 6.0
    dx = new["positions"][:, :2] - new["positions"][0, :2]
    close = np.linalg.norm(dx, axis=1)
    bearing = np.rad2deg(np.arctan2(dx[:, 1], dx[:, 0])) % 360
    bearing[close < 1e-14] = 0.0
    rows = np.column_stack(
        [
            new["md"],
            new["inc"],
            new["azi"],
            new["positions"][:, 2],
            new["positions"][:, 1],
            new["positions"][:, 0],
            close,
            bearing,
            dogleg,
            dx[:, 0],
        ]
    )
    original_book = load_workbook(out / "backup_before_replan.xlsx", read_only=True, data_only=True)
    original_values = list(original_book["井14"].iter_rows(min_row=3, values_only=True))
    original_book.close()
    for i, old_index in enumerate(old_source_indices):
        if old_index >= 0:
            rows[i] = original_values[int(old_index)][:10]
            if i >= count_prefix + count_adjust:
                rows[i, 0] += delta
    marks = []
    endpoint_rows = []
    for i, m in enumerate(new["md"]):
        mark = ""
        if count_prefix <= i < count_prefix + count_adjust:
            mark = "调整段"
            for k, b in enumerate(np.r_[start, start + ends]):
                if abs(m - b) < 1e-8:
                    mark = f"调整段端点{k}"
                    endpoint_rows.append(i + 3)
        marks.append([mark or None])
    patch = patches[own_index]
    patch.update(
        trajectory_rows=rows.tolist(),
        marks=marks,
        endpoint_rows=endpoint_rows,
        source_old_row_for_new_row=[
            None if i < 0 else int(old["source_rows"][i]) for i in old_source_indices
        ],
        old_point_count=len(old["md"]),
        new_point_count=len(new["md"]),
        start_MD_m=start,
        old_end_MD_m=end,
        new_end_MD_m=float(finish),
        downstream_MD_shift_m=delta,
    )
    book = load_workbook(out / "backup_before_replan.xlsx", read_only=True, data_only=True)
    original_segments = []
    for row in book["井14"].iter_rows(min_row=11, max_row=30, values_only=True):
        if (
            isinstance(row[11], (int, float))
            and isinstance(row[12], (int, float))
            and isinstance(row[13], (int, float))
        ):
            original_segments.append((float(row[12]), float(row[13])))
    book.close()
    segments = []
    for a, b in original_segments:
        if a < start:
            segments.append([len(segments) + 1, a, min(b, start)])
    for a, b in zip(np.r_[start, start + ends[:-1]], start + ends):
        segments.append([len(segments) + 1, float(a), float(b)])
    for a, b in original_segments:
        if b > end:
            segments.append([len(segments) + 1, max(a, end) + delta, b + delta])
    patch["segment_metadata"] = segments
    patch["footnotes"] = [
        ["数据来源：保留原案例轨迹；井14局部SLSQP调整。", None, None],
        ["插值：调整段恒工具面恒曲率；其余坐标保留。", None, None],
        ["狗腿度：与上一行间狗腿角×30/测深差。", None, None],
        ["视平移：井口水平位移在原配置方位上的投影。", None, None],
        ["段首段尾由控制参数直接计算，浅黄色并列一次。", None, None],
        ["防碰：Rev.0，K=1；仅增量更新井14相关结果。", None, None],
    ]
    patch["footnotes_first_row"] = 12 + len(segments)
    save_json(
        out / "workbook_patch.json",
        dict(
            source_file=str(out / "backup_before_replan.xlsx"),
            target_file=str(SOURCE),
            source_sha256=report["source_sha256"],
            patches=patches,
            own_sheet="井14",
            annotation_model="Rev.0",
            K=1.0,
            point_count=len(new["md"]),
            geometry="constant_toolface_constant_curvature",
            adjustment_start_MD_m=start,
            adjustment_end_MD_m=float(finish),
        ),
    )
    # Small, independent brute-force probes validate both update orientations,
    # especially the cached-minimum invalidation/deletion repair.
    rng = np.random.default_rng(20261113)
    probe_count = 0
    for wi, (w, c) in enumerate(zip(wells, cached)):
        chosen = np.unique(
            np.r_[0, len(w["md"]) - 1, rng.integers(0, len(w["md"]), min(12, len(w["md"])))]
        )
        cols = range(19) if wi == own_index else [c["neighbor_names"].index("井14")]
        for col in cols:
            q = next(q for q in wells if q["name"] == c["neighbor_names"][col])
            dist = np.linalg.norm(
                w["positions"][chosen, None, :] - q["positions"][None, :, :], axis=2
            )
            exact = dist / np.maximum(w["radius"][chosen, None] + q["radius"][None, :], 1e-14)
            np.testing.assert_allclose(
                c["sf"][chosen, col], exact.min(axis=1), rtol=1e-11, atol=1e-11
            )
            np.testing.assert_allclose(
                c["center"][chosen, col], dist.min(axis=1), rtol=1e-11, atol=1e-11
            )
            probe_count += len(chosen)
    save_json(
        out / "incremental_verification.json",
        dict(
            passed=True,
            independent_directed_point_neighbor_probes=probe_count,
            exact_splice_position_error_m=report["final_check"]["position_error_m"],
            all_well14_safe=True,
            maximum_table_dogleg_deg_per_30m=float(dogleg.max()),
            unrelated_well_pairs_reused=171,
            recomputed_well_pairs=19,
            prefix_radius_unchanged=True,
        ),
    )
    timing = dict(
        evaluation_wall_seconds=time.perf_counter() - begin,
        uncertainty_seconds=uncertainty_seconds,
        screening_seconds=sum(
            p["scan_timing"]["screening_seconds"] + p["repair_timing"]["screening_seconds"]
            for p in pair_times
        ),
        interval_refinement_seconds=sum(
            p["scan_timing"]["interval_refinement_seconds"]
            + p["repair_timing"]["refinement_seconds"]
            for p in pair_times
        ),
        pair_times=pair_times,
        invalidated_reverse_SF_point_minima_repaired=repairs,
        unrelated_well_pairs_reused=171,
        recomputed_well_pairs=19,
        unchanged_prefix_points_reused=count_prefix,
        adjusted_points=count_adjust,
        changed_error_suffix_points=len(new["md"]) - count_prefix - count_adjust,
        minimum_adjusted_SF=float(affected.minimum_SF.min()),
        minimum_adjusted_sampled_center_m=float(affected.minimum_center_m.min()),
        minimum_whole_well14_SF=float(ownframe.minimum_SF.min()),
        minimum_whole_well14_center_m=float(ownframe.minimum_center_m.min()),
        downstream_MD_shift_m=delta,
        nominal_final_MD_m=float(new["md"][-1]),
        minimum_curvature_comparison=comparison,
        definition="Incremental model construction + 19 changed-well pair scans/repair + exports/independent probes; does not include NLP or workbook authoring; screening/refinement are exclusive scan-kernel subdurations.",
    )
    save_json(out / "incremental_timing.json", timing)
    print("INCREMENTAL UPDATE VERIFIED", timing["evaluation_wall_seconds"], flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--output", type=Path, required=True)
    run(p.parse_args().output)
