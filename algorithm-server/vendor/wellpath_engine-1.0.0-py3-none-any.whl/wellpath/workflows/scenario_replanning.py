"""Run reproducible A/B/C, four-algorithm Rev0 replanning; emit one HTML per scene."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import time
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares

from wellpath.anticollision.engine import pointwise_separation_minimum
from wellpath.anticollision.error_models.propagation import rev0_covariance
from wellpath.anticollision.uncertainty import interpolate_cov
from wellpath.data_io.naming import artifact_name
from wellpath.data_io.scenarios import (
    ROOT,
    TARGET,
    prepare_scene,
    problem_configuration,
)
from wellpath.optimization.runner import solve_algorithm
from wellpath.planning.geometry_problem import WellControlProblem
from wellpath.planning.replanning_problem import ReplanningProblem


def plain(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def save_json(path, obj):
    Path(path).write_text(
        json.dumps(obj, default=plain, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def save_csv(path, fields, rows):
    with Path(path).open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(fields)
        w.writerows(rows)


def make_initial(problem):
    begin = time.perf_counter()
    cfg = problem.cfg
    geometry = WellControlProblem(cfg)
    rng = np.random.default_rng(cfg["solver"]["random_seed"])
    log = []
    starts = []
    for attempt in range(cfg["solver"]["initial_search_attempts"]):
        t = time.perf_counter()

        def residual(z):
            e = geometry.evaluate(z)
            return np.r_[
                e["position_error"] / 100.0,
                e["angle_errors"] / 10.0,
                np.minimum(e["g"][: 4 * geometry.n], 0.0) * 10.0,
            ]

        fitted = least_squares(
            residual,
            geometry.seed(rng, attempt),
            bounds=(0.0, 1.0),
            max_nfev=cfg["solver"]["feasibility_max_nfev"],
            ftol=1e-11,
            xtol=1e-11,
            gtol=1e-11,
        )
        geom_seconds = time.perf_counter() - t
        t = time.perf_counter()
        check = problem.check(fitted.x)
        restore_seconds = 0.0
        if not check["feasible"]:
            restore = time.perf_counter()
            restored = least_squares(
                lambda z: np.minimum(problem.evaluate(z)["g"] - 1e-6, 0),
                fitted.x,
                bounds=(0.0, 1.0),
                max_nfev=cfg["solver"]["feasibility_max_nfev"],
                gtol=1e-10,
                ftol=1e-10,
                xtol=1e-10,
            )
            fitted = restored
            check = problem.check(fitted.x)
            restore_seconds = time.perf_counter() - restore
        dense = problem.final_verify(fitted.x) if check["feasible"] else None
        accepted = dense is not None and dense["check"]["feasible"]
        log.append(
            dict(
                attempt=attempt + 1,
                geometric_fit_seconds=geom_seconds,
                restoration_seconds=restore_seconds,
                validation_and_restoration_seconds=time.perf_counter() - t,
                nfev=int(fitted.nfev),
                geometry_check=geometry.check(fitted.x),
                coarse_check=check,
                final_check=None if dense is None else dense["check"],
            )
        )
        print(
            f"Initial {attempt + 1}: feasible={accepted}; position={check['position_error_m']:.6g}; SF={check['minimum_sf']:.5f}",
            flush=True,
        )
        if accepted:
            starts.append(fitted.x.copy())
            break
    total = time.perf_counter() - begin
    geometry_seconds = sum(r["geometric_fit_seconds"] for r in log)
    restore_seconds = sum(r["restoration_seconds"] for r in log)
    dense_seconds = sum(
        (r["final_check"] or {}).get("final_verification_seconds", 0.0) for r in log
    )
    return starts, dict(
        elapsed_seconds=total,
        attempts=log,
        timing_breakdown=dict(
            geometric_fit_seconds=geometry_seconds,
            feasibility_restoration_seconds=restore_seconds,
            final_1m_verification_seconds=dense_seconds,
            coarse_constraint_validation_and_control_seconds=max(
                0.0, total - geometry_seconds - restore_seconds - dense_seconds
            ),
        ),
        method="Geometric MC guess -> bounded least_squares for position/attitude/geometric limits -> full-constraint restoration if needed -> independent 1m verification",
        shared_across_algorithms=True,
        status="feasible" if starts else "initial_search_failed_not_proof_of_infeasibility",
    )


def export_track(folder, label, result):
    folder.mkdir(exist_ok=True)
    save_json(folder / f"{label}_check.json", result["check"])
    physical = result["physical"]
    ends = np.cumsum(physical[:, 2])
    rel = result["relative_md"]
    seg = np.minimum(np.searchsorted(ends, rel, side="left"), len(physical) - 1)
    save_csv(
        folder / f"{label}_trajectory.csv",
        [
            "MD_m",
            "relative_MD_m",
            "N_m",
            "E_m",
            "D_m",
            "inclination_deg",
            "grid_azimuth_deg",
            "segment",
            "DLS_deg_per_30m",
            "max_axis_1sigma_m",
            "minimum_SF",
        ],
        (
            [m, l, *p, i, a, int(j + 1), physical[j, 0], r, sf]
            for m, l, p, i, a, j, r, sf in zip(
                result["md"],
                rel,
                result["positions"],
                result["inc"],
                result["azi"],
                seg,
                result["radius"],
                result["minimum_sf"],
            )
        ),
    )
    np.savez_compressed(
        folder / f"{label}_uncertainty.npz",
        md_m=result["md"],
        cov_nev_m2=result["cov"],
        radius_m=result["radius"],
        survey_md_m=result["uncertainty"]["md"],
        survey_cov_nev_m2=result["uncertainty"]["cov"],
        **{f"source__{key}": v for key, v in result["uncertainty"]["result"]["terms"].items()},
    )
    np.savez_compressed(
        folder / f"{label}_all_neighbors.npz",
        md_m=result["md"],
        neighbor_names=np.array([p["neighbor"] for p in result["profiles"]]),
        min_SF=np.column_stack([p["minimum_sf"] for p in result["profiles"]]),
        matching_offset_index=np.column_stack([p["matching_index"] for p in result["profiles"]]),
    )
    save_json(
        folder / f"{label}_segments.json",
        [
            dict(
                segment=i + 1,
                type=("straight" if d == 0 else "arc"),
                dls_deg_per_30m=d,
                curvature_1_per_m=float(np.deg2rad(d) / 30),
                initial_toolface_deg=None if d == 0 else w,
                length_m=L,
                arc_segment_model=result.get("arc_segment_model", "minimum_curvature"),
                toolface_behavior=(
                    "undefined_on_straight"
                    if d == 0
                    else "constant_within_segment"
                    if result.get("arc_segment_model") == "constant_toolface"
                    else "initial_value_only"
                ),
            )
            for i, (d, w, L) in enumerate(physical)
        ],
    )
    if result.get("arc_segment_model") == "constant_toolface":
        save_json(folder / f"{label}_geometry.json", result["geometry_metadata"])
        save_csv(
            folder / f"{label}_toolface_profile.csv",
            ["MD_m", "relative_MD_m", "segment", "segment_type", "toolface_deg"],
            (
                [
                    m,
                    l,
                    int(j + 1),
                    "straight" if physical[j, 0] == 0 else "constant_toolface_curve",
                    "" if physical[j, 0] == 0 else physical[j, 1],
                ]
                for m, l, j in zip(result["md"], rel, seg)
            ),
        )


def fixed_history_audit(problem):
    begin = time.perf_counter()
    w = problem.data["actual"]["井1"]
    h = problem.history
    r = rev0_covariance(h["md"], h["inc"], h["azi"], h["positions"], problem.data["parameters"])
    c = interpolate_cov(
        h["md"], r["cov"] + np.asarray(problem.settings["start_cov_nev_m2"]), w["md"]
    )
    ra = np.sqrt(np.maximum(np.linalg.eigvalsh(c)[:, -1], 0))
    details = []
    for n in problem.data["neighbors"]:
        other = n["scan"]
        scan = pointwise_separation_minimum(
            w["positions"],
            other["positions"],
            ra=ra,
            rb=other["radius"],
            k=problem.k,
            block_rows=128,
            block_columns=128,
            sf_method="major_axis_sum",
        )
        i, j = scan["reference_index"], scan["offset_index"]
        details.append(
            dict(
                neighbor=other["name"],
                minimum_sf=scan["minimum_sf"],
                md_well1_m=float(w["md"][i]),
                offset_md_m=float(other["md"][j]),
            )
        )
    return dict(
        minimum_sf=min(d["minimum_sf"] for d in details),
        details=details,
        included_in_optimizable_constraints=False,
        note="Fixed drilled history is immutable; its risks are reported separately from new-section acceptance.",
        elapsed_seconds=time.perf_counter() - begin,
    )


def run_scene(scene, settings, out, initial_builder=None):
    from wellpath.workflows.discrete_toolface import needs_discrete_dispatch, run_discrete_scene

    if needs_discrete_dispatch(settings):
        return run_discrete_scene(scene, settings, out, initial_builder)
    return _run_continuous_scene(scene, settings, out, initial_builder)


def _run_continuous_scene(scene, settings, out, initial_builder=None):
    begin = time.perf_counter()
    folder = out / f"scene_{scene}"
    folder.mkdir(exist_ok=True)
    setup = time.perf_counter()
    data = prepare_scene(scene, settings)
    cfg = problem_configuration(data, settings)
    problem = ReplanningProblem(cfg, data, settings)
    setup_seconds = time.perf_counter() - setup
    save_json(folder / "input_audit.json", data["audit"])
    save_json(folder / "problem.json", cfg)
    for label, wells in (("actual", data["actual"]), ("design", data["design"])):
        sub = folder / f"{label}_input"
        sub.mkdir(exist_ok=True)
        for name, w in wells.items():
            save_csv(
                sub / f"{name}.csv",
                ["source_row", "MD_m", "inclination_deg", "azimuth_grid_deg", "N_m", "E_m", "D_m"],
                (
                    [row, m, i, a, *p]
                    for row, m, i, a, p in zip(
                        w["source_rows"], w["md"], w["inc"], w["azi"], w["positions"]
                    )
                ),
            )
    covdir = folder / "neighbor_covariance"
    covdir.mkdir(exist_ok=True)
    for n in data["neighbors"]:
        np.savez_compressed(
            covdir / artifact_name(f"{n['scan']['name']}.npz"),
            md_m=n["scan"]["md"],
            cov_nev_m2=n["scan"]["cov"],
            survey_md_m=n["stations"]["md"],
            survey_cov_nev_m2=n["stations"]["cov"],
        )
    setup_seconds = time.perf_counter() - setup
    if problem.arc_segment_model == "constant_toolface":
        from wellpath.geometry.segments import clear_position_cache

        clear_position_cache()
    before = problem.profiler.snapshot()
    starts, initial = (initial_builder or make_initial)(problem)
    initial["module_profile"] = problem.profiler.since(before)
    save_json(folder / "initialization.json", initial)
    if not starts:
        if settings.get("continue_on_initial_failure", False):
            from wellpath.reports.segment_comparison import export_initial_failure

            return export_initial_failure(
                folder, data, settings, problem, initial, setup_seconds, begin
            )
        raise RuntimeError(
            f"Scenario {scene}: no verified initial point found; see initialization.json"
        )
    initial_controls = problem.unpack(starts[0])
    save_json(folder / "shared_initial_controls.json", initial_controls)
    initial_hash = hashlib.sha256(starts[0].tobytes()).hexdigest()
    initial_result = problem.final_verify(starts[0])
    export_track(folder, "shared_initial", initial_result)
    history = fixed_history_audit(problem)
    save_json(folder / "fixed_history_evaluation.json", history)
    reports = []
    tracks = {}
    for algorithm in settings["algorithms"]:
        method_folder = folder / algorithm
        method_folder.mkdir(exist_ok=True)
        algorithm_begin = time.perf_counter()
        before = problem.profiler.snapshot()
        # Clear the memoized last input. Each method starts with the same controls
        # and fixed uncertainty/offset cache. No method inherits another result.
        problem._cache_z = None
        problem._cache_e = None
        if problem.arc_segment_model == "constant_toolface":
            clear_position_cache()
        z, report = solve_algorithm(problem, [x.copy() for x in starts], algorithm)
        solve_profile = problem.profiler.since(before)
        before = problem.profiler.snapshot()
        verify_begin = time.perf_counter()
        final = problem.final_verify(z)
        verification_seconds = time.perf_counter() - verify_begin
        fallback = False
        if not final["check"]["feasible"]:
            # Do not advertise a grid-feasible result as a verified solution.
            report["rejected_selected_controls"] = problem.unpack(z)
            report["rejected_selected_dense_check"] = final["check"]
            z = starts[0].copy()
            final = problem.final_verify(z)
            fallback = True
        report["final_check"] = final["check"]
        report["final_total_length_m"] = float(final["physical"][:, 2].sum())
        report["selected_after_dense_fallback_to_initial"] = fallback
        report["full_well_final_MD_m"] = float(problem.start_md + report["final_total_length_m"])
        report["tie_in_md_m"] = problem.start_md
        report["shared_initial_hash"] = initial_hash
        report["scenario"] = scene
        report["target"] = TARGET
        report["n_segments"] = problem.n
        report["trajectory_mode"] = problem.trajectory_mode
        report["free_control_variables"] = problem.dim
        report["segment_types"] = problem.segment_types
        report["solver_executed"] = True
        report["arc_segment_model"] = problem.arc_segment_model
        report["geometry_metadata"] = problem.geometry_metadata
        report["uncertainty_model"] = settings["uncertainty_model"]
        report["effective_rev0_parameters"] = data["parameters"]
        report["sf_method"] = settings["sf_method"]
        report["k_sigma"] = settings["k_sigma"]
        report["constraints"] = cfg
        report["shared_preprocessing_seconds"] = setup_seconds
        report["feasibility_construction_seconds"] = initial["elapsed_seconds"]
        report["dense_final_verification_seconds"] = verification_seconds
        report["optimization_module_profile"] = solve_profile
        report["final_verification_module_profile"] = problem.profiler.since(before)
        export_begin = time.perf_counter()
        export_track(method_folder, "selected", final)
        # Last solver point remains available even when the selected feasible
        # design is a retained iterate or the common initial point.
        raw = np.array(report["runs"][-1]["raw_candidate_controls_normalized"])
        report["raw_solver_candidate_controls"] = problem.unpack(raw)
        report["raw_solver_candidate_check"] = problem.check(raw)
        raw_e = problem.evaluate(raw)
        raw_ends = np.cumsum(raw_e["physical"][:, 2])
        raw_query = np.unique(np.r_[0.0, np.arange(0, raw_ends[-1], 2.0), raw_ends])
        from wellpath.anticollision.uncertainty import path_at

        rp, ri, ra = path_at(problem, raw_e, raw_query)
        save_csv(
            method_folder / "raw_solver_candidate_trajectory.csv",
            ["MD_m", "N_m", "E_m", "D_m", "inclination_deg", "azimuth_deg"],
            ([m + problem.start_md, *p, i, a] for m, p, i, a in zip(raw_query, rp, ri, ra)),
        )
        report["export_seconds"] = time.perf_counter() - export_begin
        report["method_wall_seconds"] = time.perf_counter() - algorithm_begin
        report["complete_flow_seconds"] = (
            setup_seconds + initial["elapsed_seconds"] + report["method_wall_seconds"]
        )
        report["timing_definition"] = (
            "complete_flow = shared input/model preparation + shared initial construction/dense check + method wall (solver, internal validation, dense final scan, export); fixed-history audit and report visualization timed separately. Module profiles are exclusive inner times within their phase; never add again to wall time."
        )
        save_json(method_folder / "result.json", report)
        reports.append(report)
        tracks[algorithm] = final
        save_json(folder / "algorithm_results.json", reports)
        print(
            f"SCENE {scene} {algorithm}: FINAL feasible={final['check']['feasible']} length={report['final_total_length_m']:.6f}, SF={final['check']['minimum_sf']:.6f}, endpoint={final['check']['position_error_m']:.6f}, full flow={report['complete_flow_seconds']:.3f}s",
            flush=True,
        )
    save_csv(
        folder / "algorithm_comparison.csv",
        [
            "algorithm",
            "feasible",
            "solver_success",
            "selected_source",
            "new_length_m",
            "final_MD_m",
            "position_error_m",
            "max_DLS_deg_per_30m",
            "min_SF",
            "centerline_lower_bound_m",
            "complete_flow_s",
            "shared_preprocessing_s",
            "feasible_initial_s",
            "optimization_s",
            "solver_validation_s",
            "dense_final_scan_s",
            "export_s",
        ],
        (
            [
                r["algorithm"],
                r["final_check"]["feasible"],
                r["solver_success"],
                r["selected_candidate"],
                r["final_total_length_m"],
                r["full_well_final_MD_m"],
                r["final_check"]["position_error_m"],
                r["final_check"]["maximum_dls_deg_per_30m"],
                r["final_check"]["minimum_sf"],
                r["final_check"]["minimum_centerline_distance_m"],
                r["complete_flow_seconds"],
                setup_seconds,
                initial["elapsed_seconds"],
                r["optimization_seconds"],
                r["validation_seconds"],
                r["dense_final_verification_seconds"],
                r["export_seconds"],
            ]
            for r in reports
        ),
    )
    for source in data["audit"]["sources"]:
        if hashlib.sha256(Path(source["path"]).read_bytes()).hexdigest() != source["sha256"]:
            raise AssertionError("Source file changed")
    before_view = time.perf_counter()
    from wellpath.reports.scenario_replanning import create_scene_html

    create_scene_html(folder, data, settings, reports, tracks, initial_result, initial, history)
    visualization_seconds = time.perf_counter() - before_view
    save_json(
        folder / "scene_timing.json",
        dict(
            scenario_wall_seconds=time.perf_counter() - begin,
            preprocessing_seconds=setup_seconds,
            shared_initial_seconds=initial["elapsed_seconds"],
            fixed_history_audit_seconds=history["elapsed_seconds"],
            algorithms_wall_seconds=sum(r["method_wall_seconds"] for r in reports),
            visualization_seconds=visualization_seconds,
            source_files_unchanged=True,
        ),
    )
    return reports


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config", type=Path, default=ROOT / "configs/experiments/replanning_ABC.json"
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--scenarios", nargs="+", choices=list("ABC"))
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Reuse completed scene reports only; never reuse another algorithm solution as a start",
    )
    args = parser.parse_args()
    settings = json.loads(args.config.read_text())
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    save_json(out / "experiment_config.json", settings)
    if (
        settings["sf_method"] != "major_axis_sum"
        or settings["uncertainty_model"]["type"] != "iscwsa_rev0"
    ):
        raise ValueError(
            "This scenario runner requires configured Rev0 major-axis SF; use generic runner for alternative models"
        )
    if not 0 < settings["dls_upper_deg_per_30m"] < 6:
        raise ValueError("Require strict DLS upper <6")
    if settings["target_position_tolerance_m"] > 0.5:
        raise ValueError("Target radius must be <=.5 m")
    all_reports = []
    for scene in args.scenarios or settings["scenarios"]:
        completed = out / f"scene_{scene}" / "scene_timing.json"
        if args.resume and completed.exists():
            all_reports.extend(
                json.loads((completed.parent / "algorithm_results.json").read_text())
            )
            continue
        print(f"===== SCENE {scene} =====", flush=True)
        all_reports.extend(run_scene(scene, settings, out))
    save_json(out / "all_scenarios_results.json", all_reports)
    from wellpath.reports.scenario_replanning import create_index

    create_index(out, all_reports)
    print("Completed:", out.resolve(), flush=True)


if __name__ == "__main__":
    main()
