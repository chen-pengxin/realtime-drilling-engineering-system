"""Read-only 15/16/20-well comparison using the established model/scan kernels.

All K cases are exact positive rescalings of an exhaustive-equivalent K=1
scan. Export every point minimum and every directed point/neighbor minimum.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import itertools
import json
import shutil
import time
from pathlib import Path

import numpy as np

from wellpath.anticollision.error_models.propagation import REV0_DEFAULTS, WDW_DEFAULTS
from wellpath.data_io.naming import artifact_name
from wellpath.exports.provenance import snapshot_sources
from wellpath.paths import PROJECT_ROOT
from wellpath.workflows.uncertainty_comparison import (
    classify,
    evaluate,
    read_wells,
    save_json,
    write_csv,
)

ROOT = PROJECT_ROOT
K_VALUES = [1.0, 2.0, 2.5, 3.0]
LABELS = dict(
    iscwsa="ISCWSA MWD Rev5.11",
    constant_covariance="固定协方差",
    constant_isotropic="固定各向同性",
    linear_std="标准差线性增长",
    random_walk="方差线性增长",
    tabulated_covariance="协方差表",
    md_scalar_radius="MD标量半径（当前论文模型）",
    simplified_mwd="TrueMyWell简化MWD",
    iscwsa_rev0="ISCWSA Rev.0",
    wdw="WdW",
)
LEVELS = ["红色危险", "橙色警告", "黄色关注", "蓝色安全"]


def table(path, records):
    if not records:
        return
    write_csv(path, list(records[0]), ([r[k] for k in records[0]] for r in records))


def compressed_csv(path, fields, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wt", encoding="utf-8-sig", newline="", compresslevel=3) as f:
        w = csv.writer(f)
        w.writerow(fields)
        for row in rows:
            w.writerow(
                [
                    format(float(v), ".17g") if isinstance(v, (float, np.floating)) else v
                    for v in row
                ]
            )


def configuration(source, n):
    base = ROOT / "configs/collision/scan_defaults.json"
    cfg = json.loads(base.read_text())
    cfg.update(input_file=str(source), expected_wells=n, header_row=2)
    cfg["timing"]["independent_model_runs"] = False
    cfg["common_sf"] = dict(method="major_axis_sum", k_sigma=1.0)
    cfg["project_sf"] = dict(sf_method="major_axis_sum", k_sigma=1.0)
    cfg["models"]["iscwsa_rev0"]["uncertainty_model"]["parameters"] = REV0_DEFAULTS.copy()
    cfg["models"]["wdw"]["uncertainty_model"]["parameters"] = WDW_DEFAULTS.copy()
    cfg["assumptions"] = [
        "Use full float64 source N/E/D, MD, inclination and grid azimuth; do not overwrite supplied coordinates.",
        "Workbook trajectories are planning/interpolated points, not independent 1 m MWD measurements.",
        "Grid azimuth is treated as true azimuth (zero convergence); no survey date/location/tool calibration metadata supplied.",
        "Existing project parameters retained for sensitivity comparison, not field-calibrated model accuracy ranking.",
        "ISCWSA/Rev0/WdW synthetic stations every 30 m plus supplied fractional endpoints; MC attitude interpolation and covariance interpolation.",
        "SF=D/[K*(r1+r2)]; covariance r=sqrt(lambda_max(C)), scalar r=current scalar_radius(MD). No bore radius/margin/extra position sigma deducted or added by SF.",
        "K is a common positive scalar for both wells; exact SF_K=SF_1/K. Independent center distances and matching indices remain unchanged.",
        "SF and center distance minima are over all cross-well sampled point combinations, not equal MD only.",
        "Horizontal AABB conservative pruning preserves all sampled minima. Center distances use independent exact point KD-tree searches.",
        "No shallow-section exclusion; source wellheads with center distance <=5 m count as red.",
        "All minima and matches retained, but Cartesian point-pair matrices are not stored; center distance is sampled-point distance, not certified continuous-curve clearance.",
    ]
    return cfg


def export_group(folder, wells, cfg, result, input_audit):
    start = time.perf_counter()
    names = result["names"]
    models = result["models"]
    n = len(wells)
    pairs_list = list(itertools.combinations(range(n), 2))
    payload = dict(
        group=folder.name,
        models=names,
        labels=LABELS,
        k_values=K_VALUES,
        default_model="iscwsa_rev0",
        thresholds=cfg["thresholds"],
        wells=[],
        summaries=[],
        source_audit=input_audit,
        scan_timing=result["timing"],
    )
    data_dir = folder / "shared"
    data_dir.mkdir(exist_ok=True)
    center_rows = []
    for wi, w in enumerate(wells):
        names_other = np.array([q["name"] for q in wells])
        center = result["centers"][wi].min(axis=1)
        cw = result["centers"][wi].argmin(axis=1)
        idx = result["center_args"][wi][np.arange(len(center)), cw]
        pf = dict(
            name=w["name"],
            md=w["md"].tolist(),
            positions=w["positions"].tolist(),
            center=center.tolist(),
            models={},
        )
        for s in range(len(w["md"])):
            j = int(cw[s])
            q = int(idx[s])
            center_rows.append(
                [
                    w["name"],
                    w["source_rows"][s],
                    w["md"][s],
                    *w["positions"][s],
                    center[s],
                    wells[j]["name"],
                    wells[j]["md"][q],
                    *wells[j]["positions"][q],
                    int(center[s] <= 5.0),
                ]
            )
        others = np.arange(n) != wi
        np.savez_compressed(
            data_dir / artifact_name(f"{w['name']}_all_neighbors_K1.npz"),
            md_m=w["md"],
            model_names=np.array(names),
            neighbor_names=names_other[others],
            minimum_sf_K1=result["sfs"][wi][:, 0][:, :, others],
            matching_point_indices=result["args"][wi][:, 0][:, :, others],
            center_distance_m=result["centers"][wi][:, others],
            center_matching_point_indices=result["center_args"][wi][:, others],
        )
        # Explicit orientation avoids NumPy advanced-index axis ambiguity.
        check = np.load(data_dir / artifact_name(f"{w['name']}_all_neighbors_K1.npz"))
        assert check["minimum_sf_K1"].shape == (len(names), len(w["md"]), n - 1)
        for mi, name in enumerate(names):
            sf = result["sfs"][wi][mi, 0].min(axis=1)
            pf["models"][name] = dict(sf1=sf.tolist(), radius=models[mi][wi]["radius"].tolist())
        payload["wells"].append(pf)
    write_csv(
        data_dir / "center_distance_points.csv",
        [
            "well",
            "source_row",
            "MD_m",
            "N_m",
            "E_m",
            "D_m",
            "min_center_m",
            "nearest_well",
            "nearest_MD_m",
            "nearest_N_m",
            "nearest_E_m",
            "nearest_D_m",
            "center_le_5m",
        ],
        center_rows,
    )
    del center_rows
    center_pairs = []
    for (i, j), r in zip(pairs_list, result["pairs"][0]):
        center_pairs.append(
            {
                k: r[k]
                for k in ["well_a", "well_b", "center_min_m", "center_md_a_m", "center_md_b_m"]
            }
        )
    table(data_dir / "center_distance_pairs.csv", center_pairs)
    for mi, name in enumerate(names):
        md_folder = folder / "models" / name
        md_folder.mkdir(parents=True, exist_ok=True)
        save_json(
            md_folder / "parameters.json",
            dict(
                settings=cfg["models"][name],
                effective_parameters=models[mi][0].get("effective_parameters"),
                radius_definition="sqrt(lambda_max(C)), C in 1sigma m2"
                if models[mi][0]["cov"] is not None
                else "scalar boundary radius in metres",
                model_construction_seconds=result["construction"][mi],
                assumed_not_field_calibrated=True,
            ),
        )

        def errors():
            for wi, w in enumerate(wells):
                d = models[mi][wi]
                for k in range(len(w["md"])):
                    c = d["cov"]
                    cv = (
                        [None] * 6
                        if c is None
                        else [
                            c[k, 0, 0],
                            c[k, 1, 1],
                            c[k, 2, 2],
                            c[k, 0, 1],
                            c[k, 0, 2],
                            c[k, 1, 2],
                        ]
                    )
                    yield [
                        w["name"],
                        w["source_rows"][k],
                        w["md"][k],
                        w["inc"][k],
                        w["azi"][k],
                        d["radius"][k],
                        *cv,
                    ]
                if "survey_md" in d:
                    np.savez_compressed(
                        md_folder / artifact_name(f"{w['name']}_survey_covariance.npz"),
                        md_m=d["survey_md"],
                        cov_nev_m2=d["survey_cov"],
                    )
                if "terms" in d:
                    np.savez_compressed(
                        md_folder / artifact_name(f"{w['name']}_source_terms.npz"),
                        md_m=d["survey_md"],
                        **d["terms"],
                    )

        compressed_csv(
            md_folder / "uncertainty_points.csv.gz",
            [
                "well",
                "source_row",
                "MD_m",
                "inclination_deg",
                "azimuth_grid_deg",
                "radius_m",
                "C_NN_m2",
                "C_EE_m2",
                "C_DD_m2",
                "C_NE_m2",
                "C_ND_m2",
                "C_ED_m2",
            ],
            errors(),
        )
    all_summary = []
    all_pair_rows = []
    all_well_rows = []
    k_times = []
    for kval in K_VALUES:
        tick = time.perf_counter()
        derive = 0.0
        k_folder = folder / f"K_{kval:g}"
        k_folder.mkdir(exist_ok=True)
        for mi, name in enumerate(names):
            model_folder = k_folder / name
            model_folder.mkdir(exist_ok=True)
            interval_rows = []
            well_rows = []
            derived = []
            # Derivation includes matching, grading, interval aggregation; excludes CSV writing.
            t = time.perf_counter()
            for wi, w in enumerate(wells):
                sf_all = result["sfs"][wi][mi, 0] / kval
                sf = sf_all.min(axis=1)
                neighbors = sf_all.argmin(axis=1)
                matched = result["args"][wi][mi, 0, np.arange(len(sf)), neighbors]
                center = result["centers"][wi].min(axis=1)
                sf_code = np.select([sf <= 1.0, sf <= 1.5, sf <= 2.5], [0, 1, 2], default=3)
                code = classify(sf, center, cfg)
                derived.append((sf_all, sf, neighbors, matched, center, sf_code, code))
                row = dict(
                    group=folder.name,
                    model=name,
                    K=kval,
                    well=w["name"],
                    points=len(sf),
                    minimum_SF=float(sf.min()),
                    minimum_center_m=float(center.min()),
                    sf_le_1_5_points=int((sf <= 1.5).sum()),
                    center_le_5m_points=int((center <= 5.0).sum()),
                    max_error_radius_m=float(models[mi][wi]["radius"].max()),
                )
                row.update(
                    {
                        f"{level}_points": int((code == i).sum())
                        for i, level in enumerate(["red", "orange", "yellow", "blue"])
                    }
                )
                well_rows.append(row)
                all_well_rows.append(row)
                boundaries = np.r_[0, np.flatnonzero(np.diff(code) != 0) + 1, len(code)]
                for a, b in zip(boundaries[:-1], boundaries[1:]):
                    interval_rows.append(
                        dict(
                            well=w["name"],
                            risk_code=int(code[a]),
                            risk=LEVELS[code[a]],
                            first_MD_m=float(w["md"][a]),
                            last_MD_m=float(w["md"][b - 1]),
                            point_count=int(b - a),
                            minimum_SF=float(sf[a:b].min()),
                            minimum_center_m=float(center[a:b].min()),
                        )
                    )
            pair_rows = []
            for (i, j), r in zip(pairs_list, result["pairs"][mi]):
                sf = r["common_min_SF"] / kval
                distance = r["center_min_m"]
                code = int(classify(np.array(sf), np.array(distance), cfg))
                row = dict(
                    group=folder.name,
                    model=name,
                    K=kval,
                    well_a=wells[i]["name"],
                    well_b=wells[j]["name"],
                    minimum_SF=sf,
                    SF_MD_a_m=r["common_md_a_m"],
                    SF_MD_b_m=r["common_md_b_m"],
                    distance_at_SF_min_m=r["common_distance_at_SF_min_m"],
                    radius_a_at_SF_min_m=float(
                        models[mi][i]["radius"][np.argmin(result["sfs"][i][mi, 0, :, j])]
                    ),
                    minimum_center_m=distance,
                    center_MD_a_m=r["center_md_a_m"],
                    center_MD_b_m=r["center_md_b_m"],
                    sf_risk_code=int(
                        np.select([sf <= 1.0, sf <= 1.5, sf <= 2.5], [0, 1, 2], default=3)
                    ),
                    risk_code=code,
                    risk=LEVELS[code],
                    **{
                        f"{axis}_{side}_m": r[f"common_{axis}_{side}_m"]
                        for side in ("a", "b")
                        for axis in ("N", "E", "D")
                    },
                )
                ia = int(np.argmin(result["sfs"][i][mi, 0, :, j]))
                ib = int(result["args"][i][mi, 0, ia, j])
                row["radius_b_at_SF_min_m"] = float(models[mi][j]["radius"][ib])
                np.testing.assert_allclose(
                    sf,
                    row["distance_at_SF_min_m"]
                    / max(
                        kval * (row["radius_a_at_SF_min_m"] + row["radius_b_at_SF_min_m"]), 1e-14
                    ),
                    rtol=1e-12,
                    atol=1e-12,
                )
                pair_rows.append(row)
                all_pair_rows.append(row)
            summary = dict(
                group=folder.name,
                model=name,
                label=LABELS[name],
                K=kval,
                well_count=n,
                points=sum(len(w["md"]) for w in wells),
                well_pairs=len(pair_rows),
                minimum_SF=min(r["minimum_SF"] for r in pair_rows),
                minimum_center_m=min(r["minimum_center_m"] for r in pair_rows),
                sf_le_1_5_pairs=sum(r["minimum_SF"] <= 1.5 for r in pair_rows),
                center_le_5m_pairs=sum(r["minimum_center_m"] <= 5 for r in pair_rows),
                combined_unsafe_pairs=sum(r["risk_code"] <= 1 for r in pair_rows),
                **{
                    f"{level}_points": sum(r[f"{level}_points"] for r in well_rows)
                    for level in ["red", "orange", "yellow", "blue"]
                },
                **{
                    f"{level}_pairs": sum(r["risk_code"] == c for r in pair_rows)
                    for c, level in enumerate(["red", "orange", "yellow", "blue"])
                },
                max_error_radius_m=max(float(d["radius"].max()) for d in models[mi]),
            )
            derive += time.perf_counter() - t
            all_summary.append(summary)
            payload["summaries"].append(summary)
            table(model_folder / "pair_scan.csv", pair_rows)
            table(model_folder / "well_summary.csv", well_rows)
            table(model_folder / "risk_intervals.csv", interval_rows)

            def point_rows():
                for wi, w in enumerate(wells):
                    sf_all, sf, neighbors, matched, center, sf_code, code = derived[wi]
                    for s in range(len(sf)):
                        j = int(neighbors[s])
                        q = int(matched[s])
                        other = wells[j]
                        yield [
                            w["name"],
                            int(w["source_rows"][s]),
                            w["md"][s],
                            *w["positions"][s],
                            sf[s],
                            other["name"],
                            int(q),
                            other["md"][q],
                            *other["positions"][q],
                            float(np.linalg.norm(w["positions"][s] - other["positions"][q])),
                            models[mi][wi]["radius"][s],
                            models[mi][j]["radius"][q],
                            center[s],
                            int(sf_code[s]),
                            int(code[s]),
                            LEVELS[code[s]],
                            "|".join(
                                wells[jj]["name"]
                                for jj in range(n)
                                if jj != wi and sf_all[s, jj] <= 1.5
                            ),
                        ]

            compressed_csv(
                model_folder / "point_scan.csv.gz",
                [
                    "well",
                    "source_row",
                    "MD_m",
                    "N_m",
                    "E_m",
                    "D_m",
                    "minimum_SF",
                    "SF_neighbor",
                    "neighbor_point_index_0based",
                    "neighbor_MD_m",
                    "neighbor_N_m",
                    "neighbor_E_m",
                    "neighbor_D_m",
                    "distance_at_SF_min_m",
                    "own_radius_m",
                    "neighbor_radius_m",
                    "minimum_center_m",
                    "sf_risk_code",
                    "combined_risk_code",
                    "combined_risk",
                    "all_SF_le_1_5_neighbors",
                ],
                point_rows(),
            )
        elapsed = time.perf_counter() - tick
        k_times.append(
            dict(
                K=kval,
                derivation_and_grading_seconds=derive,
                export_seconds=elapsed - derive,
                total_postprocess_seconds=elapsed,
            )
        )
        print(f"{folder.name} K={kval:g} export complete ({elapsed:.2f}s)", flush=True)
    table(folder / "model_K_summary.csv", all_summary)
    table(folder / "all_model_K_pairs.csv", all_pair_rows)
    table(folder / "all_model_K_wells.csv", all_well_rows)
    save_json(
        folder / "workbook_data.json",
        dict(
            group=folder.name,
            summary=all_summary,
            pairs=all_pair_rows,
            wells=all_well_rows,
            config=cfg,
            timing=result["timing"],
            K_timing=k_times,
            input_audit=input_audit,
        ),
    )
    payload["K_timing"] = k_times
    save_json(folder / "visualization_data.json", payload)
    save_json(
        folder / "timing.json",
        dict(
            shared_evaluation=result["timing"],
            K_postprocessing=k_times,
            all_export_wall_seconds=time.perf_counter() - start,
            definitions=dict(
                shared_evaluation="One joint 10-model K=1 calculation. Includes uncertainty construction, exact sampled center search, horizontal AABB screening, candidate interval SF refinement, matching and aggregation.",
                K="Exact SF_1/K and regrading. Shared scan is performed once; do not multiply shared time by 4.",
                center="Exact point KD-tree search. Horizontal AABB pruning is applied to the SF candidate intervals.",
                refinement="Refinement of candidate interval Cartesian point combinations, not resampling or optimization.",
                per_model="Construction time and exclusive model kernels are not standalone end-to-end model benchmarks.",
            ),
        ),
    )
    save_json(folder / "shared/pair_timing.json", result["pair_timing"])
    return all_summary


def run(output, input_directory=None):
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    start = time.perf_counter()
    input_dir = Path(input_directory) if input_directory else ROOT / "data/scenarios/cluster_groups"
    all_rows = []
    audits = []
    for filename, n in [
        ("cluster_15_design.xlsx", 15),
        ("cluster_16_design.xlsx", 16),
        ("cluster_20_design.xlsx", 20),
    ]:
        group_start = time.perf_counter()
        source = input_dir / filename
        if not source.exists() and input_directory is None:
            source = ROOT.parent / f"group_{n}" / "source.xlsx"
        folder = output / f"group_{n}"
        folder.mkdir()
        cfg = configuration(source, n)
        save_json(folder / "config.json", cfg)
        before = hashlib.sha256(source.read_bytes()).hexdigest()
        wells = read_wells(source, cfg)
        audit = dict(
            source_file=str(source),
            sha256_before=before,
            well_count=n,
            total_points=sum(len(w["md"]) for w in wells),
            pairs=n * (n - 1) // 2,
            well_data=[
                dict(
                    name=w["name"],
                    points=len(w["md"]),
                    start_MD_m=float(w["md"][0]),
                    end_MD_m=float(w["md"][-1]),
                    wellhead_NED_m=w["positions"][0].tolist(),
                    max_scan_interval_m=float(np.diff(w["md"]).max()),
                )
                for w in wells
            ],
        )
        save_json(folder / "input_audit.json", audit)
        shutil.copyfile(source, folder / "source.xlsx")
        read_seconds = time.perf_counter() - group_start
        print(
            f"{folder.name}: {audit['total_points']} points, {audit['pairs']} pairs; starting 10-model scan",
            flush=True,
        )
        result = evaluate(wells, cfg, verbose=False)
        print(
            f"{folder.name}: evaluation complete {result['timing']['evaluation_total_seconds']:.3f}s",
            flush=True,
        )
        for wi, w in enumerate(wells):
            write_csv(
                folder / "shared" / artifact_name(f"{w['name']}_trajectory.csv"),
                ["source_row", "MD_m", "inclination_deg", "azimuth_grid_deg", "N_m", "E_m", "D_m"],
                (
                    [r, md, inc, azi, *pos]
                    for r, md, inc, azi, pos in zip(
                        w["source_rows"], w["md"], w["inc"], w["azi"], w["positions"]
                    )
                ),
            )
        all_rows.extend(export_group(folder, wells, cfg, result, audit))
        audit.update(
            sha256_after=hashlib.sha256(source.read_bytes()).hexdigest(),
            input_read_copy_seconds=read_seconds,
            group_numerical_export_seconds=time.perf_counter() - group_start,
        )
        assert audit["sha256_after"] == before
        save_json(folder / "input_audit.json", audit)
        audits.append(audit)
        print(f"{folder.name}: COMPLETE {audit['group_numerical_export_seconds']:.2f}s", flush=True)
        del result, wells
    table(output / "all_groups_model_K_summary.csv", all_rows)
    save_json(
        output / "batch_audit.json",
        dict(
            groups=audits,
            model_K_cases=len(all_rows),
            K_values=K_VALUES,
            numerical_export_wall_seconds=time.perf_counter() - start,
        ),
    )
    copies = output / "reproduction"
    copies.mkdir()
    snapshot_sources(ROOT, copies)
    print("ALL GROUPS COMPLETE", output, flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--input-directory", type=Path)
    args = p.parse_args()
    run(args.output, args.input_directory)
