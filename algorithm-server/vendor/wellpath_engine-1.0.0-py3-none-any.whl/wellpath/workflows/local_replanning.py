"""Local well14 replacement using the existing SLSQP/constant-toolface kernels.

Numerical preparation and solving only; author/install workbook separately
after independent final acceptance. All unrelated pair scans remain cached.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import Bounds, least_squares, minimize

from wellpath.anticollision.error_models.propagation import rev0_covariance
from wellpath.anticollision.uncertainty import path_at
from wellpath.data_io.scenarios import sample_well
from wellpath.geometry.minimum_curvature import interpolate_minimum_curvature
from wellpath.optimization.runner import solve_algorithm
from wellpath.paths import PROJECT_ROOT
from wellpath.planning.geometry_problem import WellControlProblem
from wellpath.planning.replanning_problem import ReplanningProblem
from wellpath.workflows.scenario_replanning import export_track, save_json
from wellpath.workflows.uncertainty_comparison import read_wells

ROOT = PROJECT_ROOT
BASE = ROOT / "results/cluster_wellheads_spacing8m_20261113/group_20"
SOURCE = ROOT / "data/scenarios/cluster_groups/cluster_20_design.xlsx"


class LocalReplanningProblem(ReplanningProblem):
    def equality_constraints(self, z):
        e = WellControlProblem.evaluate(self, z)
        return np.r_[e["position_error"] / self.scale, e["angle_errors"] / 30.0]

    def evaluate(self, z, collision_cells=None):
        cached = self._cache_z is not None and np.array_equal(z, self._cache_z)
        e = super().evaluate(z, collision_cells)
        if not cached:
            # Five exact splice equalities replace the redundant very narrow
            # endpoint/angle inequality bands, whose tiny gradients hurt SQP.
            n_geo = 4 * self.n
            e["g"] = np.r_[e["g"][:n_geo], e["g"][n_geo + 12 :]]
        return e

    def uncertainty(self, e):
        """Global 30m synthetic stations, fixed history; never reset at tie-in."""
        ends = np.cumsum(e["physical"][:, 2])
        finish = self.start_md + ends[-1]
        original = self.data["original"]
        original_extra = original["md"][
            (original["md"] < self.start_md)
            & (np.abs(original["md"] - np.round(original["md"])) > 1e-7)
        ]
        md = np.unique(
            np.r_[np.arange(0.0, finish, 30.0), original_extra, self.start_md, self.start_md + ends]
        )
        old = md < self.start_md
        p = np.empty((len(md), 3))
        inc = np.empty(len(md))
        azi = np.empty(len(md))
        p[old], inc[old], azi[old] = interpolate_minimum_curvature(
            original["md"], original["inc"], original["azi"], original["positions"], md[old]
        )
        p[~old], inc[~old], azi[~old] = path_at(self, e, md[~old] - self.start_md)
        result = rev0_covariance(md, inc, azi, p, self.data["parameters"])
        return dict(
            md=md,
            cov=result["cov"],
            positions=p,
            inc=inc,
            azi=azi,
            result=result,
            geometry=self.arc_segment_model,
            geometry_metadata=self.geometry_metadata,
            covariance_geometry="MC station Jacobian on global 30m synthetic stations plus segment boundaries",
            history_preserved=True,
        )


def load_data(start, end, source_path=None):
    cfg = json.loads((BASE / "config.json").read_text())
    wells = read_wells(source_path or SOURCE, cfg)
    own = next(w for w in wells if w["name"] == "井14")
    errors = pd.read_csv(BASE / "models/iscwsa_rev0/uncertainty_points.csv.gz")
    params = json.loads((BASE / "models/iscwsa_rev0/parameters.json").read_text())[
        "effective_parameters"
    ]
    neighbors = []
    for w in wells:
        w["radius"] = errors.loc[errors.well == w["name"], "radius_m"].to_numpy()
        if w["name"] == "井14":
            continue
        # Neighbors' full 1m scans and errors are reused, no model rebuild.
        opt = sample_well(w, 10.0)
        opt["radius"] = np.interp(opt["md"], w["md"], w["radius"])
        neighbors.append(dict(scan=w, opt=opt))
    idx0 = int(np.flatnonzero(own["md"] == start)[0])
    idx1 = int(np.flatnonzero(own["md"] == end)[0])
    history = sample_well(own, 30.0, extra=[start])
    keep = history["md"] <= start
    history = {k: (v[keep] if isinstance(v, np.ndarray) else v) for k, v in history.items()}
    return dict(
        original=own,
        wells=wells,
        neighbors=neighbors,
        history=history,
        parameters=params,
        audit=dict(
            tie_in=dict(
                md_m=start,
                position_m=own["positions"][idx0].tolist(),
                inclination_deg=own["inc"][idx0],
                azimuth_deg=own["azi"][idx0],
            )
        ),
        end_index=idx1,
        start_index=idx0,
    )


def configuration(data, end):
    start = data["audit"]["tie_in"]
    w = data["original"]
    j = data["end_index"]
    interval = end - start["md_m"]
    settings = json.loads(
        (ROOT / "configs/experiments/replanning_ABC_constant_toolface.json").read_text()
    )
    settings.update(
        optimization_cells_per_segment=32,
        optimization_target_radius_m=0.00009,
        optimization_sf_buffer=0.05,
        centerline_buffer_m=0.15,
        initialization_max_seconds=900.0,
        planned_survey_max_step_m=30.0,
        final_scan_step_m=1.0,
        target_position_tolerance_m=0.0001,
        target_inclination_tolerance_deg=0.00001,
        target_azimuth_tolerance_deg=0.00001,
    )
    settings["solver"].update(
        initial_search_attempts=16,
        feasibility_max_nfev=500,
        maxiter=500,
        max_function_evaluations=10000,
        max_seconds_per_run=1200.0,
        retain_feasible_iterates=True,
    )
    cfg = dict(
        description="20-well group well14 local risk avoidance; splice original downstream geometry",
        trajectory_mode="arc-straight",
        n_segments=3,
        arc_segment_model="constant_toolface",
        start=dict(
            position_m=start["position_m"],
            inclination_deg=start["inclination_deg"],
            azimuth_deg=start["azimuth_deg"],
        ),
        target=dict(
            position_m=w["positions"][j].tolist(),
            inclination_deg=w["inc"][j],
            azimuth_deg=w["azi"][j],
            position_mode="sphere",
            position_tolerance_m=0.0001,
            inclination_tolerance_deg=0.00001,
            azimuth_tolerance_deg=0.00001,
        ),
        default_segment_bounds=dict(
            dls_deg_per_30m=[0.01, 5.999],
            start_toolface_deg=[-180.0, 180.0],
            length_m=[1.0, interval * 0.9],
        ),
        inclination_bounds_deg=[0.01, 120.0],
        max_segment_bend_deg=150.0,
        max_dls_deg_per_30m=5.999,
        solver=settings["solver"],
        initial_controls=[
            [3.411801, 0.0, interval * 0.45],
            [0.0, 0.0, interval * 0.1],
            [3.411801, 0.0, interval * 0.45],
        ],
    )
    return cfg, settings


def construct_initial(problem, out):
    """Geometric fits followed by true SLSQP constrained feasibility restoration."""
    begin = time.perf_counter()
    geometry = WellControlProblem(problem.cfg)
    rng = np.random.default_rng(20261113)
    logs = []
    best = None

    def equality(z):
        e = geometry.evaluate(z)
        return np.r_[e["position_error"] / problem.scale, e["angle_errors"] / 30.0]

    for attempt in range(problem.cfg["solver"]["initial_search_attempts"]):
        tick = time.perf_counter()
        seed = geometry.seed(rng, attempt)
        fit = least_squares(
            lambda z: np.r_[equality(z), np.minimum(geometry.evaluate(z)["g"][:12], 0.0)],
            seed,
            bounds=(0.0, 1.0),
            max_nfev=500,
            ftol=1e-12,
            xtol=1e-12,
            gtol=1e-12,
        )
        geometric_seconds = time.perf_counter() - tick
        tick = time.perf_counter()
        # All safety constraints participate in each restoration step.
        restore_history = []

        def callback(z):
            e = problem.evaluate(z)
            restore_history.append(
                dict(
                    iteration=len(restore_history),
                    elapsed_seconds=time.perf_counter() - tick,
                    position_error_m=float(np.linalg.norm(e["position_error"])),
                    minimum_sf=e["separation"]["minimum_sf"],
                    center_distance_m=e["separation"]["minimum_centerline_distance_m"],
                    violation=float(max(0.0, -e["g"].min())),
                )
            )

        restored = minimize(
            lambda z: float(problem.unpack(z)[:, 2].sum()) / problem.scale,
            fit.x,
            method="SLSQP",
            bounds=Bounds(np.zeros(problem.dim), np.ones(problem.dim)),
            constraints=[
                dict(type="eq", fun=equality),
                dict(type="ineq", fun=lambda z: problem.evaluate(z)["g"]),
            ],
            callback=callback,
            options=dict(maxiter=250, ftol=1e-10),
        )
        z = restored.x
        check = problem.check(z)
        dense = problem.final_verify(z) if check["feasible"] else None
        row = dict(
            attempt=attempt + 1,
            geometric_fit_seconds=geometric_seconds,
            restoration_seconds=time.perf_counter() - tick,
            solver_success=bool(restored.success),
            message=str(restored.message),
            check=check,
            final_check=None if dense is None else dense["check"],
            history=restore_history,
            controls=problem.unpack(z),
        )
        logs.append(row)
        save_json(out / "initialization_attempts.json", logs)
        score = max(0.0, -float(problem.evaluate(z)["g"].min()))
        if best is None or score < best[0]:
            best = (score, z.copy())
        print(
            f"Initial {attempt + 1}: success={restored.success} feasible={check['feasible']} pos={check['position_error_m']:.6g} SF={check['minimum_sf']:.6f} center={check['minimum_centerline_distance_m']:.6f}",
            flush=True,
        )
        if dense is not None and dense["check"]["feasible"]:
            result = dict(
                status="feasible",
                elapsed_seconds=time.perf_counter() - begin,
                attempts=logs,
                method="bounded geometric least squares -> SLSQP exact splice equalities + all safety inequalities -> full 1m verification",
            )
            save_json(out / "initialization.json", result)
            return z, result
    save_json(out / "best_failed_controls.json", problem.unpack(best[1]))
    raise RuntimeError("No accepted local initial point; original workbook not modified.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=float, default=720.0)
    parser.add_argument("--end", type=float, default=1000.0)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    begin = time.perf_counter()
    backup = out / "backup_before_replan.xlsx"
    if not backup.exists():
        shutil.copy2(SOURCE, backup)
    allowed = {hashlib.sha256(backup.read_bytes()).hexdigest()}
    if (out / "workbook_verification.json").exists():
        allowed.add(json.loads((out / "workbook_verification.json").read_text())["updated_sha256"])
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() in allowed
    data = load_data(args.start, args.end, backup)
    cfg, settings = configuration(data, args.end)
    save_json(out / "problem.json", cfg)
    save_json(out / "settings.json", settings)
    problem = LocalReplanningProblem(cfg, data, settings)
    setup = time.perf_counter() - begin
    if args.resume and (out / "initial_controls.json").exists():
        controls = json.loads((out / "initial_controls.json").read_text())
        z = problem.pack(controls)
        initial = json.loads((out / "initialization.json").read_text())
    else:
        z, initial = construct_initial(problem, out)
        save_json(out / "initial_controls.json", problem.unpack(z))
    before = problem.profiler.snapshot()
    selected, report = solve_algorithm(problem, [z.copy()], "SLSQP")
    profile = problem.profiler.since(before)
    tick = time.perf_counter()
    final = problem.final_verify(selected)
    dense_seconds = time.perf_counter() - tick
    if not final["check"]["feasible"]:
        selected = z
        final = problem.final_verify(z)
        report["final_fallback_to_verified_initial"] = True
    if not final["check"]["feasible"]:
        raise RuntimeError("Final acceptance failed; no overwrite")
    export_track(out, "selected", final)
    save_json(out / "selected_controls.json", problem.unpack(selected))
    report.update(
        final_check=final["check"],
        setup_seconds=setup,
        initial_seconds=initial["elapsed_seconds"],
        final_dense_seconds=dense_seconds,
        module_profile=profile,
        wall_seconds=time.perf_counter() - begin,
        old_interval_MD_m=[args.start, args.end],
        new_interval_MD_m=[args.start, float(final["md"][-1])],
        downstream_MD_shift_m=float(final["md"][-1] - args.end),
        source_sha256=hashlib.sha256(backup.read_bytes()).hexdigest(),
    )
    save_json(out / "result.json", report)
    print("FINAL", json.dumps(report["final_check"], ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
