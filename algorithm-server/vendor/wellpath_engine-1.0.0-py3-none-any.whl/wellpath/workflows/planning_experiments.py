"""Single or factorial comparisons of constrained solvers and trajectory layouts."""

import argparse
import copy
import csv
import hashlib
import importlib.metadata
import json
import time
from pathlib import Path

import numpy as np

from wellpath.anticollision.settings import configured_k, configured_sf_method, sf_formula
from wellpath.geometry.arc import minimum_curvature_increment
from wellpath.optimization.runner import ALGORITHMS, feasible_starts, solve_algorithm
from wellpath.paths import PROJECT_ROOT
from wellpath.planning.configuration import (
    TRAJECTORY_MODES,
    experiment_layouts,
    layout_configuration,
    resolve_trajectory,
)
from wellpath.planning.geometry_problem import samples
from wellpath.planning.problem import PlanningProblem
from wellpath.reports.planning import plot_comparison, plot_plan_comparison, plot_run


def save_json(path, obj):
    path.write_text(
        json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )


def export_run(problem, initial, final, report, out, plots):
    begin = time.perf_counter()
    out.mkdir(parents=True, exist_ok=True)
    report["configuration"] = problem.cfg
    report["versions"] = {
        name: importlib.metadata.version(name) for name in ("numpy", "scipy", "welleng", "plotly")
    }
    report["segment_types"] = problem.segment_types
    report["free_control_variables"] = problem.dim
    report["trajectory_mode"] = problem.trajectory_mode
    report["n_segments"] = problem.n
    report["trajectory_geometry"] = problem.geometry_metadata["nominal_geometry"]
    report["geometry_metadata"] = problem.geometry_metadata
    report["arc_segment_model"] = problem.arc_segment_model
    report["k_sigma"] = problem.engine.k
    report["sf_method"] = problem.engine.sf_method
    report["sf_formula"] = sf_formula(problem.engine.sf_method, problem.engine.scalar_radius_mode)
    if final is not None:
        e = problem.evaluate(final)
        report["final_position_m"] = e["p"].tolist()
        if "pair_sf_matrix" in e.get("separation", {}):
            report["pair_sf_names"] = e["separation"]["pair_sf_names"]
            report["pair_sf_matrix"] = [
                [None if not np.isfinite(value) else float(value) for value in row]
                for row in e["separation"]["pair_sf_matrix"]
            ]
            report["pair_sf_details"] = e["separation"]["pair_sf_details"]
        report["segments"] = []
        max_error = 0.0
        for i, ((dls, w, L), rec) in enumerate(zip(e["physical"], e["records"])):
            k = np.deg2rad(dls) / 30
            if problem.arc_segment_model == "minimum_curvature":
                error = float(
                    np.linalg.norm(
                        minimum_curvature_increment(rec[1], rec[3], L) - (rec[2] - rec[0])
                    )
                )
                max_error = max(max_error, error)
            report["segments"].append(
                dict(
                    segment=i + 1,
                    type=problem.segment_types[i],
                    length_m=float(L),
                    initial_toolface_deg=None
                    if problem.segment_types[i] == "straight"
                    else float(w),
                    toolface_behavior=(
                        "undefined_on_straight"
                        if problem.segment_types[i] == "straight"
                        else "constant_within_segment"
                        if problem.arc_segment_model == "constant_toolface"
                        else "initial_value_only"
                    ),
                    curvature_1_per_m=float(k),
                    dls_deg_per_30m=float(dls),
                    radius_m=None if k < 1e-14 else float(1 / k),
                )
            )
        report["minimum_curvature_crosscheck_error_m"] = (
            max_error if problem.arc_segment_model == "minimum_curvature" else None
        )
        if problem.arc_segment_model == "constant_toolface":
            report["minimum_curvature_crosscheck_note"] = (
                "Not an exact planar minimum-curvature segment; nominal path follows constant local toolface equations. Survey uncertainty still uses its separately configured propagation basis."
            )
        header = [
            "segment",
            "local_MD_m",
            "relative_MD_m",
            "north_m",
            "east_m",
            "tvd_m",
            "inclination_deg",
            "azimuth_deg",
            "actual_toolface_deg",
            "DLS_deg_per_30m",
        ]
        for label, z in [("initial", initial), ("optimized", final)]:
            with (out / f"{label}_trajectory.csv").open("w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(header)
                writer.writerows(samples(problem, z, 0.5))
        profiles = e.get("separation", {}).get("profiles", [])
        with (out / "separation_profile.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["neighbor", "relative_md_m", "minimum_sf", "sf_threshold"])
            for profile in profiles:
                writer.writerows(
                    [profile["neighbor"], md, value, problem.engine.threshold]
                    for md, value in zip(profile["relative_md_m"], profile["minimum_sf"])
                )
        if problem.engine.scalar_radius_mode and profiles:
            sf_values = np.asarray([profile["minimum_sf"] for profile in profiles])
            limiting = np.argmin(sf_values, axis=0)
            relative_md = np.asarray(profiles[0]["relative_md_m"])
            from wellpath.anticollision.uncertainty import path_at

            positions, _, _ = path_at(problem, e, relative_md)
            start_md = float(problem.cfg["iscwsa"]["planned"].get("start_md_m", 0.0))
            with (out / "point_minimum_separation.csv").open(
                "w", newline="", encoding="utf-8-sig"
            ) as f:
                writer = csv.writer(f)
                writer.writerow(
                    [
                        "md_m",
                        "relative_md_m",
                        "north_m",
                        "east_m",
                        "tvd_m",
                        "minimum_sf",
                        "limiting_neighbor",
                        "sf_threshold",
                        "is_risk",
                    ]
                )
                for i, md in enumerate(relative_md):
                    neighbor_index = int(limiting[i])
                    value = float(sf_values[neighbor_index, i])
                    writer.writerow(
                        [
                            md + start_md,
                            md,
                            *positions[i],
                            value,
                            profiles[neighbor_index]["neighbor"],
                            problem.engine.threshold,
                            value < problem.engine.threshold,
                        ]
                    )
        if plots:
            plot_run(problem, initial, final, report, out)
        # Retain full 1-sigma covariance matrices to audit ISCWSA propagation.
        from wellpath.anticollision.uncertainty import planned_covariance

        c = planned_covariance(problem, e)
        covariance_result = dict(
            model=c["model"],
            model_type=c["model_type"],
            nominal_geometry=problem.geometry_metadata,
            md_m=c["md"].tolist(),
            cov_nev_m2=c["cov"].tolist(),
            with_history=c["with_history"],
            note="Measurement-station uncertainty covariance; intermediate covariance uses PSD linear interpolation.",
        )
        if c["model_type"] == "md_scalar_radius":
            covariance_result["radius_m"] = c["radius_m"].tolist()
            covariance_result["note"] = (
                "Display-only matrices r(MD)^2 I; radius_m is a boundary radius, not a 1-sigma uncertainty. SF follows the configured sf_method; additive paths use D/[k*(r1+r2)]."
            )
        if c["model_type"] == "simplified_mwd":
            mwd = c["simplified_mwd"]
            covariance_result["simplified_mwd"] = {
                key: (value.tolist() if isinstance(value, np.ndarray) else value)
                for key, value in mwd.items()
                if key != "cov"
            }
            covariance_result["note"] = (
                "TrueMyWell three-parameter MWD envelope. Covariance is the spherical proxy R^2 I, not full ISCWSA propagation. Intermediate covariance uses PSD linear interpolation; current project SF convention applies."
            )
        if c.get("propagated_uncertainty") is not None:
            propagated = c["propagated_uncertainty"]
            covariance_result["propagated_source_parameters"] = propagated["parameters"]
            covariance_result["propagation_basis"] = propagated["propagation_basis"]
            covariance_result["implementation"] = propagated["implementation"]
            covariance_result["source_covariance_nev_m2"] = {
                name: value.tolist() for name, value in propagated["terms"].items()
            }
        covariance_result["sf_method"] = problem.engine.sf_method
        covariance_result["k_sigma"] = problem.engine.k
        covariance_result["sf_formula"] = report["sf_formula"]
        save_json(out / "uncertainty_covariance.json", covariance_result)
        if c["model_type"] == "iscwsa":
            save_json(out / "iscwsa_covariance.json", covariance_result)
    report["export_and_plot_seconds"] = time.perf_counter() - begin
    report["total_seconds_including_initialization_and_export"] = (
        report["feasibility_seconds"]
        + report.get("algorithm_wall_seconds", 0.0)
        + report["export_and_plot_seconds"]
    )
    save_json(out / "result.json", report)


def run(
    config_path,
    output,
    algorithm_override=None,
    no_plots=False,
    trajectory_mode_override=None,
    n_segments_override=None,
):
    wall = time.perf_counter()
    config_path = Path(config_path)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    exp = json.loads(config_path.read_text(encoding="utf-8"))
    if trajectory_mode_override is not None:
        exp["trajectory_mode"] = trajectory_mode_override
    if n_segments_override is not None:
        exp["n_segments"] = n_segments_override
    problem_path = config_path.parent / exp["problem_file"]
    base = json.loads(problem_path.read_text(encoding="utf-8"))
    base.setdefault("iscwsa", {})["k_sigma"] = configured_k(base.get("iscwsa", {}))
    base["iscwsa"]["sf_method"] = configured_sf_method(base["iscwsa"])
    mode = exp.get("mode", "single")
    if mode != "single" and (
        trajectory_mode_override is not None or n_segments_override is not None
    ):
        raise ValueError(
            "CLI trajectory selectors apply to single experiments; "
            "comparison uses trajectory_modes and segment_counts."
        )
    algorithms = (
        [algorithm_override or exp.get("algorithm", "SLSQP")]
        if mode == "single"
        else exp.get("algorithms", list(ALGORITHMS))
    )
    if any(a not in ALGORITHMS for a in algorithms):
        raise ValueError(f"Valid solvers: {ALGORITHMS}")
    layouts = experiment_layouts(exp, base)
    from wellpath.planning.toolface import expand_toolface_configs, has_discrete_toolface

    expanded = []
    discrete_groups = {}
    for layout in layouts:
        candidate = layout_configuration(base, layout, comparison=mode == "comparison")
        if has_discrete_toolface(candidate):
            members = []
            for index, (fixed, selection) in enumerate(
                expand_toolface_configs(candidate, exp.get("max_toolface_assignments", 4096)), 1
            ):
                child = dict(
                    layout,
                    name=f"{layout['name']}__tf{index:04d}",
                    default_segment_bounds=fixed["default_segment_bounds"],
                    segment_bounds=fixed["segment_bounds"],
                    discrete_toolface_selection=selection,
                )
                expanded.append(child)
                members.append(child["name"])
            discrete_groups[layout["name"]] = members
        else:
            expanded.append(layout)
    layouts = expanded
    repeats = int(exp.get("repeats", 1))
    rows = []
    if mode not in ("single", "comparison") or repeats < 1:
        raise ValueError("mode single/comparison; repeats >=1.")
    save_json(output / "experiment_config.json", exp)
    # Persist exactly the input problem used so the run can be audited later.
    save_json(output / "input_problem.json", base)
    comparison_entries = []
    for layout in layouts:
        for repeat in range(repeats):
            cfg = layout_configuration(base, layout, comparison=mode == "comparison")
            if "discrete_toolface_selection" in layout:
                cfg["discrete_toolface_selection"] = layout["discrete_toolface_selection"]
            if "uncertainty_model" in exp:
                model = copy.deepcopy(exp["uncertainty_model"])
                cfg["iscwsa"]["planned"]["uncertainty_model"] = copy.deepcopy(model)
                for neighbor in cfg["iscwsa"]["neighbors"]:
                    neighbor["survey"]["uncertainty_model"] = copy.deepcopy(model)
            cfg["solver"]["random_seed"] = (
                exp.get("base_seed", cfg["solver"].get("random_seed", 7)) + repeat
            )
            print(
                f"\nLayout {layout['name']} repeat {repeat + 1}: {resolve_trajectory(cfg)[1]}",
                flush=True,
            )
            problem = PlanningProblem(cfg, problem_path.parent)
            starts, phase = feasible_starts(problem)
            # All algorithms receive identical frozen feasible initial controls.
            initial = (
                min(starts, key=lambda z: problem.unpack(z)[:, 2].sum()).copy() if starts else None
            )
            initial_hash = hashlib.sha256(np.asarray(starts, dtype=float).tobytes()).hexdigest()
            for algorithm in algorithms:
                if problem.arc_segment_model == "constant_toolface":
                    from wellpath.geometry.segments import clear_position_cache

                    clear_position_cache()
                    problem._cache_z = None
                    problem._cache_e = None
                final, report = solve_algorithm(problem, starts, algorithm)
                report.update(
                    feasibility_phase=phase,
                    feasibility_seconds=phase["elapsed_seconds"],
                    shared_initial_sha256=initial_hash,
                    repeat=repeat + 1,
                    layout=layout["name"],
                    sf_threshold=problem.engine.threshold,
                    shared_initial_controls=[problem.unpack(s).tolist() for s in starts],
                )
                if "discrete_toolface_selection" in cfg:
                    report["discrete_toolface_selection"] = cfg["discrete_toolface_selection"]
                sub = output / f"{layout['name']}__{algorithm}__r{repeat + 1}"
                export_run(
                    problem, initial, final, report, sub, exp.get("plots", True) and not no_plots
                )
                row = dict(
                    layout=layout["name"],
                    trajectory_mode=problem.trajectory_mode,
                    n_segments=problem.n,
                    algorithm=algorithm,
                    repeat=repeat + 1,
                    status=report["status"],
                    solver_success=report.get("solver_success", False),
                    selected_candidate_solver_success=report.get(
                        "selected_candidate_solver_success", False
                    ),
                    selected_candidate=report.get("selected_candidate"),
                    length_m=report.get("final_total_length_m"),
                    minimum_sf=report.get("final_check", {}).get("minimum_sf"),
                    sf_threshold=problem.engine.threshold,
                    feasibility_seconds=phase["elapsed_seconds"],
                    solver_seconds=report["optimization_seconds"],
                    validation_seconds=report.get("validation_seconds", 0.0),
                    total_seconds=report["total_seconds_including_initialization_and_export"],
                    shared_initial_sha256=initial_hash,
                )
                rows.append(row)
                if (
                    mode == "comparison"
                    and repeat == 0
                    and algorithm == algorithms[0]
                    and final is not None
                ):
                    comparison_entries.append(
                        dict(
                            problem=problem,
                            final=final,
                            label=f"{layout['name']} ({algorithm})",
                            report=report,
                        )
                    )
                save_json(output / "summary.json", rows)
    if rows:
        with (output / "summary.csv").open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    if mode == "comparison" and not no_plots:
        plot_comparison(rows, output)
        plot_plan_comparison(comparison_entries, output)
    # Aggregate repeated experiments without silently dropping failures.
    aggregate = []
    for layout in layouts:
        for algorithm in algorithms:
            group = [
                r for r in rows if r["layout"] == layout["name"] and r["algorithm"] == algorithm
            ]
            lengths = [r["length_m"] for r in group if r["length_m"] is not None]
            aggregate.append(
                dict(
                    layout=layout["name"],
                    algorithm=algorithm,
                    repeats=len(group),
                    feasible_count=sum(r["status"] == "feasible_design" for r in group),
                    converged_selected_count=sum(
                        r["selected_candidate_solver_success"] for r in group
                    ),
                    mean_solver_seconds=float(np.mean([r["solver_seconds"] for r in group])),
                    mean_feasible_length_m=float(np.mean(lengths)) if lengths else None,
                    std_feasible_length_m=float(np.std(lengths)) if lengths else None,
                )
            )
    save_json(output / "aggregate.json", aggregate)
    if discrete_groups:
        selections = []
        for name, members in discrete_groups.items():
            for algorithm in algorithms:
                for repeat in range(1, repeats + 1):
                    group = [
                        r
                        for r in rows
                        if r["layout"] in members
                        and r["algorithm"] == algorithm
                        and r["repeat"] == repeat
                    ]
                    feasible = [
                        r
                        for r in group
                        if r["status"] == "feasible_design" and r["length_m"] is not None
                    ]
                    best = min(feasible, key=lambda r: r["length_m"]) if feasible else None
                    selections.append(
                        dict(
                            layout=name,
                            algorithm=algorithm,
                            repeat=repeat,
                            total_assignments=len(members),
                            completed_assignments=len(group),
                            feasible_assignments=len(feasible),
                            best_record=best,
                            charged_assignment_flow_seconds=sum(r["total_seconds"] for r in group),
                            global_continuous_optimum_proven=False,
                        )
                    )
        save_json(
            output / "finite_toolface_selection.json",
            dict(
                method="complete finite angle enumeration + constrained continuous NLP; no rounding",
                results=selections,
            ),
        )
    save_json(
        output / "experiment_timing.json",
        dict(
            actual_experiment_wall_seconds=time.perf_counter() - wall,
            note="Initialization is run once per layout/repeat and shared across algorithms. Per-row total includes "
            "that shared cost for standalone reproducibility; summing row totals double-counts it.",
        ),
    )
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config", type=Path, default=PROJECT_ROOT / "configs/experiments" / "single.json"
    )
    parser.add_argument("--output", type=Path, default=PROJECT_ROOT / "results" / "single")
    parser.add_argument("--algorithm", choices=ALGORITHMS)
    parser.add_argument(
        "--trajectory-mode",
        choices=TRAJECTORY_MODES,
        help="arc: all arcs; arc-straight: alternating, starting with an arc (single mode)",
    )
    parser.add_argument(
        "--n-segments",
        type=int,
        help="Total number of segments, any positive integer (single mode)",
    )
    parser.add_argument("--no-plots", action="store_true")
    args = parser.parse_args()
    run(
        args.config,
        args.output,
        args.algorithm,
        args.no_plots,
        args.trajectory_mode,
        args.n_segments,
    )


if __name__ == "__main__":
    main()
