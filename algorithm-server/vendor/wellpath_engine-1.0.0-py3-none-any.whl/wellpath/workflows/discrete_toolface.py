"""Exact finite toolface enumeration around the existing scene NLP pipeline."""

import copy
import html
import json
import shutil
import time
from pathlib import Path

from wellpath.data_io.scenarios import trajectory_bounds
from wellpath.planning.toolface import expand_toolface_configs, has_discrete_toolface


def selection_configuration(settings):
    default, overrides = trajectory_bounds(settings)
    return dict(
        n_segments=settings.get("n_segments", 3),
        trajectory_mode=settings.get("trajectory_mode", "arc-straight"),
        arc_segment_model=settings.get("arc_segment_model", "minimum_curvature"),
        default_segment_bounds=default,
        segment_bounds=overrides,
    )


def needs_discrete_dispatch(settings):
    return has_discrete_toolface(selection_configuration(settings))


def run_discrete_scene(scene, settings, out, initial_builder=None):
    from wellpath.optimization.segment_initialization import make_segment_initial
    from wellpath.reports.scenario_replanning import table
    from wellpath.reports.segment_comparison import page
    from wellpath.workflows.scenario_replanning import _run_continuous_scene, save_json

    begin = time.perf_counter()
    out = Path(out)
    folder = out / f"scene_{scene}"
    folder.mkdir(exist_ok=True, parents=True)
    configurations = list(
        expand_toolface_configs(
            selection_configuration(settings), settings.get("max_toolface_assignments", 4096)
        )
    )
    records = []
    rows = []
    branch_times = []
    for index, (fixed, selection) in enumerate(configurations, 1):
        branch = folder / "discrete_assignments" / f"choice_{index:04d}"
        branch.mkdir(exist_ok=True, parents=True)
        s = copy.deepcopy(settings)
        s.pop("toolface_control", None)
        s["segment_bounds"] = fixed["segment_bounds"]
        s["continue_on_initial_failure"] = True
        s["discrete_toolface_selection"] = selection
        save_json(branch / "fixed_assignment.json", selection)
        save_json(branch / "experiment_config.json", s)
        print(
            f"DISCRETE {index}/{len(configurations)} scene={scene} angles={selection['assignment_deg']}",
            flush=True,
        )
        result = _run_continuous_scene(scene, s, branch, initial_builder or make_segment_initial)
        branch_time = json.loads((branch / f"scene_{scene}" / "scene_timing.json").read_text())
        branch_times.append(branch_time)
        if index == 1:
            for name in ("input_audit.json", "actual_input", "design_input", "neighbor_covariance"):
                source = branch / f"scene_{scene}" / name
                if source.is_dir():
                    shutil.copytree(source, folder / name, dirs_exist_ok=True)
                else:
                    shutil.copy2(source, folder / name)
        for r in result:
            r = copy.deepcopy(r)
            r["discrete_assignment"] = selection
            r["discrete_assignment_index"] = index
            r["assignment_result_directory"] = str(
                (branch / f"scene_{scene}" / r["algorithm"]).relative_to(folder)
            )
            records.append(r)
            c = r.get("final_check") or {}
            rows.append(
                [
                    index,
                    selection["assignment_deg"],
                    r["algorithm"],
                    bool(c.get("feasible")),
                    r.get("solver_success"),
                    r.get("final_total_length_m"),
                    r["complete_flow_seconds"],
                ]
            )
    aggregate = []
    for method in settings["algorithms"]:
        group = [r for r in records if r["algorithm"] == method]
        feasible = [r for r in group if (r.get("final_check") or {}).get("feasible")]
        winner = min(feasible, key=lambda r: r["final_total_length_m"]) if feasible else None
        r = copy.deepcopy(winner or group[0])
        r["algorithm"] = method
        r["finite_choice_search"] = dict(
            total_assignments=len(configurations),
            completed_assignments=len(group),
            feasible_assignments=len(feasible),
            selected_assignment=None if winner is None else winner["discrete_assignment"],
            selected_directory=None if winner is None else winner["assignment_result_directory"],
            global_optimum_proven=False,
            history_scope="runs describes only the selected assignment (or one failed assignment if none selected); all assignment histories are retained in all_assignment_results.json",
            shared_initial_scope="Within each fixed-angle assignment; different assignments require their own feasible initial controls",
            method="complete Cartesian enumeration + constrained NLP; angles fixed before initialization and every constraint call",
        )
        r["selected_assignment_flow_seconds"] = (
            None if winner is None else winner["complete_flow_seconds"]
        )
        r["selected_assignment_optimization_seconds"] = (
            None if winner is None else winner["optimization_seconds"]
        )
        for key in (
            "shared_preprocessing_seconds",
            "feasibility_construction_seconds",
            "optimization_seconds",
            "validation_seconds",
            "dense_final_verification_seconds",
            "export_seconds",
            "method_wall_seconds",
            "complete_flow_seconds",
        ):
            r[key] = sum(v.get(key, 0.0) for v in group)
        r["solver_executed"] = any(v.get("solver_executed", False) for v in group)
        r["solver_success"] = False if winner is None else winner.get("solver_success")
        if winner is None:
            r.update(
                final_check=None,
                final_total_length_m=None,
                status="finite_choice_search_no_certified_solution",
            )
        method_folder = folder / method
        method_folder.mkdir(exist_ok=True)
        save_json(method_folder / "result.json", r)
        aggregate.append(r)
    save_json(folder / "algorithm_results.json", aggregate)
    save_json(folder / "all_assignment_results.json", records)
    save_json(folder / "finite_choice_configuration.json", settings)
    initial_summaries = [
        json.loads(
            (
                folder
                / "discrete_assignments"
                / f"choice_{i:04d}"
                / f"scene_{scene}"
                / "initialization.json"
            ).read_text()
        )
        for i in range(1, len(configurations) + 1)
    ]
    save_json(
        folder / "initialization.json",
        dict(
            status="finite_angle_enumeration",
            assignment_count=len(configurations),
            attempts=[entry for item in initial_summaries for entry in item["attempts"]],
            elapsed_seconds=sum(item["elapsed_seconds"] for item in initial_summaries),
            timing_breakdown={
                key: sum(item["timing_breakdown"].get(key, 0.0) for item in initial_summaries)
                for key in initial_summaries[0]["timing_breakdown"]
            },
            method="each discrete angle assignment has its own shared feasible initial construction; timings sum over all assignments",
        ),
    )
    report_begin = time.perf_counter()
    links = "".join(
        f'<li><a href="discrete_assignments/choice_{i:04d}/scene_{scene}/场景{scene}_再规划对比.html">组合{i}：{html.escape(str(selection["assignment_deg"]))}</a></li>'
        for i, (_, selection) in enumerate(configurations, 1)
    )
    body = (
        f"<header><h1>场景{scene}：离散工具面枚举 + 连续约束NLP</h1><p>共{len(configurations)}个固定角组合，全部在初值和优化之前固定工具面，不做求解后取整。各组合内四算法共享初值，不同角组合分别构建初值。每算法完整流程按全部角组合累计，获选组合时间另存selected_assignment_flow_seconds。</p></header><section><h2>全部组合记录</h2>"
        + table(
            ["组合", "固定角（规范化°）", "算法", "最终可行", "success", "新段长m", "该组合流程s"],
            rows,
        )
        + "</section><section><h2>各算法最终选择</h2><pre>"
        + html.escape(
            json.dumps(
                [
                    dict(
                        algorithm=r["algorithm"],
                        selection=r["finite_choice_search"],
                        length=r.get("final_total_length_m"),
                        complete_flow=r["complete_flow_seconds"],
                    )
                    for r in aggregate
                ],
                ensure_ascii=False,
                indent=2,
            )
        )
        + "</pre></section><section><h2>逐组合完整图表与配置</h2><ul>"
        + links
        + "</ul></section>"
    )
    (folder / f"场景{scene}_再规划对比.html").write_text(
        page(f"场景{scene} 离散工具面结果", body), encoding="utf-8"
    )
    save_json(
        folder / "scene_timing.json",
        dict(
            scenario_wall_seconds=time.perf_counter() - begin,
            preprocessing_seconds=sum(v["preprocessing_seconds"] for v in branch_times),
            shared_initial_seconds=sum(v["shared_initial_seconds"] for v in branch_times),
            algorithms_wall_seconds=sum(v["algorithms_wall_seconds"] for v in branch_times),
            enumeration_summary_render_seconds=time.perf_counter() - report_begin,
            enumeration_assignments=len(configurations),
            source_files_unchanged=True,
        ),
    )
    return aggregate
