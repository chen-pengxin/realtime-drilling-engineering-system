"""Plan rigid per-well translations and recompute independent group scans.

Workbook authoring is performed separately with artifact-tool, using the
patch JSON emitted here. Original workbooks remain untouched in this phase.
"""

import hashlib
import time

import numpy as np

from wellpath.data_io.naming import artifact_name
from wellpath.paths import PROJECT_ROOT
from wellpath.workflows.cluster_comparison import configuration, export_group, table
from wellpath.workflows.uncertainty_comparison import evaluate, read_wells, save_json

ROOT = PROJECT_ROOT
OUT = ROOT / "results/cluster_wellheads_spacing8m_20261113"
INPUT = ROOT / "data/scenarios/cluster_groups"


def wellheads(wells):
    old = np.array([w["positions"][0, :2] for w in wells])
    n = len(wells)
    center = old.mean(axis=0)
    new = old.copy()
    row_ids = []
    if n in [15, 16]:
        counts = [(n + 1) // 2, n // 2]
        # Both rows are centered east/west. Weighted north offsets keep the
        # original arithmetic centroid exactly, including the odd 8+7 case.
        row_n = [center[0] - 8 * counts[1] / n, center[0] + 8 * counts[0] / n]
        counters = [0, 0]
        for i in range(n):
            row = i % 2
            k = counters[row]
            counters[row] += 1
            new[i] = [row_n[row], center[1] + 8 * ((counts[row] - 1) / 2 - k)]
            row_ids.append(row + 1)
    elif n == 20:
        # Existing two north rows are already 8 m apart. Expand only E.
        new[:, 1] = center[1] + 2 * (old[:, 1] - center[1])
        row_ids = [1 if p[0] < center[0] else 2 for p in new]
    else:
        raise ValueError(n)
    horizontal = np.linalg.norm(new[:, None] - new[None, :], axis=2)
    horizontal[np.diag_indices(n)] = np.inf
    assert horizontal.min() >= 8 - 1e-10
    np.testing.assert_allclose(new.mean(axis=0), center, rtol=0, atol=1e-10)
    for row_id in [1, 2]:
        row = new[np.array(row_ids) == row_id]
        np.testing.assert_allclose(np.diff(np.sort(row[:, 1])), 8.0, rtol=0, atol=1e-10)
    assert abs(np.unique(new[:, 0])[1] - np.unique(new[:, 0])[0] - 8) < 1e-10
    return old, new, center, row_ids


def run():
    all_summary = []
    all_changes = []
    groups = []
    start = time.perf_counter()
    for filename, n in [
        ("cluster_15_design.xlsx", 15),
        ("cluster_16_design.xlsx", 16),
        ("cluster_20_design.xlsx", 20),
    ]:
        folder = OUT / f"group_{n}"
        folder.mkdir(exist_ok=True)
        source = OUT / "backups" / filename
        target = INPUT / filename
        cfg = configuration(source, n)
        wells = read_wells(source, cfg)
        old, new, center, row_ids = wellheads(wells)
        changes = []
        for i, w in enumerate(wells):
            shift = new[i] - old[i]
            w["positions"] = w["positions"].copy()
            w["positions"][:, :2] += shift
            row = dict(
                group=f"group_{n}",
                well=w["name"],
                row=row_ids[i],
                old_N_m=old[i, 0],
                old_E_m=old[i, 1],
                new_N_m=new[i, 0],
                new_E_m=new[i, 1],
                delta_N_m=shift[0],
                delta_E_m=shift[1],
                unchanged_wellhead_D_m=float(w["positions"][0, 2]),
                points=len(w["md"]),
            )
            changes.append(row)
            all_changes.append(row)
        save_json(
            folder / "wellhead_changes.json",
            dict(
                center_definition="Arithmetic mean of original wellhead N/E; D unchanged",
                center_NE_m=center.tolist(),
                row_spacing_m=8.0,
                within_row_spacing_m=8.0,
                changes=changes,
            ),
        )
        table(folder / "wellhead_changes.csv", changes)
        cfg["input_file"] = str(target)
        cfg["assumptions"].insert(
            0,
            "Wellheads relocated to 8 m rows/in-row spacing; per-well rigid N/E translation; source MD/I/A/D and relative trajectory shapes unchanged.",
        )
        save_json(folder / "config.json", cfg)
        audit = dict(
            source_file=str(target),
            original_backup_file=str(source),
            pre_edit_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
            sha256_before="PENDING_WORKBOOK_AUTHORING",
            sha256_after="PENDING_WORKBOOK_AUTHORING",
            well_count=n,
            total_points=sum(len(w["md"]) for w in wells),
            pairs=n * (n - 1) // 2,
            well_data=[
                dict(
                    name=w["name"],
                    points=len(w["md"]),
                    start_MD_m=float(w["md"][0]),
                    end_MD_m=float(w["md"][-1]),
                    wellhead_NED_m=w["positions"][0].tolist(),
                    max_scan_interval_m=float(np.diff(w["md"]).max()),
                )
                for w in wells
            ],
            relocation=dict(
                center_NE_m=center.tolist(),
                row_spacing_m=8.0,
                within_row_spacing_m=8.0,
                minimum_horizontal_wellhead_distance_m=float(
                    np.linalg.norm(new[:, None] - new[None, :], axis=2)[
                        ~np.eye(n, dtype=bool)
                    ].min()
                ),
            ),
        )
        save_json(folder / "input_audit.json", audit)
        print(f"group_{n}: relocated {len(wells)} wells; starting 10-model scan", flush=True)
        result = evaluate(wells, cfg, verbose=False)
        print(
            f"group_{n}: shared evaluation {result['timing']['evaluation_total_seconds']:.3f}s",
            flush=True,
        )
        for wi, w in enumerate(wells):
            from wellpath.workflows.uncertainty_comparison import write_csv

            write_csv(
                folder / "shared" / artifact_name(f"{w['name']}_trajectory.csv"),
                ["source_row", "MD_m", "inclination_deg", "azimuth_grid_deg", "N_m", "E_m", "D_m"],
                (
                    [r, md, inc, azi, *pos]
                    for r, md, inc, azi, pos in zip(
                        w["source_rows"], w["md"], w["inc"], w["azi"], w["positions"]
                    )
                ),
            )
        all_summary.extend(export_group(folder, wells, cfg, result, audit))
        # Source annotation uses current default Rev.0 K=1, major-axis-sum.
        mi = result["names"].index("iscwsa_rev0")
        patches = []
        for wi, w in enumerate(wells):
            sf_all = result["sfs"][wi][mi, 0]
            sf = sf_all.min(axis=1)
            neighbors = sf_all.argmin(axis=1)
            indices = result["args"][wi][mi, 0, np.arange(len(sf)), neighbors]
            center_distance = result["centers"][wi].min(axis=1)
            from wellpath.workflows.uncertainty_comparison import classify

            codes = classify(sf, center_distance, cfg)
            patch = dict(
                sheet=w["name"],
                first_row=int(w["source_rows"][0]),
                last_row=int(w["source_rows"][-1]),
                coordinates_EN=w["positions"][:, [1, 0]].tolist(),
                annotations=[],
            )
            assert patch["last_row"] - patch["first_row"] + 1 == len(sf)
            for s in range(len(sf)):
                j = int(neighbors[s])
                q = int(indices[s])
                distance = float(np.linalg.norm(w["positions"][s] - wells[j]["positions"][q]))
                risk_neighbors = "|".join(
                    wells[jj]["name"] for jj in range(n) if jj != wi and sf_all[s, jj] <= 1.5
                )
                risk = ["红色危险", "橙色警告", "黄色关注", "蓝色安全"][codes[s]]
                if center_distance[s] <= 5:
                    risk += "（中心距≤5m）"
                patch["annotations"].append(
                    [
                        float(sf[s]),
                        risk_neighbors or None,
                        wells[j]["name"],
                        float(wells[j]["md"][q]),
                        distance,
                        risk,
                    ]
                )
            patches.append(patch)
        save_json(
            folder / "workbook_patch.json",
            dict(
                source_file=str(source),
                target_file=str(target),
                filename=filename,
                group=f"group_{n}",
                annotation_model="ISCWSA Rev.0",
                annotation_K=1.0,
                patches=patches,
            ),
        )
        groups.append(audit)
        del result, wells
        print(f"group_{n}: numerical results and authoring patch ready", flush=True)
    table(OUT / "all_groups_model_K_summary.csv", all_summary)
    table(OUT / "wellhead_changes_all_groups.csv", all_changes)
    save_json(
        OUT / "batch_audit.json",
        dict(
            groups=groups,
            model_K_cases=len(all_summary),
            K_values=[1.0, 2.0, 2.5, 3.0],
            numerical_export_wall_seconds=time.perf_counter() - start,
        ),
    )
    print("ALL RELOCATION SCANS READY", flush=True)


if __name__ == "__main__":
    run()
