"""Explicit filesystem roots for optional data-driven workflows."""

import os
from pathlib import Path

PROJECT_ROOT = (
    Path(os.environ.get("WELLPATH_PROJECT_ROOT", Path(__file__).resolve().parents[2]))
    .expanduser()
    .resolve()
)


def project_path(value):
    """Resolve a bundled project asset; absolute caller paths are respected."""
    path = Path(value).expanduser()
    return path if path.is_absolute() else PROJECT_ROOT / path
