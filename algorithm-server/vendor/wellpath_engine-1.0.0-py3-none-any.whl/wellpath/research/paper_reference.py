"""Independent reproduction of the thesis-era WdW and ISCWSA Rev.0 models.

This module is deliberately separate from the production welleng Rev5.11 path.
The ISCWSA implementation follows the thesis' listed error-source weights and
random/systematic/global accumulation classes; it is a historical reproduction,
not a current ISCWSA certification.
"""

from __future__ import annotations

import numpy as np

from wellpath.anticollision.uncertainty import scalar_radius


def _unit_vectors(inc_deg, azi_deg):
    inc = np.deg2rad(inc_deg)
    azi = np.deg2rad(azi_deg)
    t = np.array([np.sin(inc) * np.cos(azi), np.sin(inc) * np.sin(azi), np.cos(inc)])
    v2 = np.array([-np.sin(azi), np.cos(azi), 0.0])
    v3 = np.array([np.cos(inc) * np.cos(azi), np.cos(inc) * np.sin(azi), -np.sin(inc)])
    return t, v2, v3


def wdw_covariance(md, inc_deg, azi_deg, confidence=1.0, parameters=None):
    """Wolff-de Wardt point-error ellipse using paper Eqs. (2.37)-(2.41),(3.1)-(3.15).

    The thesis does not publish numerical WdW source magnitudes. Defaults here
    are an explicit comparison profile, not values claimed to be prescribed by
    that paper; callers should pass field-calibrated values for operations.
    """
    md = np.asarray(md, float)
    inc = np.asarray(inc_deg, float)
    azi = np.asarray(azi_deg, float)
    if md.ndim != 1 or len(md) < 2 or inc.shape != md.shape or azi.shape != md.shape:
        raise ValueError("WdW needs matching MD, inclination and azimuth arrays with >=2 stations.")
    if not np.isfinite(np.r_[md, inc, azi]).all() or np.any(np.diff(md) <= 0):
        raise ValueError("WdW inputs must be finite and MD strictly increasing.")
    p = dict(
        compass_sigma_deg=0.36,
        magnetization_sigma_deg=0.0,
        gyro_sigma_deg=0.0,
        inclination_sigma_deg=1.0,
        depth_scale_sigma=0.0025,
    )
    if parameters:
        p.update(parameters)
    if confidence <= 0 or not np.isfinite(confidence):
        raise ValueError("confidence must be positive.")
    covs = []
    major = []
    minor = []
    vertical = []
    for k in range(len(md)):
        accum = {
            name: np.zeros(3)
            for name in ("compass", "magnetization", "gyro", "inclination", "depth")
        }
        for j in range(k):
            ds = md[j + 1] - md[j]
            im = 0.5 * (inc[j] + inc[j + 1])
            am = 0.5 * (azi[j] + azi[j + 1])
            t, v2, v3 = _unit_vectors(im, am)
            # Midpoint quadrature of the thesis' trajectory-integrated error vectors.
            terms = {
                "compass": (float(p["compass_sigma_deg"]), np.sin(np.deg2rad(im)) * v2),
                "magnetization": (
                    float(p["magnetization_sigma_deg"]),
                    np.sin(np.deg2rad(im)) ** 2 * np.sin(np.deg2rad(am)) * v2,
                ),
                "gyro": (float(p["gyro_sigma_deg"]), np.tan(np.deg2rad(im)) * v2),
                "inclination": (float(p["inclination_sigma_deg"]), np.sin(np.deg2rad(im)) * v3),
            }
            for name, (sigma_deg, weight) in terms.items():
                accum[name] += np.deg2rad(sigma_deg) * ds * weight
            accum["depth"] += float(p["depth_scale_sigma"]) * ds * t
        cov = np.zeros((3, 3))
        for vec in accum.values():
            cov += np.outer(vec, vec)
        cov = (cov + cov.T) * 0.5
        vals = np.linalg.eigvalsh(cov)[::-1].clip(0.0)
        covs.append(cov)
        major.append(confidence * np.sqrt(vals[0]))
        minor.append(confidence * np.sqrt(vals[1]))
        vertical.append(confidence * np.sqrt(vals[2]))
    return dict(
        cov_nev_m2=np.asarray(covs),
        axes_m=np.column_stack([major, minor, vertical]),
        center_nev_m=np.zeros((len(md), 3)),
        confidence=float(confidence),
        parameters=p,
        model="WdW (thesis Eq. 2.37-2.41, 3.1-3.15)",
    )


def _balanced_increment(md0, md1, inc0, inc1, azi0, azi1):
    t0, _, _ = _unit_vectors(inc0, azi0)
    t1, _, _ = _unit_vectors(inc1, azi1)
    dot = float(np.clip(t0 @ t1, -1.0, 1.0))
    dogleg = np.arccos(dot)
    ratio = 1.0 if dogleg < 1e-10 else 2 * np.tan(dogleg / 2) / dogleg
    return 0.5 * (md1 - md0) * ratio * (t0 + t1)


def _segment_jacobian(md0, md1, inc0, inc1, azi0, azi1, at_end):
    values = np.array(
        [md1 if at_end else md0, inc1 if at_end else inc0, azi1 if at_end else azi0], float
    )
    steps = np.array([1e-3, 1e-5, 1e-5])
    jac = np.empty((3, 3))
    for q, step in enumerate(steps):
        lo = values.copy()
        hi = values.copy()
        lo[q] -= step
        hi[q] += step
        argslo = [md0, md1, inc0, inc1, azi0, azi1]
        argshi = argslo.copy()
        slot = (1, 2, 4) if at_end else (0, 3, 5)
        argslo[slot[q]] = lo[q]
        argshi[slot[q]] = hi[q]
        jac[:, q] = (_balanced_increment(*argshi) - _balanced_increment(*argslo)) / (2 * step)
    return jac


def _rev0_weights(inc_deg, azi_deg, declination_deg, dip_deg, b_total_nt, gravity):
    I = np.deg2rad(inc_deg)
    _A = np.deg2rad(azi_deg)
    Am = np.deg2rad(azi_deg - declination_deg)
    theta = np.deg2rad(dip_deg)
    alpha = 0.0
    si, ci, sa, ca = np.sin(I), np.cos(I), np.sin(Am), np.cos(Am)
    td = np.tan(theta)
    g = float(gravity)
    B = float(b_total_nt)
    az_defined = abs(si) > 1e-4
    cot_i = ci / si if az_defined else 0.0
    return {
        "ABX": np.array([0.0, 0.0, (cot_i - td * ca) / g]),
        "ABY": np.array([0.0, -ci / g, (td * ci * sa) / g]),
        "ABZ": np.array([0.0, -si / g, td * si * sa / g]),
        "ASX": np.array([0.0, 0.0, 0.0]),
        "ASY": np.array([0.0, si * ci, -td * si * ci * sa]),
        "ASZ": np.array([0.0, -si * ci / g, td * si * ci * sa / g]),
        "MBX": np.array(
            [0.0, 0.0, (ca * np.cos(alpha) - ci * sa * np.sin(alpha)) / (B * np.cos(theta))]
        ),
        "MBY": np.array(
            [0.0, 0.0, -(ca * np.sin(alpha) + ci * sa * np.cos(alpha)) / (B * np.cos(theta))]
        ),
        "MBZ": np.array([0.0, 0.0, -si * sa / (B * np.cos(theta))]),
        "MSX": np.array(
            [
                0.0,
                0.0,
                (ci * ca * np.sin(alpha) - td * si * np.sin(alpha) + sa * np.cos(alpha))
                * (ca * np.cos(alpha) - ci * sa * np.sin(alpha)),
            ]
        ),
        "MSY": np.array(
            [
                0.0,
                0.0,
                -(ci * ca * np.cos(alpha) - td * si * np.cos(alpha) - sa * np.sin(alpha))
                * (ca * np.sin(alpha) + ci * sa * np.cos(alpha)),
            ]
        ),
        "MSZ": np.array([0.0, 0.0, -(si * ca + td * ci) * si * sa]),
        "SAG": np.array([0.0, si, 0.0]),
        "MX": np.array([0.0, np.sin(alpha), -np.cos(alpha) / si if az_defined else 0.0]),
        "MY": np.array([0.0, np.cos(alpha), np.sin(alpha) / si if az_defined else 0.0]),
        "AMID_CONST": np.array([0.0, 0.0, 1.0]),
        "AMID_DIR": np.array([0.0, 0.0, si * sa]),
        "AZ": np.array([0.0, 0.0, 1.0]),
        "DBH": np.array([0.0, 0.0, 1.0 / (B * np.cos(theta))]),
        "MDI": np.array(
            [0.0, 0.0, -si * sa * (ci - td * si * ca) / max(1.0 - si**2 * sa**2, 1e-8)]
        ),
        "MFI": np.array(
            [0.0, 0.0, -si * sa * (td * ci + si * ca) / (B * max(1.0 - si**2 * sa**2, 1e-8))]
        ),
        "DREF": np.array([1.0, 0.0, 0.0]),
        "DSF": np.array([0.0, 0.0, 0.0]),
        "DST": np.array([0.0, 0.0, 0.0]),
    }


def iscwsa_rev0_covariance(md, inc_deg, azi_deg, confidence=1.0, parameters=None):
    """Historical thesis Rev.0 error budget (not the installed Rev5.11 model)."""
    md = np.asarray(md, float)
    inc = np.asarray(inc_deg, float)
    azi = np.asarray(azi_deg, float)
    if md.ndim != 1 or len(md) < 2 or inc.shape != md.shape or azi.shape != md.shape:
        raise ValueError("ISCWSA Rev.0 needs matching MD/attitude arrays with >=2 stations.")
    if not np.isfinite(np.r_[md, inc, azi]).all() or np.any(np.diff(md) <= 0):
        raise ValueError("ISCWSA Rev.0 inputs must be finite and MD strictly increasing.")
    p = dict(
        accel_bias_mps2=0.004,
        accel_scale=0.0005,
        mag_bias_nt=70.0,
        mag_scale=0.0016,
        sag_deg=0.2,
        misalignment_x_deg=0.06,
        misalignment_y_deg=0.06,
        amid_constant_deg=0.25,
        amid_direction_deg=0.6,
        declination_sigma_deg=0.36,
        dbh_deg_nt=5000.0,
        dip_sigma_deg=0.20,
        total_field_sigma_nt=130.0,
        depth_random_m=0.35,
        depth_system_m=0.0,
        depth_scale=0.00024,
        depth_stretch_per_m=2.2e-7,
        b_total_nt=48000.0,
        dip_deg=58.0,
        declination_deg=2.0,
        gravity=9.80665,
    )
    if parameters:
        p.update(parameters)
    if confidence <= 0 or not np.isfinite(confidence):
        raise ValueError("confidence must be positive.")
    sigmas = {
        "ABX": p["accel_bias_mps2"],
        "ABY": p["accel_bias_mps2"],
        "ABZ": p["accel_bias_mps2"],
        "ASX": p["accel_scale"],
        "ASY": p["accel_scale"],
        "ASZ": p["accel_scale"],
        "MBX": p["mag_bias_nt"],
        "MBY": p["mag_bias_nt"],
        "MBZ": p["mag_bias_nt"],
        "MSX": p["mag_scale"],
        "MSY": p["mag_scale"],
        "MSZ": p["mag_scale"],
        "SAG": np.deg2rad(p["sag_deg"]),
        "MX": np.deg2rad(p["misalignment_x_deg"]),
        "MY": np.deg2rad(p["misalignment_y_deg"]),
        "AMID_CONST": np.deg2rad(p["amid_constant_deg"]),
        "AMID_DIR": np.deg2rad(p["amid_direction_deg"]),
        "AZ": np.deg2rad(p["declination_sigma_deg"]),
        "DBH": np.deg2rad(p["dbh_deg_nt"]),
        "MDI": np.deg2rad(p["dip_sigma_deg"]),
        "MFI": p["total_field_sigma_nt"],
        "DREF": p["depth_random_m"],
        "DSF": p["depth_system_m"],
        "DST": p["depth_stretch_per_m"],
    }
    modes = {
        name: (
            "random"
            if name == "DREF"
            else "global"
            if name in ("AZ", "DBH", "MDI", "MFI", "DST")
            else "systematic"
        )
        for name in sigmas
    }
    accum = {name: np.zeros(3) for name in sigmas}
    random_cov = {name: np.zeros((3, 3)) for name in sigmas}
    covs = []
    axes = []
    for k in range(len(md)):
        if k:
            dprev = _segment_jacobian(
                md[k - 1], md[k], inc[k - 1], inc[k], azi[k - 1], azi[k], True
            )
            dprev0 = _segment_jacobian(
                md[k - 1], md[k], inc[k - 1], inc[k], azi[k - 1], azi[k], False
            )
            im = 0.5 * (inc[k - 1] + inc[k])
            am = 0.5 * (azi[k - 1] + azi[k])
            sources = _rev0_weights(
                im, am, p["declination_deg"], p["dip_deg"], p["b_total_nt"], p["gravity"]
            )
            t_mid, _, _ = _unit_vectors(im, am)
            ds = md[k] - md[k - 1]
            for name, weight in sources.items():
                if name not in sigmas:
                    continue
                # Each survey interval receives its source perturbation; the thesis classifies
                # random terms independently and keeps systematic/global terms correlated.
                local = 0.5 * (dprev @ weight + dprev0 @ weight) * sigmas[name]
                if name == "DREF":
                    local = ds * sigmas[name] * t_mid
                if name == "DSF":
                    local = ds * sigmas[name] * t_mid
                if name == "DST":
                    local = ds * (0.5 * (md[k] + md[k - 1])) * sigmas[name] * t_mid
                if modes[name] == "random":
                    random_cov[name] += np.outer(local, local)
                else:
                    accum[name] += local
        cov = sum(random_cov.values(), np.zeros((3, 3)))
        cov += sum((np.outer(v, v) for v in accum.values()), np.zeros((3, 3)))
        cov = (cov + cov.T) * 0.5
        vals = np.linalg.eigvalsh(cov)[::-1].clip(0.0)
        covs.append(cov)
        axes.append(confidence * np.sqrt(vals))
    return dict(
        cov_nev_m2=np.asarray(covs),
        axes_m=np.asarray(axes),
        center_nev_m=np.zeros((len(md), 3)),
        confidence=float(confidence),
        parameters=p,
        model="ISCWSA Rev.0 (thesis Eq. 3.42-3.72)",
    )


def scalar_sphere(md, settings=None):
    radius = scalar_radius(md, settings or {"uncertainty_model": {"type": "md_scalar_radius"}})
    cov = radius[:, None, None] ** 2 * np.eye(3)[None, :, :]
    return dict(
        radius_m=radius,
        cov_nev_m2=cov,
        axes_m=np.repeat(radius[:, None], 3, axis=1),
        center_nev_m=np.zeros((len(radius), 3)),
        model="Scalar sphere (first paper Eq. 2-65)",
    )
