"""Fast geometric seed construction; candidates require the exact final kernel."""

import argparse
import time
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares, minimize
from scipy.spatial import cKDTree

from wellpath.geometry.arc import angles
from wellpath.geometry.segments import (
    constant_toolface_angles,
    constant_toolface_inclination_extrema,
)
from wellpath.planning.geometry_problem import WellControlProblem
from wellpath.workflows.local_replanning import configuration, load_data
from wellpath.workflows.scenario_replanning import save_json

nodes, weights = np.polynomial.legendre.leggauss(24)
nodes = (nodes + 1) / 2
weights = weights / 2


def fast_segment(p, t, d, w, s):
    s = np.atleast_1d(s)
    ii, aa, _ = constant_toolface_angles(t, d, w, s[:, None] * nodes)
    v = np.stack([np.sin(ii) * np.cos(aa), np.sin(ii) * np.sin(aa), np.cos(ii)], axis=-1)
    pp = p + s[:, None] * np.einsum("ijk,j->ik", v, weights)
    ii, aa, _ = constant_toolface_angles(t, d, w, s)
    tt = np.stack([np.sin(ii) * np.cos(aa), np.sin(ii) * np.sin(aa), np.cos(ii)], axis=-1)
    return pp, tt


class FastGeometry:
    def __init__(self, g, tree, angle_tolerance=0.0):
        self.g = g
        self.tree = tree
        self.cache_z = None
        self.angle_tolerance = angle_tolerance

    def evaluate(self, z):
        if self.cache_z is not None and np.array_equal(self.cache_z, z):
            return self.cache
        p = self.g.p0.copy()
        t = self.g.t0.copy()
        limits = []
        points = []
        for d, w, L in self.g.unpack(z):
            if d == 0:
                pp = p + np.linspace(0, L, 49)[:, None] * t
                tt = np.tile(t, (49, 1))
            else:
                pp, tt = fast_segment(p, t, d, w, np.linspace(0, L, 49))
            low, high = constant_toolface_inclination_extrema(t, d, w, L)
            limits.extend(
                [low - self.g.amin, self.g.amax - high, (np.deg2rad(150) - np.deg2rad(d) * L / 30)]
            )
            points.extend(pp)
            p = pp[-1]
            t = tt[-1]
        inc, azi = angles(t)
        da = (azi - self.g.cfg["target"]["azimuth_deg"] + 180) % 360 - 180
        eq = np.r_[
            (p - self.g.pt) / self.g.scale,
            (inc - self.g.cfg["target"]["inclination_deg"]) / 30,
            da / 30,
        ]
        if self.angle_tolerance:
            limits.extend((self.angle_tolerance / 30 - np.abs(eq[3:])).tolist())
            eq = eq[:3]
        dist = self.tree.query(np.asarray(points))[0]
        self.cache_z = np.asarray(z).copy()
        self.cache = (eq, np.r_[limits, (dist - 5.5) / 5], float(dist.min()))
        return self.cache


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=float, default=720.0)
    parser.add_argument("--end", type=float, default=2245.3483975784497)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--terminal-angle-tolerance", type=float, default=0.0)
    a = parser.parse_args()
    a.output.mkdir(parents=True, exist_ok=True)
    data = load_data(a.start, a.end)
    cfg, s = configuration(data, a.end)
    g = WellControlProblem(cfg)
    tree = cKDTree(np.vstack([n["scan"]["positions"] for n in data["neighbors"]]))
    fast = FastGeometry(g, tree, a.terminal_angle_tolerance)
    rng = np.random.default_rng(20261113)
    logs = []
    start = time.perf_counter()
    for attempt in range(80):
        interval = a.end - a.start
        if attempt == 0:
            ph = np.array(
                [[3.4, 0, interval * 0.36], [0, 0, interval * 0.59], [1.3, -90, interval * 0.05]]
            )
        else:
            ph = np.array(
                [
                    [
                        rng.uniform(2.5, 5.8),
                        rng.uniform(-80, 80),
                        rng.uniform(0.18, 0.6) * interval,
                    ],
                    [0, 0, rng.uniform(0.2, 0.65) * interval],
                    [
                        rng.uniform(0.3, 4),
                        rng.uniform(-150, 150),
                        rng.uniform(0.03, 0.35) * interval,
                    ],
                ]
            )
        z = np.clip(g.pack(ph), 1e-6, 1 - 1e-6)
        fit = least_squares(
            lambda z: np.r_[fast.evaluate(z)[0], np.minimum(fast.evaluate(z)[1][:9], 0.0)],
            z,
            bounds=(0, 1),
            max_nfev=350,
            ftol=1e-10,
            xtol=1e-10,
            gtol=1e-10,
        )
        result = minimize(
            lambda z: float(g.unpack(z)[:, 2].sum()) / g.scale,
            fit.x,
            method="SLSQP",
            bounds=[(0, 1)] * g.dim,
            constraints=[
                dict(type="eq", fun=lambda z: fast.evaluate(z)[0]),
                dict(type="ineq", fun=lambda z: fast.evaluate(z)[1]),
            ],
            options=dict(maxiter=250, ftol=1e-10),
        )
        eq, ineq, dist = fast.evaluate(result.x)
        entry = dict(
            attempt=attempt + 1,
            success=bool(result.success),
            message=str(result.message),
            maximum_equality_error=float(abs(eq).max()),
            minimum_inequality=float(ineq.min()),
            minimum_sampled_center_m=dist,
            controls=g.unpack(result.x),
            elapsed_seconds=time.perf_counter() - start,
        )
        logs.append(entry)
        save_json(a.output / "geometry_scout.json", logs)
        print(attempt + 1, result.success, dist, abs(eq).max(), ineq.min(), flush=True)
        if abs(eq).max() < 1e-6 and ineq.min() > -1e-6:
            _exact = g.evaluate(result.x)
            save_json(a.output / "scouted_controls.json", g.unpack(result.x))
            save_json(a.output / "scouted_exact_geometry.json", g.check(result.x))
            print("ACCEPTED FOR EXACT RESTORATION", g.check(result.x), flush=True)
            break


if __name__ == "__main__":
    main()
