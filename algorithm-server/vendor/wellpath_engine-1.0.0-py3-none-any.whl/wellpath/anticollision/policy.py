"""Four-level collision risk grading and absolute center-distance override."""


def classify_separation(
    minimum_sf, minimum_center_distance_m, sf_levels=(1.0, 1.5, 2.5), center_distance_red_m=5.0
):
    """Classify by SF; a close centerline distance overrides to red."""
    distance = float(minimum_center_distance_m)
    if distance <= center_distance_red_m:
        return "red"
    sf = float(minimum_sf)
    if sf <= sf_levels[0]:
        return "red"
    if sf <= sf_levels[1]:
        return "orange"
    if sf <= sf_levels[2]:
        return "yellow"
    return "blue"
