"""Single-well ISCWSA, empirical covariance and MD scalar-radius models.

Covariances describe 1-sigma NEV position uncertainty. Scalar radii describe
configured spatial boundaries without an implied probability distribution.
Collision evaluation consumes these outputs in the separate collision module.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from wellpath.anticollision.error_models.common import interpolate_cov, validate_covariance
from wellpath.anticollision.error_models.iscwsa.model import header, make_survey
from wellpath.anticollision.error_models.md_scalar_radius.model import scalar_radius
from wellpath.anticollision.error_models.schema import (
    DEFAULT_UNCERTAINTY_MODEL,
    EMPIRICAL_MODELS,
    HEADER_REQUIRED_FIELDS,
    MODEL_OPTIONAL_FIELDS,
    MODEL_REQUIRED_FIELDS,
    PROPAGATED_MODELS,
    SCALAR_RADIUS_MODELS,
    _model_spec,
    _model_type,
)
from wellpath.anticollision.error_models.simplified_mwd.model import simplified_mwd_uncertainty
from wellpath.data_io.survey import load_survey, normalize_survey
from wellpath.data_io.trajectory_workbook import load_xlsx_trajectory
from wellpath.geometry.minimum_curvature import interpolate_minimum_curvature
from wellpath.geometry.segments import segment_state


def is_scalar_radius_model(settings):
    return _model_type(settings) == "md_scalar_radius"


def uncertainty_model_name(settings):
    kind = _model_type(settings)
    if kind == "iscwsa":
        return settings.get("error_model", "ISCWSA MWD Rev5.11")
    return kind


def is_empirical_model(settings):
    return _model_type(settings) not in ("iscwsa", *PROPAGATED_MODELS)


def path_at(problem, e, relative_md):
    """Shared selected nominal geometry, independent of error-model spacing."""
    query = np.asarray(relative_md, float)
    lengths = e["physical"][:, 2]
    ends = np.cumsum(lengths)
    starts = np.r_[0.0, ends[:-1]]
    indices = np.searchsorted(ends, query, side="right").clip(0, problem.n - 1)
    positions = np.empty((len(query), 3))
    inc = np.empty(len(query))
    azi = inc.copy()
    for i, ((dls, w, L), record) in enumerate(zip(e["physical"], e["records"])):
        mask = indices == i
        if not mask.any():
            continue
        s = np.clip(query[mask] - starts[i], 0, L)
        positions[mask], t, _ = segment_state(
            record[0], record[1], dls, w, s, problem.arc_segment_model
        )
        inc[mask] = np.rad2deg(np.arctan2(np.hypot(t[:, 0], t[:, 1]), t[:, 2]))
        azi[mask] = np.rad2deg(np.arctan2(t[:, 1], t[:, 0])) % 360
    return positions, inc, azi


def propagated_uncertainty(md, inc, azi, positions, settings):
    """Public planning/neighbor adapter; full history begins at fixed MD=0.

    A nonzero WdW mean is exposed by the numerical kernel but rejected here:
    nominal well centers must not be silently moved inside an uncertainty API.
    """
    from wellpath.anticollision.error_models.propagation import rev0_covariance, wdw_covariance

    spec = _model_spec(settings)
    kind = spec["type"]
    if kind not in PROPAGATED_MODELS:
        raise ValueError("propagated_uncertainty requires iscwsa_rev0 or wdw")
    params = spec.get("parameters", {})
    if not isinstance(params, dict):
        raise ValueError("parameters must be an object")
    basis = spec.get("propagation_basis", "minimum_curvature")
    if kind == "iscwsa_rev0":
        result = rev0_covariance(md, inc, azi, positions, params, propagation_basis=basis)
    else:
        result = wdw_covariance(
            md,
            inc,
            azi,
            params,
            propagation_basis=basis,
            quadrature_order=spec.get("quadrature_order", 16),
        )
        if np.any(result["center_offset_m"]):
            raise ValueError(
                "Nonzero WdW magnetization_mean_deg requires explicit corrected-center data; "
                "kernel returns center_offset_m using Eq. 3.6. Planning adapter refuses to ignore it."
            )
    cov0 = validate_covariance(settings.get("start_cov_nev_m2", np.zeros((3, 3))))
    result["cov"] = result["cov"] + cov0
    result["start_cov_nev_m2"] = cov0
    return result


def planned_covariance(problem, e):
    settings = problem.cfg["iscwsa"]["planned"]
    kind = _model_type(settings)
    scalar_model = is_scalar_radius_model(settings)
    interval = float(
        settings.get(
            "scan_interval_m", settings.get("survey_interval_m", 1.0 if scalar_model else 10.0)
        )
    )
    if not np.isfinite(interval) or interval <= 0:
        raise ValueError("survey_interval_m must be finite and positive.")
    total = float(e["physical"][:, 2].sum())
    stations = np.r_[np.arange(0, total, interval), total]
    positions, inc, azi = path_at(problem, e, stations)
    start_md = float(settings.get("start_md_m", 0.0))
    if not np.isfinite(start_md) or start_md < 0:
        raise ValueError("start_md_m must be finite and nonnegative.")
    md = stations + start_md
    history = settings.get("history")
    if history is not None and not isinstance(history, dict):
        raise ValueError("history must be an object or null.")
    empirical = is_empirical_model(settings)
    if history and empirical:
        raise ValueError(
            "history propagation is ISCWSA-only; empirical models use their explicit MD profile."
        )
    if history:
        required = ("md_m", "inclination_deg", "azimuth_deg", "positions_m")
        if not isinstance(history, dict) or any(key not in history for key in required):
            raise ValueError("history requires md_m, inclination_deg, azimuth_deg and positions_m.")
        hm = np.asarray(history["md_m"], float)
        hi = np.asarray(history["inclination_deg"], float)
        ha = np.asarray(history["azimuth_deg"], float)
        hp = np.asarray(history["positions_m"], float)
        if (
            hm.ndim != 1
            or len(hm) < 1
            or hi.shape != hm.shape
            or ha.shape != hm.shape
            or hp.shape != (len(hm), 3)
            or not all(np.isfinite(a).all() for a in (hm, hi, ha, hp))
            or np.any(hm < 0)
            or np.any(np.diff(hm) <= 0)
            or np.any((hi < 0) | (hi > 180))
        ):
            raise ValueError(
                "history needs finite matching MD/attitude/Nx3 coordinates, increasing nonnegative MD and inclination in [0,180]."
            )
        if not np.isclose(hm[-1], md[0]):
            raise ValueError("History must end at planned start_md_m.")
        if abs(hi[-1] - inc[0]) > 1e-6 or abs((ha[-1] - azi[0] + 180) % 360 - 180) > 1e-6:
            raise ValueError("History terminal attitude must match trajectory start.")
        hp = np.asarray(history["positions_m"], float)
        if hp.shape != (len(hm), 3) or not np.allclose(hp[-1], positions[0], atol=1e-5):
            raise ValueError("History NEV positions must terminate at planned start position.")
        md = np.r_[hm[:-1], md]
        inc = np.r_[hi[:-1], inc]
        azi = np.r_[ha[:-1], azi]
        positions = np.vstack([hp[:-1], positions])
    propagated = None
    mwd = None
    if scalar_model:
        radius = scalar_radius(md, settings)
        cov = np.eye(3, dtype=np.float64)[None, :, :] * radius[:, None, None] ** 2
        survey = None
    elif kind == "simplified_mwd":
        mwd = simplified_mwd_uncertainty(md, inc, settings)
        cov = mwd["cov"]
        survey = None
    elif kind in PROPAGATED_MODELS:
        propagated = propagated_uncertainty(md, inc, azi, positions, settings)
        cov = propagated["cov"]
        survey = None
    elif empirical:
        cov = empirical_covariance(md, settings, problem.config_dir)
        survey = None
    else:
        survey = make_survey(md, inc, azi, positions, settings)
        cov = np.asarray(survey.cov_nev)
    return dict(
        md=md,
        cov=np.asarray(cov),
        survey=survey,
        measurement_count=len(md),
        with_history=bool(history),
        model_type=kind
        if kind in ("md_scalar_radius", "simplified_mwd", *PROPAGATED_MODELS)
        else ("empirical" if empirical else "iscwsa"),
        simplified_mwd=mwd,
        propagated_uncertainty=propagated,
        model=uncertainty_model_name(settings),
        radius_m=(radius if scalar_model else None),
    )


def load_neighbor(spec, config_dir):
    settings = spec["survey"]
    kind = _model_type(settings)
    source_kind = "survey"
    input_key = next(
        (
            key
            for key in ("survey_file", "xlsx_file", "csv_file", "txt_file", "witsml_file")
            if key in settings
        ),
        None,
    )
    if input_key:
        path = Path(config_dir) / settings[input_key]
        loaded = load_survey(path, settings)
        md = loaded["md"]
        inc = loaded["inc"]
        azi = loaded["azi"]
        positions = loaded["positions"]
        source_kind = loaded["source_kind"]
    else:
        records = [dict(md=value) for value in settings["md_m"]]
        for field, key in (("inc", "inclination_deg"), ("azi", "azimuth_deg")):
            if key in settings:
                if len(settings[key]) != len(records):
                    raise ValueError("Survey array lengths must agree.")
                for row, value in zip(records, settings[key]):
                    row[field] = value
        if "positions_m" in settings:
            if len(settings["positions_m"]) != len(records):
                raise ValueError("Survey coordinate lengths must agree.")
            for row, position in zip(records, settings["positions_m"]):
                row.update(zip(("north", "east", "tvd"), position))
        loaded = normalize_survey(records, settings)
        md = loaded["md"]
        inc = loaded["inc"]
        azi = loaded["azi"]
        positions = loaded["positions"]
    scalar_model = is_scalar_radius_model(settings)
    empirical = is_empirical_model(settings)
    if not scalar_model and not empirical and not loaded["has_attitude"]:
        raise ValueError(
            "ISCWSA surveys require inclination and azimuth columns in addition to MD/N/E/D."
        )
    if kind == "simplified_mwd" and not loaded["has_attitude"]:
        raise ValueError(
            "simplified_mwd requires measured inclination and azimuth; MD/positions alone are insufficient."
        )
    propagated = None
    mwd = None
    if scalar_model:
        radius_profile = scalar_radius(md, settings)
        cov = np.eye(3, dtype=np.float64)[None, :, :] * radius_profile[:, None, None] ** 2
        survey = None
    elif kind == "simplified_mwd":
        mwd = simplified_mwd_uncertainty(md, inc, settings)
        cov = mwd["cov"]
        survey = None
    elif kind in PROPAGATED_MODELS:
        propagated = propagated_uncertainty(md, inc, azi, positions, settings)
        cov = propagated["cov"]
        survey = None
    elif empirical:
        cov = empirical_covariance(md, settings, config_dir)
        survey = None
    else:
        survey = make_survey(md, inc, azi, positions, settings)
        cov = np.asarray(survey.cov_nev)
    # Positions between supplied neighbor measurement stations are minimum-
    # curvature arcs. Check coordinates agree with each station's MD/attitude.
    from wellpath.geometry.arc import minimum_curvature_increment, tangent

    for i in range(len(md) - 1):
        delta = minimum_curvature_increment(
            tangent(inc[i], azi[i]), tangent(inc[i + 1], azi[i + 1]), md[i + 1] - md[i]
        )
        if loaded["has_attitude"] and np.linalg.norm(
            delta - (positions[i + 1] - positions[i])
        ) > spec.get("coordinate_consistency_tolerance_m", 0.02):
            raise ValueError(
                f"Neighbor {spec['name']} MD/attitude/coordinates disagree at station {i}."
            )
    return dict(
        name=spec["name"],
        spec=spec,
        survey=survey,
        md=np.asarray(md, float),
        inc=np.asarray(inc, float),
        azi=np.asarray(azi, float),
        positions=positions,
        cov=np.asarray(cov),
        radius=float(spec.get("radius_m", 0.1)),
        model_type=kind
        if kind in ("md_scalar_radius", "simplified_mwd", *PROPAGATED_MODELS)
        else ("empirical" if empirical else "iscwsa"),
        simplified_mwd=mwd,
        propagated_uncertainty=propagated,
        model=uncertainty_model_name(settings),
        source_kind=source_kind,
        settings=settings,
        raw_positions=positions.copy(),
        raw_md=np.asarray(md, float).copy(),
        has_attitude=loaded["has_attitude"],
    )


def neighbor_at(well, query):

    query = np.asarray(query, float)
    md = well["md"]
    if not well.get("has_attitude", True):
        positions = np.column_stack(
            [np.interp(query, md, well["positions"][:, j]) for j in range(3)]
        )
        return positions, interpolate_cov(md, well["cov"], query)
    positions, _, _ = interpolate_minimum_curvature(
        md, well["inc"], well["azi"], well["positions"], query
    )
    return positions, interpolate_cov(md, well["cov"], query)


def scan_md_grid(md_start, md_end, interval=1.0, extra=None):
    interval = float(interval)
    if interval <= 0:
        raise ValueError("scan interval must be positive.")
    if md_end < md_start:
        raise ValueError("scan MD end must not precede start.")
    values = np.arange(md_start, md_end, interval, dtype=np.float64)
    values = np.r_[values, md_end]
    if extra is not None:
        values = np.r_[values, np.asarray(extra, dtype=np.float64)]
    return np.unique(values).astype(np.float64)


def neighbor_scan(well, interval=1.0):
    query = scan_md_grid(well["md"][0], well["md"][-1], interval, well["md"])
    p, _ = neighbor_at(well, query)
    return query, p


def planned_scan(problem, e, interval=1.0):
    ends = np.cumsum(e["physical"][:, 2])
    starts = np.r_[0.0, ends[:-1]]
    query = scan_md_grid(0.0, float(ends[-1]), interval, np.r_[starts, ends])
    p, _, _ = path_at(problem, e, query)
    return query, p


def planned_scalar_scan_fixed(problem, e):
    """Fixed slots for global 1 m MD samples plus every exact segment endpoint.

    Inactive grid slots keep constraint dimensions constant as lengths change.
    Explicit boundary slots retain fractional endpoints, including the final one.
    """
    ends = np.cumsum(e["physical"][:, 2])
    total = float(ends[-1])
    grid = np.arange(0.0, float(problem.upper[:, 2].sum()), 1.0, dtype=np.float64)
    query = np.r_[np.minimum(grid, total), 0.0, ends]
    active = np.r_[grid <= total, np.ones(problem.n + 1, dtype=bool)]
    order = np.argsort(query, kind="stable")
    query = query[order]
    active = active[order]
    candidates = np.flatnonzero(active)
    _, first = np.unique(query[candidates], return_index=True)
    active[:] = False
    active[candidates[first]] = True
    p, _, _ = path_at(problem, e, query)
    return query, p, active


# Compatibility shims for callers of the earlier combined module.
# All collision decisions live in src/wellpath/anticollision/engine.py; uncertainty functions never call them.
def scalar_pairwise_min(*args, **kwargs):
    from wellpath.anticollision.engine import scalar_pairwise_min as evaluate

    return evaluate(*args, **kwargs)


def scalar_pair_matrix(*args, **kwargs):
    from wellpath.anticollision.engine import scalar_pair_matrix as evaluate

    return evaluate(*args, **kwargs)


def pairwise_sf(*args, **kwargs):
    from wellpath.anticollision.engine import pairwise_sf as evaluate

    return evaluate(*args, **kwargs)


def __getattr__(name):
    if name == "SeparationEngine":
        from wellpath.anticollision.engine import SeparationEngine

        return SeparationEngine
    raise AttributeError(name)


def empirical_covariance(md, settings, config_dir=None):
    spec = _model_spec(settings)
    kind = spec["type"]
    if kind not in EMPIRICAL_MODELS:
        raise ValueError(f"Unknown empirical model {kind!r}")
    md = np.asarray(md, float)
    if (
        md.ndim != 1
        or len(md) < 1
        or not np.isfinite(md).all()
        or np.any(md < 0)
        or np.any(np.diff(md) <= 0)
    ):
        raise ValueError(
            "Empirical model MD stations must be finite, nonnegative and strictly increasing."
        )
    from importlib import import_module

    return import_module(f"wellpath.anticollision.error_models.{kind}.model").covariance(
        md, spec, config_dir
    )


__all__ = [
    "EMPIRICAL_MODELS",
    "DEFAULT_UNCERTAINTY_MODEL",
    "PROPAGATED_MODELS",
    "SCALAR_RADIUS_MODELS",
    "MODEL_REQUIRED_FIELDS",
    "MODEL_OPTIONAL_FIELDS",
    "HEADER_REQUIRED_FIELDS",
    "validate_covariance",
    "interpolate_cov",
    "scalar_radius",
    "simplified_mwd_uncertainty",
    "header",
    "make_survey",
    "load_xlsx_trajectory",
]
