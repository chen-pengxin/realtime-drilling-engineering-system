"""Shared configurable coverage multiplier for planning and scan evaluation."""

import math

DEFAULT_K_SIGMA = 1.0
DEFAULT_SF_METHOD = "major_axis_sum"
SF_METHODS = ("major_axis_sum", "directional_sum", "project_rss")


def configured_k(settings):
    """Use K=1 when omitted; retain an explicit positive finite override."""
    value = settings.get("k_sigma", DEFAULT_K_SIGMA)
    if isinstance(value, bool):
        raise ValueError("k_sigma must be finite and positive, not a boolean.")
    try:
        k = float(value)
    except (ValueError, TypeError):
        raise ValueError("k_sigma must be finite and positive.") from None
    if not math.isfinite(k) or k <= 0:
        raise ValueError("k_sigma must be finite and positive.")
    return k


def configured_sf_method(settings, key="sf_method"):
    """Resolve the shared default and the historical directional-method alias."""
    method = settings.get(key, DEFAULT_SF_METHOD)
    if method == "additive_directional_radii":
        method = "directional_sum"
    if method not in SF_METHODS:
        raise ValueError(f"{key} must be one of {SF_METHODS}.")
    return method


def scan_sf_settings(config):
    """Effective batch channels; common K inherits project K unless overridden.

    covariance_scale remains a supported explicit common-channel K alias.
    The project_rss scalar branch retains its original unscaled radius sum.
    """
    project = dict(config.get("project_sf", {}))
    project["sf_method"] = configured_sf_method(project)
    project["k_sigma"] = configured_k(project)
    for key, value in (("well_radius_m", 0.1), ("surface_margin_m", 0.3), ("sigma_pa_m", 0.5)):
        project.setdefault(key, value)
    common = dict(config.get("common_sf", {}))
    common["method"] = configured_sf_method(common, "method")
    if "covariance_scale" in common:
        alias = configured_k({"k_sigma": common["covariance_scale"]})
        if "k_sigma" in common and configured_k(common) != alias:
            raise ValueError("common_sf.k_sigma conflicts with covariance_scale.")
        common["k_sigma"] = alias
    common.setdefault("k_sigma", project["k_sigma"])
    common["k_sigma"] = configured_k(common)
    for key in ("well_radius_m", "surface_margin_m", "sigma_pa_m"):
        common.setdefault(key, project[key])
    return common, project


def sf_formula(method, scalar=False):
    """Machine-readable formula for the selected path (radii are unscaled)."""
    if scalar:
        return (
            "D/(r1+r2) [legacy scalar path; k unused]"
            if method == "project_rss"
            else "D/[k*(r1+r2)]"
        )
    return {
        "major_axis_sum": "D/[k*(sqrt(lambda_max(C1))+sqrt(lambda_max(C2)))]",
        "directional_sum": "D/[k*(sqrt(u.T*C1*u)+sqrt(u.T*C2*u))]",
        "project_rss": "max(D-2*well_radius_m-surface_margin_m,0)/[k*sqrt(u.T*(C1+C2)*u+sigma_pa_m^2)]",
    }[method]
