"""Modern ISCWSA named tool-code model, implemented by welleng."""

import inspect

import numpy as np
import welleng as we

from wellpath.anticollision.error_models.common import validate_covariance
from wellpath.anticollision.error_models.schema import HEADER_REQUIRED_FIELDS, _model_type


def header(settings):
    fields = settings.get("header")
    if not isinstance(fields, dict):
        raise ValueError("ISCWSA header is required and must be an object.")
    required = HEADER_REQUIRED_FIELDS
    if any(k not in fields or fields[k] is None for k in required):
        raise ValueError("ISCWSA header requires explicit non-null " + ", ".join(required))
    unknown = set(fields) - set(inspect.signature(we.survey.SurveyHeader).parameters)
    if unknown:
        raise ValueError(f"Unknown ISCWSA header parameters: {sorted(unknown)}.")
    if fields["azi_reference"] != "true":
        raise ValueError(
            "Optimizer geometry uses true-north NEV; transform grid/magnetic inputs before use."
        )
    for key in required[:-1]:
        try:
            value = float(fields[key])
        except (ValueError, TypeError) as exc:
            raise ValueError(f"header.{key} must be finite.") from exc
        if not np.isfinite(value):
            raise ValueError(f"header.{key} must be finite.")
    if not -90 <= float(fields["latitude"]) <= 90 or not -180 <= float(fields["longitude"]) <= 180:
        raise ValueError("header latitude/longitude must be in [-90,90]/[-180,180] degrees.")
    if float(fields["b_total"]) <= 0 or not -90 <= float(fields["dip"]) <= 90:
        raise ValueError("header b_total must be positive; dip must be in [-90,90] degrees.")
    for key, expected in (("deg", True), ("depth_unit", "meters"), ("surface_unit", "meters")):
        if key in fields and (
            fields[key] != expected or (key == "deg" and fields[key] is not True)
        ):
            raise ValueError(
                f"header.{key} must be {expected!r}; normalize input units before propagation."
            )
    for key, default in (
        ("G", 9.80665),
        ("earth_rate", 0.26251614),
        ("vertical_inc_limit", 0.0001),
        ("grid_scale_factor", 1.0),
    ):
        value = float(fields.get(key, default))
        if not np.isfinite(value) or value <= 0:
            raise ValueError(f"header.{key} must be finite and positive.")
    for key in ("altitude", "vertical_section_azimuth"):
        if fields.get(key) is not None and not np.isfinite(float(fields[key])):
            raise ValueError(f"header.{key} must be finite.")
    if fields.get("xcl_representation", "nev_direct") not in ("nev_direct", "dia"):
        raise ValueError("header.xcl_representation must be nev_direct or dia.")
    if fields.get("dp_basis", "balanced_tangent") not in ("balanced_tangent", "min_curve"):
        raise ValueError("header.dp_basis must be balanced_tangent or min_curve.")
    if fields.get("tie_on") is not None and not isinstance(fields["tie_on"], bool):
        raise ValueError("header.tie_on must be true, false or null.")
    allowance = fields.get("first_station_allowance")
    if allowance is not None and not isinstance(allowance, bool) and allowance != "uncorrelated":
        raise ValueError(
            "header.first_station_allowance must be true, false, null or uncorrelated."
        )
    fields = dict(fields)
    fields.setdefault("dp_basis", "min_curve")
    return we.survey.SurveyHeader(**fields)


def make_survey(md, inc, azi, positions, settings):
    if _model_type(settings) != "iscwsa":
        raise ValueError(
            "make_survey only accepts ISCWSA; use empirical_covariance for configured empirical models."
        )
    model = settings.get("error_model", "ISCWSA MWD Rev5.11")
    if model not in we.error.get_error_models():
        raise ValueError(f"Unknown ISCWSA tool code: {model}")
    md = np.asarray(md, float)
    inc = np.asarray(inc, float)
    azi = np.asarray(azi, float)
    if (
        md.ndim != 1
        or len(md) < 2
        or not np.isfinite(md).all()
        or np.any(md < 0)
        or np.any(np.diff(md) <= 0)
    ):
        raise ValueError(
            "ISCWSA measurement stations need >=2 finite, nonnegative, strictly increasing MD values."
        )
    positions = np.asarray(positions, float)
    if inc.shape != md.shape or azi.shape != md.shape or positions.shape != (len(md), 3):
        raise ValueError("ISCWSA MD/inc/azi and Nx3 positions must have matching station counts.")
    if (
        not np.isfinite(inc).all()
        or not np.isfinite(azi).all()
        or not np.isfinite(positions).all()
        or np.any((inc < 0) | (inc > 180))
    ):
        raise ValueError(
            "ISCWSA attitudes/positions must be finite, with inclination in [0,180] degrees."
        )
    if "start_cov_nev_m2" not in settings:
        raise ValueError("ISCWSA start_cov_nev_m2 is required.")
    cov0 = validate_covariance(settings["start_cov_nev_m2"])
    radius = float(settings.get("radius_m", 0.1))
    if not np.isfinite(radius) or radius < 0:
        raise ValueError("radius_m must be finite and nonnegative.")
    survey = we.survey.Survey(
        md=md,
        inc=inc,
        azi=azi,
        n=positions[:, 0],
        e=positions[:, 1],
        tvd=positions[:, 2],
        header=header(settings),
        deg=True,
        error_model=model,
        start_nev=positions[0],
        start_cov_nev=cov0,
        radius=radius,
    )
    dropped = getattr(survey.err.errors, "dropped_terms", [])
    if dropped:
        raise ValueError(
            "ISCWSA tool terms failed to evaluate; refusing incomplete covariance: "
            + ", ".join(str(term) for term in dropped)
        )
    return survey
