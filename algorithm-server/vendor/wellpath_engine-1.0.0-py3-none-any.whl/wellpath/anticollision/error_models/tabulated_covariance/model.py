"""tabulated_covariance empirical position-uncertainty model."""

import csv
from pathlib import Path

import numpy as np

from wellpath.anticollision.error_models.common import interpolate_cov, validate_covariance


def covariance(md, spec, config_dir=None):
    if "csv_file" in spec:
        if config_dir is None:
            raise ValueError("config_dir is required for tabulated_covariance csv_file.")
        with (Path(config_dir) / spec["csv_file"]).open(encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
        required = (
            "md_m",
            "cov_nn_m2",
            "cov_ee_m2",
            "cov_vv_m2",
            "cov_ne_m2",
            "cov_nv_m2",
            "cov_ev_m2",
        )
        if not rows or any((k not in rows[0] for k in required)):
            raise ValueError("Covariance CSV columns: " + ", ".join(required))
        table_md = np.asarray([float(r["md_m"]) for r in rows])
        cov = []
        for r in rows:
            nn, ee, vv, ne, nv, ev = [float(r[k]) for k in required[1:]]
            cov.append([[nn, ne, nv], [ne, ee, ev], [nv, ev, vv]])
        cov = np.asarray(cov, float)
    else:
        table_md = np.asarray(spec.get("md_m"), float)
        cov = np.asarray(spec.get("cov_nev_m2"), float)
    if table_md.ndim != 1 or cov.shape != (len(table_md), 3, 3):
        raise ValueError("tabulated_covariance requires md_m Nx1 and cov_nev_m2 Nx3x3.")
    if (
        len(table_md) < 1
        or not np.isfinite(table_md).all()
        or np.any(table_md < 0)
        or np.any(np.diff(table_md) <= 0)
    ):
        raise ValueError(
            "tabulated_covariance md_m must be finite, nonnegative and strictly increasing."
        )
    for matrix in cov:
        validate_covariance(matrix)
    if md.min() < table_md[0] - 1e-09 or md.max() > table_md[-1] + 1e-09:
        raise ValueError("tabulated_covariance cannot extrapolate beyond its MD range.")
    return interpolate_cov(table_md, cov, md)
