"""Published single-point depth-dependent scalar envelope."""

import json
from pathlib import Path

import numpy as np

from wellpath.anticollision.error_models.schema import _model_spec

DEFAULTS = json.loads(Path(__file__).with_name("parameters.json").read_text())


def scalar_radius(md, settings):
    """Return the configured single-point scalar radius in metres.

    Default is the published piecewise MD rule. The optional parameters make
    the same interface usable for a calibrated field rule without changing the
    algorithm: r_low for MD <= md1, r_mid for md1 < MD <= md2, and a linear
    slope after md2.
    """
    spec = _model_spec(settings, direct_scalar=True)
    if spec["type"] != "md_scalar_radius":
        raise ValueError("scalar_radius only accepts md_scalar_radius and its aliases.")
    md = np.asarray(md, dtype=np.float64)
    if md.ndim != 1 or not np.isfinite(md).all() or np.any(md < 0):
        raise ValueError("Scalar-radius MD values must be finite and nonnegative.")
    md1 = float(spec.get("md_break_1_m", DEFAULTS["md_break_1_m"]))
    md2 = float(spec.get("md_break_2_m", DEFAULTS["md_break_2_m"]))
    rlow = float(spec.get("radius_low_m", DEFAULTS["radius_low_m"]))
    rmid = float(spec.get("radius_mid_m", DEFAULTS["radius_mid_m"]))
    slope = float(spec.get("slope_after_m2_m", DEFAULTS["slope_after_m2_m"]))
    if not (
        np.isfinite([md1, md2, rlow, rmid, slope]).all()
        and 0 <= md1 <= md2
        and rlow > 0
        and rmid > 0
        and slope >= 0
    ):
        raise ValueError(
            "Scalar-radius parameters require 0 <= md_break_1_m < md_break_2_m, "
            "positive radii and nonnegative slope_after_m2_m."
        )
    return np.where(md < md1, rlow, rmid + slope * (md - md2)).astype(np.float64)
