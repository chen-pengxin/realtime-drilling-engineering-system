"""iscwsa_rev0 source-error propagation model."""

import json
from pathlib import Path

import numpy as np

from wellpath.anticollision.error_models.common import (
    basis,
    inputs,
    parameters,
    rf_derivative_coefficients,
)

REV0_DEFAULTS = json.loads(Path(__file__).with_name("parameters.json").read_text())["parameters"]


def rev0_covariance(md, inc, azi, positions, override=None, propagation_basis="minimum_curvature"):
    """Thesis Eqs. 3.42-3.78. Angles in rad internally; covariance is 1-sigma NEV m².

    Source parameters use Fig. 4.12 plus Tables 3.2/3.3. ASZ's 1/G in
    printed Eq. 3.47 is retained by an explicit configurable switch. The
    zero-MD position and depth reference are fixed; first attitude is uncertain.
    """
    md, inc, azi = inputs(md, inc, azi)
    pos = np.asarray(positions, dtype=np.float64)
    if pos.shape != (len(md), 3) or not np.isfinite(pos).all():
        raise ValueError("Invalid NEV")
    p = parameters(REV0_DEFAULTS, override)
    if p["gravity"] <= 0 or p["b_total_nt"] <= 0 or abs(p["dip_deg"]) >= 89.9:
        raise ValueError("Invalid gravity, field strength, or dip singularity")
    t, n, e = basis(inc, azi)
    I = np.deg2rad(inc)
    Am = np.deg2rad(azi - p["declination_deg"])
    si, ci, sa, ca = np.sin(I), np.cos(I), np.sin(Am), np.cos(Am)
    tf = np.deg2rad(p["toolface_deg"])
    s, c = np.sin(tf), np.cos(tf)
    dip = np.deg2rad(p["dip_deg"])
    td = np.tan(dip)
    B = p["b_total_nt"]
    G = p["gravity"]
    angular = {}
    modes = {}

    def add(name, wi, sin_wa, sigma, mode="systematic"):
        # J_A is proportional to sin(I), so multiply before evaluating cot/csc.
        angular[name] = float(sigma) * (
            n * np.asarray(wi)[..., None] + e * np.asarray(sin_wa)[..., None]
        )
        modes[name] = mode

    add("ABX", -ci * s / G, (td * si * (ci * sa * s - ca * c) + ci * c) / G, p["accel_bias_mps2"])
    add("ABY", -ci * c / G, (td * si * (ci * sa * c + ca * s) - ci * s) / G, p["accel_bias_mps2"])
    add("ABZ", -si / G, td * si**2 * sa / G, p["accel_bias_mps2"])
    add(
        "ASX",
        si * ci * s * s,
        -si * (td * si * (ci * sa * s - ca * c) + ci * c) * s,
        p["accel_scale"],
    )
    add(
        "ASY",
        si * ci * c * c,
        -si * (td * si * (ci * sa * c + ca * s) - ci * s) * c,
        p["accel_scale"],
    )
    asz_G = G if p["asz_divide_by_gravity"] else 1.0
    add("ASZ", -si * ci / asz_G, td * si**2 * ci * sa / asz_G, p["accel_scale"])
    add("MBX", 0.0, si * (ca * c - ci * sa * s) / (B * np.cos(dip)), p["mag_bias_nt"])
    add("MBY", 0.0, -si * (ca * s + ci * sa * c) / (B * np.cos(dip)), p["mag_bias_nt"])
    add("MBZ", 0.0, -(si**2) * sa / (B * np.cos(dip)), p["mag_bias_nt"])
    add(
        "MSX",
        0.0,
        si * (ci * ca * s - td * si * s + sa * c) * (ca * c - ci * sa * s),
        p["mag_scale"],
    )
    add(
        "MSY",
        0.0,
        -si * (ci * ca * c - td * si * c - sa * s) * (ca * s + ci * sa * c),
        p["mag_scale"],
    )
    add("MSZ", 0.0, -(si**2) * sa * (si * ca + td * ci), p["mag_scale"])
    rad = np.deg2rad
    add("SAG", si, 0.0, rad(p["sag_deg"]))
    add("MX", s, -c, rad(p["misalignment_x_deg"]))
    add("MY", c, s, rad(p["misalignment_y_deg"]))
    add("AMID_CONST", 0.0, si, rad(p["amid_constant_deg"]))
    add("AMID_DIR", 0.0, si**2 * sa, rad(p["amid_direction_deg"]))
    add("AZ", 0.0, si, rad(p["declination_sigma_deg"]), "global")
    add("DBH", 0.0, si / (B * np.cos(dip)), rad(p["dbh_deg_nt"]), "global")
    den = 1 - si**2 * sa**2
    if np.any(den < 1e-10):
        raise ValueError("Rev.0 magnetic correction singularity: need another tool model")
    add("MDI", 0.0, -(si**2) * sa * (ci - td * si * ca) / den, rad(p["dip_sigma_deg"]), "global")
    add(
        "MFI",
        0.0,
        -(si**2) * sa * (td * ci + si * ca) / (B * den),
        p["total_field_sigma_nt"],
        "global",
    )
    depth = {
        "DREF": np.full(len(md), p["depth_random_m"]),
        "DSYS": np.full(len(md), p["depth_system_m"]),
        "DSF": md * p["depth_scale"],
        "DST": md * (pos[:, 2] - pos[0, 2]) * p["depth_stretch_per_m"],
    }
    modes.update(DREF="random", DSYS="systematic", DSF="systematic", DST="global")
    for value in depth.values():
        value[0] = 0.0  # fixed surface depth tie-on
    if propagation_basis not in ("minimum_curvature", "balanced_tangent"):
        raise ValueError("propagation_basis must be minimum_curvature or balanced_tangent")
    ds = np.diff(md)
    rf, h = rf_derivative_coefficients(t[:-1], t[1:])
    if propagation_basis == "balanced_tangent":
        rf = np.ones_like(ds)
        h = np.zeros_like(ds)
    summed = t[:-1] + t[1:]
    depth_gradient = 0.5 * rf[:, None] * summed
    coeff = {}
    cov_terms = {}
    for name, amplitude in {**angular, **depth}.items():
        if name in angular:
            left = (
                0.5
                * ds[:, None]
                * (
                    rf[:, None] * amplitude[:-1]
                    - h[:, None] * summed * np.einsum("ni,ni->n", t[1:], amplitude[:-1])[:, None]
                )
            )
            right = (
                0.5
                * ds[:, None]
                * (
                    rf[:, None] * amplitude[1:]
                    - h[:, None] * summed * np.einsum("ni,ni->n", t[:-1], amplitude[1:])[:, None]
                )
            )
        else:
            left = -depth_gradient * amplitude[:-1, None]
            right = depth_gradient * amplitude[1:, None]
        # At point k, finalized stations j<k include BOTH adjacent segments;
        # station k contributes only the last segment's right Jacobian.
        finalized = left.copy()
        finalized[1:] += right[:-1]
        out = np.zeros((len(md), 3, 3))
        vectors = np.zeros((len(md), 3))
        if modes[name] == "random":
            out[1:] = np.cumsum(np.einsum("ni,nj->nij", finalized, finalized), axis=0) + np.einsum(
                "ni,nj->nij", right, right
            )
        else:
            vectors[1:] = np.cumsum(finalized, axis=0) + right
            out = np.einsum("ni,nj->nij", vectors, vectors)
        coeff[name] = vectors
        cov_terms[name] = out
    cov = sum(cov_terms.values(), np.zeros((len(md), 3, 3)))
    return dict(
        cov=cov,
        terms=cov_terms,
        source_vectors=coeff,
        modes=modes,
        parameters=p,
        propagation_basis=propagation_basis,
        implementation=propagation_basis + "_station_jacobian_rad_v3",
    )
