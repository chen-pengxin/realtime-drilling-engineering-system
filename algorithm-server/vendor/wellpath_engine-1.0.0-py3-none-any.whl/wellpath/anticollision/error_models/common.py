"""Shared covariance validation and propagation mathematics."""

import numpy as np


def validate_covariance(value):
    c = np.asarray(value, float)
    if c.shape != (3, 3) or not np.isfinite(c).all() or not np.allclose(c, c.T, atol=1e-12):
        raise ValueError("start_cov_nev_m2 must be finite symmetric 3x3.")
    if np.linalg.eigvalsh(c).min() < -1e-10:
        raise ValueError("start covariance must be positive semidefinite.")
    return c


def _validate_correlation(value):
    corr = np.asarray(value, float)
    if (
        corr.shape != (3, 3)
        or not np.isfinite(corr).all()
        or not np.allclose(corr, corr.T, atol=1e-12)
    ):
        raise ValueError("correlation must be a finite symmetric 3x3 matrix.")
    if not np.allclose(np.diag(corr), 1.0, atol=1e-10) or np.linalg.eigvalsh(corr).min() < -1e-10:
        raise ValueError("correlation must be PSD with unit diagonal.")
    return corr


def _covariance_from_std(std, correlation=None):
    std = np.asarray(std, float)
    if std.ndim != 2 or std.shape[1] != 3 or not np.isfinite(std).all() or np.any(std < 0):
        raise ValueError("Empirical standard deviations must be finite nonnegative Nx3.")
    corr = np.eye(3) if correlation is None else _validate_correlation(correlation)
    cov = std[:, :, None] * corr[None, :, :] * std[:, None, :]
    return np.asarray(cov, float)


def interpolate_cov(md, covs, query):
    query = np.asarray(query, float)
    out = np.empty(query.shape + (3, 3))
    for i in range(3):
        for j in range(3):
            out[..., i, j] = np.interp(query, md, covs[:, i, j])
    return out


def inputs(md, inc, azi):
    md = np.asarray(md, dtype=np.float64)
    inc = np.asarray(inc, dtype=np.float64)
    azi = np.asarray(azi, dtype=np.float64)
    if (
        md.ndim != 1
        or len(md) < 2
        or inc.shape != md.shape
        or azi.shape != md.shape
        or not np.isfinite(np.r_[md, inc, azi]).all()
        or md[0] != 0.0
        or np.any(np.diff(md) <= 0)
        or np.any((inc < 0) | (inc > 180))
    ):
        raise ValueError(
            "Require matching finite arrays, MD starts at 0, strictly increasing, I in [0,180]."
        )
    return md, inc, azi


def basis(inc, azi):
    i = np.deg2rad(inc)
    a = np.deg2rad(azi)
    si, ci = np.sin(i), np.cos(i)
    t = np.stack([si * np.cos(a), si * np.sin(a), ci], axis=-1)
    n = np.stack([ci * np.cos(a), ci * np.sin(a), -si], axis=-1)
    e = np.stack([-np.sin(a), np.cos(a), np.zeros_like(a)], axis=-1)
    return t, n, e


def parameters(defaults, override):
    extra = set(override or {}) - set(defaults)
    if extra:
        raise ValueError(f"Unknown parameters {extra}")
    p = dict(defaults, **(override or {}))
    if any(not np.isfinite(float(v)) for v in p.values()):
        raise ValueError("Nonfinite parameter")
    for key, v in p.items():
        if (
            key not in ("dip_deg", "declination_deg", "toolface_deg", "magnetization_mean_deg")
            and float(v) < 0
        ):
            raise ValueError(f"Negative uncertainty parameter {key}")
    return p


def rf_derivative_coefficients(t0, t1):
    """Return RF and RF'(beta)/sin(beta), including the coincident tangent limit."""
    dot = np.clip(np.einsum("ni,ni->n", t0, t1), -1.0, 1.0)
    beta = np.arctan2(np.linalg.norm(np.cross(t0, t1), axis=1), dot)
    if np.any(np.pi - beta < 1e-7):
        raise ValueError("Antipodal station tangents: the minimum-curvature plane is not unique.")
    rf = np.empty_like(beta)
    h = np.empty_like(beta)
    small = beta < 1e-3
    b = beta[small]
    b2 = b * b
    rf[small] = 1 + b2 / 12 + b2 * b2 / 120 + 17 * b2**3 / 20160
    h[small] = 1 / 6 + 11 * b2 / 180 + (17 / 3360 + 1 / 180 + 7 / 2160) * b2 * b2
    b = beta[~small]
    rf[~small] = 2 * np.tan(b / 2) / b
    h[~small] = ((b / (np.cos(b / 2) ** 2) - 2 * np.tan(b / 2)) / (b * b)) / np.sin(b)
    return rf, h
