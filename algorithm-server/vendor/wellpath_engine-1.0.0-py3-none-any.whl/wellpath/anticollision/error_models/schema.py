"""Error-model configuration contract and validation."""

from pathlib import Path

EMPIRICAL_MODELS = (
    "constant_covariance",
    "constant_isotropic",
    "linear_std",
    "random_walk",
    "tabulated_covariance",
)
DEFAULT_UNCERTAINTY_MODEL = "iscwsa_rev0"
PROPAGATED_MODELS = ("iscwsa_rev0", "wdw")
SCALAR_RADIUS_MODELS = ("md_scalar_radius", "single_point_radius", "depth_scalar_radius")
MODEL_REQUIRED_FIELDS = {
    "iscwsa": (),
    "constant_covariance": ("cov_nev_m2",),
    "constant_isotropic": ("sigma_m",),
    "linear_std": ("sigma0_nev_m", "slope_nev_per_m"),
    "random_walk": ("sigma0_nev_m", "q_nev_m2_per_m"),
    "tabulated_covariance": (),  # CSV or the two arrays, checked below.
    "md_scalar_radius": (),
    "simplified_mwd": (),
    "iscwsa_rev0": (),
    "wdw": (),
}
MODEL_OPTIONAL_FIELDS = {
    "iscwsa": (),
    "iscwsa_rev0": ("parameters", "propagation_basis"),
    "wdw": ("parameters", "propagation_basis", "quadrature_order"),
    "constant_covariance": (),
    "constant_isotropic": ("correlation",),
    "linear_std": ("depth_origin_m", "correlation"),
    "random_walk": ("depth_origin_m", "correlation"),
    "tabulated_covariance": ("csv_file", "md_m", "cov_nev_m2"),
    "md_scalar_radius": (
        "md_break_1_m",
        "md_break_2_m",
        "radius_low_m",
        "radius_mid_m",
        "slope_after_m2_m",
    ),
    "simplified_mwd": ("sigma_md_m", "sigma_inc_deg", "sigma_azi_deg", "depth_origin_m"),
}
HEADER_REQUIRED_FIELDS = (
    "latitude",
    "longitude",
    "b_total",
    "dip",
    "declination",
    "convergence",
    "azi_reference",
)


def _model_spec(settings, direct_scalar=False):
    """Validate the model object; surrounding survey settings have another scope."""
    if not isinstance(settings, dict):
        raise ValueError("Survey settings must be an object.")
    spec = (
        settings
        if direct_scalar and "uncertainty_model" not in settings
        else settings.get("uncertainty_model")
    )
    if spec is None:
        # An explicit legacy tool code still selects the named modern tool.
        # With no model selection the project now defaults to Rev.0.
        spec = {
            "type": (
                "md_scalar_radius"
                if direct_scalar
                else "iscwsa"
                if "error_model" in settings
                else DEFAULT_UNCERTAINTY_MODEL
            )
        }
    if not isinstance(spec, dict):
        raise ValueError("uncertainty_model must be an object with a type.")
    kind = spec.get("type", "md_scalar_radius" if direct_scalar else None)
    if not isinstance(kind, str) or not kind.strip():
        raise ValueError("uncertainty_model.type is required and must be a nonempty string.")
    kind = kind.strip().lower()
    if kind in SCALAR_RADIUS_MODELS:
        kind = "md_scalar_radius"
    if kind not in MODEL_REQUIRED_FIELDS:
        raise ValueError(
            f"Unknown uncertainty_model.type {kind!r}; choose {tuple(MODEL_REQUIRED_FIELDS)}."
        )
    allowed = {"type", *MODEL_REQUIRED_FIELDS[kind], *MODEL_OPTIONAL_FIELDS[kind]}
    unknown = set(spec) - allowed
    if unknown:
        raise ValueError(f"{kind}: unknown uncertainty_model parameters: {sorted(unknown)}.")
    required = MODEL_REQUIRED_FIELDS[kind]
    if kind == "tabulated_covariance" and "csv_file" not in spec:
        required = ("md_m", "cov_nev_m2")
    missing = [key for key in required if key not in spec or spec[key] is None]
    if missing:
        raise ValueError(f"{kind}: required uncertainty_model parameters missing: {missing}.")
    if kind == "tabulated_covariance" and "csv_file" in spec:
        if not isinstance(spec["csv_file"], (str, Path)) or not str(spec["csv_file"]).strip():
            raise ValueError("tabulated_covariance.csv_file must be a nonempty path.")
    return dict(spec, type=kind)


def _model_type(settings):
    return _model_spec(settings)["type"]
