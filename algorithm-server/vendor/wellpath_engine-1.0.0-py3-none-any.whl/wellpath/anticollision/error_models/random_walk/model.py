"""random_walk empirical position-uncertainty model."""

import numpy as np

from wellpath.anticollision.error_models.common import _covariance_from_std


def covariance(md, spec, config_dir=None):
    origin = float(spec.get("depth_origin_m", md[0]))
    if not np.isfinite(origin) or origin < 0:
        raise ValueError("depth_origin_m must be finite and nonnegative.")
    depth = np.maximum(md - origin, 0.0)
    sigma0 = np.asarray(spec.get("sigma0_nev_m"), float)
    q = np.asarray(spec.get("q_nev_m2_per_m"), float)
    if sigma0.shape != (3,) or q.shape != (3,):
        raise ValueError("random_walk requires length 3 parameters.")
    if not np.isfinite(np.r_[sigma0, q]).all() or np.any(sigma0 < 0) or np.any(q < 0):
        raise ValueError("Invalid random_walk parameters.")
    std = np.sqrt(sigma0[None, :] ** 2 + depth[:, None] * q[None, :])
    return _covariance_from_std(std, spec.get("correlation"))
