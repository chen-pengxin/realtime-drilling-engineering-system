"""constant_covariance empirical position-uncertainty model."""

import numpy as np

from wellpath.anticollision.error_models.common import validate_covariance


def covariance(md, spec, config_dir=None):
    cov = np.asarray(spec.get("cov_nev_m2"), float)
    if cov.shape != (3, 3):
        raise ValueError("constant_covariance requires cov_nev_m2 3x3.")
    return np.repeat(validate_covariance(cov)[None, :, :], len(md), axis=0)
