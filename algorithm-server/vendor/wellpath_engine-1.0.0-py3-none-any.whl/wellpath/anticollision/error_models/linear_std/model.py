"""linear_std empirical position-uncertainty model."""

import numpy as np

from wellpath.anticollision.error_models.common import _covariance_from_std


def covariance(md, spec, config_dir=None):
    origin = float(spec.get("depth_origin_m", md[0]))
    if not np.isfinite(origin) or origin < 0:
        raise ValueError("depth_origin_m must be finite and nonnegative.")
    depth = np.maximum(md - origin, 0.0)
    sigma0 = np.asarray(spec.get("sigma0_nev_m"), float)
    slope = np.asarray(spec.get("slope_nev_per_m"), float)
    if sigma0.shape != (3,) or slope.shape != (3,):
        raise ValueError("linear_std requires length 3 parameters.")
    if not np.isfinite(np.r_[sigma0, slope]).all() or np.any(sigma0 < 0) or np.any(slope < 0):
        raise ValueError("Invalid linear_std parameters.")
    std = sigma0[None, :] + depth[:, None] * slope[None, :]
    return _covariance_from_std(std, spec.get("correlation"))
