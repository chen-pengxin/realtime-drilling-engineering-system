"""constant_isotropic empirical position-uncertainty model."""

import numpy as np

from wellpath.anticollision.error_models.common import _covariance_from_std


def covariance(md, spec, config_dir=None):
    std = np.full((len(md), 3), float(spec.get("sigma_m")))
    return _covariance_from_std(std, spec.get("correlation"))
