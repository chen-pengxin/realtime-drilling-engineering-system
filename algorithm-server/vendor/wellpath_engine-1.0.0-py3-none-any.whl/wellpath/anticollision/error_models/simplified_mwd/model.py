"""TrueMyWell simplified MD/inclination/azimuth measurement envelope."""

import json
from pathlib import Path

import numpy as np

from wellpath.anticollision.error_models.schema import _model_spec

DEFAULTS = json.loads(Path(__file__).with_name("parameters.json").read_text())


def simplified_mwd_uncertainty(md, inclination_deg, settings):
    """TrueMyWell's three-parameter MWD envelope, with a spherical covariance proxy.

    The extracted source computes sigma_perp = L * hypot(sigma_inc,
    sin(I)*sigma_azi), then R = max(sigma_md, sigma_perp). It supplies no full
    covariance. R**2 I is this project's conservative isotropic adapter, not
    an ISCWSA tool-source propagation. L uses MD relative to depth_origin_m
    (default: the first supplied station), instead of source polyline chords.
    """
    spec = _model_spec(settings)
    if spec["type"] != "simplified_mwd":
        raise ValueError("simplified_mwd_uncertainty requires type simplified_mwd.")
    md = np.asarray(md, dtype=np.float64)
    inc = np.asarray(inclination_deg, dtype=np.float64)
    if (
        md.ndim != 1
        or len(md) < 1
        or not np.isfinite(md).all()
        or np.any(md < 0)
        or np.any(np.diff(md) <= 0)
    ):
        raise ValueError("simplified_mwd MD must be finite, nonnegative and strictly increasing.")
    if inc.shape != md.shape or not np.isfinite(inc).all() or np.any((inc < 0) | (inc > 180)):
        raise ValueError("simplified_mwd requires matching finite inclination_deg in [0,180].")
    values = []
    for key, default in (
        ("sigma_md_m", DEFAULTS["sigma_md_m"]),
        ("sigma_inc_deg", DEFAULTS["sigma_inc_deg"]),
        ("sigma_azi_deg", DEFAULTS["sigma_azi_deg"]),
        ("depth_origin_m", md[0]),
    ):
        try:
            value = float(spec.get(key, default))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"simplified_mwd.{key} must be finite and nonnegative.") from exc
        if not np.isfinite(value) or value < 0:
            raise ValueError(f"simplified_mwd.{key} must be finite and nonnegative.")
        values.append(value)
    # Retain the source constructor's numerical floors after unit conversion.
    sigma_md = max(values[0], 1e-6)
    sigma_inc = max(float(np.deg2rad(values[1])), 1e-9)
    sigma_azi = max(float(np.deg2rad(values[2])), 1e-9)
    length = np.maximum(md - values[3], 0.0)
    sigma_perp = length * np.hypot(sigma_inc, np.sin(np.deg2rad(inc)) * sigma_azi)
    radius = np.maximum(sigma_md, sigma_perp)
    with np.errstate(over="ignore"):
        cov = radius[:, None, None] ** 2 * np.eye(3)[None, :, :]
    if not np.isfinite(cov).all():
        raise ValueError("simplified_mwd parameters produce nonfinite covariance.")
    return dict(
        cov=cov,
        envelope_1sigma_m=radius,
        sigma_perp_m=sigma_perp,
        growth_length_m=length,
        depth_origin_m=values[3],
        effective_sigma_md_m=sigma_md,
        effective_sigma_inc_rad=sigma_inc,
        effective_sigma_azi_rad=sigma_azi,
        covariance_representation="spherical_envelope_proxy",
    )
