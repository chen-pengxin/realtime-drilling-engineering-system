"""Discover independent error models and their packaged parameter profiles."""

import json
from copy import deepcopy
from importlib import import_module, resources

from .schema import DEFAULT_UNCERTAINTY_MODEL, MODEL_REQUIRED_FIELDS

MODEL_NAMES = tuple(MODEL_REQUIRED_FIELDS)


def load_model_settings(name=DEFAULT_UNCERTAINTY_MODEL):
    """Return a new settings object; profile values can be overridden by callers.

    Empirical values and the modern ISCWSA field header are example profiles.
    Rev.0/WdW source budgets and scalar/MWD defaults retain the project values.
    """
    if name not in MODEL_NAMES:
        raise ValueError(f"Unknown model {name!r}; choose {MODEL_NAMES}")
    package = f"wellpath.anticollision.error_models.{name}"
    profile = json.loads(resources.files(package).joinpath("parameters.json").read_text())
    return deepcopy(profile if "uncertainty_model" in profile else {"uncertainty_model": profile})


def model_module(name):
    if name not in MODEL_NAMES:
        raise ValueError(f"Unknown model {name!r}; choose {MODEL_NAMES}")
    return import_module(f"wellpath.anticollision.error_models.{name}.model")
