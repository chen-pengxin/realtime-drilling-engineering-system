"""wdw source-error propagation model."""

import json
from pathlib import Path

import numpy as np

from wellpath.anticollision.error_models.common import (
    basis,
    inputs,
    parameters,
    rf_derivative_coefficients,
)

WDW_DEFAULTS = json.loads(Path(__file__).with_name("parameters.json").read_text())["parameters"]


def wdw_covariance(
    md, inc, azi, override=None, propagation_basis="minimum_curvature", quadrature_order=16
):
    """Thesis Eqs. 3.6, 3.9-3.12 on the MC path; integrate, then outer product.

    Returns the optional mean magnetic center offset separately. Callers must
    apply or explicitly reject it, rather than silently dropping a nonzero bias.
    """
    md, inc, azi = inputs(md, inc, azi)
    p = parameters(WDW_DEFAULTS, override)
    if propagation_basis not in ("minimum_curvature", "midpoint_legacy"):
        raise ValueError("WdW propagation_basis must be minimum_curvature or midpoint_legacy")
    if (
        isinstance(quadrature_order, bool)
        or int(quadrature_order) != quadrature_order
        or not 2 <= quadrature_order <= 64
    ):
        raise ValueError("quadrature_order must be an integer in [2,64]")
    ds = np.diff(md)
    ts, _, _ = basis(inc, azi)
    rf, _ = rf_derivative_coefficients(ts[:-1], ts[1:])
    if propagation_basis == "minimum_curvature":
        nodes, weights = np.polynomial.legendre.leggauss(int(quadrature_order))
        fraction = (nodes + 1) / 2
        weights = weights / 2
        dot = np.clip(np.einsum("ni,ni->n", ts[:-1], ts[1:]), -1.0, 1.0)
        beta = np.arctan2(np.linalg.norm(np.cross(ts[:-1], ts[1:]), axis=1), dot)
        normal = ts[1:] - dot[:, None] * ts[:-1]
        norm = np.linalg.norm(normal, axis=1)
        normal = np.divide(
            normal, norm[:, None], out=np.zeros_like(normal), where=norm[:, None] > 1e-14
        )
        # Spherical tangent interpolation on exactly the same planar MC arc.
        theta = beta[:, None] * fraction
        tangent = (
            np.cos(theta)[:, :, None] * ts[:-1, None, :]
            + np.sin(theta)[:, :, None] * normal[:, None, :]
        )
        im = np.rad2deg(np.arctan2(np.linalg.norm(tangent[:, :, :2], axis=2), tangent[:, :, 2]))
        am = np.rad2deg(np.arctan2(tangent[:, :, 1], tangent[:, :, 0]))
        t, n, e = basis(im, am)
        delta = 0.5 * ds[:, None] * rf[:, None] * (ts[:-1] + ts[1:])
        integrate = lambda value: ds[:, None] * np.einsum("nqi,q->ni", value, weights)
    else:
        im = 0.5 * (inc[:-1] + inc[1:])
        da = (azi[1:] - azi[:-1] + 180) % 360 - 180
        am = azi[:-1] + da * 0.5
        t, n, e = basis(im, am)
        delta = ds[:, None] * t
        integrate = lambda value: ds[:, None] * value
    si = np.sin(np.deg2rad(im))
    if p["gyro_sigma_deg"] and (
        np.any(np.abs(np.cos(np.deg2rad(im))) < 1e-8)
        or np.any((inc[:-1] - 90) * (inc[1:] - 90) <= 0)
    ):
        raise ValueError(
            "WdW gyro weighting is singular at/crossing horizontal; choose a valid tool model."
        )
    raw = {
        "COMPASS": si[..., None] * e,
        "MAGNETIZATION": (si**2 * np.sin(np.deg2rad(am)))[..., None] * e,
        "GYRO": np.tan(np.deg2rad(im))[..., None] * e,
        "INCLINATION": si[..., None] * n,
        "DEPTH_SCALE": t,
    }
    magnitudes = dict(
        COMPASS=np.deg2rad(p["compass_sigma_deg"]),
        MAGNETIZATION=np.deg2rad(p["magnetization_sigma_deg"]),
        GYRO=np.deg2rad(p["gyro_sigma_deg"]),
        INCLINATION=np.deg2rad(p["inclination_sigma_deg"]),
        DEPTH_SCALE=p["depth_scale_sigma"],
    )
    coeff = {}
    terms = {}
    for name, value in raw.items():
        increments = delta if name == "DEPTH_SCALE" else integrate(value)
        vec = np.vstack([np.zeros(3), np.cumsum(increments, axis=0)]) * magnitudes[name]
        coeff[name] = vec
        terms[name] = np.einsum("ni,nj->nij", vec, vec)
    r = np.vstack([np.zeros(3), np.cumsum(delta, axis=0)])
    terms["MISALIGNMENT"] = np.deg2rad(p["misalignment_sigma_deg"]) ** 2 * (
        md[:, None, None] ** 2 * np.eye(3) - np.einsum("ni,nj->nij", r, r)
    )
    cov = sum(terms.values(), np.zeros((len(md), 3, 3)))
    bias_integral = np.vstack([np.zeros(3), np.cumsum(integrate(raw["MAGNETIZATION"]), axis=0)])
    offset = -bias_integral * np.deg2rad(p["magnetization_mean_deg"])  # Eq. 3.6 sign convention
    return dict(
        cov=cov,
        terms=terms,
        source_vectors=coeff,
        parameters=p,
        center_offset_m=offset,
        propagation_basis=propagation_basis,
        implementation="correlated_source_" + propagation_basis + "_integrals_v3",
    )
