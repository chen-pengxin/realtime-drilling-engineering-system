"""Independent centerline and minimum-SF evaluation, screening and planning adapter."""

from __future__ import annotations

import numpy as np

from wellpath.anticollision.methods.separation_factor import (
    pairwise_sf,
    pointwise_separation_minimum,
    scalar_pair_matrix,
    scalar_pairwise_min,
)
from wellpath.anticollision.settings import (
    configured_k,
    configured_sf_method,
)
from wellpath.anticollision.uncertainty import (
    interpolate_cov,
    is_scalar_radius_model,
    load_neighbor,
    neighbor_at,
    neighbor_scan,
    path_at,
    planned_covariance,
    planned_scalar_scan_fixed,
)
from wellpath.geometry.arc import angles
from wellpath.geometry.minimum_curvature import (
    centerline_minimum_distance,
    classify_separation,
    resample_minimum_curvature,
)


class SeparationEngine:
    def __init__(self, problem):
        self.problem = problem
        self.settings = problem.cfg["iscwsa"]
        if self.settings.get("independent_wells", True) is not True:
            raise ValueError(
                "This implementation supports independent-well covariance only; "
                "correlated shared error sources require cross-covariance and are not implemented."
            )
        self.threshold = float(self.settings.get("sf_threshold", 1.5))
        self.sf_levels = tuple(float(x) for x in self.settings.get("sf_levels", (1.0, 1.5, 2.5)))
        if len(self.sf_levels) != 3 or not (
            0 < self.sf_levels[0] < self.sf_levels[1] < self.sf_levels[2]
        ):
            raise ValueError("sf_levels must be three strictly increasing positive values.")
        self.centerline_threshold = float(self.settings.get("centerline_min_distance_m", 5.0))
        self.centerline_red_m = float(self.settings.get("centerline_red_distance_m", 5.0))
        self.centerline_buffer = float(self.settings.get("centerline_optimization_buffer_m", 1e-3))
        self.centerline_scale = max(self.centerline_threshold, 1.0)
        self.sf_method = configured_sf_method(self.settings)
        if self.sf_method not in ("project_rss", "major_axis_sum", "directional_sum"):
            raise ValueError("Invalid sf_method")
        self.settings["sf_method"] = self.sf_method
        self.k = configured_k(self.settings)
        self.settings["k_sigma"] = self.k  # persist the effective value, including the default
        self.sigma_pa = float(self.settings.get("sigma_pa_m", 0.5))
        self.surface_margin = float(self.settings.get("surface_margin_m", 0.3))
        self.stations_per_arc = int(self.settings.get("scan_stations_per_arc", 5))
        self.offset_step = float(self.settings.get("offset_scan_step_m", 5))
        if (
            min(self.threshold, self.k, self.offset_step) <= 0
            or self.sigma_pa < 0
            or self.stations_per_arc < 2
        ):
            raise ValueError(
                "SF threshold, k, sigma_pa, scan step positive; stations_per_arc >= 2."
            )
        if (
            min(
                self.surface_margin,
                self.centerline_threshold,
                self.centerline_red_m,
                self.centerline_buffer,
            )
            < 0
        ):
            raise ValueError("Surface and centerline thresholds/buffers must be nonnegative.")
        self.neighbors = [load_neighbor(s, problem.config_dir) for s in self.settings["neighbors"]]
        planned_settings = self.settings["planned"]
        scalar_flags = [is_scalar_radius_model(planned_settings)] + [
            well["model_type"] == "md_scalar_radius" for well in self.neighbors
        ]
        if any(scalar_flags) and not all(scalar_flags):
            raise ValueError(
                "md_scalar_radius must be configured for the planned well and every "
                "neighbor in the same separation calculation; it cannot be mixed with covariance models."
            )
        self.scalar_radius_mode = all(scalar_flags) and bool(scalar_flags)
        self.scalar_block_rows = max(1, int(self.settings.get("scalar_block_rows", 1024)))
        self.offset_cache = {}
        self.centerline_cache = {}
        self.screening = bool(self.settings.get("horizontal_aabb_screening", True))

    def offset(self, well, factor):
        key = (well["name"], factor)
        if key not in self.offset_cache:
            if self.scalar_radius_mode:
                query, p = neighbor_scan(well, 1.0)
                self.offset_cache[key] = (query, p, None)
            else:
                md = well["md"]
                query = np.unique(np.r_[np.arange(md[0], md[-1], self.offset_step / factor), md])
                p, c = neighbor_at(well, query)
                self.offset_cache[key] = (query, p, c)
        return self.offset_cache[key]

    def centerline_details(self, e):
        ends = np.cumsum(e["physical"][:, 2])
        md = np.r_[0.0, ends]
        positions = np.vstack([e["records"][0][0], *[record[2] for record in e["records"]]])
        attitudes = np.asarray(
            [angles(e["records"][0][1]), *[angles(record[3]) for record in e["records"]]]
        )
        if self.problem.arc_segment_model == "constant_toolface":
            max_step = float(self.settings.get("centerline_resample_step_m", 2.0))
            tolerance = float(self.settings.get("centerline_curve_tolerance_m", 0.01))
            if max_step <= 0 or tolerance <= 0:
                raise ValueError("Centerline step and curve tolerance must be positive")
            queries = []
            start = 0.0
            for dls, w, length in e["physical"]:
                k = np.deg2rad(dls) / 30
                step = min(max_step, np.sqrt(8 * tolerance / k)) if k > 0 else max_step
                queries.append(
                    np.linspace(start, start + length, max(1, int(np.ceil(length / step))) + 1)
                )
                start += length
            query = np.unique(np.concatenate(queries))
            planned, _, _ = path_at(self.problem, e, query)
        else:
            _, planned, _, _ = resample_minimum_curvature(
                md,
                attitudes[:, 0],
                attitudes[:, 1],
                positions,
                max_step_m=float(self.settings.get("centerline_resample_step_m", 2.0)),
                tolerance_m=float(self.settings.get("centerline_curve_tolerance_m", 0.01)),
            )
        details = []
        for well in self.neighbors:
            if well["name"] not in self.centerline_cache:
                if well.get("has_attitude", True):
                    _, offset, _, _ = resample_minimum_curvature(
                        well["md"],
                        well["inc"],
                        well["azi"],
                        well["positions"],
                        max_step_m=float(self.settings.get("centerline_resample_step_m", 2.0)),
                        tolerance_m=float(self.settings.get("centerline_curve_tolerance_m", 0.01)),
                    )
                else:
                    offset = well["positions"]
                self.centerline_cache[well["name"]] = offset
            result = centerline_minimum_distance(
                planned, self.centerline_cache[well["name"]], screening=self.screening
            )
            # Chord error bound for two MC curves; includes imported endpoint residuals.
            error = 2 * float(self.settings.get("centerline_curve_tolerance_m", 0.01))
            error += float(well.get("endpoint_residual_m", 0.0))
            result["curve_error_bound_m"] = error
            result["distance_lower_bound_m"] = max(0.0, result["distance_m"] - error)
            result["distance_upper_bound_m"] = result["distance_m"] + error
            result.update(neighbor=well["name"], classification=None)
            details.append(result)
        return details

    def evaluate(self, e, factor=1, refine=False):
        problem = self.problem
        if self.scalar_radius_mode:
            query, p, active = planned_scalar_scan_fixed(problem, e)
            start_md = float(self.settings["planned"].get("start_md_m", 0.0))
            pmd = query + start_md
            constraints = []
            details = []
            profiles = []
            centerline = self.centerline_details(e)
            active_indices = np.flatnonzero(active)
            active_p = p[active]
            active_pmd = pmd[active]
            all_wells = [
                dict(
                    name="planned",
                    positions=active_p,
                    md=active_pmd,
                    settings=self.settings["planned"],
                )
            ]
            for well in self.neighbors:
                omd, q, _ = self.offset(well, factor)
                result = scalar_pairwise_min(
                    active_p,
                    active_pmd,
                    q,
                    omd,
                    self.settings["planned"],
                    self.scalar_block_rows,
                    settings_b=well["settings"],
                    screening=self.screening,
                    k=self.k,
                    sf_method=self.sf_method,
                )
                minimum = np.full(len(query), self.threshold * 2.0, dtype=np.float64)
                minimum[active_indices] = result["minimum_by_a"]
                constraints.extend((minimum - self.threshold) / self.threshold)
                i, j = result["reference_index"], result["offset_index"]
                center = next(item for item in centerline if item["neighbor"] == well["name"])
                classification = classify_separation(
                    result["minimum_sf"],
                    center["distance_m"],
                    self.sf_levels,
                    self.centerline_red_m,
                )
                center["classification"] = classification
                details.append(
                    dict(
                        neighbor=well["name"],
                        minimum_sf=result["minimum_sf"],
                        reference_relative_md_m=float(active_pmd[i] - start_md),
                        offset_md_m=float(omd[j]),
                        centerline_distance_m=center["distance_m"],
                        separation_point_distance_m=result["centerline_distance_m"],
                        classification=classification,
                        sf_screening=result["screening"],
                        combined_error_boundary_m=result["combined_error_boundary_m"],
                        reference_radius_m=result["reference_radius_m"],
                        offset_radius_m=result["offset_radius_m"],
                        reference_position_m=active_p[i].tolist(),
                        offset_position_m=q[j].tolist(),
                    )
                )
                profiles.append(
                    dict(
                        neighbor=well["name"],
                        relative_md_m=(active_pmd - start_md).tolist(),
                        minimum_sf=result["minimum_by_a"].tolist(),
                    )
                )
                all_wells.append(
                    dict(name=well["name"], positions=q, md=omd, settings=well["settings"])
                )
            matrix, matrix_details = scalar_pair_matrix(
                all_wells, self.settings, self.scalar_block_rows, k=self.k, sf_method=self.sf_method
            )
            center_g = [
                (
                    item["distance_lower_bound_m"]
                    - self.centerline_threshold
                    - self.centerline_buffer
                )
                / self.centerline_scale
                for item in centerline
            ]
            return dict(
                g=np.r_[constraints, center_g],
                sf_g=np.asarray(constraints),
                centerline_g=np.asarray(center_g),
                sf_constraint_count=len(constraints),
                minimum_sf=min([d["minimum_sf"] for d in details], default=None),
                minimum_centerline_distance_m=min(
                    [item["distance_m"] for item in centerline], default=None
                ),
                minimum_centerline_distance_lower_bound_m=min(
                    [item["distance_lower_bound_m"] for item in centerline], default=None
                ),
                details=details,
                profiles=profiles,
                measurement_count=int(active.sum()),
                scan_factor=1,
                centerline_details=centerline,
                covariance=planned_covariance(problem, e),
                pair_sf_matrix=matrix.tolist(),
                pair_sf_names=[well["name"] for well in all_wells],
                pair_sf_details=matrix_details,
                method="md_scalar_radius; 1 m sampling; horizontal AABB bounds and exact float64 candidate evaluation",
            )
        covariance = planned_covariance(problem, e)
        ends = np.cumsum(e["physical"][:, 2])
        starts = np.r_[0.0, ends[:-1]]
        query = np.unique(
            np.concatenate(
                [
                    np.linspace(a, b, self.stations_per_arc * factor + 1)
                    for a, b in zip(starts, ends)
                ]
            )
        )
        p, _, _ = path_at(problem, e, query)
        start_md = float(self.settings["planned"].get("start_md_m", 0.0))
        c = interpolate_cov(covariance["md"], covariance["cov"], query + start_md)
        constraints = []
        details = []
        profiles = []
        centerline = self.centerline_details(e)
        for well in self.neighbors:
            omd, q, d = self.offset(well, factor)
            margin = (
                problem.cfg.get("planned_well_radius_m", 0.1) + well["radius"] + self.surface_margin
            )
            scan = pointwise_separation_minimum(
                p,
                q,
                c=c,
                d=d,
                margin=margin,
                k=self.k,
                sigma_pa=self.sigma_pa,
                screening=self.screening,
                sf_method=self.sf_method,
            )
            minimum = scan["minimum_by_a"]
            constraints.extend((minimum - self.threshold) / self.threshold)
            row, col = scan["reference_index"], scan["offset_index"]
            worst = dict(
                neighbor=well["name"],
                minimum_sf=scan["minimum_sf"],
                reference_relative_md_m=float(query[row]),
                offset_md_m=float(omd[col]),
                centerline_distance_m=scan["centerline_distance_m"],
                combined_error_boundary_m=scan["combined_error_boundary_m"],
                sf_screening=scan["screening"],
                reference_position_m=p[row].tolist(),
                offset_position_m=q[col].tolist(),
            )
            if refine:
                from scipy.optimize import minimize

                # Seed continuous two-MD searches from multiple low grid cells.
                seeds = np.argsort(minimum)[: min(12, len(minimum))]
                for i in seeds:
                    j = int(scan["offset_indices_by_a"][i])
                    bounds = [
                        (query[max(0, i - 1)], query[min(len(query) - 1, i + 1)]),
                        (omd[max(0, j - 1)], omd[min(len(omd) - 1, j + 1)]),
                    ]

                    def value(x):
                        pp, _, _ = path_at(problem, e, np.array([x[0]]))
                        cc = interpolate_cov(
                            covariance["md"], covariance["cov"], np.array([x[0] + start_md])
                        )
                        qq, dd = neighbor_at(well, np.array([x[1]]))
                        return float(
                            pairwise_sf(
                                pp,
                                cc,
                                qq,
                                dd,
                                margin,
                                self.k,
                                self.sigma_pa,
                                sf_method=self.sf_method,
                            )[0][0, 0]
                        )

                    result = minimize(
                        value,
                        [query[i], omd[j]],
                        method="Powell",
                        bounds=bounds,
                        options={"xtol": 1e-6, "ftol": 1e-9, "maxiter": 60},
                    )
                    if result.fun < worst["minimum_sf"]:
                        rp, _, _ = path_at(problem, e, np.array([result.x[0]]))
                        op, oc = neighbor_at(well, np.array([result.x[1]]))
                        rc = interpolate_cov(
                            covariance["md"], covariance["cov"], np.array([result.x[0] + start_md])
                        )
                        boundary_value = pairwise_sf(
                            rp, rc, op, oc, margin, self.k, self.sigma_pa, sf_method=self.sf_method
                        )[2][0, 0]
                        worst.update(
                            minimum_sf=float(result.fun),
                            reference_relative_md_m=float(result.x[0]),
                            offset_md_m=float(result.x[1]),
                            centerline_distance_m=float(np.linalg.norm(op - rp)),
                            combined_error_boundary_m=float(boundary_value),
                            reference_position_m=rp[0].tolist(),
                            offset_position_m=op[0].tolist(),
                        )
            center = next(item for item in centerline if item["neighbor"] == well["name"])
            classification = classify_separation(
                worst["minimum_sf"], center["distance_m"], self.sf_levels, self.centerline_red_m
            )
            center["classification"] = classification
            worst["separation_point_distance_m"] = worst["centerline_distance_m"]
            worst["centerline_distance_m"] = center["distance_m"]
            worst["classification"] = classification
            details.append(worst)
            profiles.append(
                dict(
                    neighbor=well["name"], relative_md_m=query.tolist(), minimum_sf=minimum.tolist()
                )
            )
        center_g = [
            (item["distance_lower_bound_m"] - self.centerline_threshold - self.centerline_buffer)
            / self.centerline_scale
            for item in centerline
        ]
        return dict(
            g=np.r_[constraints, center_g],
            sf_g=np.asarray(constraints),
            centerline_g=np.asarray(center_g),
            sf_constraint_count=len(constraints),
            minimum_sf=min([d["minimum_sf"] for d in details], default=None),
            minimum_centerline_distance_m=min(
                [item["distance_m"] for item in centerline], default=None
            ),
            minimum_centerline_distance_lower_bound_m=min(
                [item["distance_lower_bound_m"] for item in centerline], default=None
            ),
            details=details,
            profiles=profiles,
            measurement_count=covariance["measurement_count"],
            centerline_details=centerline,
            scan_factor=factor,
            covariance=covariance,
            method=f"{covariance['model']} {self.sf_method} SF; independent wells; grid scan with optional continuous local refinement",
        )


__all__ = [
    "SeparationEngine",
    "pointwise_separation_minimum",
    "scalar_pairwise_min",
    "scalar_pair_matrix",
    "pairwise_sf",
]
