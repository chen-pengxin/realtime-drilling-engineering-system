"""Point-pair separation factors, horizontal AABB screening and refinement."""

import time

import numpy as np

from wellpath.anticollision.error_models.md_scalar_radius.model import scalar_radius
from wellpath.anticollision.settings import DEFAULT_K_SIGMA, DEFAULT_SF_METHOD


def pointwise_separation_minimum(
    p,
    q,
    c=None,
    d=None,
    ra=None,
    rb=None,
    margin=0.0,
    k=DEFAULT_K_SIGMA,
    sigma_pa=0.5,
    block_rows=128,
    block_columns=128,
    screening=True,
    sf_method=DEFAULT_SF_METHOD,
):
    """Exact sampled minimum, with horizontal AABB lower bounds for SF pruning.

    Bounds include maximal uncertainty, not just horizontal center distance.
    Therefore a deep, farther pair with a larger radius cannot be discarded.
    """
    timing_start = time.perf_counter()
    screening_seconds = 0.0
    refinement_seconds = 0.0
    p = np.asarray(p, dtype=np.float64)
    q = np.asarray(q, dtype=np.float64)
    if (
        p.ndim != 2
        or q.ndim != 2
        or p.shape[1:] != (3,)
        or q.shape[1:] != (3,)
        or min(len(p), len(q)) == 0
    ):
        raise ValueError("SF scan requires two nonempty N/E/D arrays.")
    if not np.isfinite(p).all() or not np.isfinite(q).all():
        raise ValueError("SF coordinates must be finite.")
    if sf_method not in ("project_rss", "major_axis_sum", "directional_sum"):
        raise ValueError("Unknown sf_method")
    scalar = ra is not None
    if scalar:
        ra = np.asarray(ra)
        rb = np.asarray(rb)
        if ra.shape != (len(p),) or rb.shape != (len(q),):
            raise ValueError("Radius arrays must match trajectory lengths.")
    else:
        c = np.asarray(c)
        d = np.asarray(d)
        if c.shape != (len(p), 3, 3) or d.shape != (len(q), 3, 3):
            raise ValueError("Covariance arrays must match trajectories.")
        eig_p = np.maximum(np.linalg.eigvalsh(c)[:, -1], 0.0)
        eig_q = np.maximum(np.linalg.eigvalsh(d)[:, -1], 0.0)
    best = np.full(len(p), np.inf)
    arg = np.full(len(p), -1, dtype=int)
    block_rows = max(1, int(block_rows))
    block_columns = max(1, int(block_columns))
    columns = []
    for first in range(0, len(q), block_columns):
        last = min(first + block_columns, len(q))
        tile = q[first:last]
        columns.append(
            (
                first,
                last,
                tile.min(axis=0),
                tile.max(axis=0),
                float(np.max(rb[first:last] if scalar else eig_q[first:last])),
            )
        )
    screening_seconds += time.perf_counter() - timing_start
    refined = 0
    box_tests = 0
    for first in range(0, len(p), block_rows):
        last = min(first + block_rows, len(p))
        ids = np.arange(first, last)
        points = p[first:last]
        # Visit geometrically nearby blocks first to establish useful incumbents.
        screen_start = time.perf_counter()
        order = sorted(
            columns,
            key=lambda tile: np.linalg.norm(
                np.maximum(
                    0.0,
                    np.maximum(
                        points.min(axis=0)[:2] - tile[3][:2], tile[2][:2] - points.max(axis=0)[:2]
                    ),
                )
            ),
        )
        screening_seconds += time.perf_counter() - screen_start
        for qfirst, qlast, lo, hi, max_uncertainty in order:
            screen_start = time.perf_counter()
            gap = np.maximum(0.0, np.maximum(lo[:2] - points[:, :2], points[:, :2] - hi[:2]))
            horizontal = np.linalg.norm(gap, axis=1)
            box_tests += len(points)
            upper = (
                ra[ids] + max_uncertainty
                if scalar
                else k * np.sqrt(eig_p[ids] + max_uncertainty + sigma_pa**2)
            )
            if not scalar and sf_method in ("major_axis_sum", "directional_sum"):
                upper = k * (np.sqrt(eig_p[ids]) + np.sqrt(max_uncertainty))
            if scalar and sf_method != "project_rss":
                upper = k * upper
            deduct = margin if not scalar and sf_method == "project_rss" else 0.0
            lower = np.maximum(horizontal - deduct, 0.0) / np.maximum(upper, 1e-14)
            active = np.ones(len(ids), dtype=bool) if not screening else lower <= best[ids] + 1e-12
            selected = ids[active]
            screening_seconds += time.perf_counter() - screen_start
            if not len(selected):
                continue
            refinement_start = time.perf_counter()
            if scalar:
                distance = np.linalg.norm(q[None, qfirst:qlast, :] - p[selected, None, :], axis=2)
                sf = distance / np.maximum(
                    (k if sf_method != "project_rss" else 1.0)
                    * (ra[selected, None] + rb[None, qfirst:qlast]),
                    1e-14,
                )
            else:
                sf, _, _ = pairwise_sf(
                    p[selected],
                    c[selected],
                    q[qfirst:qlast],
                    d[qfirst:qlast],
                    margin,
                    k,
                    sigma_pa,
                    sf_method=sf_method,
                )
            refined += len(selected) * (qlast - qfirst)
            local_j = np.argmin(sf, axis=1)
            local = sf[np.arange(len(selected)), local_j]
            update = local < best[selected]
            best[selected[update]] = local[update]
            arg[selected[update]] = qfirst + local_j[update]
            refinement_seconds += time.perf_counter() - refinement_start
    i = int(np.argmin(best))
    j = int(arg[i])
    distance = float(np.linalg.norm(q[j] - p[i]))
    boundary = (
        float((k if sf_method != "project_rss" else 1.0) * (ra[i] + rb[j]))
        if scalar
        else float(
            pairwise_sf(
                p[i : i + 1],
                c[i : i + 1],
                q[j : j + 1],
                d[j : j + 1],
                margin,
                k,
                sigma_pa,
                sf_method=sf_method,
            )[2][0, 0]
        )
    )
    total = len(p) * len(q)
    elapsed = time.perf_counter() - timing_start
    return dict(
        timing=dict(
            total_seconds=elapsed,
            screening_seconds=screening_seconds,
            refinement_seconds=refinement_seconds,
            control_seconds=max(0.0, elapsed - screening_seconds - refinement_seconds),
        ),
        minimum_sf=float(best[i]),
        minimum_by_a=best,
        offset_indices_by_a=arg,
        reference_index=i,
        offset_index=j,
        centerline_distance_m=distance,
        combined_error_boundary_m=boundary,
        screening=dict(
            enabled=bool(screening),
            total_point_pairs=total,
            evaluated_point_pairs=refined,
            screened_point_pairs=total - refined,
            horizontal_box_tests=box_tests,
        ),
    )


def scalar_pairwise_min(
    points_a,
    md_a,
    points_b,
    md_b,
    settings,
    block_rows=1024,
    settings_b=None,
    screening=True,
    k=DEFAULT_K_SIGMA,
    sf_method=DEFAULT_SF_METHOD,
):
    """Sampled scalar SF minima, using conservative bounds before exact evaluation."""
    md_a = np.asarray(md_a, dtype=np.float64)
    md_b = np.asarray(md_b, dtype=np.float64)
    ra = scalar_radius(md_a, settings)
    rb = scalar_radius(md_b, settings if settings_b is None else settings_b)
    result = pointwise_separation_minimum(
        points_a,
        points_b,
        ra=ra,
        rb=rb,
        block_rows=block_rows,
        screening=screening,
        k=k,
        sf_method=sf_method,
    )
    i = result["reference_index"]
    j = result["offset_index"]
    result.update(
        reference_radius_m=float(ra[i]),
        offset_radius_m=float(rb[j]),
        reference_md_m=float(md_a[i]),
        offset_md_m=float(md_b[j]),
    )
    return result


def scalar_pair_matrix(
    wells, settings, block_rows=1024, k=DEFAULT_K_SIGMA, sf_method=DEFAULT_SF_METHOD
):
    """Minimum SF matrix for every well pair, including diagonal infinity."""
    n = len(wells)
    matrix = np.full((n, n), np.inf, dtype=np.float64)
    details = {}
    for i in range(n):
        for j in range(i + 1, n):
            result = scalar_pairwise_min(
                wells[i]["positions"],
                wells[i]["md"],
                wells[j]["positions"],
                wells[j]["md"],
                wells[i].get("settings", settings),
                block_rows,
                settings_b=wells[j].get("settings", settings),
                k=k,
                sf_method=sf_method,
            )
            matrix[i, j] = matrix[j, i] = result["minimum_sf"]
            details[f"{i},{j}"] = dict(
                (key, value)
                for key, value in result.items()
                if key not in ("minimum_by_a", "offset_indices_by_a")
            )
    return matrix, details


def pairwise_sf(
    p, c, q, d, radii_margin=0.0, k=DEFAULT_K_SIGMA, sigma_pa=0.5, sf_method=DEFAULT_SF_METHOD
):
    """Selectable SF convention; additive methods use no well radius/extra margin."""
    p, c, q, d = [np.asarray(value, dtype=float) for value in (p, c, q, d)]
    delta = q[None, :, :] - p[:, None, :]
    distance = np.linalg.norm(delta, axis=2)
    u = np.divide(
        delta, distance[..., None], out=np.zeros_like(delta), where=distance[..., None] > 1e-14
    )
    if sf_method == "major_axis_sum":
        a = np.sqrt(np.maximum(np.linalg.eigvalsh(c)[:, -1], 0.0))
        b = np.sqrt(np.maximum(np.linalg.eigvalsh(d)[:, -1], 0.0))
        denominator = k * (a[:, None] + b[None, :])
        numerator = distance
    elif sf_method == "directional_sum":
        va = np.maximum(np.einsum("nmi,nij,nmj->nm", u, c, u), 0.0)
        vb = np.maximum(np.einsum("nmi,mij,nmj->nm", u, d, u), 0.0)
        denominator = k * (np.sqrt(va) + np.sqrt(vb))
        numerator = distance
    elif sf_method == "project_rss":
        variance = np.einsum("nmi,nij,nmj->nm", u, c, u) + np.einsum("nmi,mij,nmj->nm", u, d, u)
        denominator = k * np.sqrt(np.maximum(variance, 0) + sigma_pa**2)
        numerator = np.maximum(distance - radii_margin, 0)
    else:
        raise ValueError("sf_method must be project_rss, major_axis_sum or directional_sum")
    sf = numerator / np.maximum(denominator, 1e-14)
    return sf, distance, denominator
