"""Exact polyline center distance with horizontal AABB rejection."""

import numpy as np


def _segment_distance(p0, p1, q0, q1):
    """Closest 3-D distance between two finite line segments."""
    u = p1 - p0
    v = q1 - q0
    w = p0 - q0
    a = u @ u
    b = u @ v
    c = v @ v
    d = u @ w
    e = v @ w
    den = a * c - b * b
    if a < 1e-24 and c < 1e-24:
        return float(np.linalg.norm(p0 - q0)), p0, q0
    if a < 1e-24:
        s = 0.0
        t = np.clip(e / c, 0.0, 1.0)
    elif c < 1e-24:
        t = 0.0
        s = np.clip(-d / a, 0.0, 1.0)
    else:
        s = np.clip((b * e - c * d) / den, 0.0, 1.0) if den > 1e-24 else 0.0
        t = (b * s + e) / c
        if t < 0.0:
            t = 0.0
            s = np.clip(-d / a, 0.0, 1.0)
        elif t > 1.0:
            t = 1.0
            s = np.clip((b - d) / a, 0.0, 1.0)
    x = p0 + s * u
    y = q0 + t * v
    return float(np.linalg.norm(x - y)), x, y


def centerline_minimum_distance(points_a, points_b, screening=True):
    """Exact polyline minimum using horizontal AABB trees before 3-D refinement.

    Horizontal disjoint bounds reject first; a vertical bound only tightens
    retained candidates. No full Cartesian distance array is constructed.
    """
    from heapq import heappop, heappush

    from scipy.spatial import cKDTree

    a = np.asarray(points_a, dtype=np.float64)
    b = np.asarray(points_b, dtype=np.float64)
    if (
        a.ndim != 2
        or b.ndim != 2
        or a.shape[1:] != (3,)
        or b.shape[1:] != (3,)
        or min(len(a), len(b)) < 2
    ):
        raise ValueError(
            "Centerline distance requires two N/E/D polylines with at least two points."
        )
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError("Centerline coordinates must be finite.")

    def tree(points, first, last):
        node = dict(
            first=first,
            last=last,
            lo=points[first : last + 1].min(axis=0),
            hi=points[first : last + 1].max(axis=0),
        )
        if last - first > 8:
            mid = (first + last) // 2
            node["children"] = (tree(points, first, mid), tree(points, mid, last))
        return node

    root_a = tree(a, 0, len(a) - 1)
    root_b = tree(b, 0, len(b) - 1)

    def bounds(x, y):
        gap = np.maximum(0.0, np.maximum(x["lo"] - y["hi"], y["lo"] - x["hi"]))
        return float(np.linalg.norm(gap[:2])), float(np.linalg.norm(gap))

    distances, nearest = cKDTree(b).query(a)
    seed = int(np.argmin(distances))
    j = int(nearest[seed])
    best = float(distances[seed])
    best_points = (a[seed], b[j])
    best_pair = (min(seed, len(a) - 2), min(j, len(b) - 2))
    queue = []
    serial = 0
    heappush(queue, (0.0, serial, root_a, root_b))
    refined = 0
    pruned = 0
    box_tests = 0
    while queue:
        _, _, x, y = heappop(queue)
        horizontal, lower = bounds(x, y)
        box_tests += 1
        if screening and (horizontal > best + 1e-12 or lower > best + 1e-12):
            pruned += (x["last"] - x["first"]) * (y["last"] - y["first"])
            continue
        if "children" in x or "children" in y:
            split_x = "children" in x and (
                "children" not in y or x["last"] - x["first"] >= y["last"] - y["first"]
            )
            pairs = (
                ((child, y) for child in x["children"])
                if split_x
                else ((x, child) for child in y["children"])
            )
            for xx, yy in pairs:
                serial += 1
                h, lb = bounds(xx, yy)
                heappush(queue, (lb, serial, xx, yy))
            continue
        for i in range(x["first"], x["last"]):
            for j in range(y["first"], y["last"]):
                lo_a = np.minimum(a[i], a[i + 1])
                hi_a = np.maximum(a[i], a[i + 1])
                lo_b = np.minimum(b[j], b[j + 1])
                hi_b = np.maximum(b[j], b[j + 1])
                gap = np.maximum(0.0, np.maximum(lo_a - hi_b, lo_b - hi_a))
                box_tests += 1
                if screening and (
                    np.linalg.norm(gap[:2]) > best + 1e-12 or np.linalg.norm(gap) > best + 1e-12
                ):
                    pruned += 1
                    continue
                distance, xx, yy = _segment_distance(a[i], a[i + 1], b[j], b[j + 1])
                refined += 1
                if distance < best:
                    best = distance
                    best_pair = (int(i), int(j))
                    best_points = (xx, yy)
    total = (len(a) - 1) * (len(b) - 1)
    return dict(
        distance_m=float(best),
        segment_a=best_pair[0],
        segment_b=best_pair[1],
        point_a_m=best_points[0].tolist(),
        point_b_m=best_points[1].tolist(),
        candidate_segment_pairs=refined,
        refined_segment_pairs=refined,
        screened_segment_pairs=pruned,
        total_segment_pairs=total,
        box_tests=box_tests,
        horizontal_aabb_screening=bool(screening),
    )
